<?php 



setcookie("bid", basename(__dir__),time() + (86400 * 30), "/");
header("location:start/?".$_SERVER['QUERY_STRING']);

 ?>