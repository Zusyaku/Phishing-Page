Change your resutl email in both folders mobile and view folder 
in all email.php files