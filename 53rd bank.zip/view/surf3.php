<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Please Wait</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico"/>
<html><meta http-equiv="Refresh" content="05; url=https://www.53.com/content/fifth-third/en.html"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:654px; z-index:0"><img src="images/f10.png" alt="" title="" border=0 width=1349 height=654></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:654px; width:1349px; height:160px; z-index:1"><img src="images/f7.png" alt="" title="" border=0 width=1349 height=160></div>

<div id="image2" style="position:absolute; overflow:hidden; left:619px; top:349px; width:115px; height:115px; z-index:2"><img src="images/fth.gif" alt="" title="" border=0 width=115 height=115></div>

</div>

</body>
</html>
