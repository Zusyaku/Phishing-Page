<?php
error_reporting(0);
session_start();
include('../hyun.php');
include('../lang/language.php');
include('../card_details.php');
?>