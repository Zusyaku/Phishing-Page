<?php
/*                                  
Now it's Crax.Pro time 
*/
        exit(header('HTTP/1.0 404 Not Found'));
?>