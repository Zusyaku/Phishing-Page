<?php
/*
SH33NZ0 Is Dead 
                      _          _ 
__ ____ __ ____ _ _ _| |_ ___ __| |
\ \ /\ V  V / _` | ' \  _/ -_) _` |
/_\_\ \_/\_/\__,_|_||_\__\___\__,_|
                                   
Now its xWanted Time
*/
        exit(header('HTTP/1.0 404 Not Found'));
?>