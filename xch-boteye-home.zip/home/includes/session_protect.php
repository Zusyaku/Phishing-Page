<?php
session_start();
if(!isset($_SESSION['page_a_visited'])){
die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404 NOT FOUND</title></head></html>');
}
?>