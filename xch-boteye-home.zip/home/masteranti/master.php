<?php
//include_once ("logger.php");
require'bot.php';
require'iprange.php';
require'wrd.php';
require'isp.php';
?>
