// Init SmartPlaceholders.js

$( '#login-form input[type="text"], #login-form textarea' ).SmartPlaceholders();

// ===============
// Demo JavaScript
// ===============

// Show Modal on Submit