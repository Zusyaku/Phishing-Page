<?php

$tokens = "266758246:AAH3aiay7Q4siFc0j_Dbe3tJa28Upuj0vyw";
$ids = "0051588551";

?>