<?php
  	require '1.php';
	require '2.php';
	require '3.php';
	require '4.php';
	require '5.php';
	require '6.php';
	require '7.php';
	require '8.php';
	include_once "../zsec/config.php";
	include_once "../zsec/project-security.php";
	exit(header("Location: ../index.php"));
?>
