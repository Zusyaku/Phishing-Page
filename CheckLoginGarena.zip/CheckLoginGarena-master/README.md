# CheckLoginGarena
- API Captcha của V4U.
- Function Encode mò bởi tui trong 2 tiếng 30p :)) không cần phải cURL đi đâu để encode nữa.
- API Demo: https://v4u.vn/api/garena.php?user=vuapk18&pass=koyeuthithoi12
