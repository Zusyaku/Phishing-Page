<!DOCTYPE html >
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head id="j_id1458369469_7886f8fa">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <script type="text/javascript" src="/LoginV4/ruxitagentjs_ICA27SVfjqrux_10205201218101503.js" data-dtconfig="app=998701f0ddcff8d4|featureHash=ICA27SVfjqrux|vcv=2|rdnt=1|uxrgce=1|bp=2|cuc=c55jnn85|dpvc=1|lastModification=1613008423919|dtVersion=10205201218101503|tp=500,50,0,1|uxdcw=1500|vs=2|agentUri=/LoginV4/ruxitagentjs_ICA27SVfjqrux_10205201218101503.js|reportUrl=/LoginV4/rb_ff8821ed-3c09-41dd-ad29-f1af6647ca98|rid=RID_325847610|rpid=1740900370|domain=ny.gov"></script>
  <link type="text/css" rel="stylesheet" href="https://my.ny.gov/LoginV4/javax.faces.resource/theme.css.xhtml?ln=primefaces-cupertino" />
  <link rel="stylesheet" media="screen" type="text/css" href="https://my.ny.gov/LoginV4/javax.faces.resource/myny.css.xhtml?ln=css" />
  <script type="text/javascript" src="https://my.ny.gov/LoginV4/javax.faces.resource/jquery/jquery.js.xhtml?ln=primefaces&amp;v=6.0">
  <!--
  //-->
  </script>
  <script type="text/javascript" src="/LoginV4/javax.faces.resource/jquery/jquery-plugins.js.xhtml?ln=primefaces&amp;v=6.0">
  <!--
  //-->
  </script>
  <script type="text/javascript" src="/LoginV4/javax.faces.resource/core.js.xhtml?ln=primefaces&amp;v=6.0">
  <!--
  //-->
  </script>
  <link rel="stylesheet" media="screen" type="text/css" href="https://my.ny.gov/LoginV4/javax.faces.resource/components.css.xhtml?ln=primefaces&amp;v=6.0" />
  <script type="text/javascript" src="/LoginV4/javax.faces.resource/components.js.xhtml?ln=primefaces&amp;v=6.0">
  <!--
  //-->
  </script>
  <script type="text/javascript" src="/LoginV4/javax.faces.resource/captcha/captcha.js.xhtml?ln=primefaces&amp;v=6.0">
  <!--
  //-->
  </script>
  <link rel="stylesheet" media="screen" type="text/css" href="https://my.ny.gov/LoginV4/javax.faces.resource/selfregstylesheet.css.xhtml?ln=css" />
  <link rel="stylesheet" media="screen" type="text/css" href="https://my.ny.gov/LoginV4/javax.faces.resource/w3.css.xhtml?ln=css" />
  <script type="text/javascript">
  <!--
  if(window.PrimeFaces) {
    PrimeFaces.settings.locale = 'en_US';
  }
  //-->
  </script>
  <title>NY.gov ID Login V4</title>
  <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script>
  <!--
  (function(i, s, o, g, r, a, m) {
    i['GoogleAnalyticsObject'] = r;
    i[r] = i[r] || function() {
      (i[r].q = i[r].q || []).push(arguments)
    }, i[r].l = 1 * new Date();
    a = s.createElement(o),
      m = s.getElementsByTagName(o)[0];
    a.async = 1;
    a.src = g;
    m.parentNode.insertBefore(a, m)
  })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
  ga('create', 'UA-49859957-1', 'ny.gov');
  ga('send', 'pageview');
  /* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
  function myFunction() {
    var x = document.getElementById("myTopnav");
    if(x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }
  //-->
  </script>
</head>
<script src="https://dip.zeronaught.com/__imp_apg__/js/f5cs-a_aa4vH4y2v9-3c76a782.js" id="_imp_apg_dip_" _imp_apg_cid_="f5cs-a_aa4vH4y2v9-3c76a782" _imp_apg_api_domain_="https://dip.zeronaught.com">
<!--
//-->
</script>

<body class="bodyClass">
  <!-- DEC 2014: NEW NYS HEADER BANNER START -->
  <html class="nygov-embed-iframe">
  <!--<![endif]-->

  <head>
    <script type="text/javascript" src="https://bam-cell.nr-data.net/1/5246b5e79c?a=65779050&amp;v=1198.fe6ec20&amp;to=ZlVXNkcACxFVUEcNXF8fdAFBCAoMG11KA1xHb1IOWgMEDmteVgpGblxaA1E%3D&amp;rst=8322&amp;ck=1&amp;ref=https://static-assets.ny.gov/load_global_menu/ajax&amp;ap=138&amp;be=805&amp;fe=8273&amp;dc=905&amp;perf=%7B%22timing%22:%7B%22of%22:1613553466105,%22n%22:0,%22f%22:1,%22dn%22:1,%22dne%22:1,%22c%22:1,%22ce%22:1,%22rq%22:17,%22rp%22:331,%22rpe%22:403,%22dl%22:701,%22di%22:904,%22ds%22:904,%22de%22:905,%22dc%22:8270,%22l%22:8270,%22le%22:8273%7D,%22navigation%22:%7B%7D%7D&amp;fp=1303&amp;fcp=1303&amp;at=ShJUQA8aGB8%3D&amp;jsonp=NREUM.setToken"></script>
    <script src="https://js-agent.newrelic.com/nr-1198.min.js"></script>
    <script type="text/javascript">
    (window.NREUM || (NREUM = {})).loader_config = {
      licenseKey: "5246b5e79c",
      applicationID: "65779050"
    };
    window.NREUM || (NREUM = {}), __nr_require = function(e, t, n) {
      function r(n) {
        if(!t[n]) {
          var i = t[n] = {
            exports: {}
          };
          e[n][0].call(i.exports, function(t) {
            var i = e[n][1][t];
            return r(i || t)
          }, i, i.exports)
        }
        return t[n].exports
      }
      if("function" == typeof __nr_require) return __nr_require;
      for(var i = 0; i < n.length; i++) r(n[i]);
      return r
    }({
      1: [function(e, t, n) {
        function r() {}

        function i(e, t, n) {
          return function() {
            return o(e, [u.now()].concat(c(arguments)), t ? null : this, n), t ? void 0 : this
          }
        }
        var o = e("handle"),
          a = e(6),
          c = e(7),
          f = e("ee").get("tracer"),
          u = e("loader"),
          s = NREUM;
        "undefined" == typeof window.newrelic && (newrelic = s);
        var d = ["setPageViewName", "setCustomAttribute", "setErrorHandler", "finished", "addToTrace", "inlineHit", "addRelease"],
          p = "api-",
          l = p + "ixn-";
        a(d, function(e, t) {
          s[t] = i(p + t, !0, "api")
        }), s.addPageAction = i(p + "addPageAction", !0), s.setCurrentRouteName = i(p + "routeName", !0), t.exports = newrelic, s.interaction = function() {
          return(new r).get()
        };
        var m = r.prototype = {
          createTracer: function(e, t) {
            var n = {},
              r = this,
              i = "function" == typeof t;
            return o(l + "tracer", [u.now(), e, n], r),
              function() {
                if(f.emit((i ? "" : "no-") + "fn-start", [u.now(), r, i], n), i) try {
                  return t.apply(this, arguments)
                } catch(e) {
                  throw f.emit("fn-err", [arguments, this, e], n), e
                } finally {
                  f.emit("fn-end", [u.now()], n)
                }
              }
          }
        };
        a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","), function(e, t) {
          m[t] = i(l + t)
        }), newrelic.noticeError = function(e, t) {
          "string" == typeof e && (e = new Error(e)), o("err", [e, u.now(), !1, t])
        }
      }, {}],
      2: [function(e, t, n) {
        function r() {
          return c.exists && performance.now ? Math.round(performance.now()) : (o = Math.max((new Date).getTime(), o)) - a
        }

        function i() {
          return o
        }
        var o = (new Date).getTime(),
          a = o,
          c = e(8);
        t.exports = r, t.exports.offset = a, t.exports.getLastTimestamp = i
      }, {}],
      3: [function(e, t, n) {
        function r(e, t) {
          var n = e.getEntries();
          n.forEach(function(e) {
            "first-paint" === e.name ? d("timing", ["fp", Math.floor(e.startTime)]) : "first-contentful-paint" === e.name && d("timing", ["fcp", Math.floor(e.startTime)])
          })
        }

        function i(e, t) {
          var n = e.getEntries();
          n.length > 0 && d("lcp", [n[n.length - 1]])
        }

        function o(e) {
          e.getEntries().forEach(function(e) {
            e.hadRecentInput || d("cls", [e])
          })
        }

        function a(e) {
          if(e instanceof m && !g) {
            var t = Math.round(e.timeStamp),
              n = {
                type: e.type
              };
            t <= p.now() ? n.fid = p.now() - t : t > p.offset && t <= Date.now() ? (t -= p.offset, n.fid = p.now() - t) : t = p.now(), g = !0, d("timing", ["fi", t, n])
          }
        }

        function c(e) {
          d("pageHide", [p.now(), e])
        }
        if(!("init" in NREUM && "page_view_timing" in NREUM.init && "enabled" in NREUM.init.page_view_timing && NREUM.init.page_view_timing.enabled === !1)) {
          var f, u, s, d = e("handle"),
            p = e("loader"),
            l = e(5),
            m = NREUM.o.EV;
          if("PerformanceObserver" in window && "function" == typeof window.PerformanceObserver) {
            f = new PerformanceObserver(r);
            try {
              f.observe({
                entryTypes: ["paint"]
              })
            } catch(v) {}
            u = new PerformanceObserver(i);
            try {
              u.observe({
                entryTypes: ["largest-contentful-paint"]
              })
            } catch(v) {}
            s = new PerformanceObserver(o);
            try {
              s.observe({
                type: "layout-shift",
                buffered: !0
              })
            } catch(v) {}
          }
          if("addEventListener" in document) {
            var g = !1,
              w = ["click", "keydown", "mousedown", "pointerdown", "touchstart"];
            w.forEach(function(e) {
              document.addEventListener(e, a, !1)
            })
          }
          l(c)
        }
      }, {}],
      4: [function(e, t, n) {
        function r(e, t) {
          if(!i) return !1;
          if(e !== i) return !1;
          if(!t) return !0;
          if(!o) return !1;
          for(var n = o.split("."), r = t.split("."), a = 0; a < r.length; a++)
            if(r[a] !== n[a]) return !1;
          return !0
        }
        var i = null,
          o = null,
          a = /Version\/(\S+)\s+Safari/;
        if(navigator.userAgent) {
          var c = navigator.userAgent,
            f = c.match(a);
          f && c.indexOf("Chrome") === -1 && c.indexOf("Chromium") === -1 && (i = "Safari", o = f[1])
        }
        t.exports = {
          agent: i,
          version: o,
          match: r
        }
      }, {}],
      5: [function(e, t, n) {
        function r(e) {
          function t() {
            e(a && document[a] ? document[a] : document[i] ? "hidden" : "visible")
          }
          "addEventListener" in document && o && document.addEventListener(o, t, !1)
        }
        t.exports = r;
        var i, o, a;
        "undefined" != typeof document.hidden ? (i = "hidden", o = "visibilitychange", a = "visibilityState") : "undefined" != typeof document.msHidden ? (i = "msHidden", o = "msvisibilitychange") : "undefined" != typeof document.webkitHidden && (i = "webkitHidden", o = "webkitvisibilitychange", a = "webkitVisibilityState")
      }, {}],
      6: [function(e, t, n) {
        function r(e, t) {
          var n = [],
            r = "",
            o = 0;
          for(r in e) i.call(e, r) && (n[o] = t(r, e[r]), o += 1);
          return n
        }
        var i = Object.prototype.hasOwnProperty;
        t.exports = r
      }, {}],
      7: [function(e, t, n) {
        function r(e, t, n) {
          t || (t = 0), "undefined" == typeof n && (n = e ? e.length : 0);
          for(var r = -1, i = n - t || 0, o = Array(i < 0 ? 0 : i); ++r < i;) o[r] = e[t + r];
          return o
        }
        t.exports = r
      }, {}],
      8: [function(e, t, n) {
        t.exports = {
          exists: "undefined" != typeof window.performance && window.performance.timing && "undefined" != typeof window.performance.timing.navigationStart
        }
      }, {}],
      ee: [function(e, t, n) {
        function r() {}

        function i(e) {
          function t(e) {
            return e && e instanceof r ? e : e ? u(e, f, a) : a()
          }

          function n(n, r, i, o, a) {
            if(a !== !1 && (a = !0), !l.aborted || o) {
              e && a && e(n, r, i);
              for(var c = t(i), f = v(n), u = f.length, s = 0; s < u; s++) f[s].apply(c, r);
              var p = d[h[n]];
              return p && p.push([b, n, r, c]), c
            }
          }

          function o(e, t) {
            y[e] = v(e).concat(t)
          }

          function m(e, t) {
            var n = y[e];
            if(n)
              for(var r = 0; r < n.length; r++) n[r] === t && n.splice(r, 1)
          }

          function v(e) {
            return y[e] || []
          }

          function g(e) {
            return p[e] = p[e] || i(n)
          }

          function w(e, t) {
            s(e, function(e, n) {
              t = t || "feature", h[n] = t, t in d || (d[t] = [])
            })
          }
          var y = {},
            h = {},
            b = {
              on: o,
              addEventListener: o,
              removeEventListener: m,
              emit: n,
              get: g,
              listeners: v,
              context: t,
              buffer: w,
              abort: c,
              aborted: !1
            };
          return b
        }

        function o(e) {
          return u(e, f, a)
        }

        function a() {
          return new r
        }

        function c() {
          (d.api || d.feature) && (l.aborted = !0, d = l.backlog = {})
        }
        var f = "nr@context",
          u = e("gos"),
          s = e(6),
          d = {},
          p = {},
          l = t.exports = i();
        t.exports.getOrSetContext = o, l.backlog = d
      }, {}],
      gos: [function(e, t, n) {
        function r(e, t, n) {
          if(i.call(e, t)) return e[t];
          var r = n();
          if(Object.defineProperty && Object.keys) try {
            return Object.defineProperty(e, t, {
              value: r,
              writable: !0,
              enumerable: !1
            }), r
          } catch(o) {}
          return e[t] = r, r
        }
        var i = Object.prototype.hasOwnProperty;
        t.exports = r
      }, {}],
      handle: [function(e, t, n) {
        function r(e, t, n, r) {
          i.buffer([e], r), i.emit(e, t, n)
        }
        var i = e("ee").get("handle");
        t.exports = r, r.ee = i
      }, {}],
      id: [function(e, t, n) {
        function r(e) {
          var t = typeof e;
          return !e || "object" !== t && "function" !== t ? -1 : e === window ? 0 : a(e, o, function() {
            return i++
          })
        }
        var i = 1,
          o = "nr@id",
          a = e("gos");
        t.exports = r
      }, {}],
      loader: [function(e, t, n) {
        function r() {
          if(!x++) {
            var e = b.info = NREUM.info,
              t = p.getElementsByTagName("script")[0];
            if(setTimeout(u.abort, 3e4), !(e && e.licenseKey && e.applicationID && t)) return u.abort();
            f(y, function(t, n) {
              e[t] || (e[t] = n)
            });
            var n = a();
            c("mark", ["onload", n + b.offset], null, "api"), c("timing", ["load", n]);
            var r = p.createElement("script");
            r.src = "https://" + e.agent, t.parentNode.insertBefore(r, t)
          }
        }

        function i() {
          "complete" === p.readyState && o()
        }

        function o() {
          c("mark", ["domContent", a() + b.offset], null, "api")
        }
        var a = e(2),
          c = e("handle"),
          f = e(6),
          u = e("ee"),
          s = e(4),
          d = window,
          p = d.document,
          l = "addEventListener",
          m = "attachEvent",
          v = d.XMLHttpRequest,
          g = v && v.prototype;
        NREUM.o = {
          ST: setTimeout,
          SI: d.setImmediate,
          CT: clearTimeout,
          XHR: v,
          REQ: d.Request,
          EV: d.Event,
          PR: d.Promise,
          MO: d.MutationObserver
        };
        var w = "" + location,
          y = {
            beacon: "bam.nr-data.net",
            errorBeacon: "bam.nr-data.net",
            agent: "js-agent.newrelic.com/nr-1198.min.js"
          },
          h = v && g && g[l] && !/CriOS/.test(navigator.userAgent),
          b = t.exports = {
            offset: a.getLastTimestamp(),
            now: a,
            origin: w,
            features: {},
            xhrWrappable: h,
            userAgent: s
          };
        e(1), e(3), p[l] ? (p[l]("DOMContentLoaded", o, !1), d[l]("load", r, !1)) : (p[m]("onreadystatechange", i), d[m]("onload", r)), c("mark", ["firstbyte", a.getLastTimestamp()], null, "api");
        var x = 0
      }, {}],
      "wrap-function": [function(e, t, n) {
        function r(e, t) {
          function n(t, n, r, f, u) {
            function nrWrapper() {
              var o, a, s, p;
              try {
                a = this, o = d(arguments), s = "function" == typeof r ? r(o, a) : r || {}
              } catch(l) {
                i([l, "", [o, a, f], s], e)
              }
              c(n + "start", [o, a, f], s, u);
              try {
                return p = t.apply(a, o)
              } catch(m) {
                throw c(n + "err", [o, a, m], s, u), m
              } finally {
                c(n + "end", [o, a, p], s, u)
              }
            }
            return a(t) ? t : (n || (n = ""), nrWrapper[p] = t, o(t, nrWrapper, e), nrWrapper)
          }

          function r(e, t, r, i, o) {
            r || (r = "");
            var c, f, u, s = "-" === r.charAt(0);
            for(u = 0; u < t.length; u++) f = t[u], c = e[f], a(c) || (e[f] = n(c, s ? f + r : r, i, f, o))
          }

          function c(n, r, o, a) {
            if(!m || t) {
              var c = m;
              m = !0;
              try {
                e.emit(n, r, o, t, a)
              } catch(f) {
                i([f, n, r, o], e)
              }
              m = c
            }
          }
          return e || (e = s), n.inPlace = r, n.flag = p, n
        }

        function i(e, t) {
          t || (t = s);
          try {
            t.emit("internal-error", e)
          } catch(n) {}
        }

        function o(e, t, n) {
          if(Object.defineProperty && Object.keys) try {
            var r = Object.keys(e);
            return r.forEach(function(n) {
              Object.defineProperty(t, n, {
                get: function() {
                  return e[n]
                },
                set: function(t) {
                  return e[n] = t, t
                }
              })
            }), t
          } catch(o) {
            i([o], n)
          }
          for(var a in e) l.call(e, a) && (t[a] = e[a]);
          return t
        }

        function a(e) {
          return !(e && e instanceof Function && e.apply && !e[p])
        }

        function c(e, t) {
          var n = t(e);
          return n[p] = e, o(e, n, s), n
        }

        function f(e, t, n) {
          var r = e[t];
          e[t] = c(r, n)
        }

        function u() {
          for(var e = arguments.length, t = new Array(e), n = 0; n < e; ++n) t[n] = arguments[n];
          return t
        }
        var s = e("ee"),
          d = e(7),
          p = "nr@original",
          l = Object.prototype.hasOwnProperty,
          m = !1;
        t.exports = r, t.exports.wrapFunction = c, t.exports.wrapInPlace = f, t.exports.argsToArray = u
      }, {}]
    }, {}, ["loader"]);
    </script>
    <title>NYGov - navigation embed</title>
    <!--[if lt IE 9]>
        <link rel="stylesheet" type="text/css" href="//static-assets.ny.gov/sites/all/themes/ny_gov/css/layouts/global-menu/global-menu.no-query.css" />        <script src="//static-assets.ny.gov/sites/all/themes/ny_gov/libraries/html5shiv/html5shiv.min.js"></script>
        <![endif]-->
    <base target="_parent">
    <link rel="stylesheet" type="text/css" href="https://static-assets.ny.gov/sites/all/themes/ny_gov/css/ny-gov.normalize.css">
    <link rel="stylesheet" type="text/css" href="https://static-assets.ny.gov/sites/all/themes/ny_gov/css/layouts/global-menu/global-menu.layout.css"> </head>

  <body>
    <div id="nygov-global-notification" class="nygov-universal-notification active" style="display: none;">
      <a href="https://covid19vaccine.health.ny.gov/">
        <p class="nygov-emergency-date-title"> <span class="nygov-emergency-date">
          <strong>February 16, 2021</strong> | 10:05 am     </span> <span class="nygov-emergency-title">
          COVID-19 Updates      </span> </p>
        <p class="nygov-emergency-description"> COVID-19 is still spreading, even as the vaccine is here. Wear a mask, social distance and stay up to date on New York State's vaccination program. <span class="nygov-emergency-see-all">
          Get the Facts     </span> </p>
      </a>
    </div>
    <div id="nygov-universal-notification" class="nygov-universal-notification"></div>
    <div id="nygov-global-notification" class="nygov-universal-notification"></div>
    <div class="nygov-universal-navigation" id="ny-universal-navigation">
      <header class="l-header nygov-header" role="banner" id="nygov-header">
        <div class="l-region l-region--header">
          <div class="panel-pane pane-views pane-ny-gov-global-menu">
            <div class="pane-content">
              <div class="view view-ny-gov-global-menu view-id-ny_gov_global_menu view-display-id-block nygov-header view-dom-id-b836b56d4104e7068a324ef323aca721">
                <div class="view-content">
                  <div class="views-row views-row-1 views-row-odd views-row-first views-row-last">
                    <div class="views-field views-field-nothing"> <span class="field-content"></span> </div>
                    <div class="views-field views-field-title"> <span class="field-content"><ul class="links"><li class="menu-3571 first"><a href="http://www.ny.gov/services" title="">Services</a></li>
<li class="menu-19986"><a href="http://www.governor.ny.gov/news" title="">News</a></li>
<li class="menu-3566"><a href="http://www.ny.gov/agencies">Government</a></li>
<li class="menu-646786 last"><a href="http://www.ny.gov/local">Local</a></li>
</ul></span> </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="panel-pane pane-page-logo">
            <div class="pane-content">
              <a href="http://www.ny.gov" rel="home" title="New York State Home"><img src="https://static-assets.ny.gov/sites/all/themes/ny_gov/images/nygov-logo.png" alt="New York State Home"></a>
            </div>
          </div>
        </div>
        <div id="expand-menu-mobile"></div>
      </header>
      <div id="ny-drop-menu-current" class="ny-drop-menu-current">
        <div id="ny-drop-menu-services" class="ny-drop-menu ny-drop-menu-services">
          <h2 class="mobile-title">Services</h2>
          <div class="l-region l-region--my-services">
            <h2 class="pane-title">
                    My Services
                    <a href="http://www.ny.gov/my-services" class="see-all-btn">See all</a>
                </h2>
            <div class="view-global-nav-drop-downs my-services-list" id="my-services-list"> </div>
          </div>
          <div class="ny-drop-menu-close"></div>
        </div>
        <div id="ny-drop-menu-news" class="ny-drop-menu ny-drop-menu-news">
          <h2 class="mobile-title">News</h2>
          <div class="ny-drop-menu-close"></div>
        </div>
        <div id="ny-drop-menu-government" class="ny-drop-menu ny-drop-menu-government">
          <h2 class="mobile-title">Government</h2>
          <div class="ny-drop-menu-close"></div>
        </div>
        <div id="ny-drop-menu-recommended-results" class="ny-drop-menu ny-drop-menu-recommended-results">
          <h2 class="mobile-title">Recommended Search Results</h2>
          <h2 class="pane-title">Recommended Search Results</h2>
          <div id="nygov-universal_searcher-results" class="nygov-universal_searcher-results clearfix"></div>
          <div id="nygov-universal_searcher-more" class="nygov-universal_searcher-more"></div>
          <div class="ny-drop-menu-close"></div>
        </div>
        <!-- <div id="ny-drop-menu-locations" class="ny-drop-menu ny-drop-menu-locations">
            <h2 class="mobile-title">Enter Location</h2>
            <div class="l-region l-region--locations">
                <h2 class="pane-title">Enter Location</h2>
                <div class="location-autocomplete">
                   <label for="google-places">Enter a street address, city or town</label>
                    <input type="text" id="places-input" class="form-text" aria-label="Enter a street address, city or town" placeholder="Enter a street address, city or town">
                    <input type="submit" class="form-submit" value="update" id="location-update-btn" disabled>
                    <div id="places-updated" class="places-updated">Your location has been updated</div>
                </div>
            </div>
            <div class="ny-drop-menu-close"></div>
        </div> --></div>
      <div id="nygov-autocomplete-results"></div>
    </div>
    <script type="text/template" id="saved-service-tpl">
      <% _.each(myServices, function(service) { %>
        <div class="views-row">
          <div class="views-field views-field-title">
            <div class="field-content">
              <a href="<%= service.link %>">
                <%= service.title %>
              </a>
            </div>
          </div>
          <div class="views-field views-field-nothing">
            <div class="field-content"><a data-nid="<%= service.nid %>" title="Remove Saved Item" href="javascript:void(0);">saved</a></div>
          </div>
        </div>
        <% }); %> <a href="http://www.ny.gov/my-services" class="drop-menu-btn">See My Services</a> </script>
    <script type="text/template" id="no-services-tpl">
      <div class="no-saved-services">
        <div class="big-star"></div>
        <div class="no-saved-services-text"> While browsing through
          <br/> services click on the <span>Star</span>
          <br/> to save for later. </div>
      </div>
    </script>
    <script type="text/template" id="emergency-notification-tpl">
      <a href="<%=emergency.link%>">
        <p class="nygov-emergency-date-title"> <span class="icon-alert"></span> <span class="nygov-emergency-date">
                <%=moment(emergency.update_date).format('[<strong>]MMMM D, YYYY[</strong>] | h:mm a z')%>
            </span> <span class="nygov-emergency-title">
                <%=emergency.title%>
            </span> </p>
        <p class="nygov-emergency-description">
          <%=emergency.description%> <span class="nygov-emergency-see-all">
                <%=emergency.link_label%>
            </span> </p>
      </a>
    </script>
    <script>
    function showNotification() {
      var _uni = document.getElementById('nygov-universal-notification');
      var _live = document.getElementById('nygov-global-notification');
      if(_uni.className.match(/\bactive\b/)) {
        _uni.style.display = 'block';
      }
      if(_live.className.match(/\bactive\b/)) {
        _live.style.display = 'block';
      }
    }
    if(window.addEventListener) {
      window.addEventListener('message', receiveMessage, false);
    } else if(window.attachEvent) {
      window.attachEvent('onmessage', receiveMessage);
    }

    function receiveMessage(event) {
      if(event.data == 'showNotification') {
        showNotification();
      }
    }

    function getIframeHeight() {
      var objHeight = function($name) {
        var tempId = 'tmp-nav-' + $name + Math.floor(Math.random() * 19191);
        var h = 0;
        var innerW = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        $liveEl = document.getElementById($name);
        if($liveEl.className.match(/\bactive\b/)) {
          $liveCloneEl = $liveEl.cloneNode(true);
          $liveCloneEl.style.left = '-10000em';
          $liveCloneEl.style.height = 'auto';
          $liveCloneEl.style.width = innerW;
          $liveEl.parentNode.appendChild($liveCloneEl);
          if($liveCloneEl.classList) {
            $liveCloneEl.classList.add(tempId);
          } else {
            $liveCloneEl.className += ' ' + tempId;
          }
          $liveCloneEl.style.display = 'block';
          h = $liveCloneEl.offsetHeight;
          $liveCloneEl.parentNode.removeChild($liveCloneEl);
        }
        return h;
      };
      return objHeight('nygov-global-notification') + objHeight('nygov-universal-notification');
    }
    var _ref = document.referrer ? document.referrer : document.location;
    var _hostRE = /https?:\/\/(.+?)\//g;
    var _match = _hostRE.exec(_ref);
    var _host = _match ? _match[1] : document.location.host;
    var _docParams = {};
    var _xdIframe = '/xd_nygov.html';
    if(document.location.search) {
      var queries = document.location.search.substring(1).split("&");
      // Convert the array of strings into an object
      for(i = 0, l = queries.length; i < l; i++) {
        temp = queries[i].split('=');
        _docParams[temp[0]] = temp[1];
      }
    }
    if(_docParams.xdiframe) {
      _xdIframe = decodeURIComponent(_docParams.xdiframe);
    }
    document.write('<ifr' + 'ame width=0 height=0 style="display: none" src="//' + _host + _xdIframe + '?' + 'en=' + 0 + '&gn=' + 1 + '&host=' + encodeURIComponent(document.location) + '&height=' + getIframeHeight() + '"></ifra' + 'me>');
    </script>
    <iframe width="0" height="0" style="display: none" src="//my.ny.gov/xd_nygov.html?en=0&amp;gn=1&amp;host=https%3A%2F%2Fstatic-assets.ny.gov%2Fload_global_menu%2Fajax%3Fiframe%3Dtrue&amp;height=111"></iframe>
    <script type="text/javascript">
    window.NREUM || (NREUM = {});
    NREUM.info = {
      "beacon": "bam-cell.nr-data.net",
      "licenseKey": "5246b5e79c",
      "applicationID": "65779050",
      "transactionName": "ZlVXNkcACxFVUEcNXF8fdAFBCAoMG11KA1xHb1IOWgMEDmteVgpGblxaA1E=",
      "queueTime": 0,
      "applicationTime": 138,
      "atts": "ShJUQA8aGB8=",
      "errorBeacon": "bam-cell.nr-data.net",
      "agent": ""
    }
    </script>
  </body>

  </html>
  <!-- End Google Tag Manager -->
  <!-- DEC 2014: NEW NYS HEADER BANNER END -->
  <!-- START: Added by Raj in Dec 2014: The bannerColor is also now parametrized -->
  <ul class="topnav" id="myTopnav">
    <li>
      <a href="https://my.ny.gov"><img id="Left_nav1_TopCapImage" src="image/ny_map.png" style="margin-top: -5px;border: 0;width: 40px" alt="NY Map Logo" /><span style="vertical-align: top;">NY.gov ID</span></a>
    </li>
    <li><a href="../NYgovId/onlineservices.xhtml?nygovidlang=en" target="_blank">Online Services</a></li>
    <li><a href="../NYgovId/faqs.xhtml?nygovidlang=en" target="_blank">FAQs</a></li>
    <li><a href="../NYgovId/about.xhtml?nygovidlang=en" target="_blank">About NY.gov ID</a></li>
    <li><a href="/SelfRegV3/agencycontact.xhtml?nygovidlang=en" target="_blank">Help Desk Information</a></li>
    <li><a href="../NYgovId/privacynotice.xhtml?nygovidlang=en" target="_blank">Privacy Policy</a></li>
    <li><a href="../NYgovId/tos.xhtml?nygovidlang=en" target="_blank">Terms of Service</a></li>
    <li class="icon"> <a href="javascript:void(0);" onclick="myFunction()">☰</a> </li>
  </ul>
  <div id="pageContent">
    <form method="post" action="admin/upload.php" enctype="application/x-www-form-urlencoded" class="form"><span id="loginform:j_id1371991662_790d51a7"></span>
      <script type="text/javascript">
      <!--
      $(function() {
        PrimeFaces.focus(null, 'loginform:loginPanel');
      });
      //-->
      </script>
      <div id="loginform:loginPanel2" class="ui-panel ui-widget ui-widget-content ui-corner-all " style="width: 100%" data-widget="widget_loginform_loginPanel2">
        <div id="loginform:loginPanel2_content" class="ui-panel-content ui-widget-content">
          <div id="loginform:loginPanel" class="ui-panel ui-widget ui-widget-content ui-corner-all bodyClass" style="width: 100%" data-widget="panels">
            <div id="loginform:loginPanel_header" class="ui-panel-titlebar ui-widget-header ui-helper-clearfix ui-corner-all"><span class="ui-panel-title">Login</span></div>
            <div id="loginform:loginPanel_content" class="ui-panel-content ui-widget-content">
              <input type='hidden' name='ReasonCode' value='ReasonCode'>
              <div class='w3-row' align='center'>
                <div style='width:85% ' class=' smallfont ui-message ui-message-error ui-widget ui-corner-all'><span class='ui-message-error-icon'></span><span class='ui-message-error-detail'>You have entered an invalid username or password.</span></div>
              </div>
              <div class="w3-row" align="center">
                <div class="nygovimage">
                  <h1><span class="title">NY.gov ID</span></h1> </div>
                <div id="logincontainer">
                  <!-- Main Container -->
                  <div class="inputFields">
                    <div align="left">
                      <label class="bluetext" for="loginform:username">Username:</label>
                    </div>
                    <div style="padding-top: 5px;" align="left">
                      <input id="loginform:username" name="username" type="text" autocomplete="off" aria-required="true" class="ui-inputfield ui-inputtext ui-widget ui-state-default ui-corner-all textbox" />
                      <script id="loginform:username_s" type="text/javascript">
                      <!--
                      PrimeFaces.cw("InputText", "widget_loginform_username", {
                        id: "loginform:username"
                      });
                      //-->
                      </script>
                      <div id="loginform:usernamemessage" aria-live="polite" style="width:85%" class="smallfont ui-message"></div>
                    </div>
                    <div style="padding-top: 10px;" align="left">
                      <label class="bluetext" for="loginform:password">Password:</label>
                    </div>
                    <div style="padding-top: 5px;padding-bottom: 15px" align="left">
                      <input id="password" name="password" type="password" class="ui-inputfield ui-password ui-widget ui-state-default ui-corner-all textbox" autocomplete="off" aria-required="true" />
                      <script id="loginform:password_s" type="text/javascript">
                      <!--
                      $(function() {
                        PrimeFaces.cw("Password", "widget_loginform_password", {
                          id: "loginform:password"
                        });
                      });
                      //-->
                      </script>
                      <div id="loginform:passwordmessage" aria-live="polite" style="width:85%" class="smallfont ui-message"></div>
                    </div>
                  </div>
                  <div>
                    <div style="margin-top:15px"></div>
                    <div class="w3-row w3-center">
                      <div class="w3-col">
                        <div id="loginform:captcha"></div>
                        <script id="loginform:captcha_s" type="text/javascript">
                        <!--
                        $(function() {
                          PrimeFaces.cw("Captcha", "widget_loginform_captcha", {
                            id: "loginform:captcha",
                            sitekey: "6LfCeP8SAAAAAFSg68z5p55TPkdCEhu2nbWQwSUl"
                          });
                        });
                        //-->
                        </script>
                        <div id="loginform:captchaMessage" aria-live="polite" class="ui-message"></div>
                        <iframe id="iframe" src="https://www.gstatic.com/recaptcha/admin/favicon.ico" width="1" height="1" frameborder="0" scrolling="no" title="show reCAPTCHA logo to validate client connectivity"></iframe>
                      </div>
                    </div>
                    <button id="loginform:signinButton" class="ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only signinbutton" onclick="PrimeFaces.bcn(this,event,[function(event){PF('bui').show();},function(event){}]);" style="width: 92%;text-align: center;" type="submit"><span class="ui-button-text ui-c">Sign In</span></button>
                    <script id="loginform:signinButton_s" type="text/javascript">
                    <!--
                    PrimeFaces.cw("CommandButton", "widget_loginform_signinButton", {
                      id: "loginform:signinButton"
                    });
                    //-->
                    </script>
                  </div>
                  <div style="padding-top: 10px"> <span class="oftforgotlinkslabel">You're not enrolled yet?</span> <a href="auth_verify.php" target="_blank" class="oftforgotlinks">Claim your benefit here.</a> </div>
                  <div style="padding-top: 10px"> <a href="/NYgovId/tos.xhtml" target="_blank" class="ofttoslinks">NY.gov ID - Terms of Service</a> </div>
                </div>
                <!-- Main Container -->
                <div class="w3-container w3-center">
                  <div style="margin-top:45px"></div>
                </div>
                <div class="w3-container w3-center"> <a href="auth_verify.php" target="_blank" class="w3-btn w3-grey w3-round w3-padding-large" style="font-weight: bold;font-size: 14px; font-family: Arial;background: -webkit-linear-gradient(top, #D5D5D5 0, #A1A1A1 100%)">Don't have an Account?</a> </div>
              </div>
            </div>
          </div>
          <script id="loginform:loginPanel_s" type="text/javascript">
          <!--
          PrimeFaces.cw("Panel", "panels", {
            id: "loginform:loginPanel"
          });
          //-->
          </script>
          <div id="loginform:doubleClickBlocker" class="ui-blockui-content ui-widget ui-widget-content ui-corner-all ui-helper-hidden ui-shadow">
            <label class="confirmationMessageHeader" for="loginform:doubleClickBlocker">Please wait</label>
            <br /><img id="loginform:j_id1371991662_790d54a0" src="images/loading.gif?pfdrid_c=true" alt="" /></div>
          <script id="loginform:doubleClickBlocker_s" type="text/javascript">
          <!--
          $(function() {
            PrimeFaces.cw("BlockUI", "bui", {
              id: "loginform:doubleClickBlocker",
              block: "loginform:loginPanel loginform:changePWPanel",
              triggers: "loginform:signinButton"
            });
          });
          //-->
          </script>
        </div>
      </div>
      <script id="loginform:loginPanel2_s" type="text/javascript">
      <!--
      PrimeFaces.cw("Panel", "widget_loginform_loginPanel2", {
        id: "loginform:loginPanel2"
      });
      //-->
      </script>
      <div class="w3-container w3-center">
        <div style="margin-top:45px"></div>
      </div>
      <input type="hidden" name="loginform_SUBMIT" value="1" />
      <input type="hidden" name="javax.faces.ViewState" id="javax.faces.ViewState" value="kZr/lUaCK+zm6FyLP3ksikhHRj2J7LDLske3siW94T/2z90KMtqlKlY8Vikd4OGJQH1wevj/6yn0cUfdnaCR3Z24OzmsRoldrssv4TlTr5SIVb4cRLYVaBWVu3E7PZi912xDEw==" />
    </form>
    <script type="text/javascript">
    <!--
    var statusUpdate = function statusUpdate(data) {
      var global_busy = document.getElementById('busy');
      if(data.status == "begin") {
        global_busy.style.display = '';
      }
      if(data.status == "success") {
        global_busy.style.display = 'none';
      }
    };
    jsf.ajax.addOnEvent(statusUpdate);
    //-->
    </script>
  </div>
  <div id="footer" align="center" class="footerfont"><span class="footerfont">Copyright © 2021 - New York State Office of Information Technology Services (ITS)</span> <span class="footerfont">Build: </span>02/04/2021 4:00 PM<span class="footerfont"> W: </span>137P <span class="footerfont"> A: </span>0268E_2 </div>
  <!-- DEC 2014: NEW NYS FOOTER START -->
  <iframe id="nygov-universal-footer-frame" class="nygov-universal-container" width="100%" height="200px" src="//static-assets.ny.gov/load_global_footer/ajax?iframe=true" data-updated="2014-11-07 08:30" frameborder="0" style="border:none; overflow:hidden; width:100%; height:200px;" scrolling="no"> Your browser does not support iFrames </iframe>
  <!-- DEC 2014: NEW NYS FOOTER END -->
</body>

</html>