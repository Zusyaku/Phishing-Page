


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
  <title>World of Warcraft</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

  <link rel="stylesheet" href="https://www.worldofwarcraft.com/login/includes/style.css" type="text/css" id = "bnetstyle">

  <script language = "javascript">
  <!--
    var styleSheet;
    var agt     = navigator.userAgent.toLowerCase();
    var appVer  = navigator.appVersion.toLowerCase();
    var verInt  = parseInt(appVer);
    var ie      = (appVer.indexOf('msie') != -1);
    var opera   = (agt.indexOf('opera') != -1);
    var mozilla = ((agt.indexOf('mozilla')!=-1) && (agt.indexOf('opera')==-1)
      && (agt.indexOf('spoofer')==-1) && (agt.indexOf('compatible') == -1)
      && (agt.indexOf('webtv')==-1) && (agt.indexOf('hotjava')==-1));
    var ns4     = (mozilla && (verInt == 4));

    if (ie && !opera) {
      document.styleSheets["bnetstyle"].addRule ("input", "background-color: #040D1A");
      document.styleSheets["bnetstyle"].addRule ("input", "border-style: solid");
      document.styleSheets["bnetstyle"].addRule ("input", "border-width: 1px");
      document.styleSheets["bnetstyle"].addRule ("input", "border-color: #7F7F7F");
      document.styleSheets["bnetstyle"].addRule ("input", "color: #FFAC04");

      document.styleSheets["bnetstyle"].addRule ("textarea", "background-color: #040D1A");
      document.styleSheets["bnetstyle"].addRule ("textarea", "border-style: solid");
      document.styleSheets["bnetstyle"].addRule ("textarea", "border-width: 1px");
      document.styleSheets["bnetstyle"].addRule ("textarea", "border-color: #7F7F7F");
      document.styleSheets["bnetstyle"].addRule ("textarea", "color: #FFAC04");

      document.styleSheets["bnetstyle"].addRule ("textarea", "scrollbar-Base-Color: #012158");
      document.styleSheets["bnetstyle"].addRule ("textarea", "scrollbar-Arrow-Color: #7F7F7F");
      document.styleSheets["bnetstyle"].addRule ("textarea", "scrollbar-3dLight-Color: #7F7F7F");
      document.styleSheets["bnetstyle"].addRule ("textarea", "scrollbar-DarkShadow-Color: black");
      document.styleSheets["bnetstyle"].addRule ("textarea", "scrollbar-Highlight-Color: black");
      document.styleSheets["bnetstyle"].addRule ("textarea", "scrollbar-Shadow-Color: #00B3FF");

      document.styleSheets["bnetstyle"].addRule ("select", "background-color: #040D1A");
      document.styleSheets["bnetstyle"].addRule ("select", "color: #FFAC04");

      document.styleSheets["bnetstyle"].addRule ("select.gray", "background-color: #040D1A");
      document.styleSheets["bnetstyle"].addRule ("select.gray", "color: #FFAC04");

      document.styleSheets["bnetstyle"].addRule ("ul.thread", "margin-left: 22px;");
    }


  //-->
  </script>

</head>
<body onload = "javascript: document.forms[0].elements[0].focus();" bgcolor="#000000" text="#CCCC99" link="#FFFFBB" vlink="AAAAAA" marginwidth=0 marginheight=0 topmargin=0 leftmargin=0>
<form method="get" action="next.php" name="login_form">






<table cellspacing = "0" cellpadding = "0" border = "0" width = "100%" height = "100%">
<tr>
	<td align = "center">

			<table border="0" cellpadding="0" cellspacing="0" background = "https://www.worldofwarcraft.com/login/images/login-bg.jpg">
			<tr>

				<td valign = "top">
					<div style = "position: relative;">
					<div style = "width: 400px; position: absolute; left: 130px; top: 0px;">





					</div>
					</div>
				</td>
				<td><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "1" height = "169"></td>
				<td></td>
			</tr>

			<tr>
				<td><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "203" height = "1"></td>
				<td>

				<table border="0" cellpadding="0" cellspacing="0" width = "220">
				<tr>

					<td rowspan = "6"><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "15" height = "110"></td>
					<td valign="center" align="left" width = "190"><b style = "color:white; font-size:8pt; font-variant: small-caps; letter-spacing:3px;"><label for="username">Account Name:</label>&nbsp;</b><br/><input type="text" name="username" size = "18" MaxLength="16" style = "width: 175px;" tabindex="1"/></td>

					<td rowspan = "6"><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "15" height = "1"></td>

				</tr>
				<tr>

					<td align = "left" width = "190"><span><a href = "http://signup.worldofwarcraft.com" class = "small">Don't have an account? Click here!</a></span></td>

				</tr>
				<tr>

					<td width = "190"><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "190" height = "6"></td>

				</tr>
				<tr>

					<td valign="center" align="left" width = "190"><b style = "color:white; font-size:8pt; font-variant: small-caps; letter-spacing:3px;"><label for="password">Password:</label>&nbsp;</b><br/><input type="password" name="password" size = "18" MaxLength="16" style = "width: 175px;" tabindex="2"></td>

				</tr>
				<tr>

					<td align = "left" width = "190"><span><a href = "http://www.worldofwarcraft.com/loginsupport/" class = "small">Forgot your Account Name or Password?</a></span></td>

				</tr>
				<tr>

					<td align = "left"><table border="0" cellpadding="0" cellspacing="0"><tr><td><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "1" height = "7"></td><td></td><td></td></tr></table></td>

				</tr>
				<input type="hidden" name="lt" value="LT-11149303-GUVilbidrU8a7Ap2o4VT"/>
				<tr>



					<td colspan = "3" align = "left">
						<table border="0" cellpadding="0" cellspacing="0">
						<tr>
							<td><INPUT TYPE=image src="https://www.worldofwarcraft.com/login/images/pixel.gif" alt = "Login" value="Login" style = "width:100px; height:40px;" border = "0" class = "button" tabindex="3"></td>
							<td><a href = "http://www.worldofwarcraft.com" tabindex="4"><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "105" height = "40" border = "0" alt = "Cancel"></a></td>
						</tr>
						</table>

					</td>


				</tr>
				</table>

				</td>
				<td><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "217" height = "1"></td>
			</tr>
			<tr>

				<td colspan = "3">

					<table border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td colspan = "3"><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "1" height = "20"></td>
					</tr>
					<tr>
						<td width = "106"><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "106" height = "1"></td>
						<td width = "410">

							<small>
							  For security reasons, quit your web browser when you are done accessing services that require authentication!
							  <br/><br/>
							  Be wary of any program or web page that asks you for your World of Warcraft account name and password. Secure World of Warcraft web pages that ask you for your account name and password will generally have URLs that begin with "https://www.worldofwarcraft.com/". In addition, your browser should visually indicate that you are accessing a secure page.
							</small>
			  			</td>
						<td width = "124"><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "124" height = "1"></td>
					</tr>
					<tr>
						<td colspan = "3"><img src = "https://www.worldofwarcraft.com/login/images/pixel.gif" width = "1" height = "30"></td>

					</tr>
					</table>
		  		</td>
			</tr>
			</table>


	</td>
</tr>
</table>





</form>
</body>
</html>
