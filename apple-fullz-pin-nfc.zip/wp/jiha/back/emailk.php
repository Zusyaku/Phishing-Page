<?php
$send="resulta000@gmail.com";

?>