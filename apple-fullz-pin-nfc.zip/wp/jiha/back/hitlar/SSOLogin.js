$(function () {
    var projects = [];
    var INGIDText = $("#IngIdText").text();
    var CARDText = $("#CardText").text();
    var inputValidate = true;
    var vingid = $("input[id$=ingid]");
    var vcardid = $("input[id$=cardid]");
    var vcardid1 = $("input[id$=cardid1]");
    var vcardid2 = $("input[id$=cardid2]");
    var vcardid3 = $("input[id$=cardid3]");
    var vcardid4 = $("input[id$=cardid4]");
    var vcardid5 = $("input[id$=cardid5]");
    vingid.val(INGIDText);
    vcardid.val(CARDText);
    var isCardIDClicked = false;    
    if ($("#DisplayError").text() == "ErrorOverlay") {
        var triggers = $("#overlay-hb").overlay({
            top: 260,
            mask: {
                color: '#ffffff',
                loadSpeed: 200,
                opacity: 0.9,
                top: 284,
                left: 165

            },
            closeOnClick: false,
            load: true,
            onBeforeLoad: function () {
                var that = this
                $(this.getOverlay()).remove().appendTo("body");
                $(".identtexta_SSOOverlay", this.getOverlay()).click(function (e) {
                    that.close();
                });

            },
            onLoad: function (a) {
                $("#exposeMask").addClass("exposemaskoverlay");

            }

        });

    }
    
    SelectHomeBankSelectionPerSegment();

    $('#btnIdentification').click(function () {
        sendIdentification(isCardIDClicked); return false;
    });
    $('#btnIdentification').dblclick(function () { return false; });
    $('#btnIdentificationReset').click(function () {
        Validated(isCardIDClicked); return false;
    });
    $('#btnIdentificationReset').dblclick(function () { return false; });
    $(".faq_toggle").bind("click", function () {
        $(this).parent().siblings().removeClass("active");
        $(this).parent().toggleClass("active");
        return false;
    });
    vingid.focus(function (e) {
        if (vingid.val() == INGIDText) {
            vingid.val('');

        }
        else {

            var element = document.getElementById('ingid');
            var cursurpoint = getCurrsorPos(element);
            vingid.val(removeSpaces(vingid.val()));
            setCurrsorPosition("ingid", parseInt(cursurpoint));
        }

    });
    vingid.blur(function (e) {
        if (vingid.val() === '' || vingid.val() === INGIDText) {
            vingid.val(INGIDText);
        }
        else {

            if (vingid.val().length >= 8) {
                var ingIDValue = vingid.val();
                if (ingIDValue.indexOf(" ") == -1)
                { vingid.val(ingIDValue.substr(0, 8) + " " + ingIDValue.substr(8, ingIDValue.length)); }
            }
        }
    });


    $("input[id$=cardid], input[id$=ingid]").keydown(function (e) {
        if ($("input[id$=" + this.id + "]").attr('readonly') == "readonly") {
            if (e.which == 8) {
                return false;
            }
        }
    });


    vingid.keyup(function (e) {
        if (vingid.val().length >= 10) {
            vcardid.focus();
            if (vcardid1.val().length > 3)
            { vcardid2.focus(); }
            else
            { vcardid1.focus(); }
        }
    });
    vcardid.focus(function (e) {
        isCardIDClicked = true;
        if (vcardid.val() == CARDText) {
            vcardid.val('');

        }
        if (IsAddCardIDClicked) {
            setNormalBorder('tbCardID');
            $("#CardFour").removeClass("hbbuttondropdownhide");
            vcardid.addClass("hbbuttondropdownhide");
            $("#tbCardID").removeClass("tableselectboxstyle");
            vcardid2.focus();
        }
    });
    $("input[id$=cardid1], input[id$=cardid2], input[id$=cardid3],input[id$=cardid4],input[id$=cardid5]").blur(function (e) {
        showCardIfEmpty()
    });
    $('#pwd').keypress(function (e) {
        if (e.which === 13)
        { return false; }
        var s = String.fromCharCode(e.which);
        if (s.toUpperCase() === s && s.toLowerCase() !== s && !e.shiftKey) {
            $("#caps_lock").removeClass("caps_lock").addClass("showcapslock");
        }
        else {
            $("#caps_lock").removeClass("showcapslock").addClass("caps_lock");
        }
    });


    vcardid1.keyup(function (e) {

        if (vcardid1.val().length >= 4 && e.which !== 8 && !(e.which < 48)) {
            vcardid2.focus();

        }
    });

    vcardid2.keyup(function (e) {
        if (e.which === 8 && vcardid2.val().length === 0) {
            vcardid1.focus().val(vcardid1.val());
        }
        if (vcardid2.val().length >= 4 && e.which !== 8 && !(e.which < 48)) {
            vcardid3.focus();

        }
    });

    vcardid3.keyup(function (e) {
        if (e.which === 8 && vcardid3.val().length === 0) {
            vcardid2.focus().val(vcardid2.val());
        }
        if (vcardid3.val().length == 4 && e.which != 8 && !(e.which < 48)) {
            vcardid4.focus();

        }
    });

    vcardid4.keyup(function (e) {
        if (e.which === 8 && vcardid4.val().length === 0) {
            vcardid3.focus().val(vcardid3.val());
        }
        if (vcardid4.val().length >= 4 && e.which !== 8 && !(e.which < 48)) {
            vcardid5.focus();
        }
    });

    vcardid5.keydown(function (e) {
        if (e.which === 8 && vcardid5.val().length === 0) {
            vcardid4.focus().val(vcardid4.val());
        }
    });


    var CookieInformation;
    if ($("#Phrase").text() != null && $("#Phrase").text() != "") {
        var Value = $("#Phrase").text().split("+");
        for (var i = 0; i < Value.length - 1; i = i + 1) {
            var ckInfo = Value[i].split("-");
            if (i === 0) {
                CookieInformation = { IngId: ckInfo[0].replace(/IngID=/g, ""), CardId: ckInfo[1].replace(/CardID=/g, ""), INGHeader: "ING ID", HomeBankSelection: ckInfo[2] };
            }
            else {
                CookieInformation = { IngId: ckInfo[0].replace(/IngID=/g, ""), CardId: ckInfo[1].replace(/CardID=/g, ""), INGHeader: "", HomeBankSelection: ckInfo[2] };
            }
            projects.push(CookieInformation);
        }

        vingid.removeClass("ingtextinput1").addClass("ingtextinputsearch");
        vcardid.removeClass("ingtextinput1").addClass("ingtextinputsearch");
        $(".hbbuttonDropdown").removeClass("hbbuttondropdownhide");
    }
    else {
        $(".a_SSO1").addClass("fontweightbold");
        IsAddCardIDClicked = true;
        $(".hbbuttonDropdown").addClass("hbbuttondropdownhide");
        vingid.removeClass("ingtextinputsearch").addClass("ingtextinput1"); ;
        vcardid.removeClass("ingtextinputsearch").addClass("ingtextinput1");

    }
    if (projects.length > 0) {

        vingid.attr('readonly', true);
        vcardid.attr('readonly', true);
        var projectsCardID = projects;
        projects.sort(compareIngId);

        $("input[id$=ingid]").autocomplete({
            minLength: 0,
            source: projects,
            focus: function (event, ui) {
                $("input[id$=ingid]").val(ui.item.label);
                return false;
            },
            select: function (event, ui) {
                if (ui.item.IngId != null) {
                    vingid.val(ui.item.IngId);
                    vcardid.val(ui.item.CardId);
                    if ($('input:radio[name=version]').length != 0) {
                        if (ui.item.HomeBankSelection == "01") {
                            $('input:radio[name=version]')[0].checked = true;
                            $("input[name='logonType']").val("01");
                        } else {
                            $('input:radio[name=version]')[1].checked = true;
                            $("input[name='logonType']").val("02");
                        }
                    }
                    $("input#saveCheckbox").attr('checked', true);
                    $("input[id$=pwd]").val("");
                    FilterTheDataSourceOfCard("INGID", projectsCardID);

                }
                return false;
            },
            search: function (event, ui) {
                return true;
            },
            open: function (event, ui) {
                $("<br /><li align='center' class='addIngID' ><div class='addIngIDL'></div><div class='k2BtnM' style='width: 150px;'><span class='k2BtnIcon_popup'> " + $("#AddINGID").text() + " </span></div><div class='k2BtnR'></div></li>").appendTo($("input[id$=ingid]").autocomplete("widget"));
            }
        })
		.data("autocomplete")._renderItem = function (ul, item) {

		    return $("<li  class='ldropdown'></li>")
				.data("item.autocomplete", item)
				.append("<a> <table border=0><tr><td> ING ID: </td><td>&nbsp" + item.IngId + "</td><tr><td> Card ID: </td><td> &nbsp" + item.CardId + "</td></a>")
				.appendTo(ul);
		};


        //auto complete for the card ID
        projectsCardID.sort(compareCardId);
        var ArrayCardID = [];
        for (var i = 0; i <= projectsCardID.length - 1; i = i + 1) {
            if (projectsCardID[i].IngId == $("#BBLLastUsedIngId").text()) {
                ArrayCardID.push(projectsCardID[i]);
            }
        }
        if (ArrayCardID.length > 0) {
            ArrayCardID[0].INGHeader = "Card ID";
        }
        $("input[id$=cardid]").autocomplete({
            minLength: 0,
            source: ArrayCardID,
            focus: function (event, ui) {
                $("input[id$=cardid]").val(ui.item.label);
                return false;
            },
            select: function (event, ui) {
                if (ui.item.IngId != null) {
                    vingid.val(ui.item.IngId);
                    vcardid.val(ui.item.CardId);
                    if ($('input:radio[name=version]').length != 0) {
                        if (ui.item.HomeBankSelection == "01") {
                            $('input:radio[name=version]')[0].checked = true;
                            $("input[name='logonType']").val("01");
                        } else {
                            $('input:radio[name=version]')[1].checked = true;
                            $("input[name='logonType']").val("02");
                        }
                    }
                    $("input#saveCheckbox").attr('checked', true);
                    $("input[id$=pwd]").val("");
                }
                return false;
            },
            search: function (event, ui) {
                return true;
            },
            open: function (event, ui) {
                $("<br /><li  align='center' class='ShowAll' ><img  class='imageShowHideAll'  src='/_LAYOUTS/ING_K2/IMAGES/SSO/downArrow.gif'  /><a id='showAll' class='adropdown'>" + $("#ShowAll").text() + "</a></li><li align='center' style='background-color: #ebebeb; height:30px;width:236px; padding:2px;margin-bottom:-2px;margin-left:-2px;' class='k2BtnGrey30px disablecardid' ><div class='addIngIDL'></div><div class='k2BtnM' style='width: 150px;'><span class='k2BtnIcon_popup'> " + $("#AddCardID").html() + "  </span></div><div class='k2BtnR'></div></li>").appendTo($("input[id$=cardid]").autocomplete("widget"));
            }
        })
		.data("autocomplete")._renderItem = function (ul, item) {
		    if (item.INGHeader != "") {
		        ul.append("<li style='background-color: #ebebeb; padding: 3px; text-align:center;width:236px;'>" + $("#CardIDLinkedToINGID").html() + "</li>");

		    }
		    return $("<li  class='ldropdown'></li>")
				.data("item.autocomplete", item)
				.append("<a> <table border=0><tr><td> ING ID: </td><td>&nbsp" + item.IngId + "</td><tr><td> Card ID: </td><td> &nbsp" + item.CardId + "</td></a>")
				.appendTo(ul);
		};

    }
    else {

    }

    CheckErrors();
    $(".inner").corner("round 7px").parent().css('padding', '1px').corner("round 7px");
    var BBLLastUsedIngId = $("#BBLLastUsedIngId");
    var BBLLastUsedCardNr = $("#BBLLastUsedCardNr");
    if (BBLLastUsedIngId.text() != null && BBLLastUsedIngId.text() != "") {
        vingid.val(BBLLastUsedIngId.text());
        $("input#saveCheckbox").attr('checked', true);
    }

    if (BBLLastUsedCardNr.text() != null && BBLLastUsedCardNr.text() != "") {
        vcardid.val(BBLLastUsedCardNr.text());
        UpdateCardIDValues();
    }

    if (BBLLastUsedIngId.text() != null && BBLLastUsedIngId.text() != "" && BBLLastUsedCardNr.text() != null && BBLLastUsedCardNr.text() != "" && $("#Phrase").text() != null && $("#Phrase").text() != "" && $('input:radio[name=version]').length > 0) {

        var homeBankSelection = BBLLastUsedIngId.text() + "-" + BBLLastUsedCardNr.text() + "-02";
        if ($("#Phrase").text().indexOf(homeBankSelection) > -1) {
            $('input:radio[name=version]')[1].checked = true;
            $("input[name='logonType']").val("02");
        } else {
            $('input:radio[name=version]')[0].checked = true;
            $("input[name='logonType']").val("01");
        }

    }

    $("#showAll").live("click", function () { UpdateDataSourceofCard(projectsCardID); });

    $("#Hideall").live("click", function () { FilterTheDataSourceOfCard('CardID', projectsCardID); });

    $(".disablecardid").live("click", function () { DisableAutoComplete('cardid', isCardIDClicked); });

    $(".addIngID").live("click", function () { DisableAutoComplete('ingid', isCardIDClicked); });

});

function SelectHomeBankSelectionPerSegment() {
    if ($('input:radio[name=version]').length > 0) {
        if (ING.K2.Context.Current.Segment.toLowerCase() == "business") {
            $('input:radio[name=version]')[1].checked = true;
        }
        else {
            $('input:radio[name=version]')[0].checked = true;
        }
    }

}


function UpdateDataSourceofCard(projectCardInfo) {
    var projectsCardID = [];
    projectsCardID = projectCardInfo;
    $("input[id$=cardid]").autocomplete("destroy");
    $("input[id$=cardid]").autocomplete({
        minLength: 0,
        source: projectsCardID,
        focus: function (event, ui) {
            $("input[id$=cardid]").val(ui.item.label);
            return false;
        },
        select: function (event, ui) {
            if (ui.item.IngId != null) {
                $("input[id$=ingid]").val(ui.item.IngId);
                $("input[id$=cardid]").val(ui.item.CardId);
                if ($('input:radio[name=version]').length != 0) {
                    if (ui.item.HomeBankSelection == "01") {
                        $('input:radio[name=version]')[0].checked = true;
                        $("input[name='logonType']").val("01");
                    } else {
                        $('input:radio[name=version]')[1].checked = true;
                        $("input[name='logonType']").val("02");
                    
                    } 
                }
                $("input#saveCheckbox").attr('checked', true);
                $("input[id$=pwd]").val("");
            }
            return false;
        },
        search: function (event, ui) {
            return true;
        },
        open: function (event, ui) {
            $("<br /><li  align='center' class='ShowAll' ><img  class='imageShowHideAll'  src='/_LAYOUTS/ING_K2/IMAGES/SSO/upArrow.gif'  /><a class='adropdown' id='Hideall' >" + $("#Hide").text() + "</a></li><li align='center' style='background-color: #ebebeb; height:30px; width:236px; padding:2px;margin-bottom:-2px;margin-left:-2px;' class='k2BtnGrey30px disablecardid' ><div class='addIngIDL'></div><div class='k2BtnM' style='width: 150px;'><span class='k2BtnIcon_popup'> " + $("#AddCardID").html() + "  </span></div><div class='k2BtnR'></div></li>").appendTo($("input[id$=cardid]").autocomplete("widget"));
        }
    })
		.data("autocomplete")._renderItem = function (ul, item) {

		    return $("<li  class='ldropdown'></li>")
				.data("item.autocomplete", item)
				.append("<a> <table border=0><tr><td> ING ID: </td><td>&nbsp" + item.IngId + "</td><tr><td> Card ID: </td><td> &nbsp" + item.CardId + "</td></a>")
				.appendTo(ul);
		};

    autocompleteTag_onDropdownClick('cardid');
}

function FilterTheDataSourceOfCard(RequestType, projectCardInfo) {
    var ArrayCardID = [];
    var projectsCardID = [];
    projectsCardID = projectCardInfo;
    var ingID = removeSpaces($("input[id$=ingid]").val());
    for (var i = 0; i <= projectsCardID.length - 1; i = i + 1) {
        if (projectsCardID[i].IngId == ingID) {
            ArrayCardID.push(projectsCardID[i]);
        }
    }
    if (ArrayCardID.length > 0) {
        ArrayCardID[0].INGHeader = "Card ID";
    }
    $("input[id$=cardid]").autocomplete("destroy");

    $("input[id$=cardid]").autocomplete({
        minLength: 0,
        source: ArrayCardID,
        focus: function (event, ui) {
            $("input[id$=cardid]").val(ui.item.label);
            return false;
        },
        select: function (event, ui) {
            if (ui.item.IngId != null) {
                $("input[id$=ingid]").val(ui.item.IngId);
                $("input[id$=cardid]").val(ui.item.CardId);
                if ($('input:radio[name=version]').length != 0) {
                    if (ui.item.HomeBankSelection == "01") {
                        $('input:radio[name=version]')[0].checked = true;
                        $("input[name='logonType']").val("01");
                    } else {
                        $('input:radio[name=version]')[1].checked = true;
                        $("input[name='logonType']").val("02");
                    } 
                }
                $("input#saveCheckbox").attr('checked', true);
                $("input[id$=pwd]").val("");
            }
            return false;
        },
        search: function (event, ui) {
            return true;
        },
        open: function (event, ui) {
            $("<br /><li align='center' class='ShowAll' ><img  class='imageShowHideAll'  src='/_LAYOUTS/ING_K2/IMAGES/SSO/downArrow.gif'  /><a id='showAll' class='adropdown' >" + $("#ShowAll").text() + "</a></li><li align='center' style='background-color: #ebebeb; height:30px; width:236px; padding:2px;margin-bottom:-2px;margin-left:-2px;' class='k2BtnGrey30px disablecardid' ><div class='addIngIDL'></div><div class='k2BtnM' style='width: 150px;'><span class='k2BtnIcon_popup'> " + $("#AddCardID").html() + "  </span></div><div class='k2BtnR'></div></li>").appendTo($("input[id$=cardid]").autocomplete("widget"));
        }
    })
		.data("autocomplete")._renderItem = function (ul, item) {
		    if (item.INGHeader != "") {
		        ul.append("<li style='background-color: #ebebeb;  padding: 3px; text-align:center;width:236px;'>" + $("#CardIDLinkedToINGID").html() + "</li>");

		    }
		    return $("<li class='ldropdown'></li>")
				.data("item.autocomplete", item)
				.append("<a> <table border=0><tr><td> ING ID: </td><td>&nbsp" + item.IngId + "</td><tr><td> Card ID: </td><td> &nbsp" + item.CardId + "</td></a>")
				.appendTo(ul);
		};

    if (RequestType != "INGID") {
        autocompleteTag_onDropdownClick('cardid');
    }
}

function compareIngId(a, b) {
    return a.IngId - b.IngId;
}
function compareCardId(a, b) {
    return a.CardId - b.CardId;
}

function removeSpaces(string) {
    return string.replace(/\s/g, "");
}


function CheckErrors() {
    if ($("#DisplayError").text() == "ErrorBlock") {
        if ($("#sErrrorDescription").text() == "") {
            $("#inputDocumentErrorBox").addClass("inputdocumenterrorboxstyleshow");
        }
        else {
            $("#inputDocumentErrorBox1").addClass("inputdocumenterrorboxstyleshow");
            $("#inputDocumentErrorBox").removeClass("inputdocumenterrorboxstyleshow");
            $("#CustomErrorTitle").html($("#sErrrorDescription").text());            
            $("#inputDocument_ErrorBoxTitle1").addClass("hidecontent");
            $("#CustomErrorTitle").addClass("showcontent");
        }

    }
   
}

function getCurrsorPos(el) {
    if (typeof el.selectionStart != "undefined")
        return el.selectionStart;
    else if (document.selection)
        return Math.abs(document.selection.createRange().moveStart("character", -1000000));
}

function setCurrsorPosition(elemId, caretPos) {
    var elem = document.getElementById(elemId);
    if (elem != null) {
        if (elem.createTextRange) {
            var range = elem.createTextRange();
            range.move('character', caretPos);
            range.select();
        }
        else {
            if (elem.selectionStart) {
                elem.focus();
                elem.setSelectionRange(caretPos, caretPos);
            }
            else
                elem.focus();
        }
    }
}

function numbersOnly(e, id) {
    if (e.which == 13 && id != 'txtIdentification')
    { return false; }
    var key;
    var keychar;
    if (window.event) {
        key = window.event.keyCode;
    }
    else if (e) {
        key = e.which;
    } else {
        return true;
    }
    if (key == 13 && id == 'txtIdentification') {
        $("#btnIdentification").click();
        return false;
    }
    keychar = String.fromCharCode(key);
    var arrnumbers = [null, 0, 8, 9, 13, 27];
    if (jQuery.inArray(key, arrnumbers) > -1) {
        return true;
    }
    else if ((("0123456789").indexOf(keychar) > -1)) {
        return true;
    }
    else {
        return false;
    }
}

function AddNumbers(Number) {
    var i = 0;
    var count = 0;

    for (i; i <= Number.length - 1; i = i + 1) {
        count = count + parseInt(Number.substring(i, i + 1));
    }

    return count;
}
function ValidateCardID() {
    var vcardid = $("input[id$=cardid]");
    var vcardid1 = $("input[id$=cardid1]");
    var vcardid2 = $("input[id$=cardid2]");
    var vcardid3 = $("input[id$=cardid3]");
    var vcardid4 = $("input[id$=cardid4]");
    var vcardid5 = $("input[id$=cardid5]");
    if (IsAddCardIDClicked) {
        var isCardIDValid = true;
        if (vcardid1.val().length != 4) {
            $("#inputDocumentErrorBox").addClass("inputdocumenterrorboxstyleshow");
            if (vcardid1.val() == "") {
                setRedBorder('cardid1');
            } else { setNormalBorder1('cardid1'); }
            isCardIDValid = false;
            setNormalBorder('tbCardID');
        }
        else { setNormalBorder1('cardid1'); }
        if (vcardid2.val().length != 4) {
            $("#inputDocumentErrorBox").addClass("inputdocumenterrorboxstyleshow");
            if (vcardid2.val() == "") {
                setRedBorder('cardid2');
            } else { setNormalBorder1('cardid2'); }
            isCardIDValid = false;
            setNormalBorder('tbCardID');
        }
        else { setNormalBorder1('cardid2'); }
        if (vcardid3.val().length != 4) {
            $("#inputDocumentErrorBox").addClass("inputdocumenterrorboxstyleshow");
            if (vcardid3.val() == "") {
                setRedBorder('cardid3');
            } else { setNormalBorder1('cardid3'); }
            isCardIDValid = false;
            setNormalBorder('tbCardID');
        }
        else { setNormalBorder1('cardid3'); }

        if (vcardid4.val().length != 4) {
            $("#inputDocumentErrorBox").addClass("inputdocumenterrorboxstyleshow");
            if (vcardid4.val() == "") {
                setRedBorder('cardid4');
            } else { setNormalBorder1('cardid4'); }
            isCardIDValid = false;
            setNormalBorder('tbCardID');
        }
        else { setNormalBorder1('cardid4'); }

        if (vcardid5.val() == "") {
            $("#inputDocumentE rrorBox").addClass("inputdocumenterrorboxstyleshow");
            setRedBorder('cardid5');
            setNormalBorder('tbCardID');
        }
        else { setNormalBorder1('cardid5'); }
        if (vcardid1.val() + vcardid2.val() + vcardid3.val() + vcardid4.val() + vcardid5.val() != "") {
            vcardid.val(vcardid1.val() + vcardid2.val() + vcardid3.val() + vcardid4.val() + vcardid5.val());
        } else { vcardid.val($("#CardText").text()); }
    }
    else {
        return true;
    }
}

var IsAddCardIDClicked = false;
function DisableAutoComplete(id, isCardIDClicked) {
    var vcardid = $("input[id$=cardid]");
    var vingid = $("input[id$=ingid]");
    //Unchecking the check box
    $("input[id$=txtIdentification]").val("");
    $("input#saveCheckbox").attr('checked', false);
    vingid.attr('readonly', false);
    vcardid.attr('readonly', false);
    $("input[id$=" + id + "]").autocomplete("close");
    $("input[id$=" + id + "]").autocomplete("disable");
    $("input[id$=pwd]").val("");
    if (id == "ingid") {
        vingid.val("");
        vcardid.val($("#CardText").text());
        $("input[id$=" + id + "]").focus();
    }
    else {
        isCardIDClicked = true;
        $("input[id$=cardid]").focus();
        setNormalBorder('tbCardID');
        $("#CardFour").removeClass("hbbuttondropdownhide");
        vcardid.addClass("hbbuttondropdownhide");
        $("#tbCardID").removeClass("tableselectboxstyle");
        $("input[id$=cardid2]").focus();

    }

    IsAddCardIDClicked = true;
    $("input[id$=cardid1]").val("");
    $("input[id$=cardid2]").val("");
    $("input[id$=cardid3]").val("");
    $("input[id$=cardid4]").val("");
    $("input[id$=cardid5]").val("");
    $(".hbbuttonDropdown").addClass("hbbuttondropdownhide");
    SelectHomeBankSelectionPerSegment();
}

function autocompleteTag_onDropdownClick(id) {
    $("input[id$=" + id + "]").autocomplete('search', '');
    $("input[id$=" + id + "]").focus();
}

function setNormalBorder1(id) {
    element = document.getElementById(id);
    element.style.border = '1px solid #ccc';

}
function setNormalBorder(id) {
    element = document.getElementById(id);
    element.style.border = '0px solid #ccc';

}

function setRedBorder(id) {
    element = document.getElementById(id);
    element.style.border = '2px solid #ff0000';
}

function UpdateRadioButtonInfo(selectedValue) {
    if (selectedValue == "Home'Bank plus") {
        $("input[name='logonType']").val("02");
    }
    else if (selectedValue == "Home'Bank") {
        $("input[name='logonType']").val("01");
    }
}

function ShowPicture(id, Source) {
    if (Source == "1") {
        if (document.layers) document.layers['' + id + ''].visibility = "show"
        else if (document.all) document.all['' + id + ''].style.visibility = "visible"
        else if (document.getElementById) document.getElementById('' + id + '').style.visibility = "visible"
    }
    else
        if (Source == "0") {
            if (document.layers) document.layers['' + id + ''].visibility = "hide"
            else if (document.all) document.all['' + id + ''].style.visibility = "hidden"
            else if (document.getElementById) document.getElementById('' + id + '').style.visibility = "hidden"
        }
}
function validateINGID() {
    var InputValue = $("input[id$=ingid]").val().replace(/\s/g, "");
    var LastChar = InputValue.substr(InputValue.length - 2);
    InputValue = InputValue.substring(0, InputValue.length - 2);
    if (LastChar == 97) { LastChar = 0; }
    if ((LastChar == (InputValue - (Math.floor(InputValue / 97)) * 97)) && parseInt(InputValue) != "NaN") {
        return true;
    }
    else { return false; }
}

function SaveCurrentValuesToCookies(anchorType) {
    var vcardid = $("input[id$=cardid]");
    var vcardid1 = $("input[id$=cardid1]");
    var vcardid2 = $("input[id$=cardid2]");
    var vcardid3 = $("input[id$=cardid3]");
    var vcardid4 = $("input[id$=cardid4]");
    var vcardid5 = $("input[id$=cardid5]");
    var param = GetQueryStringValue('URL');
    if (param.indexOf('HP') != -1) {
        ShowOverlayForHomepay(anchorType);
    }
    if (IsAddCardIDClicked) {
        if (vcardid1.val() + vcardid2.val() + vcardid3.val() + vcardid4.val() + vcardid5.val() != "") {
            vcardid.val(vcardid1.val() + vcardid2.val() + vcardid3.val() + vcardid4.val() + vcardid5.val());
        }
    }

    if (($("input[id$=ingid]").val() != $("#IngIdText").html()) && ($("input[id$=ingid]").val() != "")) {

        setCookie("SSOCookieCurrentINGID", $("input[id$=ingid]").val(), 365);
    }
    else {

        setCookie("SSOCookieCurrentINGID", "", 365);
    }
    if (($("input[id$=cardid]").val() != $("#CardText").html()) && ($("input[id$=cardid]").val() != "")) {

        setCookie("SSOCookieCurrentCardID", $("input[id$=cardid]").val(), 365);
    }
    else {
        setCookie("SSOCookieCurrentCardID", "", 365);

    }
}

function ShowOverlayForHomepay(anchorType) {
    $("#newPasswordTitle").addClass("hidecontent");
    $("#forgotPasswordTitle").addClass("hidecontent");
    $("#newPasswordDescription").addClass("hidecontent");
    $("#forgotPasswordDescription").addClass("hidecontent");
    $("#CustomErrorTitle").addClass("showcontent");
    if (anchorType == "New") {
        $("a[id$=A1]").attr("href", $("a[id$=aNewPassword]").attr("href"));
        $("a[id$=aNewPassword]").attr("href", "#");
        $("#newPasswordTitle").addClass("showcontent");
        $("#newPasswordDescription").addClass("showcontent");
        $("#forgotPasswordTitle").removeClass("showcontent");
        $("#forgotPasswordDescription").removeClass("showcontent");
    }
    else {
        $("a[id$=A1]").attr("href", $("a[id$=aForgotPassword]").attr("href"));
        $("a[id$=aForgotPassword]").attr("href", "#");
        $("#forgotPasswordTitle").addClass("showcontent");
        $("#forgotPasswordDescription").addClass("showcontent");
        $("#newPasswordTitle").removeClass("showcontent");
        $("#newPasswordDescription").removeClass("showcontent");
    }
    document.getElementById('modalShowConfirmation').click();

}

function AddZeroToINGID(strINGID) {
    return "0" + strINGID;
}

function GetINGIDWithZero(strINGID) {
    if (strINGID.length < 10) {
        strINGID = AddZeroToINGID(strINGID);
        strINGID = GetINGIDWithZero(strINGID);
    }

    return strINGID;

}
function setCookie(c_name, value, exdays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + exdays);
    var c_value = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toUTCString() + ";path=/");
    document.cookie = c_name + "=" + c_value;
}

function getCookie(c_name) {
    var i, x, y, ARRcookies = document.cookie.split(";");
    for (i = 0; i < ARRcookies.length; i++) {
        x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
        y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
        x = x.replace(/^\s+|\s+$/g, "");
        if (x == c_name) {
            return unescape(y);
        }
    }
    return "";
}

function showCardIfEmpty() {
    var vcardid = $("input[id$=cardid]");
    var focusedElementID = document.activeElement.id;
    if (navigator.appName == "Microsoft Internet Explorer") {
        if (focusedElementID == "cardid1" || focusedElementID == "cardid2" || focusedElementID == "cardid3" || focusedElementID == "cardid4" || focusedElementID == "cardid5") {

        }
        else {
            if ($("input[id$=cardid1]").val() + $("input[id$=cardid2]").val() + $("input[id$=cardid3]").val() + $("input[id$=cardid4]").val() + $("input[id$=cardid5]").val() == "") {
                $("#tbCardID").addClass("tableselectboxstyle");
                $("#CardFour").addClass("hbbuttondropdownhide");
                vcardid.removeClass("hbbuttondropdownhide");
                vcardid.val($("#CardText").html());
                setNormalBorder1('tbCardID');
            }
            else {
                $("#tbCardID").addClass("tableselectboxstyle");
                $("#CardFour").addClass("hbbuttondropdownhide");
                vcardid.removeClass("hbbuttondropdownhide");
                vcardid.val($("input[id$=cardid1]").val() + $("input[id$=cardid2]").val() + $("input[id$=cardid3]").val() + $("input[id$=cardid4]").val() + $("input[id$=cardid5]").val());
                setNormalBorder1('tbCardID');
            }
        }
    }

    //}

}

function UpdateCardIDValues() {
    var vcardid = $("input[id$=cardid]");
    $("input[id$=cardid1]").val(vcardid.val().substring(0, 4));
    $("input[id$=cardid2]").val(vcardid.val().substring(4, 8));
    $("input[id$=cardid3]").val(vcardid.val().substring(8, 12));
    $("input[id$=cardid4]").val(vcardid.val().substring(12, 16));
    $("input[id$=cardid5]").val(vcardid.val().substring(16, 17));
}

function GetNumberCountForOdd(Number) {
    var i = 0;
    var count = 0;

    for (i; i <= Number.length - 1; i = i + 2) {
        count = count + parseInt(Number.substring(i, i + 1));
    }

    return count;
}

function GetNumberCountForEven(Number) {
    var i = 1;
    var count = 0;
    var luhnValue;
    var value;
    for (i; i <= Number.length - 1; i = i + 2) {
        luhnValue = 2 * Number.substring(i, i + 1)
        if (luhnValue.toString().length = 2) {
            value = AddNumbers(luhnValue.toString());
        }
        else {
            value = luhnValue;
        }
        count = count + parseInt(value);
    }

    return count;
}

function GetQueryStringValue(name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.href);
    if (results == null)
        return "";
    else
        return results[1];
}

function numberpadleft(nr, n, str) { return Array(n - String(nr).length + 1).join(str || '0') + nr; }

function CurrentDateTime() {
    now = new Date();
    year = "" + now.getFullYear();
    month = (now.getMonth() + 1); month = numberpadleft(month, 2, "0");
    day = now.getDate(); day = numberpadleft(day, 2, "0");
    hour = now.getHours(); hour = numberpadleft(hour, 2, "0");
    minute = now.getMinutes(); minute = numberpadleft(minute, 2, "0");
    return year + "/" + month + "/" + day + " " + hour + ":" + minute;

}
