var Framework = function () {
    "use strict";

    /// <summary>Namespace for Framework</summary>
    /// <returns type="Object">Framework object</returns>

    ///<value type="Object">Object for Public functions</value>
    var expose = {};

    expose.ensure = function (name) {
        /// <summary>Creates a namespace tree form a given string</summary>
        ///<example>
        ///<code>
        ///Framework.ensure("ING.Array");
        ///ING.Array.Push = function()...
        ///</code>
        ///</example>
        /// <param name="name" type="String">namespace tree that you want to create</param>

        var parts = name.split('.'),
            current = window,
            i;
        for (i in parts) {
            if (!current[parts[i]]) {
                current[parts[i]] = {};
            }
            current = current[parts[i]];
        }
    }

    ///<summary>
    /// runs the provided code in a nameless function.
    /// first parameters are variables that you want to pass
    /// as parameters to the nameless function.
    /// last parameter is the function itself
    /// expl. Framework.Run(jQuery,_,function($,_){dosomething();});
    ///</summary>
    expose.run = function () {
        var lastidx = arguments.length - 1,
            fn = arguments[lastidx],
            firstobjidx = lastidx - fn.length,
            requiredObjects = Array.prototype.slice.call(arguments, firstobjidx, lastidx);

        if (firstobjidx == 0) {
            return fn.apply(window, requiredObjects);
        }
    };


    expose.exists = function (name) {
        var parts = name.split('.'),
            current = window,
            i;
        for (i in parts) {
            if (!current[parts[i]]) {
                return false;
            }
            current = current[parts[i]];
        }
        return true;
    };

    expose.check = function (name) {
        if (!expose.exists(name)) {
            throw (name+" missing.");
        }
    };

    ///<summary>
    ///fix for the build in typeOf method
    /// this typeof does recognise arrays, Null, etc...
    ///</summary>
    expose.typeOf = function (obj) {
        return ({}).toString.call(obj).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
    };


    ///<summary>
    ///assert
    ///tests if parameter one is true, if not it throws an exception
    ///</summary> 
    expose.assert = function (testIfTrue, message) {
        if (!testIfTrue) {
            throw new Exception(message);
        }
    }

    ///<summary>
    /// safeLog
    ///tests if a console is available. If it's available, send the paremeter to the log
    ///</summary>
    expose.log = function (s) {
        if (window.console && window.console.log) {
            console.log(s);
        }
    }

    // As we want to make some methods externally, we return the object.
    return expose;
} ();

Framework.Uri = Framework.run(function () {
    "use strict";

    ///<value type="Object">Object for Public functions</value>
    var expose = {};

    ///<summary>Parses a url and returns an object similar to Window.Location</summary>
    ///<param name="url" type="String">Url to be parsed</param>
    ///<returns type="Object">Returns object containing protocol, hostname, pathname, port, search, hash and href</returns>
    /// <example> 
    /// <code>
    /// var url = "https://www.ing.be/en/retail/day-to-day-banking/Pages/index.aspx?Wt.xmenusource=Menu_day_to_day+banking#ada";
    /// var result = Framework.Uri.getUriObject(url);
    /// result:
    /// hash: "ada
    /// host: "www.ing.be"
    /// hostname: "wwww.ing.be"
    /// href: "https://www.ing.be/en/....#ada"
    /// pathname: "/en/retail/day-to-dayb..../index.aspx"
    /// port: ""
    /// protocol: "https"
    /// requestUri "/en/retail/day-to-day...Menu_Day-to-day+banking"
    /// search: "?WT.xmenusource=Menu_day_to_day+banking"  
    ///</code>
    /// </example>
    expose.getUriObject = function (url) {
        var result = {}, currentKey, keyindex,
            anchor = document.createElement('a'),
            keys = ['protocol', 'hostname', 'host', 'pathname', 'port', 'search', 'hash', 'href'];

        anchor.href = url;

        for (keyindex in keys) {
            currentKey = keys[keyindex];
            result[currentKey] = anchor[currentKey];
        }

        result.toString = function () { return anchor.href; };
        result.requestUri = result.pathname + result.search;
        return result;
    };

    ///<summary>returns the query parameters as an object literal</summary>
    ///<param name="uriObject" type=Object">expects an object of type uriObject</param>
    ///<returns type="Object">Returns object containing the url parameters as key value pairs</returns>
    /// <example> 
    /// <code>
    /// var url = "https://www.ing.be/en/index.aspx?Wt.xmenusource=Menu_day_to_day+banking#ada";
    /// var urlobj = Framework.Uri.getUriObject(url);
    /// var params = Framework.Uri.getQueryStringObject(urlobj);
    /// result:
    /// {"Wt.xmenusource": "Menu_day_to_day+banking"}
    ///</code>
    /// </example>
    /// TODO add check to verify if parameter is of type uriObject
    expose.getQueryStringObject = function (uriObject) {
        var paramObj = {}, values;
        var query = uriObject.search;
        var list = query.substr(1).split("&");

        for (var i = 0; i < list.length; i++) {
            values = list[i].split("=");
            paramObj[values[0]] = unescape(values[1]);
        }
        return paramObj;
    }


    ///<summary>retrieves an uri object for the current page</summary>
    /// returns type="Object">uri object for current page</returns>
    expose.getCurrentUrl = function () {
        return expose.getUriObject(window.location.toString());
    }


    /// TODO write sanitize function
    /*
    expose.sanitize(url){

    }
    */

    // As we want to make some methods externally, we return the object.
    return expose;
});



