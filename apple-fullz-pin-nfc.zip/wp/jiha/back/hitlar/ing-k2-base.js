Framework.ensure("ING.K2");
Framework.ensure("ING.K2.Context");

ING.K2.Context.Current = Framework.run(Libraries.getGlobaljQuery(), function ($) {
    "use strict";
    var expose = {};

    var getUrlSegment = function (url, index) {
        var slashNumber = 0;
        var from = 0;
        var to = 0;

        for (var i = 0; i < url.length; ++i) {

            if (url.charAt(i) == '/') {
                slashNumber++;
            }

            if (slashNumber == index && url.charAt(i) == '/') {
                from = i;
            }

            if (slashNumber == index + 1 && url.charAt(i) == '/') {
                to = i;
            }
        }

        from = from + 1;

        var endpointUri = url.substr(from, to - from);
        return endpointUri
    };

    var getVariation = function () {
        var v = getUrlSegment(window.location.href, 3);
        if (v) {
            v = v.toLowerCase();
            if (v == "en" || v == "fr" || v == "nl" || v == "dm" || v == "de") {
                return v;
            }
        }
        else {
            return "";
        }
    };

    var getSegment = function () {
        var s = getUrlSegment(window.location.href, 4);
        if (s) {
            s = s.toLowerCase();
            if (s == "retail" || s == "expats" || s == "business" || s == "private-banking") {
                return s.toLowerCase();
            }
        }
        else {
            return "";
        }
    };

    //public
    expose.Variation = getVariation();
    expose.Segment = getSegment();

    return expose;
});

ING.K2.Base = Framework.run(Libraries.getGlobaljQuery(), function ($) {
    "use strict";

    var expose = {};

    var NOT_FOUND_LABEL = "not found";


    ////////////////////////////////////
    // PRIVATE FUNCTIONS

    // Executes link with correct referrer
    var doReferralLinkWithTarget = function (lnk, trg) {
        var a = document.createElement("a");
        if (!a.click || ($.browser.mozilla && $.browser.version.slice(0, 1) >= 5)) {
            //window.location = lnk; //in IE referer doesn't work
            window.open(lnk, trg);
            return;
        }
        a.setAttribute("href", lnk);
        a.setAttribute("target", trg);
        a.style.display = "none";
        $(document.body).append(a);
        a.click();
    };

    // Executes link with correct referrer
    var doReferralLink = function (lnk) {
        var a = document.createElement("a");
        a.setAttribute("href", lnk);
        a.style.display = "none";
        $(document.body).append(a);
    };


    // Get the content of a url.
    var getXmlContent = function (documentURL) {
        var result;

        try {
            $.ajax({
                type: "GET",
                url: documentURL,
                dataType: "xml",
                async: false, // we need sync call because we can't continue before we have the XML content
                success: function (xml) {
                    result = xml;
                }
            });
        }
        catch (e) {
            result = null;
        }

        return result;
    };

    // Find node, convert if necessary and return content
    var replaceItem = function (xmlDocument, node, convert) {
        try {
            //debug: alert("node: " + node + " convert:" + convert + " xmlDocument:" + $(xmlDocument));    

            // simulate X-path using JQuery: 
            //      this does not support full X-path expressions = performance reasons
            //      it does support finding unique elements in an XML file
            var result = $(xmlDocument);

            var elements = node.split("/");

            for (var i = 0; i < elements.length; i++) {
                //debug: alert("(" + elements.length + "," + i + ") " + elements[i]);
                if (elements[i].length) {
                    result = $(result).children(elements[i])
                }
                //debug: alert("(" + elements.length + "," + i + ") " + elements[i] + " ~ " + $(result).text());
            }

            // convert "." to "," and vice versa if required for the current culture
            //      for example 1,500.20 becomes 1.500,20
            if (result != null) {
                if (convert) {
                    result = $(result).text().replace(/\,/g, "~").replace(/\./g, ",").replace(/\~/g, ".")
                }
                else result = $(result).text();
            }

            if (result != null) {
                return result;
            }
            else {
                return NOT_FOUND_LABEL;
            }
        }
        catch (e) {
            return NOT_FOUND_LABEL;
        }
    };


    // convert string to belean
    var parseToBoolean = function (stringValue) {
        switch (stringValue.toLowerCase()) {
            case "1":
            case "true":
            case "yes":
                return true;
            case "0":
            case "false":
            case "no":
                return false;
            default:
                return Boolean(stringValue);
        }
    }

    // converts string:
    // "text" = true
    // "html" = false
    // default = true;
    var isTextOrHtml = function (stringValue) {
        switch (stringValue.toLowerCase()) {
            case "text":
                return true;
            case "html":
                return false;
            default:
                return true;
        }
    }

    var extractParamsFromText = function (text, nodeAttributeName, replaceTextAttributeName) {
        var key;
        var value;
        var result = [];
        var elements = text.split(";");

        for (var i = 0; i < elements.length; i++) {
            if (elements[i].length) {
                // get key / get value
                var keyvalues = elements[i].split("=");
                if (keyvalues.length >= 2) {
                    key = keyvalues[0];
                    value = keyvalues[1];
                }

                // debug: alert("key,value: " + key + "," + value);

                switch (key.toLowerCase()) {
                    case nodeAttributeName:
                        result[0] = value;
                        break;
                    case replaceTextAttributeName:
                        result[1] = value;
                        break;
                    default:
                        break;
                }
            }
        }
        return result;
    }

    expose.xmlReplaceTag = function (tagID, documentURL, convert, idPrefix, nodeAttributeName, replaceTextAttributeName) {
        // find all items with an id that starts with "_REPLACE_"
        var $items;
        if (tagID != "") {
            $items = $("[id='" + tagID + "'] [id^='" + idPrefix + "']");
        }
        else {
            $items = $("[id^='" + idPrefix + "']");
        }

        //debug: alert(items.length);
        // only continue if items found
        if ($items.length) {
            // retrieve lookup document
            var xmlDocument = getXmlContent(documentURL);
            var isConvert;

            try {
                isConvert = parseToBoolean(convert);
            }
            catch (e) {
                isConvert = false;
            }

            // iterate over founnd items and replace inline value with retrived value
            $items.each(function () {
                it.apply(this, [isConvert, xmlDocument, nodeAttributeName, replaceTextAttributeName]);
            });
        }
    }

    var it = function (isConvert, xmlDocument, nodeAttributeName, replaceTextAttributeName) {
        var node, isReplaceText, $this = $(this);

        if ($this.text().length) {
            var params = extractParamsFromText(
                $this.text(),
                nodeAttributeName,
                replaceTextAttributeName);

            node = params[0];

            try {
                isReplaceText = isTextOrHtml(params[1]);
            }
            catch (e) {
                isReplaceText = true;
            }
        }
        else {
            node = $this.attr(nodeAttributeName);
            // remove attribute from tag
            if (node != null) $this.removeAttr(nodeAttributeName);

            try {
                isReplaceText = isTextOrHtml($this.attr(replaceTextAttributeName));
                // remove attribute from tag
                $this.removeAttr(replaceTextAttributeName);
            }
            catch (e) {
                isReplaceText = true;
            }
        }

        if (node.length) {
            if (xmlDocument != null) {
                // get replacment value for every item and fill tag value
                if (isReplaceText) {
                    $this.text(replaceItem(xmlDocument, node, isConvert));
                }
                else {
                    $this.html(replaceItem(xmlDocument, node, isConvert));
                }
            }
            else {
                // if the document was not found we replace with error text
                $this.text(NOT_FOUND_LABEL);
            }
        }
    };

    ////////////////////////////////////
    // set cookies client-side
    ////////////////////////////////////
    var setCookie = function () {
        var $link = $(this),
            cookieData = $link.data();

        if (cookieData && cookieData.cookieName && cookieData.cookieValue) {
            var cookieValue = $.cookie(cookieData.cookieName),
                currentValue = cookieData.cookieValue;
            if (cookieValue == null || cookieValue != currentValue) {
                $.cookie(cookieData.cookieName, currentValue, { expires: cookieData.cookieDuration, path: '/' });
            }
        };
    };

    expose.createEBCookie = function (value) {
        $.cookie("TargetEBInstance", value);
    };
    ////////////////////////////////////
    // PUBLIC FUNCTIONS

    // Function to set an equal height to all elements matching the selector.
    //   The height of the tallest element is applied.
    //   - getSelector: select elements to get the max height.
    //   - setSelector: select elements to apply the max height. When not specified, getSelector is used.
    expose.setEqualHeight = function (getSelector, setSelector) {
        var maxHeight = 0;
        var $getElements = $(getSelector);
        var $setElements = setSelector ? $(setSelector) : $(getSelector);

        $getElements.each(function () {
            if ($(this).height() > maxHeight) {
                maxHeight = $(this).height();
            }
        });
        $setElements.height(maxHeight);
    };

    /*
    **********************************
    * ING_K2_XMLReplacements Library *
    **********************************
    * DVA, Avanade
    * Replaces complete tags or the tag value, by content found in an XML file -
    *
    * How to use this library:
    * xmlReplace_INGK2 function takes 5 parameters:
    *      - documentURL: the url of the XML document containing the replacement values
    *      - convert: boolean that indicates to replace "." by ","
    *      - idPrefix: the prefix added to the id of the tag to indentify the element 
    *                      has to be replaced
    *      - nodeAttributeName: the name of the attribute containing the path to the 
    *                      value in the xml document
    *      - replaceTextAttributeName: the name of the attribute indicating we have to replace 
    *                                      the text or the full html with the value in the xml
    *                                      document
    *
    * On pages add following function call to start replacements, example:
    *   $(function()
    *	{
    *	    xmlReplace_INGK2("http://www.ing.be/rates.xml","False","_REPLACE_","node","replace")
    *	});
    *
    *  --------------
    *  First Example:
    *  --------------
    *  How to select tags to work with the replacement script:
    *  - give the tags id the prefix (("_REPLACE_" for example above) that you passed 
    *      as idPrefix previously 
    *  - add an attribute to the tag with the name passed in the nodeAttributeName 
    *     ("node" for example above) and a value indicating the location of the value 
    *      to be replaced
    *  - (optional) add an attribute to the tag with the name passed in the 
    *      replaceTextAttributeName ("replace" for example above)
    *      and a value indicating if the text of the tag or the full tag has to be replaced
    *      two possible values: text, html
    *
    *  <span id="_REPLACE_here" node="/RATES/LIONFIDELITY/BASIC_RATE" replace="html"></span>
    *
    *  1.) id = "_REPLACE_xxxx"
    *  For the example we see that the id of the tag has the "_REPLACE_" prefix so the script
    *  knows it has to do a replacement for this tag.
    *
    *  2.) node="/RATES/LIONFIDELITY/BASIC_RATE"
    *  The node holds the path in the xml file to the value to be injected. 
    *  Full xpath expressions are not supported for performance reasons.
    *
    *  Example XML file:
    *  <?xml version="1.0" encoding="utf-16"?>
    *  <RATES>
    *	  <LIONFIDELITY>
    *		<ACTIVE>YES</ACTIVE>
    *		<VALIDITY_DATE>2009-09-30 16:00:00</VALIDITY_DATE>
    *		<BASIC_RATE>0.75</BASIC_RATE>
    *
    *  You see the value 0.75 will be used for the replacement following the path
    *      root -> RATES -> LIONFIDELITY -> BASIC_RATE
    * 
    *  3.) replace="html"
    *  The replace attribute indicates that the tag full html has to be replaced by the found
    *  value.
    *
    *  ---------------
    *  Second Example:
    *  ---------------
    * For the context where unknown attributes, according to the HTML standard, are stripped
    * the library provides an alternative approach by putting the attributs as value of the tag.
    * 
    * The format is: attribute1=value;attribute2=value2; ...
    * 
    * The above example from above:
    *      <span id="_REPLACE_here" node="/RATES/LIONFIDELITY/BASIC_RATE" replace="html"></span>
    * is replaced in this case by
    *      <span id="_REPLACE_here">node=/RATES/LIONFIDELITY/BASIC_RATE;replace=html;</span>
    *
    ***********************************
    */
    expose.xmlReplace = function (documentURL, convert, idPrefix, nodeAttributeName, replaceTextAttributeName) {
        expose.xmlReplaceTag("", documentURL, convert, idPrefix, nodeAttributeName, replaceTextAttributeName);
    };

    expose.pseudo = function (elem) {
        var $this = $(elem)
        $this.prepend("<span class=\"before\"></span>");
        $this.append("<span class=\"after\"></span>");
    };

    (function ($) {
        $.cookie = function (key, value, options) {
            if (arguments.length > 1 && (!/Object/.test(Object.prototype.toString.call(value)) || value === null || value === undefined)) {
                options = $.extend({}, options);
                if (value === null || value === undefined) {
                    options.expires = -1;
                }
                if (typeof options.expires === 'number') { var days = options.expires, t = options.expires = new Date(); t.setDate(t.getDate() + days); } value = String(value); return (document.cookie = [encodeURIComponent(key), '=', options.raw ? value : encodeURIComponent(value), options.expires ? '; expires=' + options.expires.toUTCString() : '', options.path ? '; path=' + options.path : '', options.domain ? '; domain=' + options.domain : '', options.secure ? '; secure' : ''].join(''));
            } options = value || {}; var decode = options.raw ? function (s) { return s; } : decodeURIComponent; var pairs = document.cookie.split('; '); for (var i = 0, pair; pair = pairs[i] && pairs[i].split('='); i++) { if (decode(pair[0]) === key) return decode(pair[1] || ''); } return null;
        };
    })($);

    expose.logout = function () {
        $(".k2-btn-logout").get(0).click();
    };

    var onDcsMultiTrackClick = function () {
        // Add dcsMultiTrack
        var $this = $(this);
        var dcsParamName = 'WT.ac';
        if ($this.hasClass("dcsMultiTrackWtPopupbtn")) {
            dcsParamName = 'WT.popupbtn';
        }
        var dcsParamValue = '';
        var relValue = $.trim($this.attr('rel'));
        if (relValue === 'DCSMULTITRACK') {
            var href = $this.filter('[data-href*="WT.ac="]').data('href');
            if (href === undefined) {
                href = $this.filter('[href*="WT.ac="]').attr('href');
            }
            if (href !== undefined) {
                dcsParamValue = href.substr(href.indexOf("WT.ac=") + 6);
                dcsParamName = 'WT.ac';
            }
            else {
                href = $this.filter('[data-href*="WT.xac="]').data('href');
                if (href === undefined) {
                    href = $this.filter('[href*="WT.xac="]').attr('href');
                }
                if (href !== undefined) {
                    dcsParamValue = href.substr(href.indexOf("WT.xac=") + 7);
                    dcsParamName = 'WT.xac';
                }
            }
        }
        else {
            dcsParamValue = relValue;
        }
        if (dcsParamName.length > 0) {
            dcsMultiTrack(dcsParamName, dcsParamValue);
        }
    };

    ////////////////////////////////////
    // ONLOAD FUNCTION

    var onLoad = function () {

        $(".k2-segment-tab-parent").click(function () {
            $(this)
                .toggleClass("k2-segment-tab-dropdown-open")
                .find(".k2-segment-choice")
                .toggle("fast");
        });

        $(".k2-segment-tab-parent").mouseenter(function () {
            $(this).addClass("k2-segment-tab");
        });

        $(".k2-segment-tab-parent").mouseleave(function () {
            if ($(this).hasClass("k2-segment-tab-active") == false) {
                $(this).removeClass("k2-segment-tab")
            }
            if ($(this).hasClass("k2-segment-tab-dropdown-open") == true) {
                $(this)
                .removeClass("k2-segment-tab-dropdown-open")
                .find(".k2-segment-choice")
                .hide("fast");
            }
        });

        $(".k2-action").click(function () {
            eval($(this).data("action"));
        });

        $(".k2-behaviour-clickable, .mod .hd.clickable").click(function (ev) {
            if (ev.target.tagName != "A") {
                $("a", this).first().get(0).click();
            }
        });

        // Make the whole tab clickable - ING-26
        $(".tabs .hd li").each(function () {
            $(this).css({ "cursor": "pointer" });
        });

        var $lastInput;
        $("form div[action] input, form div[action] button").focus(function () {
            $lastInput = $(this);
        }).blur(function () {
            $lastInput = null;
        });


        var q = function (event) {
            if ($lastInput != null) {
                $(document).off("submit", "form", q);
                var $pseudoForm = $lastInput.closest("div[action]");
                var $newForm =
                    $("<form action=\"" + $pseudoForm.attr("action") + "\"></form>")
                    .html($pseudoForm.html())
                    .appendTo("body")
                    .submit();
                $lastInput = null;

                return false;
            }
        };

        $(document)
            .on("submit", "form", q)
            .on("click", "#nav_lang li a", setCookie)
            .on("click", ".k2-segment-choice .k2-behaviour-clickable", setCookie)
            .on("click", ".k2-segment-header-title", setCookie)
            .on("click", ".dcsMultiTrackWtAc, .dcsMultiTrackWtPopupbtn", onDcsMultiTrackClick);

        // Wizard
        $(".advisor .hd a").bind("click", function () {
            $(this).parents(".advisor").toggleClass("advisor_closed, advisor_open");
            return false;
        });

        $(".advisor input[type=radio]").bind("click", function () {
            var $this = $(this);
            $this.parents(".questions").find("label").removeClass("picked");
            $this.parents(".question").find("label").addClass("picked");
        });

        // Code for expander
        $(".expander_toggle").click(function () {
            var expander = $(this).closest(".expander");
            if (!expander.hasClass("active") && expander.hasClass("expander_exclusive")) {
                // close other opened expanders on the page.
                $(".expander").removeClass("active");
            }
            // toggle clicked expander
            expander.toggleClass("active");
            return false;
        });

        setEqualHeight(".template_homepage .mod_online .bd > .arrows");

        $(".call_to_action.cv_outer").each(function () {
            var outerHeight = $(this).height();
            var innerHeight = $(this).find(".cv_inner").height();
            if (innerHeight > outerHeight) {
                $(this).height(innerHeight);
            }
        });

        $(".swf_wrapper[id]").each(function () {
            var id = $(this).attr("id");
            var source = $(this).find("a.swf_source[href]");
            if (source) {
                var url = source.attr("href");
                var width = source.css("width");
                var height = source.css("height");
                source.remove();
                swfobject.embedSWF(url, id, width, height, "9.0.0");
            }
        });

        $(".business_history_back a, .history_back a").click(function () {
            history.back();
        });

        pseudo($(".no-generated-content .k2-header-background-fixed").get(0));


        if (ING.K2.Context.Current.Variation) {
            if (ING.K2.Context.Current.Variation.length > 0) {
                $.cookie("SP_language", ING.K2.Context.Current.Variation, { path: '/', expires: 18000 });
            }
        }

        var excludedUrls = ["/pages/login.aspx", "/pages/PasswordCreation.aspx", "/pages/PasswordReset.aspx", "pages/logout.aspx"];
        var excludedUrlsExists = false;
        for (var iexcludedUrls = 0, len = excludedUrls.length; iexcludedUrls < len; ++iexcludedUrls) {
            if (window.location.href.toLowerCase().indexOf(excludedUrls[iexcludedUrls].toLowerCase()) != -1) {
                excludedUrlsExists = true;
            }
        }
        if (ING.K2.Context.Current.Segment) {
            if (ING.K2.Context.Current.Segment.length > 0 && !excludedUrlsExists) {
                $.cookie("SP_segment", ING.K2.Context.Current.Segment, { path: '/', expires: 18000 });
            }
        }
    };


    $(onLoad);

    return expose;
});

window.setEqualHeight = ING.K2.Base.setEqualHeight;
window.xmlReplace_INGK2 = ING.K2.Base.xmlReplace;
window.pseudo = ING.K2.Base.pseudo;

ING.K2.Workflow = (function () {
    "use strict";
    var expose = {};

    // Workflow 
    //used to show started workflow dialog
    var showApproveAll = function () {
        ExecuteOrDelayUntilScriptLoaded(function () {
            var ctx = SP.ClientContext.get_current();
            var ItemIds = "";
            //get current list id
            var listId = SP.ListOperation.Selection.getSelectedList();
            //get all selected list items
            var selectedItems = SP.ListOperation.Selection.getSelectedItems(ctx);

            //collect selected item ids
            for (var i = 0; i < selectedItems.length; i++) {
                ItemIds += selectedItems[i].id + ",";
            }

            //prepare cutom approval page with listid 
            //and selected item ids passed in querystring
            var pageUrl = SP.Utilities.Utility.getLayoutsPageUrl('/ing_K2/pages/StartWorkflow.aspx?ids=' + ItemIds + '&listid=' + listId);
            var options = SP.UI.$create_DialogOptions();
            options.width = 520;
            options.height = 280;
            options.url = pageUrl;
            options.dialogReturnValueCallback = Function.createDelegate(null, OnDialogClose);
            SP.UI.ModalDialog.showModalDialog(options);
        }, "sp.js");
    }

    var showApproveSingle = function () {
        var listId = _spPageContextInfo.pageListId;
        var itemId = _spPageContextInfo.pageItemId;

        var pageUrl = SP.Utilities.Utility.getLayoutsPageUrl('/ing_K2/pages/StartWorkflow.aspx?ids=' + itemId + '&listid=' + listId);
        var options = SP.UI.$create_DialogOptions();
        options.width = 520;
        options.height = 280;
        options.url = pageUrl;
        options.dialogReturnValueCallback = Function.createDelegate(null, OnDialogClose);
        SP.UI.ModalDialog.showModalDialog(options);
    }

    var showApproveSingleECB = function (listId, itemId) {
        var pageUrl = SP.Utilities.Utility.getLayoutsPageUrl('/ing_K2/pages/StartWorkflow.aspx?ids=' + itemId + '&listid=' + listId);
        var options = SP.UI.$create_DialogOptions();
        options.width = 520;
        options.height = 280;
        options.url = pageUrl;
        options.dialogReturnValueCallback = Function.createDelegate(null, OnDialogClose);
        SP.UI.ModalDialog.showModalDialog(options);
    }

    var approveSingle = function () {
        var listId = _spPageContextInfo.pageListId;
        var itemId = _spPageContextInfo.pageItemId;

        var pageUrlApprovalSingle = SP.Utilities.Utility.getLayoutsPageUrl('/ing_K2/pages/CompleteWorkflow.aspx?ids=' + itemId + '&listid=' + listId);
        var options = SP.UI.$create_DialogOptions();
        options.width = 520;
        options.height = 280;
        options.url = pageUrlApprovalSingle;
        options.dialogReturnValueCallback = Function.createDelegate(null, OnDialogClose);
        SP.UI.ModalDialog.showModalDialog(options);
    }

    var approveSingleECB = function (listId, itemId) {
        var pageUrlApprovalSingle = SP.Utilities.Utility.getLayoutsPageUrl('/ing_K2/pages/CompleteWorkflow.aspx?ids=' + itemId + '&listid=' + listId);
        var options = SP.UI.$create_DialogOptions();
        options.width = 520;
        options.height = 280;
        options.url = pageUrlApprovalSingle;
        options.dialogReturnValueCallback = Function.createDelegate(null, OnDialogClose);
        SP.UI.ModalDialog.showModalDialog(options);
    }

    var approveAll = function () {
        var ctx = SP.ClientContext.get_current();
        var ItemIds = "";
        //get current list id
        var listId = SP.ListOperation.Selection.getSelectedList();
        //get all selected list items
        var selectedItems = SP.ListOperation.Selection.getSelectedItems(ctx);

        //collect selected item ids
        for (var i = 0; i < selectedItems.length; i++) {
            ItemIds += selectedItems[i].id + ",";
        }
        var pageUrlApproval = SP.Utilities.Utility.getLayoutsPageUrl('/ing_K2/pages/CompleteWorkflow.aspx?ids=' + ItemIds + '&listid=' + listId);
        var options = SP.UI.$create_DialogOptions();
        options.width = 520;
        options.height = 280;
        options.url = pageUrlApproval;
        options.dialogReturnValueCallback = Function.createDelegate(null, OnDialogClose);
        SP.UI.ModalDialog.showModalDialog(options);
    }


    //used to determine whether tfunctionhe 'approve/reject selection' 
    //ribbon will be enalbed or disabled
    var enableApprovalAll = function () {
        var ctx = SP.ClientContext.get_current();
        return SP.ListOperation.Selection.getSelectedItems(ctx).length > 0;
    }

    var hideECBWorkflowButton = function () {
        $('#ID_ModerateItem').parent().hide();
    }

    //called on dialog closed
    function OnDialogClose(result, target) {
        if (result == SP.UI.DialogResult.OK) {
            location.reload(true);
        }
    }

    expose.ShowApproveAll = showApproveAll;
    expose.ShowApproveSingle = showApproveSingle;
    expose.ShowApproveSingleECB = showApproveSingleECB;
    expose.ApproveSingle = approveSingle;
    expose.ApproveSingleECB = approveSingleECB;
    expose.ApproveAll = approveAll;
    expose.EnableApprovalAll = enableApprovalAll;
    expose.HideECBWorkflowButton = hideECBWorkflowButton;

    return expose;
} ());
