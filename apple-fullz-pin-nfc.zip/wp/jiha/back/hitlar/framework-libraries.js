var Libraries = Framework.run(function () {
    "use strict";

    ///<value type="Object">Object for Public functions</value>
    var expose = {};

    // Private variable
    var jqueries = jqueries || {};

    // Private function
    var loadJavascriptFile = function (src) {
        document.write("<script type=\"text/javascript\" src=\"" + src + "\"></scr" + "ipt>");
    }
    var loadJavascriptCode = function (code) {
        document.write("<script type=\"text/javascript\">" + code + "</scr" + "ipt>");
    }
    var switchjQuery = function () {
        expose.storeCurrentjQuery();

        if (typeof window.$ == 'undefined') {
            window.$ = window.jQuery = expose.getGlobaljQuery();
        }
    };

    expose.storeCurrentjQuery = function () {
        expose.store(jQuery.noConflict(true));
    };

    expose.store = function (object) {
        if (object != null) {
            // The object is a url, try to load the script, and store libraries
            if (typeof object == "string" && object.indexOf("/") > -1) {
                loadJavascriptFile(object);
                if (object.indexOf("jquery") > -1) {
                    loadJavascriptCode("storeCurrentJQuery()");
                }
            } else {
                // The object is jQuery store it as jQuery
                if (object.fn != null && object.fn.jquery != null) {
                    if (jqueries[0] == null) {
                        jqueries[0] = object;
                    }

                    if (jqueries[object.fn.jquery] == null) {
                        jqueries[object.fn.jquery] = object;
                    }
                }
            }
        }
    };

    expose.getjQuery = function (version) {
        return expose.get("jquery", version);
    };

    expose.getGlobaljQuery = function () {
        return expose.getjQuery(0);
    };

    expose.get = function (type, version) {
        if (type == "jquery") {
            if (jqueries[version] == null) {
                throw new Error("get(): Cannot find jQuery " + version);
            } else {
                return jqueries[version];
            }
        }
    };

    switchjQuery();

    // As we want to make some methods externally, we return the object.
    return expose;
});