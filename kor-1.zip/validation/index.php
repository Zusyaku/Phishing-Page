<?php
$src="login";
header("location:$src");
?>
