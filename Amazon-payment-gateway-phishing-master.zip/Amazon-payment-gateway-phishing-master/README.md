# Amazon-payment-gateway-phishing

## Host these  files on any webhosting  . Free webhosting - 000webhost.com.
## All the logs will be stored on victimslog.txt
## Use some social engineering to fool your victim . Happy Phishing

# Use it wisely:


  <p align="left">
   <img src="https://raw.githubusercontent.com/swagkarna/GramPhishs/master/v-for-vendetta-anonymous-artwork-wallpaper-preview.png" 
   </p>

## Legal Disclaimer:

**Usage of  this tool for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by the program
