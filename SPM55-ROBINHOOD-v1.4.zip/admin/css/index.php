<script type="text/javascript">
	alert ('Kontol ngapain?')
	window.location = "../../"
</script>