
    <div class="sidebar" data-color="purple" data-background-color="black" data-image="../assets/img/sidebar-2.jpg">
      <div class="logo"><a href="https://wa.me/6281320483670" target="_blank" class="simple-text logo-normal" style="color: white;">
          <?= $judul; ?>
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="index.php">
              <i class="material-icons">dashboard</i>
              <p>Statistic</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="reset.php">
              <i class="fa fa-trash"></i>
              <p>Reset Statistic</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="logout.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">