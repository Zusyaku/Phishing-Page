<?php
session_start();
session_destroy();
echo "<script type='text/javascript'>
alert ('Success Logout!');
window.top.location='../';
</script>";