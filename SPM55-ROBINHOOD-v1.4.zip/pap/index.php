<?php
if (!isset($_POST['bulebabi'])) {
exit(header("HTTP/1.0 404 Not Found"));
}
?>