<?php
$_setup = false;
$template = "default";
$version = "0.2";
?>
