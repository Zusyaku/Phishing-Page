# GOOGLE-Phishing-Page
This Phishing page is created for knowledge purpose , you can edit the mail address in send.php file, 
This page Created by #MKR(ManojKashyapR)
Page is created intend in mind that, for knowledge of Phishing,
I am not responsible for Missuing this file,(Only for Students who are Learning Phishing).
For any query ping me to manoj.manina@gmail.com
Thank you
         
 ( M )( K )( R )          

 ( G )( M )( A )( I )( L )
 
 
 Create free account in 000webhostapp or any free hosting site then upload this files,  
 then change your mail address in send.php
 Thank you :)
 
 Visit website for Training:- https://www.ethicalbyte.in
 
For livedemo visit:- https://youtu.be/Pl2se-wgys8
For Security reasons browser will block you, click detail button below to your browser and click "Visit this unsafe site"
