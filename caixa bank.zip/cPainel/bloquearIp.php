<?php
  $arquivo = "../license/license.txt";
  $arquivo = file("$arquivo");
  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>-=[ Sheik Admin ]=-</title>
<link rel = "shortcut icon" type = "image / x-icon" href="GreenDollar.ico"/>
<style>
.cadastrando {
	width: 92px;
	height: 30px;
	background-image:url(../img/bttok.png);
	background-position: 0px 31px;
	border:0 none;
	cursor:pointer;
	display:block;
}

.cadastrando:hover {
	background-position: 0px 31px;
	width: 92px;
	height: 30px

}
.csscontadores {
	font-weight: bold;
}
.csscontadores {
	font-family: Tahoma, Geneva, sans-serif;
}
.csscontadores {
	font-size: 12px;
}
.csscontadores {
	font-size: 13px;
}
.css1 {
	text-align: center;
	font-family: Tahoma, Geneva, sans-serif;
	font-weight: bold;
	color: #FFF;
}
.css2 {
	text-align: center;
}
.css2 {
	text-align: center;
}
.csscontadores {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
	color: #0C0;
}
.csscontadoress {
	color: #F60;
	font-family: Tahoma, Geneva, sans-serif;
}
.csscontadoress {
	font-size: 14px;
}
.csscontadoress {
	font-weight: bold;
	color: #0C0;
}
#shk {
    border-width: 10px;
    border-style: inset;
    border-color: #DF0000;
    }
body { background:#E5E5E5;
}
</style>
</head>

<body>
<p class="css1"><img src="logoSheikSanta.png" width="844" height="136" /></p>
<table width="42%" border="0" align="center">
  <tr>
    <td align="center" valign="top" class="csscontadores">&nbsp;</td>
  </tr>
</table>
<span class="css2">
</span>
<table id="shk" width="47%" border="0" align="center">
  <tr>
    <td bgcolor="#FFFFFF" class="csscontadoress" align="center" valign="top" height="225">
    <form name="form1" id="form1" method="post" action="gravar.php" />
    Cadastrar Novo IP<br />
<textarea name="texto" rows="15" cols="25" />
</textarea>
<input type="hidden" name="file" value="<?=$arquivo?>" />
<br /><br /><br />
<input type="submit" class="cadastrando" value="">
</form></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF" class="csscontadoress" align="center" valign="top" height="225">
    Ips Cadastrados<br />

    <textarea name="texto" rows="15" cols="25" />
<?php foreach($arquivo as $texto) {
    echo "$texto";
  }
?>
</textarea></td>
  </tr>
</table>

<span class="css2"> </span><span class="css2"></span>
</body>
</html>