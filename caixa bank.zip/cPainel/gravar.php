﻿<?php

$texto = $_POST["texto"];

$myFile = "../license/" . "license" . ".txt";


$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");



$stringData = "
$texto";
fwrite($fh, $stringData);

fclose($fh);

header("Location: index.php");


?>