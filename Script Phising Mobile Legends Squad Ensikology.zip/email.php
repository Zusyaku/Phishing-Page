
<?php
$emailku = 'ensikology@gmail.com'; //ganti email disini
?>