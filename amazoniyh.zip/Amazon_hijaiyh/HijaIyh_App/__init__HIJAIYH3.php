<html>
<head>
    <title>HijaIyh:Re - 2020 Init.</title>
    	<link rel="stylesheet" href="https://fedoracss.github.io/dist/css/fedora.min.css" type="text/css">
	<!-- <script src="https://kit.fontawesome.com/aafae70235.js"></script> -->
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    </head>
    <body>
        <div class="container">
            <center>
            <img src="HijaIyh_App/assets/img/hijaiyh-logo.png"><br>
                <h3> - HijaIyh:Re -</h3>
            </center>
<div style="max-width:40%;margin:0 auto;">
<?php
if(!isset($_GET['_'])){ ?>
<form method="post" action="?_">
  <div class="group">
    <label> ACCOUNT KEY </label>
    <input type="text" class="input" autocomplete="off" name="account_key">
  </div>
  <div class="group">
    <label> API KEY </label>
    <input type="text" class="input" autocomplete="off" name="api_key">
    </div>
  <div class="group">
    <button type="submit" name="submit" class="btn primary full-width"><i class="fa fa-code"></i> ACTIVATE</button>
  </div>
</form>
<?php
}else{
  echo "<center><h1>Initializing please wait ... </h1></center>";
  if(isset($_POST['submit']))
  {
    $account_key = trim($_POST['account_key']);
    $api_key = trim($_POST['api_key']);
    
    print_r($api->check_live($account_key,$api_key)) ;
    unset($_POST['submit']);
    echo "<meta http-equiv='refresh' content='3;url=panel?api=$api_key'>";
  }
}

?>
    
        </div>
        </div>
    </body>
</html>