(function(p) {
    p.execute(function() {
        p.register("jQuery", function() {
            function b(c, q, a) {
                if (a === void 0 && c.nodeType === 1)
                    if (a = "data-" + q.replace(R, "-$1").toLowerCase(), a = c.getAttribute(a), typeof a === "string") {
                        try {
                            a = a === "true" ? !0 : a === "false" ? !1 : a === "null" ? null : !h.isNaN(a) ? parseFloat(a) : M.test(a) ? h.parseJSON(a) : a
                        } catch (d) {}
                        h.data(c, q, a)
                    } else a = void 0;
                return a
            }

            function n(c) {
                for (var q in c)
                    if (q !== "toJSON") return !1;
                return !0
            }

            function m(c, q, a) {
                var d = q + "defer",
                    e = q + "queue",
                    b = q + "mark",
                    f = h.data(c, d, void 0, !0);
                f && (a ===
                    "queue" || !h.data(c, e, void 0, !0)) && (a === "mark" || !h.data(c, b, void 0, !0)) && setTimeout(function() {
                    !h.data(c, e, void 0, !0) && !h.data(c, b, void 0, !0) && (h.removeData(c, d, !0), f.resolve())
                }, 0)
            }

            function k() {
                return !1
            }

            function i() {
                return !0
            }

            function l(c, q, a) {
                var d = h.extend({}, a[0]);
                d.type = c;
                d.originalEvent = {};
                d.liveFired = void 0;
                h.event.handle.call(q, d);
                d.isDefaultPrevented() && a[0].preventDefault()
            }

            function j(c) {
                var q, a, d, e, b, f, g, o, r, s, j, i = [];
                e = [];
                b = h._data(this, "events");
                if (!(c.liveFired === this || !b || !b.live || c.target.disabled ||
                        c.button && c.type === "click")) {
                    c.namespace && (j = RegExp("(^|\\.)" + c.namespace.split(".").join("\\.(?:.*\\.)?") + "(\\.|$)"));
                    c.liveFired = this;
                    var l = b.live.slice(0);
                    for (g = 0; g < l.length; g++) b = l[g], b.origType.replace(ea, "") === c.type ? e.push(b.selector) : l.splice(g--, 1);
                    e = h(c.target).closest(e, c.currentTarget);
                    for (o = 0, r = e.length; o < r; o++) {
                        s = e[o];
                        for (g = 0; g < l.length; g++)
                            if (b = l[g], s.selector === b.selector && (!j || j.test(b.namespace)) && !s.elem.disabled) {
                                f = s.elem;
                                d = null;
                                if (b.preType === "mouseenter" || b.preType === "mouseleave") c.type =
                                    b.preType, (d = h(c.relatedTarget).closest(b.selector)[0]) && h.contains(f, d) && (d = f);
                                (!d || d !== f) && i.push({
                                    elem: f,
                                    handleObj: b,
                                    level: s.level
                                })
                            }
                    }
                    for (o = 0, r = i.length; o < r; o++) {
                        e = i[o];
                        if (a && e.level > a) break;
                        c.currentTarget = e.elem;
                        c.data = e.handleObj.data;
                        c.handleObj = e.handleObj;
                        j = e.handleObj.origHandler.apply(e.elem, arguments);
                        if (j === !1 || c.isPropagationStopped())
                            if (a = e.level, j === !1 && (q = !1), c.isImmediatePropagationStopped()) break
                    }
                    return q
                }
            }

            function f(c, q) {
                return (c && c !== "*" ? c + "." : "") + q.replace(Ja, "`").replace(Ka,
                    "&")
            }

            function g(c, q, a) {
                q = q || 0;
                if (h.isFunction(q)) return h.grep(c, function(c, h) {
                    return !!q.call(c, h, c) === a
                });
                else if (q.nodeType) return h.grep(c, function(c) {
                    return c === q === a
                });
                else if (typeof q === "string") {
                    var d = h.grep(c, function(c) {
                        return c.nodeType === 1
                    });
                    if (La.test(q)) return h.filter(q, d, !a);
                    else q = h.filter(q, d)
                }
                return h.grep(c, function(c) {
                    return h.inArray(c, q) >= 0 === a
                })
            }

            function a(c, q) {
                if (q.nodeType === 1 && h.hasData(c)) {
                    var a = h.expando,
                        d = h.data(c),
                        e = h.data(q, d);
                    if (d = d[a]) {
                        var b = d.events,
                            e = e[a] = h.extend({},
                                d);
                        if (b) {
                            delete e.handle;
                            e.events = {};
                            for (var f in b) {
                                a = 0;
                                for (d = b[f].length; a < d; a++) h.event.add(q, f + (b[f][a].namespace ? "." : "") + b[f][a].namespace, b[f][a], b[f][a].data)
                            }
                        }
                    }
                }
            }

            function e(c, q) {
                var a;
                if (q.nodeType === 1) {
                    q.clearAttributes && q.clearAttributes();
                    q.mergeAttributes && q.mergeAttributes(c);
                    a = q.nodeName.toLowerCase();
                    if (a === "object") q.outerHTML = c.outerHTML;
                    else if (a === "input" && (c.type === "checkbox" || c.type === "radio")) {
                        if (c.checked) q.defaultChecked = q.checked = c.checked;
                        if (q.value !== c.value) q.value = c.value
                    } else if (a ===
                        "option") q.selected = c.defaultSelected;
                    else if (a === "input" || a === "textarea") q.defaultValue = c.defaultValue;
                    q.removeAttribute(h.expando)
                }
            }

            function d(c) {
                return "getElementsByTagName" in c ? c.getElementsByTagName("*") : "querySelectorAll" in c ? c.querySelectorAll("*") : []
            }

            function o(c) {
                if (c.type === "checkbox" || c.type === "radio") c.defaultChecked = c.checked
            }

            function r(c) {
                h.nodeName(c, "input") ? o(c) : "getElementsByTagName" in c && h.grep(c.getElementsByTagName("input"), o)
            }

            function s(c, q) {
                q.src ? h.ajax({
                    url: q.src,
                    async: !1,
                    dataType: "script"
                }) : h.globalEval((q.text || q.textContent || q.innerHTML || "").replace(Ma, "/*$0*/"));
                q.parentNode && q.parentNode.removeChild(q)
            }

            function x(c, q, a) {
                var d = q === "width" ? c.offsetWidth : c.offsetHeight,
                    e = q === "width" ? Na : Oa;
                if (d > 0) return a !== "border" && h.each(e, function() {
                    a || (d -= parseFloat(h.css(c, "padding" + this)) || 0);
                    a === "margin" ? d += parseFloat(h.css(c, a + this)) || 0 : d -= parseFloat(h.css(c, "border" + this + "Width")) || 0
                }), d + "px";
                d = W(c, q, q);
                if (d < 0 || d == null) d = c.style[q] || 0;
                d = parseFloat(d) || 0;
                a && h.each(e, function() {
                    d +=
                        parseFloat(h.css(c, "padding" + this)) || 0;
                    a !== "padding" && (d += parseFloat(h.css(c, "border" + this + "Width")) || 0);
                    a === "margin" && (d += parseFloat(h.css(c, a + this)) || 0)
                });
                return d + "px"
            }

            function u(c) {
                return function(q, a) {
                    var D;
                    typeof q !== "string" && (a = q, q = "*");
                    if (h.isFunction(a))
                        for (var d = q.toLowerCase().split(ma), e = 0, b = d.length, f, g; e < b; e++) f = d[e], (g = /^\+/.test(f)) && (f = f.substr(1) || "*"), D = c[f] = c[f] || [], f = D, f[g ? "unshift" : "push"](a)
                }
            }

            function y(c, q, a, h, d, e) {
                d = d || q.dataTypes[0];
                e = e || {};
                e[d] = !0;
                for (var d = c[d], b = 0, f =
                        d ? d.length : 0, g = c === fa, o; b < f && (g || !o); b++) o = d[b](q, a, h), typeof o === "string" && (!g || e[o] ? o = void 0 : (q.dataTypes.unshift(o), o = y(c, q, a, h, o, e)));
                if ((g || !o) && !e["*"]) o = y(c, q, a, h, "*", e);
                return o
            }

            function t(c, q) {
                var a, d, e = h.ajaxSettings.flatOptions || {};
                for (a in q) q[a] !== void 0 && ((e[a] ? c : d || (d = {}))[a] = q[a]);
                d && h.extend(!0, c, d)
            }

            function w(c, q, a, d) {
                if (h.isArray(q)) h.each(q, function(q, e) {
                    a || Pa.test(c) ? d(c, e) : w(c + "[" + (typeof e === "object" || h.isArray(e) ? q : "") + "]", e, a, d)
                });
                else if (!a && q != null && typeof q === "object")
                    for (var e in q) w(c +
                        "[" + e + "]", q[e], a, d);
                else d(c, q)
            }

            function z() {
                try {
                    return new window.XMLHttpRequest
                } catch (c) {}
            }

            function A() {
                setTimeout(F, 0);
                return aa = h.now()
            }

            function F() {
                aa = void 0
            }

            function B(c, q) {
                var a = {};
                h.each(na.concat.apply([], na.slice(0, q)), function() {
                    a[this] = c
                });
                return a
            }

            function C(c) {
                if (!ga[c]) {
                    var q = v.body,
                        a = h("<" + c + ">").appendTo(q),
                        d = a.css("display");
                    a.remove();
                    if (d === "none" || d === "") {
                        if (!N) N = v.createElement("iframe"), N.frameBorder = N.width = N.height = 0;
                        q.appendChild(N);
                        if (!X || !N.createElement) X = (N.contentWindow ||
                            N.contentDocument).document, X.write((h.support.boxModel ? "<!doctype html>" : "") + "<html><body>"), X.close();
                        a = X.createElement(c);
                        X.body.appendChild(a);
                        d = h.css(a, "display");
                        q.removeChild(N)
                    }
                    ga[c] = d
                }
                return ga[c]
            }

            function p(c) {
                return h.isWindow(c) ? c : c.nodeType === 9 ? c.defaultView || c.parentWindow : !1
            }
            var v = window.document,
                I = window.navigator,
                O = window.location,
                h = function() {
                    function c() {
                        if (!q.isReady) {
                            try {
                                v.documentElement.doScroll("left")
                            } catch (a) {
                                setTimeout(c, 1);
                                return
                            }
                            q.ready()
                        }
                    }
                    var q = function(c, a) {
                            return new q.fn.init(c,
                                a, h)
                        },
                        a = window.jQuery,
                        d = window.$,
                        h, e = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,
                        b = /\S/,
                        f = /^\s+/,
                        g = /\s+$/,
                        o = /\d/,
                        r = /^<(\w+)\s*\/?>(?:<\/\1>)?$/,
                        s = /^[\],:{}\s]*$/,
                        j = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,
                        i = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
                        l = /(?:^|:|,)(?:\s*\[)+/g,
                        u = /(webkit)[ \/]([\w.]+)/,
                        k = /(opera)(?:.*version)?[ \/]([\w.]+)/,
                        x = /(msie) ([\w.]+)/,
                        w = /(mozilla)(?:.*? rv:([\w.]+))?/,
                        m = /-([a-z]|[0-9])/ig,
                        n = /^-ms-/,
                        z = function(c, q) {
                            return (q + "").toUpperCase()
                        },
                        t = I.userAgent,
                        y, F, B = Object.prototype.toString,
                        A = Object.prototype.hasOwnProperty,
                        p = Array.prototype.push,
                        C = Array.prototype.slice,
                        E = String.prototype.trim,
                        M = Array.prototype.indexOf,
                        O = {};
                    q.fn = q.prototype = {
                        constructor: q,
                        init: function(c, a, d) {
                            var h;
                            if (!c) return this;
                            if (c.nodeType) return this.context = this[0] = c, this.length = 1, this;
                            if (c === "body" && !a && v.body) return this.context = v, this[0] = v.body, this.selector = c, this.length = 1, this;
                            if (typeof c === "string")
                                if ((h = c.charAt(0) === "<" && c.charAt(c.length - 1) === ">" && c.length >= 3 ? [null, c,
                                        null
                                    ] : e.exec(c)) && (h[1] || !a))
                                    if (h[1]) return d = (a = a instanceof q ? a[0] : a) ? a.ownerDocument || a : v, (c = r.exec(c)) ? q.isPlainObject(a) ? (c = [v.createElement(c[1])], q.fn.attr.call(c, a, !0)) : c = [d.createElement(c[1])] : (c = q.buildFragment([h[1]], [d]), c = (c.cacheable ? q.clone(c.fragment) : c.fragment).childNodes), q.merge(this, c);
                                    else {
                                        if ((a = v.getElementById(h[2])) && a.parentNode) {
                                            if (a.id !== h[2]) return d.find(c);
                                            this.length = 1;
                                            this[0] = a
                                        }
                                        this.context = v;
                                        this.selector = c;
                                        return this
                                    } else return !a || a.jquery ? (a || d).find(c) : this.constructor(a).find(c);
                            else if (q.isFunction(c)) return d.ready(c);
                            if (c.selector !== void 0) this.selector = c.selector, this.context = c.context;
                            return q.makeArray(c, this)
                        },
                        selector: "",
                        jquery: "1.6.4",
                        length: 0,
                        size: function() {
                            return this.length
                        },
                        toArray: function() {
                            return C.call(this, 0)
                        },
                        get: function(c) {
                            return c == null ? this.toArray() : c < 0 ? this[this.length + c] : this[c]
                        },
                        pushStack: function(c, a, d) {
                            var h = this.constructor();
                            q.isArray(c) ? p.apply(h, c) : q.merge(h, c);
                            h.prevObject = this;
                            h.context = this.context;
                            if (a === "find") h.selector = this.selector +
                                (this.selector ? " " : "") + d;
                            else if (a) h.selector = this.selector + "." + a + "(" + d + ")";
                            return h
                        },
                        each: function(c, a) {
                            return q.each(this, c, a)
                        },
                        ready: function(c) {
                            q.bindReady();
                            y.done(c);
                            return this
                        },
                        eq: function(c) {
                            return c === -1 ? this.slice(c) : this.slice(c, +c + 1)
                        },
                        first: function() {
                            return this.eq(0)
                        },
                        last: function() {
                            return this.eq(-1)
                        },
                        slice: function() {
                            return this.pushStack(C.apply(this, arguments), "slice", C.call(arguments).join(","))
                        },
                        map: function(c) {
                            return this.pushStack(q.map(this, function(q, a) {
                                return c.call(q, a,
                                    q)
                            }))
                        },
                        end: function() {
                            return this.prevObject || this.constructor(null)
                        },
                        push: p,
                        sort: [].sort,
                        splice: [].splice
                    };
                    q.fn.init.prototype = q.fn;
                    q.extend = q.fn.extend = function() {
                        var c, a, h, d, e, b = arguments[0] || {},
                            f = 1,
                            D = arguments.length,
                            g = !1;
                        typeof b === "boolean" && (g = b, b = arguments[1] || {}, f = 2);
                        typeof b !== "object" && !q.isFunction(b) && (b = {});
                        D === f && (b = this, --f);
                        for (; f < D; f++)
                            if ((c = arguments[f]) != null)
                                for (a in c) h = b[a], d = c[a], b !== d && (g && d && (q.isPlainObject(d) || (e = q.isArray(d))) ? (e ? (e = !1, h = h && q.isArray(h) ? h : []) : h = h && q.isPlainObject(h) ?
                                    h : {}, b[a] = q.extend(g, h, d)) : d !== void 0 && (b[a] = d));
                        return b
                    };
                    q.extend({
                        noConflict: function(c) {
                            if (window.$ === q) window.$ = d;
                            if (c && window.jQuery === q) window.jQuery = a;
                            return q
                        },
                        isReady: !1,
                        readyWait: 1,
                        holdReady: function(c) {
                            c ? q.readyWait++ : q.ready(!0)
                        },
                        ready: function(c) {
                            if (c === !0 && !--q.readyWait || c !== !0 && !q.isReady) {
                                if (!v.body) return setTimeout(q.ready, 1);
                                q.isReady = !0;
                                c !== !0 && --q.readyWait > 0 || (y.resolveWith(v, [q]), q.fn.trigger && q(v).trigger("ready").unbind("ready"))
                            }
                        },
                        bindReady: function() {
                            if (!y) {
                                y = q._Deferred();
                                if (v.readyState === "complete") return setTimeout(q.ready, 1);
                                if (v.addEventListener) v.addEventListener("DOMContentLoaded", F, !1), window.addEventListener("load", q.ready, !1);
                                else if (v.attachEvent) {
                                    v.attachEvent("onreadystatechange", F);
                                    window.attachEvent("onload", q.ready);
                                    var a = !1;
                                    try {
                                        a = window.frameElement == null
                                    } catch (h) {}
                                    v.documentElement.doScroll && a && c()
                                }
                            }
                        },
                        isFunction: function(c) {
                            return q.type(c) === "function"
                        },
                        isArray: Array.isArray || function(c) {
                            return q.type(c) === "array"
                        },
                        isWindow: function(c) {
                            return c &&
                                typeof c === "object" && "setInterval" in c
                        },
                        isNaN: function(c) {
                            return c == null || !o.test(c) || isNaN(c)
                        },
                        type: function(c) {
                            return c == null ? String(c) : O[B.call(c)] || "object"
                        },
                        isPlainObject: function(c) {
                            if (!c || q.type(c) !== "object" || c.nodeType || q.isWindow(c)) return !1;
                            try {
                                if (c.constructor && !A.call(c, "constructor") && !A.call(c.constructor.prototype, "isPrototypeOf")) return !1
                            } catch (a) {
                                return !1
                            }
                            for (var h in c);
                            return h === void 0 || A.call(c, h)
                        },
                        isEmptyObject: function(c) {
                            for (var q in c) return !1;
                            return !0
                        },
                        error: function(c) {
                            throw c;
                        },
                        parseJSON: function(c) {
                            if (typeof c !== "string" || !c) return null;
                            c = q.trim(c);
                            if (window.JSON && window.JSON.parse) return window.JSON.parse(c);
                            if (s.test(c.replace(j, "@").replace(i, "]").replace(l, ""))) return (new Function("return " + c))();
                            q.error("Invalid JSON: " + c)
                        },
                        parseXML: function(c) {
                            var a, h;
                            try {
                                window.DOMParser ? (h = new DOMParser, a = h.parseFromString(c, "text/xml")) : (a = new ActiveXObject("Microsoft.XMLDOM"), a.async = "false", a.loadXML(c))
                            } catch (d) {
                                a = void 0
                            }(!a || !a.documentElement || a.getElementsByTagName("parsererror").length) &&
                            q.error("Invalid XML: " + c);
                            return a
                        },
                        noop: function() {},
                        globalEval: function(c) {
                            c && b.test(c) && (window.execScript || function(c) {
                                window.eval.call(window, c)
                            })(c)
                        },
                        camelCase: function(c) {
                            return c.replace(n, "ms-").replace(m, z)
                        },
                        nodeName: function(c, q) {
                            return c.nodeName && c.nodeName.toUpperCase() === q.toUpperCase()
                        },
                        each: function(c, a, h) {
                            var d, e = 0,
                                b = c.length,
                                f = b === void 0 || q.isFunction(c);
                            if (h)
                                if (f)
                                    for (d in c) {
                                        if (a.apply(c[d], h) === !1) break
                                    } else
                                        for (; e < b;) {
                                            if (a.apply(c[e++], h) === !1) break
                                        } else if (f)
                                            for (d in c) {
                                                if (a.call(c[d],
                                                        d, c[d]) === !1) break
                                            } else
                                                for (; e < b;)
                                                    if (a.call(c[e], e, c[e++]) === !1) break;
                            return c
                        },
                        trim: E ? function(c) {
                            return c == null ? "" : E.call(c)
                        } : function(c) {
                            return c == null ? "" : c.toString().replace(f, "").replace(g, "")
                        },
                        makeArray: function(c, a) {
                            var h = a || [];
                            if (c != null) {
                                var d = q.type(c);
                                c.length == null || d === "string" || d === "function" || d === "regexp" || q.isWindow(c) ? p.call(h, c) : q.merge(h, c)
                            }
                            return h
                        },
                        inArray: function(c, q) {
                            if (!q) return -1;
                            if (M) return M.call(q, c);
                            for (var a = 0, h = q.length; a < h; a++)
                                if (q[a] === c) return a;
                            return -1
                        },
                        merge: function(c,
                            q) {
                            var a = c.length,
                                h = 0;
                            if (typeof q.length === "number")
                                for (var d = q.length; h < d; h++) c[a++] = q[h];
                            else
                                for (; q[h] !== void 0;) c[a++] = q[h++];
                            c.length = a;
                            return c
                        },
                        grep: function(c, q, a) {
                            for (var h = [], d, a = !!a, e = 0, b = c.length; e < b; e++) d = !!q(c[e], e), a !== d && h.push(c[e]);
                            return h
                        },
                        map: function(c, a, h) {
                            var d, e, b = [],
                                f = 0,
                                D = c.length;
                            if (c instanceof q || D !== void 0 && typeof D === "number" && (D > 0 && c[0] && c[D - 1] || D === 0 || q.isArray(c)))
                                for (; f < D; f++) d = a(c[f], f, h), d != null && (b[b.length] = d);
                            else
                                for (e in c) d = a(c[e], e, h), d != null && (b[b.length] =
                                    d);
                            return b.concat.apply([], b)
                        },
                        guid: 1,
                        proxy: function(c, a) {
                            if (typeof a === "string") var h = c[a],
                                a = c,
                                c = h;
                            if (q.isFunction(c)) {
                                var d = C.call(arguments, 2),
                                    h = function() {
                                        return c.apply(a, d.concat(C.call(arguments)))
                                    };
                                h.guid = c.guid = c.guid || h.guid || q.guid++;
                                return h
                            }
                        },
                        access: function(c, a, h, d, e, b) {
                            var f = c.length;
                            if (typeof a === "object") {
                                for (var D in a) q.access(c, D, a[D], d, e, h);
                                return c
                            }
                            if (h !== void 0) {
                                d = !b && d && q.isFunction(h);
                                for (D = 0; D < f; D++) e(c[D], a, d ? h.call(c[D], D, e(c[D], a)) : h, b);
                                return c
                            }
                            return f ? e(c[0], a) : void 0
                        },
                        now: function() {
                            return (new Date).getTime()
                        },
                        uaMatch: function(c) {
                            c = c.toLowerCase();
                            c = u.exec(c) || k.exec(c) || x.exec(c) || c.indexOf("compatible") < 0 && w.exec(c) || [];
                            return {
                                browser: c[1] || "",
                                version: c[2] || "0"
                            }
                        },
                        sub: function() {
                            function c(q, a) {
                                return new c.fn.init(q, a)
                            }
                            q.extend(!0, c, this);
                            c.superclass = this;
                            c.fn = c.prototype = this();
                            c.fn.constructor = c;
                            c.sub = this.sub;
                            c.fn.init = function(h, d) {
                                d && d instanceof q && !(d instanceof c) && (d = c(d));
                                return q.fn.init.call(this, h, d, a)
                            };
                            c.fn.init.prototype = c.fn;
                            var a = c(v);
                            return c
                        },
                        browser: {}
                    });
                    q.each("Boolean Number String Function Array Date RegExp Object".split(" "), function(c, q) {
                        O["[object " + q + "]"] = q.toLowerCase()
                    });
                    t = q.uaMatch(t);
                    if (t.browser) q.browser[t.browser] = !0, q.browser.version = t.version;
                    if (q.browser.webkit) q.browser.safari = !0;
                    b.test("\u00a0") && (f = /^[\s\xA0]+/, g = /[\s\xA0]+$/);
                    h = q(v);
                    v.addEventListener ? F = function() {
                        v.removeEventListener("DOMContentLoaded", F, !1);
                        q.ready()
                    } : v.attachEvent && (F = function() {
                        v.readyState === "complete" && (v.detachEvent("onreadystatechange", F),
                            q.ready())
                    });
                    return q
                }(),
                J = "done fail isResolved isRejected promise then always pipe".split(" "),
                G = [].slice;
            h.extend({
                _Deferred: function() {
                    var c = [],
                        q, a, d, e = {
                            done: function() {
                                if (!d) {
                                    var a = arguments,
                                        b, f, D, g, o;
                                    q && (o = q, q = 0);
                                    for (b = 0, f = a.length; b < f; b++) D = a[b], g = h.type(D), g === "array" ? e.done.apply(e, D) : g === "function" && c.push(D);
                                    o && e.resolveWith(o[0], o[1])
                                }
                                return this
                            },
                            resolveWith: function(h, e) {
                                if (!d && !q && !a) {
                                    e = e || [];
                                    a = 1;
                                    try {
                                        for (; c[0];) c.shift().apply(h, e)
                                    } finally {
                                        q = [h, e], a = 0
                                    }
                                }
                                return this
                            },
                            resolve: function() {
                                e.resolveWith(this,
                                    arguments);
                                return this
                            },
                            isResolved: function() {
                                return !(!a && !q)
                            },
                            cancel: function() {
                                d = 1;
                                c = [];
                                return this
                            }
                        };
                    return e
                },
                Deferred: function(c) {
                    var q = h._Deferred(),
                        a = h._Deferred(),
                        d;
                    h.extend(q, {
                        then: function(c, a) {
                            q.done(c).fail(a);
                            return this
                        },
                        always: function() {
                            return q.done.apply(q, arguments).fail.apply(this, arguments)
                        },
                        fail: a.done,
                        rejectWith: a.resolveWith,
                        reject: a.resolve,
                        isRejected: a.isResolved,
                        pipe: function(c, a) {
                            return h.Deferred(function(d) {
                                h.each({
                                    done: [c, "resolve"],
                                    fail: [a, "reject"]
                                }, function(c, a) {
                                    var e =
                                        a[0],
                                        b = a[1],
                                        f;
                                    if (h.isFunction(e)) q[c](function() {
                                        if ((f = e.apply(this, arguments)) && h.isFunction(f.promise)) f.promise().then(d.resolve, d.reject);
                                        else d[b + "With"](this === q ? d : this, [f])
                                    });
                                    else q[c](d[b])
                                })
                            }).promise()
                        },
                        promise: function(c) {
                            if (c == null) {
                                if (d) return d;
                                d = c = {}
                            }
                            for (var a = J.length; a--;) c[J[a]] = q[J[a]];
                            return c
                        }
                    });
                    q.done(a.cancel).fail(q.cancel);
                    delete q.cancel;
                    c && c.call(q, q);
                    return q
                },
                when: function(c) {
                    function q(c) {
                        return function(q) {
                            a[c] = arguments.length > 1 ? G.call(arguments, 0) : q;
                            --b || f.resolveWith(f,
                                G.call(a, 0))
                        }
                    }
                    var a = arguments,
                        d = 0,
                        e = a.length,
                        b = e,
                        f = e <= 1 && c && h.isFunction(c.promise) ? c : h.Deferred();
                    if (e > 1) {
                        for (; d < e; d++) a[d] && h.isFunction(a[d].promise) ? a[d].promise().then(q(d), f.reject) : --b;
                        b || f.resolveWith(f, a)
                    } else f !== c && f.resolveWith(f, e ? [c] : []);
                    return f.promise()
                }
            });
            h.support = function() {
                var c = v.createElement("div"),
                    q = v.documentElement,
                    a, d, e, b, f, g;
                c.setAttribute("className", "t");
                c.innerHTML = "   <link/><table></table><a href='/a' style='top:1px;float:left;opacity:.55;'>a</a><input type='checkbox'/>";
                a = c.getElementsByTagName("*");
                d = c.getElementsByTagName("a")[0];
                if (!a || !a.length || !d) return {};
                e = v.createElement("select");
                b = e.appendChild(v.createElement("option"));
                a = c.getElementsByTagName("input")[0];
                f = {
                    leadingWhitespace: c.firstChild.nodeType === 3,
                    tbody: !c.getElementsByTagName("tbody").length,
                    htmlSerialize: !!c.getElementsByTagName("link").length,
                    style: /top/.test(d.getAttribute("style")),
                    hrefNormalized: d.getAttribute("href") === "/a",
                    opacity: /^0.55$/.test(d.style.opacity),
                    cssFloat: !!d.style.cssFloat,
                    checkOn: a.value === "on",
                    optSelected: b.selected,
                    getSetAttribute: c.className !== "t",
                    submitBubbles: !0,
                    changeBubbles: !0,
                    focusinBubbles: !1,
                    deleteExpando: !0,
                    noCloneEvent: !0,
                    inlineBlockNeedsLayout: !1,
                    shrinkWrapBlocks: !1,
                    reliableMarginRight: !0
                };
                a.checked = !0;
                f.noCloneChecked = a.cloneNode(!0).checked;
                e.disabled = !0;
                f.optDisabled = !b.disabled;
                try {
                    delete c.test
                } catch (o) {
                    f.deleteExpando = !1
                }!c.addEventListener && c.attachEvent && c.fireEvent && (c.attachEvent("onclick", function() {
                    f.noCloneEvent = !1
                }), c.cloneNode(!0).fireEvent("onclick"));
                a = v.createElement("input");
                a.value = "t";
                a.setAttribute("type", "radio");
                f.radioValue = a.value === "t";
                a.setAttribute("checked", "checked");
                c.appendChild(a);
                d = v.createDocumentFragment();
                d.appendChild(c.firstChild);
                f.checkClone = d.cloneNode(!0).cloneNode(!0).lastChild.checked;
                c.innerHTML = "";
                c.style.width = c.style.paddingLeft = "1px";
                e = v.getElementsByTagName("body")[0];
                d = v.createElement(e ? "div" : "body");
                b = {
                    visibility: "hidden",
                    width: 0,
                    height: 0,
                    border: 0,
                    margin: 0,
                    background: "none"
                };
                e && h.extend(b, {
                    position: "absolute",
                    left: "-1000px",
                    top: "-1000px"
                });
                for (g in b) d.style[g] = b[g];
                d.appendChild(c);
                q = e || q;
                q.insertBefore(d, q.firstChild);
                f.appendChecked = a.checked;
                h.boxModel = f.boxModel = v.compatMode === "CSS1Compat";
                if ("zoom" in c.style) c.style.display = "inline", c.style.zoom = 1, f.inlineBlockNeedsLayout = c.offsetWidth === 2, c.style.display = "", c.innerHTML = "<div style='width:4px;'></div>", f.shrinkWrapBlocks = c.offsetWidth !== 2;
                c.innerHTML = "<table><tr><td style='padding:0;border:0;display:none'></td><td>t</td></tr></table>";
                e = c.getElementsByTagName("td");
                a = e[0].offsetHeight === 0;
                e[0].style.display = "";
                e[1].style.display = "none";
                f.reliableHiddenOffsets = a && e[0].offsetHeight === 0;
                c.innerHTML = "";
                if (v.defaultView && v.defaultView.getComputedStyle) a = v.createElement("div"), a.style.width = "0", a.style.marginRight = "0", c.appendChild(a), f.reliableMarginRight = (parseInt((v.defaultView.getComputedStyle(a, null) || {
                    marginRight: 0
                }).marginRight, 10) || 0) === 0;
                d.innerHTML = "";
                q.removeChild(d);
                if (c.attachEvent)
                    for (g in {
                            submit: 1,
                            change: 1,
                            focusin: 1
                        }) q = "on" + g, a = q in c, a || (c.setAttribute(q,
                        "return;"), a = typeof c[q] === "function"), f[g + "Bubbles"] = a;
                d = d = e = b = e = a = c = a = null;
                return f
            }();
            var M = /^(?:\{.*\}|\[.*\])$/,
                R = /([A-Z])/g;
            h.extend({
                cache: {},
                uuid: 0,
                expando: "jQuery" + (h.fn.jquery + Math.random()).replace(/\D/g, ""),
                noData: {
                    embed: !0,
                    object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",
                    applet: !0
                },
                hasData: function(c) {
                    c = c.nodeType ? h.cache[c[h.expando]] : c[h.expando];
                    return !!c && !n(c)
                },
                data: function(c, a, d, e) {
                    if (h.acceptData(c)) {
                        var b = h.expando,
                            f = typeof a === "string",
                            g = c.nodeType,
                            o = g ? h.cache : c,
                            r = g ? c[h.expando] :
                            c[h.expando] && h.expando;
                        if (r && (!e || !r || !o[r] || o[r][b]) || !(f && d === void 0)) {
                            if (!r) g ? c[h.expando] = r = ++h.uuid : r = h.expando;
                            if (!o[r] && (o[r] = {}, !g)) o[r].toJSON = h.noop;
                            if (typeof a === "object" || typeof a === "function") e ? o[r][b] = h.extend(o[r][b], a) : o[r] = h.extend(o[r], a);
                            c = o[r];
                            e && (c[b] || (c[b] = {}), c = c[b]);
                            d !== void 0 && (c[h.camelCase(a)] = d);
                            if (a === "events" && !c[a]) return c[b] && c[b].events;
                            f ? (d = c[a], d == null && (d = c[h.camelCase(a)])) : d = c;
                            return d
                        }
                    }
                },
                removeData: function(c, a, d) {
                    if (h.acceptData(c)) {
                        var e, b = h.expando,
                            f = c.nodeType,
                            g = f ? h.cache : c,
                            o = f ? c[h.expando] : h.expando;
                        if (g[o]) {
                            if (a && (e = d ? g[o][b] : g[o]))
                                if (e[a] || (a = h.camelCase(a)), delete e[a], !n(e)) return;
                            if (d && (delete g[o][b], !n(g[o]))) return;
                            a = g[o][b];
                            h.support.deleteExpando || !g.setInterval ? delete g[o] : g[o] = null;
                            if (a) {
                                g[o] = {};
                                if (!f) g[o].toJSON = h.noop;
                                g[o][b] = a
                            } else f && (h.support.deleteExpando ? delete c[h.expando] : c.removeAttribute ? c.removeAttribute(h.expando) : c[h.expando] = null)
                        }
                    }
                },
                _data: function(c, a, d) {
                    return h.data(c, a, d, !0)
                },
                acceptData: function(c) {
                    if (c.nodeName) {
                        var a =
                            h.noData[c.nodeName.toLowerCase()];
                        if (a) return !(a === !0 || c.getAttribute("classid") !== a)
                    }
                    return !0
                }
            });
            h.fn.extend({
                data: function(c, a) {
                    var d = null;
                    if (typeof c === "undefined") {
                        if (this.length && (d = h.data(this[0]), this[0].nodeType === 1))
                            for (var e = this[0].attributes, f, g = 0, o = e.length; g < o; g++) f = e[g].name, f.indexOf("data-") === 0 && (f = h.camelCase(f.substring(5)), b(this[0], f, d[f]));
                        return d
                    } else if (typeof c === "object") return this.each(function() {
                        h.data(this, c)
                    });
                    var r = c.split(".");
                    r[1] = r[1] ? "." + r[1] : "";
                    return a === void 0 ?
                        (d = this.triggerHandler("getData" + r[1] + "!", [r[0]]), d === void 0 && this.length && (d = h.data(this[0], c), d = b(this[0], c, d)), d === void 0 && r[1] ? this.data(r[0]) : d) : this.each(function() {
                            var d = h(this),
                                e = [r[0], a];
                            d.triggerHandler("setData" + r[1] + "!", e);
                            h.data(this, c, a);
                            d.triggerHandler("changeData" + r[1] + "!", e)
                        })
                },
                removeData: function(c) {
                    return this.each(function() {
                        h.removeData(this, c)
                    })
                }
            });
            h.extend({
                _mark: function(c, a) {
                    c && (a = (a || "fx") + "mark", h.data(c, a, (h.data(c, a, void 0, !0) || 0) + 1, !0))
                },
                _unmark: function(c, a, d) {
                    c !==
                        !0 && (d = a, a = c, c = !1);
                    if (a) {
                        var d = d || "fx",
                            e = d + "mark";
                        (c = c ? 0 : (h.data(a, e, void 0, !0) || 1) - 1) ? h.data(a, e, c, !0): (h.removeData(a, e, !0), m(a, d, "mark"))
                    }
                },
                queue: function(c, a, d) {
                    if (c) {
                        var a = (a || "fx") + "queue",
                            e = h.data(c, a, void 0, !0);
                        d && (!e || h.isArray(d) ? e = h.data(c, a, h.makeArray(d), !0) : e.push(d));
                        return e || []
                    }
                },
                dequeue: function(c, a) {
                    var a = a || "fx",
                        d = h.queue(c, a),
                        e = d.shift();
                    e === "inprogress" && (e = d.shift());
                    e && (a === "fx" && d.unshift("inprogress"), e.call(c, function() {
                        h.dequeue(c, a)
                    }));
                    d.length || (h.removeData(c, a + "queue", !0), m(c, a, "queue"))
                }
            });
            h.fn.extend({
                queue: function(c, a) {
                    typeof c !== "string" && (a = c, c = "fx");
                    return a === void 0 ? h.queue(this[0], c) : this.each(function() {
                        var d = h.queue(this, c, a);
                        c === "fx" && d[0] !== "inprogress" && h.dequeue(this, c)
                    })
                },
                dequeue: function(c) {
                    return this.each(function() {
                        h.dequeue(this, c)
                    })
                },
                delay: function(c, a) {
                    c = h.fx ? h.fx.speeds[c] || c : c;
                    a = a || "fx";
                    return this.queue(a, function() {
                        var d = this;
                        setTimeout(function() {
                            h.dequeue(d, a)
                        }, c)
                    })
                },
                clearQueue: function(c) {
                    return this.queue(c || "fx", [])
                },
                promise: function(c) {
                    function a() {
                        --f ||
                            d.resolveWith(e, [e])
                    }
                    typeof c !== "string" && (c = void 0);
                    var c = c || "fx",
                        d = h.Deferred(),
                        e = this,
                        b = e.length,
                        f = 1,
                        g = c + "defer",
                        o = c + "queue";
                    c += "mark";
                    for (var r; b--;)
                        if (r = h.data(e[b], g, void 0, !0) || (h.data(e[b], o, void 0, !0) || h.data(e[b], c, void 0, !0)) && h.data(e[b], g, h._Deferred(), !0)) f++, r.done(a);
                    a();
                    return d.promise()
                }
            });
            var L = /[\n\t\r]/g,
                K = /\s+/,
                Q = /\r/g,
                Z = /^(?:button|input)$/i,
                Qa = /^(?:button|input|object|select|textarea)$/i,
                Ra = /^a(?:rea)?$/i,
                oa = /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,
                T, pa;
            h.fn.extend({
                attr: function(c, a) {
                    return h.access(this, c, a, !0, h.attr)
                },
                removeAttr: function(c) {
                    return this.each(function() {
                        h.removeAttr(this, c)
                    })
                },
                prop: function(c, a) {
                    return h.access(this, c, a, !0, h.prop)
                },
                removeProp: function(c) {
                    c = h.propFix[c] || c;
                    return this.each(function() {
                        try {
                            this[c] = void 0, delete this[c]
                        } catch (a) {}
                    })
                },
                addClass: function(c) {
                    var a, d, e, b, f, g, o;
                    if (h.isFunction(c)) return this.each(function(a) {
                        h(this).addClass(c.call(this, a, this.className))
                    });
                    if (c && typeof c === "string") {
                        a = c.split(K);
                        for (d =
                            0, e = this.length; d < e; d++)
                            if (b = this[d], b.nodeType === 1)
                                if (!b.className && a.length === 1) b.className = c;
                                else {
                                    f = " " + b.className + " ";
                                    for (g = 0, o = a.length; g < o; g++) ~f.indexOf(" " + a[g] + " ") || (f += a[g] + " ");
                                    b.className = h.trim(f)
                                }
                    }
                    return this
                },
                removeClass: function(c) {
                    var a, d, e, b, f, g, o;
                    if (h.isFunction(c)) return this.each(function(a) {
                        h(this).removeClass(c.call(this, a, this.className))
                    });
                    if (c && typeof c === "string" || c === void 0) {
                        a = (c || "").split(K);
                        for (d = 0, e = this.length; d < e; d++)
                            if (b = this[d], b.nodeType === 1 && b.className)
                                if (c) {
                                    f =
                                        (" " + b.className + " ").replace(L, " ");
                                    for (g = 0, o = a.length; g < o; g++) f = f.replace(" " + a[g] + " ", " ");
                                    b.className = h.trim(f)
                                } else b.className = ""
                    }
                    return this
                },
                toggleClass: function(c, a) {
                    var d = typeof c,
                        e = typeof a === "boolean";
                    return h.isFunction(c) ? this.each(function(d) {
                        h(this).toggleClass(c.call(this, d, this.className, a), a)
                    }) : this.each(function() {
                        if (d === "string")
                            for (var b, f = 0, g = h(this), o = a, r = c.split(K); b = r[f++];) o = e ? o : !g.hasClass(b), g[o ? "addClass" : "removeClass"](b);
                        else if (d === "undefined" || d === "boolean") this.className &&
                            h._data(this, "__className__", this.className), this.className = this.className || c === !1 ? "" : h._data(this, "__className__") || ""
                    })
                },
                hasClass: function(c) {
                    for (var c = " " + c + " ", a = 0, d = this.length; a < d; a++)
                        if (this[a].nodeType === 1 && (" " + this[a].className + " ").replace(L, " ").indexOf(c) > -1) return !0;
                    return !1
                },
                val: function(c) {
                    var a, d, e = this[0];
                    if (arguments.length) {
                        var b = h.isFunction(c);
                        return this.each(function(d) {
                            var e = h(this);
                            if (this.nodeType === 1 && (d = b ? c.call(this, d, e.val()) : c, d == null ? d = "" : typeof d === "number" ? d += "" :
                                    h.isArray(d) && (d = h.map(d, function(c) {
                                        return c == null ? "" : c + ""
                                    })), a = h.valHooks[this.nodeName.toLowerCase()] || h.valHooks[this.type], !a || !("set" in a) || a.set(this, d, "value") === void 0)) this.value = d
                        })
                    } else if (e) {
                        if ((a = h.valHooks[e.nodeName.toLowerCase()] || h.valHooks[e.type]) && "get" in a && (d = a.get(e, "value")) !== void 0) return d;
                        d = e.value;
                        return typeof d === "string" ? d.replace(Q, "") : d == null ? "" : d
                    }
                }
            });
            h.extend({
                valHooks: {
                    option: {
                        get: function(c) {
                            var a = c.attributes.value;
                            return !a || a.specified ? c.value : c.text
                        }
                    },
                    select: {
                        get: function(c) {
                            var a,
                                d = c.selectedIndex,
                                e = [],
                                b = c.options,
                                c = c.type === "select-one";
                            if (d < 0) return null;
                            for (var f = c ? d : 0, g = c ? d + 1 : b.length; f < g; f++)
                                if (a = b[f], a.selected && (h.support.optDisabled ? !a.disabled : a.getAttribute("disabled") === null) && (!a.parentNode.disabled || !h.nodeName(a.parentNode, "optgroup"))) {
                                    a = h(a).val();
                                    if (c) return a;
                                    e.push(a)
                                }
                            return c && !e.length && b.length ? h(b[d]).val() : e
                        },
                        set: function(c, a) {
                            var d = h.makeArray(a);
                            h(c).find("option").each(function() {
                                this.selected = h.inArray(h(this).val(), d) >= 0
                            });
                            if (!d.length) c.selectedIndex = -1;
                            return d
                        }
                    }
                },
                attrFn: {
                    val: !0,
                    css: !0,
                    html: !0,
                    text: !0,
                    data: !0,
                    width: !0,
                    height: !0,
                    offset: !0
                },
                attrFix: {
                    tabindex: "tabIndex"
                },
                attr: function(c, a, d, e) {
                    var b = c.nodeType;
                    if (c && !(b === 3 || b === 8 || b === 2)) {
                        if (e && a in h.attrFn) return h(c)[a](d);
                        if (!("getAttribute" in c)) return h.prop(c, a, d);
                        var f, g;
                        if (e = b !== 1 || !h.isXMLDoc(c)) a = h.attrFix[a] || a, (g = h.attrHooks[a]) || (oa.test(a) ? g = pa : T && (g = T));
                        if (d !== void 0)
                            if (d === null) h.removeAttr(c, a);
                            else return g && "set" in g && e && (f = g.set(c, d, a)) !== void 0 ? f : (c.setAttribute(a, "" + d), d);
                        else return g && "get" in g && e && (f = g.get(c, a)) !== null ? f : (f = c.getAttribute(a), f === null ? void 0 : f)
                    }
                },
                removeAttr: function(c, a) {
                    var d;
                    if (c.nodeType === 1 && (a = h.attrFix[a] || a, h.attr(c, a, ""), c.removeAttribute(a), oa.test(a) && (d = h.propFix[a] || a) in c)) c[d] = !1
                },
                attrHooks: {
                    type: {
                        set: function(c, a) {
                            if (Z.test(c.nodeName) && c.parentNode) h.error("type property can't be changed");
                            else if (!h.support.radioValue && a === "radio" && h.nodeName(c, "input")) {
                                var d = c.value;
                                c.setAttribute("type", a);
                                if (d) c.value = d;
                                return a
                            }
                        }
                    },
                    value: {
                        get: function(c,
                            a) {
                            return T && h.nodeName(c, "button") ? T.get(c, a) : a in c ? c.value : null
                        },
                        set: function(c, a, d) {
                            if (T && h.nodeName(c, "button")) return T.set(c, a, d);
                            c.value = a
                        }
                    }
                },
                propFix: {
                    tabindex: "tabIndex",
                    readonly: "readOnly",
                    "for": "htmlFor",
                    "class": "className",
                    maxlength: "maxLength",
                    cellspacing: "cellSpacing",
                    cellpadding: "cellPadding",
                    rowspan: "rowSpan",
                    colspan: "colSpan",
                    usemap: "useMap",
                    frameborder: "frameBorder",
                    contenteditable: "contentEditable"
                },
                prop: function(c, a, d) {
                    var e = c.nodeType;
                    if (c && !(e === 3 || e === 8 || e === 2)) {
                        var b, f;
                        if (e !==
                            1 || !h.isXMLDoc(c)) a = h.propFix[a] || a, f = h.propHooks[a];
                        return d !== void 0 ? f && "set" in f && (b = f.set(c, d, a)) !== void 0 ? b : c[a] = d : f && "get" in f && (b = f.get(c, a)) !== null ? b : c[a]
                    }
                },
                propHooks: {
                    tabIndex: {
                        get: function(c) {
                            var a = c.getAttributeNode("tabindex");
                            return a && a.specified ? parseInt(a.value, 10) : Qa.test(c.nodeName) || Ra.test(c.nodeName) && c.href ? 0 : void 0
                        }
                    }
                }
            });
            h.attrHooks.tabIndex = h.propHooks.tabIndex;
            pa = {
                get: function(c, a) {
                    var d;
                    return h.prop(c, a) === !0 || (d = c.getAttributeNode(a)) && d.nodeValue !== !1 ? a.toLowerCase() : void 0
                },
                set: function(c, a, d) {
                    a === !1 ? h.removeAttr(c, d) : (a = h.propFix[d] || d, a in c && (c[a] = !0), c.setAttribute(d, d.toLowerCase()));
                    return d
                }
            };
            if (!h.support.getSetAttribute) T = h.valHooks.button = {
                get: function(c, a) {
                    var d;
                    return (d = c.getAttributeNode(a)) && d.nodeValue !== "" ? d.nodeValue : void 0
                },
                set: function(c, a, d) {
                    var e = c.getAttributeNode(d);
                    e || (e = v.createAttribute(d), c.setAttributeNode(e));
                    return e.nodeValue = a + ""
                }
            }, h.each(["width", "height"], function(c, a) {
                h.attrHooks[a] = h.extend(h.attrHooks[a], {
                    set: function(c, d) {
                        if (d ===
                            "") return c.setAttribute(a, "auto"), d
                    }
                })
            });
            h.support.hrefNormalized || h.each(["href", "src", "width", "height"], function(c, a) {
                h.attrHooks[a] = h.extend(h.attrHooks[a], {
                    get: function(c) {
                        c = c.getAttribute(a, 2);
                        return c === null ? void 0 : c
                    }
                })
            });
            if (!h.support.style) h.attrHooks.style = {
                get: function(c) {
                    return c.style.cssText.toLowerCase() || void 0
                },
                set: function(c, a) {
                    return c.style.cssText = "" + a
                }
            };
            if (!h.support.optSelected) h.propHooks.selected = h.extend(h.propHooks.selected, {
                get: function() {
                    return null
                }
            });
            h.support.checkOn ||
                h.each(["radio", "checkbox"], function() {
                    h.valHooks[this] = {
                        get: function(c) {
                            return c.getAttribute("value") === null ? "on" : c.value
                        }
                    }
                });
            h.each(["radio", "checkbox"], function() {
                h.valHooks[this] = h.extend(h.valHooks[this], {
                    set: function(c, a) {
                        if (h.isArray(a)) return c.checked = h.inArray(h(c).val(), a) >= 0
                    }
                })
            });
            var ea = /\.(.*)$/,
                ha = /^(?:textarea|input|select)$/i,
                Ja = /\./g,
                Ka = / /g,
                Sa = /[^\w\s.|`]/g,
                Ta = function(c) {
                    return c.replace(Sa, "\\$&")
                };
            h.event = {
                add: function(c, a, d, e) {
                    if (!(c.nodeType === 3 || c.nodeType === 8)) {
                        if (d === !1) d =
                            k;
                        else if (!d) return;
                        var b, f;
                        if (d.handler) b = d, d = b.handler;
                        if (!d.guid) d.guid = h.guid++;
                        if (f = h._data(c)) {
                            var g = f.events,
                                o = f.handle;
                            if (!g) f.events = g = {};
                            if (!o) f.handle = o = function(c) {
                                return typeof h !== "undefined" && (!c || h.event.triggered !== c.type) ? h.event.handle.apply(o.elem, arguments) : void 0
                            };
                            o.elem = c;
                            for (var a = a.split(" "), r, s = 0, j; r = a[s++];) {
                                f = b ? h.extend({}, b) : {
                                    handler: d,
                                    data: e
                                };
                                r.indexOf(".") > -1 ? (j = r.split("."), r = j.shift(), f.namespace = j.slice(0).sort().join(".")) : (j = [], f.namespace = "");
                                f.type = r;
                                if (!f.guid) f.guid =
                                    d.guid;
                                var i = g[r],
                                    l = h.event.special[r] || {};
                                if (!i && (i = g[r] = [], !l.setup || l.setup.call(c, e, j, o) === !1)) c.addEventListener ? c.addEventListener(r, o, !1) : c.attachEvent && c.attachEvent("on" + r, o);
                                if (l.add && (l.add.call(c, f), !f.handler.guid)) f.handler.guid = d.guid;
                                i.push(f);
                                h.event.global[r] = !0
                            }
                            c = null
                        }
                    }
                },
                global: {},
                remove: function(c, a, d, e) {
                    if (!(c.nodeType === 3 || c.nodeType === 8)) {
                        d === !1 && (d = k);
                        var b, f, g = 0,
                            o, r, s, j, i, l, u = h.hasData(c) && h._data(c),
                            x = u && u.events;
                        if (u && x) {
                            if (a && a.type) d = a.handler, a = a.type;
                            if (!a || typeof a ===
                                "string" && a.charAt(0) === ".")
                                for (b in a = a || "", x) h.event.remove(c, b + a);
                            else {
                                for (a = a.split(" "); b = a[g++];)
                                    if (j = b, o = b.indexOf(".") < 0, r = [], o || (r = b.split("."), b = r.shift(), s = RegExp("(^|\\.)" + h.map(r.slice(0).sort(), Ta).join("\\.(?:.*\\.)?") + "(\\.|$)")), i = x[b])
                                        if (d) {
                                            j = h.event.special[b] || {};
                                            for (f = e || 0; f < i.length; f++)
                                                if (l = i[f], d.guid === l.guid) {
                                                    if (o || s.test(l.namespace)) e == null && i.splice(f--, 1), j.remove && j.remove.call(c, l);
                                                    if (e != null) break
                                                }
                                            if (i.length === 0 || e != null && i.length === 1)(!j.teardown || j.teardown.call(c,
                                                r) === !1) && h.removeEvent(c, b, u.handle), delete x[b]
                                        } else
                                            for (f = 0; f < i.length; f++)
                                                if (l = i[f], o || s.test(l.namespace)) h.event.remove(c, j, l.handler, f), i.splice(f--, 1);
                                if (h.isEmptyObject(x)) {
                                    if (a = u.handle) a.elem = null;
                                    delete u.events;
                                    delete u.handle;
                                    h.isEmptyObject(u) && h.removeData(c, void 0, !0)
                                }
                            }
                        }
                    }
                },
                customEvent: {
                    getData: !0,
                    setData: !0,
                    changeData: !0
                },
                trigger: function(c, a, d, e) {
                    var b = c.type || c,
                        f = [],
                        g;
                    b.indexOf("!") >= 0 && (b = b.slice(0, -1), g = !0);
                    b.indexOf(".") >= 0 && (f = b.split("."), b = f.shift(), f.sort());
                    if (d && !h.event.customEvent[b] ||
                        h.event.global[b]) {
                        c = typeof c === "object" ? c[h.expando] ? c : new h.Event(b, c) : new h.Event(b);
                        c.type = b;
                        c.exclusive = g;
                        c.namespace = f.join(".");
                        c.namespace_re = RegExp("(^|\\.)" + f.join("\\.(?:.*\\.)?") + "(\\.|$)");
                        if (e || !d) c.preventDefault(), c.stopPropagation();
                        if (d) {
                            if (!(d.nodeType === 3 || d.nodeType === 8)) {
                                c.result = void 0;
                                c.target = d;
                                a = a != null ? h.makeArray(a) : [];
                                a.unshift(c);
                                f = d;
                                e = b.indexOf(":") < 0 ? "on" + b : "";
                                do {
                                    g = h._data(f, "handle");
                                    c.currentTarget = f;
                                    g && g.apply(f, a);
                                    if (e && h.acceptData(f) && f[e] && f[e].apply(f, a) ===
                                        !1) c.result = !1, c.preventDefault();
                                    f = f.parentNode || f.ownerDocument || f === c.target.ownerDocument && window
                                } while (f && !c.isPropagationStopped());
                                if (!c.isDefaultPrevented()) {
                                    var o, f = h.event.special[b] || {};
                                    if ((!f._default || f._default.call(d.ownerDocument, c) === !1) && !(b === "click" && h.nodeName(d, "a")) && h.acceptData(d)) {
                                        try {
                                            if (e && d[b])(o = d[e]) && (d[e] = null), h.event.triggered = b, d[b]()
                                        } catch (r) {}
                                        o && (d[e] = o);
                                        h.event.triggered = void 0
                                    }
                                }
                                return c.result
                            }
                        } else h.each(h.cache, function() {
                            var d = this[h.expando];
                            d && d.events &&
                                d.events[b] && h.event.trigger(c, a, d.handle.elem)
                        })
                    }
                },
                handle: function(c) {
                    var c = h.event.fix(c || window.event),
                        a = ((h._data(this, "events") || {})[c.type] || []).slice(0),
                        d = !c.exclusive && !c.namespace,
                        e = Array.prototype.slice.call(arguments, 0);
                    e[0] = c;
                    c.currentTarget = this;
                    for (var f = 0, b = a.length; f < b; f++) {
                        var g = a[f];
                        if (d || c.namespace_re.test(g.namespace)) {
                            c.handler = g.handler;
                            c.data = g.data;
                            c.handleObj = g;
                            g = g.handler.apply(this, e);
                            if (g !== void 0) c.result = g, g === !1 && (c.preventDefault(), c.stopPropagation());
                            if (c.isImmediatePropagationStopped()) break
                        }
                    }
                    return c.result
                },
                props: "altKey attrChange attrName bubbles button cancelable charCode clientX clientY ctrlKey currentTarget data detail eventPhase fromElement handler keyCode layerX layerY metaKey newValue offsetX offsetY pageX pageY prevValue relatedNode relatedTarget screenX screenY shiftKey srcElement target toElement view wheelDelta which".split(" "),
                fix: function(c) {
                    if (c[h.expando]) return c;
                    for (var a = c, c = h.Event(a), d = this.props.length, e; d;) e = this.props[--d], c[e] = a[e];
                    if (!c.target) c.target = c.srcElement || v;
                    if (c.target.nodeType ===
                        3) c.target = c.target.parentNode;
                    if (!c.relatedTarget && c.fromElement) c.relatedTarget = c.fromElement === c.target ? c.toElement : c.fromElement;
                    if (c.pageX == null && c.clientX != null) d = c.target.ownerDocument || v, a = d.documentElement, d = d.body, c.pageX = c.clientX + (a && a.scrollLeft || d && d.scrollLeft || 0) - (a && a.clientLeft || d && d.clientLeft || 0), c.pageY = c.clientY + (a && a.scrollTop || d && d.scrollTop || 0) - (a && a.clientTop || d && d.clientTop || 0);
                    if (c.which == null && (c.charCode != null || c.keyCode != null)) c.which = c.charCode != null ? c.charCode : c.keyCode;
                    if (!c.metaKey && c.ctrlKey) c.metaKey = c.ctrlKey;
                    if (!c.which && c.button !== void 0) c.which = c.button & 1 ? 1 : c.button & 2 ? 3 : c.button & 4 ? 2 : 0;
                    return c
                },
                guid: 1E8,
                proxy: h.proxy,
                special: {
                    ready: {
                        setup: h.bindReady,
                        teardown: h.noop
                    },
                    live: {
                        add: function(c) {
                            h.event.add(this, f(c.origType, c.selector), h.extend({}, c, {
                                handler: j,
                                guid: c.handler.guid
                            }))
                        },
                        remove: function(c) {
                            h.event.remove(this, f(c.origType, c.selector), c)
                        }
                    },
                    beforeunload: {
                        amazonOriginal: null,
                        setup: function(c, a, d) {
                            if (h.isWindow(this)) {
                                var e = function() {};
                                if (typeof this.onbeforeunload ===
                                    "function") e = h.event.special.beforeunload.amazonOriginal = this.onbeforeunload;
                                this.onbeforeunload = function() {
                                    var c = Array.prototype.slice.call(arguments);
                                    e.apply(this, c);
                                    d.apply(this, c)
                                }
                            }
                        },
                        teardown: function() {
                            this.onbeforeunload = h.event.special.beforeunload.amazonOriginal
                        }
                    }
                }
            };
            h.removeEvent = v.removeEventListener ? function(c, a, d) {
                c.removeEventListener && c.removeEventListener(a, d, !1)
            } : function(c, a, d) {
                c.detachEvent && c.detachEvent("on" + a, d)
            };
            h.Event = function(c, a) {
                if (!this.preventDefault) return new h.Event(c,
                    a);
                c && c.type ? (this.originalEvent = c, this.type = c.type, this.isDefaultPrevented = c.defaultPrevented || c.returnValue === !1 || c.getPreventDefault && c.getPreventDefault() ? i : k) : this.type = c;
                a && h.extend(this, a);
                this.timeStamp = h.now();
                this[h.expando] = !0
            };
            h.Event.prototype = {
                preventDefault: function() {
                    this.isDefaultPrevented = i;
                    var c = this.originalEvent;
                    if (c) c.preventDefault ? c.preventDefault() : c.returnValue = !1
                },
                stopPropagation: function() {
                    this.isPropagationStopped = i;
                    var c = this.originalEvent;
                    if (c) c.stopPropagation && c.stopPropagation(),
                        c.cancelBubble = !0
                },
                stopImmediatePropagation: function() {
                    this.isImmediatePropagationStopped = i;
                    this.stopPropagation()
                },
                isDefaultPrevented: k,
                isPropagationStopped: k,
                isImmediatePropagationStopped: k
            };
            var qa = function(c) {
                    var a = c.relatedTarget,
                        d = !1,
                        e = c.type;
                    c.type = c.data;
                    if (a !== this && (a && (d = h.contains(this, a)), !d)) h.event.handle.apply(this, arguments), c.type = e
                },
                ra = function(c) {
                    c.type = c.data;
                    h.event.handle.apply(this, arguments)
                };
            h.each({
                mouseenter: "mouseover",
                mouseleave: "mouseout"
            }, function(c, a) {
                h.event.special[c] = {
                    setup: function(d) {
                        h.event.add(this, a, d && d.selector ? ra : qa, c)
                    },
                    teardown: function(c) {
                        h.event.remove(this, a, c && c.selector ? ra : qa)
                    }
                }
            });
            if (!h.support.submitBubbles) h.event.special.submit = {
                setup: function() {
                    if (h.nodeName(this, "form")) return !1;
                    else h.event.add(this, "click.specialSubmit", function(c) {
                        var a = c.target,
                            d = h.nodeName(a, "input") || h.nodeName(a, "button") ? a.type : "";
                        (d === "submit" || d === "image") && h(a).closest("form").length && l("submit", this, arguments)
                    }), h.event.add(this, "keypress.specialSubmit", function(c) {
                        var a =
                            c.target,
                            d = h.nodeName(a, "input") || h.nodeName(a, "button") ? a.type : "";
                        (d === "text" || d === "password") && h(a).closest("form").length && c.keyCode === 13 && l("submit", this, arguments)
                    })
                },
                teardown: function() {
                    h.event.remove(this, ".specialSubmit")
                }
            };
            if (!h.support.changeBubbles) {
                var $, sa = function(c) {
                        var a = h.nodeName(c, "input") ? c.type : "",
                            d = c.value;
                        if (a === "radio" || a === "checkbox") d = c.checked;
                        else if (a === "select-multiple") d = c.selectedIndex > -1 ? h.map(c.options, function(c) {
                            return c.selected
                        }).join("-") : "";
                        else if (h.nodeName(c,
                                "select")) d = c.selectedIndex;
                        return d
                    },
                    ba = function(c, a) {
                        var d = c.target,
                            e, f;
                        if (ha.test(d.nodeName) && !d.readOnly && (e = h._data(d, "_change_data"), f = sa(d), (c.type !== "focusout" || d.type !== "radio") && h._data(d, "_change_data", f), !(e === void 0 || f === e)))
                            if (e != null || f) c.type = "change", c.liveFired = void 0, h.event.trigger(c, a, d)
                    };
                h.event.special.change = {
                    filters: {
                        focusout: ba,
                        beforedeactivate: ba,
                        click: function(c) {
                            var a = c.target,
                                d = h.nodeName(a, "input") ? a.type : "";
                            (d === "radio" || d === "checkbox" || h.nodeName(a, "select")) && ba.call(this,
                                c)
                        },
                        keydown: function(c) {
                            var a = c.target,
                                d = h.nodeName(a, "input") ? a.type : "";
                            (c.keyCode === 13 && !h.nodeName(a, "textarea") || c.keyCode === 32 && (d === "checkbox" || d === "radio") || d === "select-multiple") && ba.call(this, c)
                        },
                        beforeactivate: function(c) {
                            c = c.target;
                            h._data(c, "_change_data", sa(c))
                        }
                    },
                    setup: function() {
                        if (this.type === "file") return !1;
                        for (var c in $) h.event.add(this, c + ".specialChange", $[c]);
                        return ha.test(this.nodeName)
                    },
                    teardown: function() {
                        h.event.remove(this, ".specialChange");
                        return ha.test(this.nodeName)
                    }
                };
                $ = h.event.special.change.filters;
                $.focus = $.beforeactivate
            }
            h.support.focusinBubbles || h.each({
                focus: "focusin",
                blur: "focusout"
            }, function(c, a) {
                function d(c) {
                    var e = h.event.fix(c);
                    e.type = a;
                    e.originalEvent = {};
                    h.event.trigger(e, null, e.target);
                    e.isDefaultPrevented() && c.preventDefault()
                }
                var e = 0;
                h.event.special[a] = {
                    setup: function() {
                        e++ === 0 && v.addEventListener(c, d, !0)
                    },
                    teardown: function() {
                        --e === 0 && v.removeEventListener(c, d, !0)
                    }
                }
            });
            h.each(["bind", "one"], function(c, a) {
                h.fn[a] = function(c, d, e) {
                    var f;
                    if (typeof c ===
                        "object") {
                        for (var b in c) this[a](b, d, c[b], e);
                        return this
                    }
                    if (arguments.length === 2 || d === !1) e = d, d = void 0;
                    a === "one" ? (f = function(c) {
                        h(this).unbind(c, f);
                        return e.apply(this, arguments)
                    }, f.guid = e.guid || h.guid++) : f = e;
                    if (c === "unload" && a !== "one") this.one(c, d, e);
                    else {
                        b = 0;
                        for (var g = this.length; b < g; b++) h.event.add(this[b], c, f, d)
                    }
                    return this
                }
            });
            h.fn.extend({
                unbind: function(c, a) {
                    if (typeof c === "object" && !c.preventDefault)
                        for (var d in c) this.unbind(d, c[d]);
                    else {
                        d = 0;
                        for (var e = this.length; d < e; d++) h.event.remove(this[d],
                            c, a)
                    }
                    return this
                },
                delegate: function(c, a, d, e) {
                    return this.live(a, d, e, c)
                },
                undelegate: function(c, a, d) {
                    return arguments.length === 0 ? this.unbind("live") : this.die(a, null, d, c)
                },
                trigger: function(c, a) {
                    return this.each(function() {
                        h.event.trigger(c, a, this)
                    })
                },
                triggerHandler: function(c, a) {
                    if (this[0]) return h.event.trigger(c, a, this[0], !0)
                },
                toggle: function(c) {
                    var a = arguments,
                        d = c.guid || h.guid++,
                        e = 0,
                        f = function(d) {
                            var f = (h.data(this, "lastToggle" + c.guid) || 0) % e;
                            h.data(this, "lastToggle" + c.guid, f + 1);
                            d.preventDefault();
                            return a[f].apply(this, arguments) || !1
                        };
                    for (f.guid = d; e < a.length;) a[e++].guid = d;
                    return this.click(f)
                },
                hover: function(c, a) {
                    return this.mouseenter(c).mouseleave(a || c)
                }
            });
            var ia = {
                focus: "focusin",
                blur: "focusout",
                mouseenter: "mouseover",
                mouseleave: "mouseout"
            };
            h.each(["live", "die"], function(c, a) {
                h.fn[a] = function(c, d, e, b) {
                    var g = 0,
                        o, r, s = b || this.selector,
                        j = b ? this : h(this.context);
                    if (typeof c === "object" && !c.preventDefault) {
                        for (o in c) j[a](o, d, c[o], s);
                        return this
                    }
                    if (a === "die" && !c && b && b.charAt(0) === ".") return j.unbind(b),
                        this;
                    if (d === !1 || h.isFunction(d)) e = d || k, d = void 0;
                    for (c = (c || "").split(" ");
                        (b = c[g++]) != null;)
                        if (o = ea.exec(b), r = "", o && (r = o[0], b = b.replace(ea, "")), b === "hover") c.push("mouseenter" + r, "mouseleave" + r);
                        else if (o = b, ia[b] ? (c.push(ia[b] + r), b += r) : b = (ia[b] || b) + r, a === "live") {
                        r = 0;
                        for (var i = j.length; r < i; r++) h.event.add(j[r], "live." + f(b, s), {
                            data: d,
                            selector: s,
                            handler: e,
                            origType: b,
                            origHandler: e,
                            preType: o
                        })
                    } else j.unbind("live." + f(b, s), e);
                    return this
                }
            });
            h.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error".split(" "),
                function(c, a) {
                    h.fn[a] = function(c, d) {
                        d == null && (d = c, c = null);
                        return arguments.length > 0 ? this.bind(a, c, d) : this.trigger(a)
                    };
                    h.attrFn && (h.attrFn[a] = !0)
                });
            (function() {
                function c(c, a, d, e, h, b) {
                    for (var h = 0, f = e.length; h < f; h++) {
                        var g = e[h];
                        if (g) {
                            for (var q = !1, g = g[c]; g;) {
                                if (g.sizcache === d) {
                                    q = e[g.sizset];
                                    break
                                }
                                if (g.nodeType === 1 && !b) g.sizcache = d, g.sizset = h;
                                if (g.nodeName.toLowerCase() === a) {
                                    q = g;
                                    break
                                }
                                g = g[c]
                            }
                            e[h] = q
                        }
                    }
                }

                function a(c, d, e, h, b, f) {
                    for (var b = 0, g = h.length; b < g; b++) {
                        var q = h[b];
                        if (q) {
                            for (var o = !1, q = q[c]; q;) {
                                if (q.sizcache ===
                                    e) {
                                    o = h[q.sizset];
                                    break
                                }
                                if (q.nodeType === 1) {
                                    if (!f) q.sizcache = e, q.sizset = b;
                                    if (typeof d !== "string") {
                                        if (q === d) {
                                            o = !0;
                                            break
                                        }
                                    } else if (s.filter(d, [q]).length > 0) {
                                        o = q;
                                        break
                                    }
                                }
                                q = q[c]
                            }
                            h[b] = o
                        }
                    }
                }
                var d = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,
                    e = 0,
                    b = Object.prototype.toString,
                    f = !1,
                    g = !0,
                    o = /\\/g,
                    r = /\W/;
                [0, 0].sort(function() {
                    g = !1;
                    return 0
                });
                var s = function(c, a, e, h) {
                    var e = e || [],
                        f = a = a || v;
                    if (a.nodeType !== 1 && a.nodeType !== 9) return [];
                    if (!c || typeof c !== "string") return e;
                    var g, q, o, r, l, u = !0,
                        k = s.isXML(a),
                        w = [],
                        m = c;
                    do
                        if (d.exec(""), g = d.exec(m))
                            if (m = g[3], w.push(g[1]), g[2]) {
                                r = g[3];
                                break
                            }
                    while (g);
                    if (w.length > 1 && i.exec(c))
                        if (w.length === 2 && j.relative[w[0]]) q = n(w[0] + w[1], a);
                        else
                            for (q = j.relative[w[0]] ? [a] : s(w.shift(), a); w.length;) c = w.shift(), j.relative[c] && (c += w.shift()), q = n(c, q);
                    else if (!h && w.length > 1 && a.nodeType === 9 && !k && j.match.ID.test(w[0]) && !j.match.ID.test(w[w.length - 1]) && (g = s.find(w.shift(), a, k), a = g.expr ? s.filter(g.expr, g.set)[0] :
                            g.set[0]), a) {
                        g = h ? {
                            expr: w.pop(),
                            set: x(h)
                        } : s.find(w.pop(), w.length === 1 && (w[0] === "~" || w[0] === "+") && a.parentNode ? a.parentNode : a, k);
                        q = g.expr ? s.filter(g.expr, g.set) : g.set;
                        for (w.length > 0 ? o = x(q) : u = !1; w.length;) g = l = w.pop(), j.relative[l] ? g = w.pop() : l = "", g == null && (g = a), j.relative[l](o, g, k)
                    } else o = [];
                    o || (o = q);
                    o || s.error(l || c);
                    if (b.call(o) === "[object Array]")
                        if (u)
                            if (a && a.nodeType === 1)
                                for (c = 0; o[c] != null; c++) o[c] && (o[c] === !0 || o[c].nodeType === 1 && s.contains(a, o[c])) && e.push(q[c]);
                            else
                                for (c = 0; o[c] != null; c++) o[c] &&
                                    o[c].nodeType === 1 && e.push(q[c]);
                    else e.push.apply(e, o);
                    else x(o, e);
                    r && (s(r, f, e, h), s.uniqueSort(e));
                    return e
                };
                s.uniqueSort = function(c) {
                    if (w && (f = g, c.sort(w), f))
                        for (var a = 1; a < c.length; a++) c[a] === c[a - 1] && c.splice(a--, 1);
                    return c
                };
                s.matches = function(c, a) {
                    return s(c, null, null, a)
                };
                s.matchesSelector = function(c, a) {
                    return s(a, null, null, [c]).length > 0
                };
                s.find = function(c, a, d) {
                    var e;
                    if (!c) return [];
                    for (var h = 0, b = j.order.length; h < b; h++) {
                        var f, g = j.order[h];
                        if (f = j.leftMatch[g].exec(c)) {
                            var q = f[1];
                            f.splice(1, 1);
                            if (q.substr(q.length -
                                    1) !== "\\" && (f[1] = (f[1] || "").replace(o, ""), e = j.find[g](f, a, d), e != null)) {
                                c = c.replace(j.match[g], "");
                                break
                            }
                        }
                    }
                    e || (e = typeof a.getElementsByTagName !== "undefined" ? a.getElementsByTagName("*") : []);
                    return {
                        set: e,
                        expr: c
                    }
                };
                s.filter = function(c, a, d, e) {
                    for (var h, b, f = c, g = [], q = a, o = a && a[0] && s.isXML(a[0]); c && a.length;) {
                        for (var r in j.filter)
                            if ((h = j.leftMatch[r].exec(c)) != null && h[2]) {
                                var l, i, u = j.filter[r];
                                i = h[1];
                                b = !1;
                                h.splice(1, 1);
                                if (i.substr(i.length - 1) !== "\\") {
                                    q === g && (g = []);
                                    if (j.preFilter[r])
                                        if (h = j.preFilter[r](h, q,
                                                d, g, e, o)) {
                                            if (h === !0) continue
                                        } else b = l = !0;
                                    if (h)
                                        for (var x = 0;
                                            (i = q[x]) != null; x++)
                                            if (i) {
                                                l = u(i, h, x, q);
                                                var w = e ^ !!l;
                                                d && l != null ? w ? b = !0 : q[x] = !1 : w && (g.push(i), b = !0)
                                            }
                                    if (l !== void 0) {
                                        d || (q = g);
                                        c = c.replace(j.match[r], "");
                                        if (!b) return [];
                                        break
                                    }
                                }
                            }
                        if (c === f)
                            if (b == null) s.error(c);
                            else break;
                        f = c
                    }
                    return q
                };
                s.error = function(c) {
                    throw "Syntax error, unrecognized expression: " + c;
                };
                var j = s.selectors = {
                        order: ["ID", "NAME", "TAG"],
                        match: {
                            ID: /#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
                            CLASS: /\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
                            NAME: /\[name=['"]*((?:[\w\u00c0-\uFFFF\-]|\\.)+)['"]*\]/,
                            ATTR: /\[\s*((?:[\w\u00c0-\uFFFF\-]|\\.)+)\s*(?:(\S?=)\s*(?:(['"])(.*?)\3|(#?(?:[\w\u00c0-\uFFFF\-]|\\.)*)|)|)\s*\]/,
                            TAG: /^((?:[\w\u00c0-\uFFFF\*\-]|\\.)+)/,
                            CHILD: /:(only|nth|last|first)-child(?:\(\s*(even|odd|(?:[+\-]?\d+|(?:[+\-]?\d*)?n\s*(?:[+\-]\s*\d+)?))\s*\))?/,
                            POS: /:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^\-]|$)/,
                            PSEUDO: /:((?:[\w\u00c0-\uFFFF\-]|\\.)+)(?:\((['"]?)((?:\([^\)]+\)|[^\(\)]*)+)\2\))?/
                        },
                        leftMatch: {},
                        attrMap: {
                            "class": "className",
                            "for": "htmlFor"
                        },
                        attrHandle: {
                            href: function(c) {
                                return c.getAttribute("href")
                            },
                            type: function(c) {
                                return c.getAttribute("type")
                            }
                        },
                        relative: {
                            "+": function(c, a) {
                                var d = typeof a === "string",
                                    e = d && !r.test(a),
                                    d = d && !e;
                                e && (a = a.toLowerCase());
                                for (var e = 0, h = c.length, b; e < h; e++)
                                    if (b = c[e]) {
                                        for (;
                                            (b = b.previousSibling) && b.nodeType !== 1;);
                                        c[e] = d || b && b.nodeName.toLowerCase() === a ? b || !1 : b === a
                                    }
                                d && s.filter(a, c, !0)
                            },
                            ">": function(c, a) {
                                var d, e = typeof a === "string",
                                    h = 0,
                                    b = c.length;
                                if (e && !r.test(a))
                                    for (a = a.toLowerCase(); h < b; h++) {
                                        if (d = c[h]) d = d.parentNode, c[h] = d.nodeName.toLowerCase() === a ? d : !1
                                    } else {
                                        for (; h < b; h++)(d =
                                            c[h]) && (c[h] = e ? d.parentNode : d.parentNode === a);
                                        e && s.filter(a, c, !0)
                                    }
                            },
                            "": function(d, h, b) {
                                var f, g = e++,
                                    o = a;
                                typeof h === "string" && !r.test(h) && (f = h = h.toLowerCase(), o = c);
                                o("parentNode", h, g, d, f, b)
                            },
                            "~": function(d, h, b) {
                                var f, g = e++,
                                    o = a;
                                typeof h === "string" && !r.test(h) && (f = h = h.toLowerCase(), o = c);
                                o("previousSibling", h, g, d, f, b)
                            }
                        },
                        find: {
                            ID: function(c, a, d) {
                                if (typeof a.getElementById !== "undefined" && !d) return (c = a.getElementById(c[1])) && c.parentNode ? [c] : []
                            },
                            NAME: function(c, a) {
                                if (typeof a.getElementsByName !== "undefined") {
                                    for (var d = [], e = a.getElementsByName(c[1]), h = 0, b = e.length; h < b; h++) e[h].getAttribute("name") === c[1] && d.push(e[h]);
                                    return d.length === 0 ? null : d
                                }
                            },
                            TAG: function(c, a) {
                                if (typeof a.getElementsByTagName !== "undefined") return a.getElementsByTagName(c[1])
                            }
                        },
                        preFilter: {
                            CLASS: function(c, a, d, e, h, b) {
                                c = " " + c[1].replace(o, "") + " ";
                                if (b) return c;
                                for (var b = 0, f;
                                    (f = a[b]) != null; b++) f && (h ^ (f.className && (" " + f.className + " ").replace(/[\t\n\r]/g, " ").indexOf(c) >= 0) ? d || e.push(f) : d && (a[b] = !1));
                                return !1
                            },
                            ID: function(c) {
                                return c[1].replace(o,
                                    "")
                            },
                            TAG: function(c) {
                                return c[1].replace(o, "").toLowerCase()
                            },
                            CHILD: function(c) {
                                if (c[1] === "nth") {
                                    c[2] || s.error(c[0]);
                                    c[2] = c[2].replace(/^\+|\s*/g, "");
                                    var a = /(-?)(\d*)(?:n([+\-]?\d*))?/.exec(c[2] === "even" && "2n" || c[2] === "odd" && "2n+1" || !/\D/.test(c[2]) && "0n+" + c[2] || c[2]);
                                    c[2] = a[1] + (a[2] || 1) - 0;
                                    c[3] = a[3] - 0
                                } else c[2] && s.error(c[0]);
                                c[0] = e++;
                                return c
                            },
                            ATTR: function(c, a, d, e, h, b) {
                                a = c[1] = c[1].replace(o, "");
                                !b && j.attrMap[a] && (c[1] = j.attrMap[a]);
                                c[4] = (c[4] || c[5] || "").replace(o, "");
                                c[2] === "~=" && (c[4] = " " + c[4] +
                                    " ");
                                return c
                            },
                            PSEUDO: function(c, a, e, h, b) {
                                if (c[1] === "not")
                                    if ((d.exec(c[3]) || "").length > 1 || /^\w/.test(c[3])) c[3] = s(c[3], null, null, a);
                                    else return c = s.filter(c[3], a, e, 1 ^ b), e || h.push.apply(h, c), !1;
                                else if (j.match.POS.test(c[0]) || j.match.CHILD.test(c[0])) return !0;
                                return c
                            },
                            POS: function(c) {
                                c.unshift(!0);
                                return c
                            }
                        },
                        filters: {
                            enabled: function(c) {
                                return c.disabled === !1 && c.type !== "hidden"
                            },
                            disabled: function(c) {
                                return c.disabled === !0
                            },
                            checked: function(c) {
                                return c.checked === !0
                            },
                            selected: function(c) {
                                return c.selected ===
                                    !0
                            },
                            parent: function(c) {
                                return !!c.firstChild
                            },
                            empty: function(c) {
                                return !c.firstChild
                            },
                            has: function(c, a, d) {
                                return !!s(d[3], c).length
                            },
                            header: function(c) {
                                return /h\d/i.test(c.nodeName)
                            },
                            text: function(c) {
                                var a = c.getAttribute("type"),
                                    d = c.type;
                                return c.nodeName.toLowerCase() === "input" && "text" === d && (a === d || a === null)
                            },
                            radio: function(c) {
                                return c.nodeName.toLowerCase() === "input" && "radio" === c.type
                            },
                            checkbox: function(c) {
                                return c.nodeName.toLowerCase() === "input" && "checkbox" === c.type
                            },
                            file: function(c) {
                                return c.nodeName.toLowerCase() ===
                                    "input" && "file" === c.type
                            },
                            password: function(c) {
                                return c.nodeName.toLowerCase() === "input" && "password" === c.type
                            },
                            submit: function(c) {
                                var a = c.nodeName.toLowerCase();
                                return (a === "input" || a === "button") && "submit" === c.type
                            },
                            image: function(c) {
                                return c.nodeName.toLowerCase() === "input" && "image" === c.type
                            },
                            reset: function(c) {
                                var a = c.nodeName.toLowerCase();
                                return (a === "input" || a === "button") && "reset" === c.type
                            },
                            button: function(c) {
                                var a = c.nodeName.toLowerCase();
                                return a === "input" && "button" === c.type || a === "button"
                            },
                            input: function(c) {
                                return /input|select|textarea|button/i.test(c.nodeName)
                            },
                            focus: function(c) {
                                return c === c.ownerDocument.activeElement
                            }
                        },
                        setFilters: {
                            first: function(c, a) {
                                return a === 0
                            },
                            last: function(c, a, d, e) {
                                return a === e.length - 1
                            },
                            even: function(c, a) {
                                return a % 2 === 0
                            },
                            odd: function(c, a) {
                                return a % 2 === 1
                            },
                            lt: function(c, a, d) {
                                return a < d[3] - 0
                            },
                            gt: function(c, a, d) {
                                return a > d[3] - 0
                            },
                            nth: function(c, a, d) {
                                return d[3] - 0 === a
                            },
                            eq: function(c, a, d) {
                                return d[3] - 0 === a
                            }
                        },
                        filter: {
                            PSEUDO: function(c, a, d, e) {
                                var h = a[1],
                                    b = j.filters[h];
                                if (b) return b(c, d, a, e);
                                else if (h === "contains") return (c.textContent || c.innerText ||
                                    s.getText([c]) || "").indexOf(a[3]) >= 0;
                                else if (h === "not") {
                                    a = a[3];
                                    d = 0;
                                    for (e = a.length; d < e; d++)
                                        if (a[d] === c) return !1;
                                    return !0
                                } else s.error(h)
                            },
                            CHILD: function(c, a) {
                                var d = a[1],
                                    e = c;
                                switch (d) {
                                    case "only":
                                    case "first":
                                        for (; e = e.previousSibling;)
                                            if (e.nodeType === 1) return !1;
                                        if (d === "first") return !0;
                                        e = c;
                                    case "last":
                                        for (; e = e.nextSibling;)
                                            if (e.nodeType === 1) return !1;
                                        return !0;
                                    case "nth":
                                        var d = a[2],
                                            h = a[3];
                                        if (d === 1 && h === 0) return !0;
                                        var b = a[0],
                                            f = c.parentNode;
                                        if (f && (f.sizcache !== b || !c.nodeIndex)) {
                                            for (var g = 0, e = f.firstChild; e; e =
                                                e.nextSibling)
                                                if (e.nodeType === 1) e.nodeIndex = ++g;
                                            f.sizcache = b
                                        }
                                        e = c.nodeIndex - h;
                                        return d === 0 ? e === 0 : e % d === 0 && e / d >= 0
                                }
                            },
                            ID: function(c, a) {
                                return c.nodeType === 1 && c.getAttribute("id") === a
                            },
                            TAG: function(c, a) {
                                return a === "*" && c.nodeType === 1 || c.nodeName.toLowerCase() === a
                            },
                            CLASS: function(c, a) {
                                return (" " + (c.className || c.getAttribute("class")) + " ").indexOf(a) > -1
                            },
                            ATTR: function(c, a) {
                                var d = a[1],
                                    d = j.attrHandle[d] ? j.attrHandle[d](c) : c[d] != null ? c[d] : c.getAttribute(d),
                                    e = d + "",
                                    h = a[2],
                                    b = a[4];
                                return d == null ? h === "!=" : h === "=" ?
                                    e === b : h === "*=" ? e.indexOf(b) >= 0 : h === "~=" ? (" " + e + " ").indexOf(b) >= 0 : !b ? e && d !== !1 : h === "!=" ? e !== b : h === "^=" ? e.indexOf(b) === 0 : h === "$=" ? e.substr(e.length - b.length) === b : h === "|=" ? e === b || e.substr(0, b.length + 1) === b + "-" : !1
                            },
                            POS: function(c, a, d, e) {
                                var h = j.setFilters[a[2]];
                                if (h) return h(c, d, a, e)
                            }
                        }
                    },
                    i = j.match.POS,
                    l = function(c, a) {
                        return "\\" + (a - 0 + 1)
                    },
                    u;
                for (u in j.match) j.match[u] = RegExp(j.match[u].source + /(?![^\[]*\])(?![^\(]*\))/.source), j.leftMatch[u] = RegExp(/(^(?:.|\r|\n)*?)/.source + j.match[u].source.replace(/\\(\d+)/g,
                    l));
                var x = function(c, a) {
                    c = Array.prototype.slice.call(c, 0);
                    return a ? (a.push.apply(a, c), a) : c
                };
                try {
                    Array.prototype.slice.call(v.documentElement.childNodes, 0)
                } catch (k) {
                    x = function(c, a) {
                        var d = 0,
                            e = a || [];
                        if (b.call(c) === "[object Array]") Array.prototype.push.apply(e, c);
                        else if (typeof c.length === "number")
                            for (var h = c.length; d < h; d++) e.push(c[d]);
                        else
                            for (; c[d]; d++) e.push(c[d]);
                        return e
                    }
                }
                var w, m;
                v.documentElement.compareDocumentPosition ? w = function(c, a) {
                    return c === a ? (f = !0, 0) : !c.compareDocumentPosition || !a.compareDocumentPosition ?
                        c.compareDocumentPosition ? -1 : 1 : c.compareDocumentPosition(a) & 4 ? -1 : 1
                } : (w = function(c, a) {
                    if (c === a) return f = !0, 0;
                    else if (c.sourceIndex && a.sourceIndex) return c.sourceIndex - a.sourceIndex;
                    var d, e, h = [],
                        b = [];
                    d = c.parentNode;
                    e = a.parentNode;
                    var g = d;
                    if (d === e) return m(c, a);
                    else if (d) {
                        if (!e) return 1
                    } else return -1;
                    for (; g;) h.unshift(g), g = g.parentNode;
                    for (g = e; g;) b.unshift(g), g = g.parentNode;
                    d = h.length;
                    e = b.length;
                    for (g = 0; g < d && g < e; g++)
                        if (h[g] !== b[g]) return m(h[g], b[g]);
                    return g === d ? m(c, b[g], -1) : m(h[g], a, 1)
                }, m = function(c,
                    a, d) {
                    if (c === a) return d;
                    for (c = c.nextSibling; c;) {
                        if (c === a) return -1;
                        c = c.nextSibling
                    }
                    return 1
                });
                s.getText = function(c) {
                    for (var a = "", d, e = 0; c[e]; e++) d = c[e], d.nodeType === 3 || d.nodeType === 4 ? a += d.nodeValue : d.nodeType !== 8 && (a += s.getText(d.childNodes));
                    return a
                };
                (function() {
                    var c = v.createElement("div"),
                        a = "script" + (new Date).getTime(),
                        d = v.documentElement;
                    c.innerHTML = "<a name='" + a + "'/>";
                    d.insertBefore(c, d.firstChild);
                    if (v.getElementById(a)) j.find.ID = function(c, a, d) {
                        if (typeof a.getElementById !== "undefined" && !d) return (a =
                            a.getElementById(c[1])) ? a.id === c[1] || typeof a.getAttributeNode !== "undefined" && a.getAttributeNode("id").nodeValue === c[1] ? [a] : void 0 : []
                    }, j.filter.ID = function(c, a) {
                        var d = typeof c.getAttributeNode !== "undefined" && c.getAttributeNode("id");
                        return c.nodeType === 1 && d && d.nodeValue === a
                    };
                    d.removeChild(c);
                    d = c = null
                })();
                (function() {
                    var c = v.createElement("div");
                    c.appendChild(v.createComment(""));
                    if (c.getElementsByTagName("*").length > 0) j.find.TAG = function(c, a) {
                        var d = a.getElementsByTagName(c[1]);
                        if (c[1] === "*") {
                            for (var e = [], h = 0; d[h]; h++) d[h].nodeType === 1 && e.push(d[h]);
                            d = e
                        }
                        return d
                    };
                    c.innerHTML = "<a href='#'></a>";
                    if (c.firstChild && typeof c.firstChild.getAttribute !== "undefined" && c.firstChild.getAttribute("href") !== "#") j.attrHandle.href = function(c) {
                        return c.getAttribute("href", 2)
                    };
                    c = null
                })();
                v.querySelectorAll && function() {
                    var c = s,
                        a = v.createElement("div");
                    a.innerHTML = "<p class='TEST'></p>";
                    if (!(a.querySelectorAll && a.querySelectorAll(".TEST").length === 0)) {
                        s = function(a, d, e, h) {
                            d = d || v;
                            if (!h && !s.isXML(d)) {
                                var b = /^(\w+$)|^\.([\w\-]+$)|^#([\w\-]+$)/.exec(a);
                                if (b && (d.nodeType === 1 || d.nodeType === 9))
                                    if (b[1]) return x(d.getElementsByTagName(a), e);
                                    else if (b[2] && j.find.CLASS && d.getElementsByClassName) return x(d.getElementsByClassName(b[2]), e);
                                if (d.nodeType === 9) {
                                    if (a === "body" && d.body) return x([d.body], e);
                                    else if (b && b[3]) {
                                        var f = d.getElementById(b[3]);
                                        if (f && f.parentNode) {
                                            if (f.id === b[3]) return x([f], e)
                                        } else return x([], e)
                                    }
                                    try {
                                        return x(d.querySelectorAll(a), e)
                                    } catch (g) {}
                                } else if (d.nodeType === 1 && d.nodeName.toLowerCase() !== "object") {
                                    var b = d,
                                        q = (f = d.getAttribute("id")) ||
                                        "__sizzle__",
                                        o = d.parentNode,
                                        r = /^\s*[+~]/.test(a);
                                    f ? q = q.replace(/'/g, "\\$&") : d.setAttribute("id", q);
                                    if (r && o) d = d.parentNode;
                                    try {
                                        if (!r || o) return x(d.querySelectorAll("[id='" + q + "'] " + a), e)
                                    } catch (i) {} finally {
                                        f || b.removeAttribute("id")
                                    }
                                }
                            }
                            return c(a, d, e, h)
                        };
                        for (var d in c) s[d] = c[d];
                        a = null
                    }
                }();
                (function() {
                    var c = v.documentElement,
                        a = c.matchesSelector || c.mozMatchesSelector || c.webkitMatchesSelector || c.msMatchesSelector;
                    if (a) {
                        var d = !a.call(v.createElement("div"), "div"),
                            e = !1;
                        try {
                            a.call(v.documentElement, "[test!='']:sizzle")
                        } catch (h) {
                            e = !0
                        }
                        s.matchesSelector = function(c, h) {
                            h = h.replace(/\=\s*([^'"\]]*)\s*\]/g, "='$1']");
                            if (!s.isXML(c)) try {
                                if (e || !j.match.PSEUDO.test(h) && !/!=/.test(h)) {
                                    var b = a.call(c, h);
                                    if (b || !d || c.document && c.document.nodeType !== 11) return b
                                }
                            } catch (f) {}
                            return s(h, null, null, [c]).length > 0
                        }
                    }
                })();
                (function() {
                    var c = v.createElement("div");
                    c.innerHTML = "<div class='test e'></div><div class='test'></div>";
                    if (c.getElementsByClassName && c.getElementsByClassName("e").length !== 0 && (c.lastChild.className = "e", c.getElementsByClassName("e").length !==
                            1)) j.order.splice(1, 0, "CLASS"), j.find.CLASS = function(c, a, d) {
                        if (typeof a.getElementsByClassName !== "undefined" && !d) return a.getElementsByClassName(c[1])
                    }, c = null
                })();
                s.contains = v.documentElement.contains ? function(c, a) {
                    return c !== a && (c.contains ? c.contains(a) : !0)
                } : v.documentElement.compareDocumentPosition ? function(c, a) {
                    return !!(c.compareDocumentPosition(a) & 16)
                } : function() {
                    return !1
                };
                s.isXML = function(c) {
                    return (c = (c ? c.ownerDocument || c : 0).documentElement) ? c.nodeName !== "HTML" : !1
                };
                var n = function(c, a) {
                    for (var d,
                            e = [], h = "", b = a.nodeType ? [a] : a; d = j.match.PSEUDO.exec(c);) h += d[0], c = c.replace(j.match.PSEUDO, "");
                    c = j.relative[c] ? c + "*" : c;
                    d = 0;
                    for (var f = b.length; d < f; d++) s(c, b[d], e);
                    return s.filter(h, e)
                };
                h.find = s;
                h.expr = s.selectors;
                h.expr[":"] = h.expr.filters;
                h.unique = s.uniqueSort;
                h.text = s.getText;
                h.isXMLDoc = s.isXML;
                h.contains = s.contains
            })();
            var Ua = /Until$/,
                Va = /^(?:parents|prevUntil|prevAll)/,
                Wa = /,/,
                La = /^.[^:#\[\.,]*$/,
                Xa = Array.prototype.slice,
                ta = h.expr.match.POS,
                Ya = {
                    children: !0,
                    contents: !0,
                    next: !0,
                    prev: !0
                };
            h.fn.extend({
                find: function(c) {
                    var a =
                        this,
                        d, e;
                    if (typeof c !== "string") return h(c).filter(function() {
                        for (d = 0, e = a.length; d < e; d++)
                            if (h.contains(a[d], this)) return !0
                    });
                    var b = this.pushStack("", "find", c),
                        f, g, o;
                    for (d = 0, e = this.length; d < e; d++)
                        if (f = b.length, h.find(c, this[d], b), d > 0)
                            for (g = f; g < b.length; g++)
                                for (o = 0; o < f; o++)
                                    if (b[o] === b[g]) {
                                        b.splice(g--, 1);
                                        break
                                    }
                    return b
                },
                has: function(c) {
                    var a = h(c);
                    return this.filter(function() {
                        for (var c = 0, d = a.length; c < d; c++)
                            if (h.contains(this, a[c])) return !0
                    })
                },
                not: function(c) {
                    return this.pushStack(g(this, c, !1), "not",
                        c)
                },
                filter: function(c) {
                    return this.pushStack(g(this, c, !0), "filter", c)
                },
                is: function(c) {
                    return !!c && (typeof c === "string" ? h.filter(c, this).length > 0 : this.filter(c).length > 0)
                },
                closest: function(c, a) {
                    var d = [],
                        e, b, f = this[0];
                    if (h.isArray(c)) {
                        var g, o = {},
                            r = 1;
                        if (f && c.length) {
                            for (e = 0, b = c.length; e < b; e++) g = c[e], o[g] || (o[g] = ta.test(g) ? h(g, a || this.context) : g);
                            for (; f && f.ownerDocument && f !== a;) {
                                for (g in o) e = o[g], (e.jquery ? e.index(f) > -1 : h(f).is(e)) && d.push({
                                    selector: g,
                                    elem: f,
                                    level: r
                                });
                                f = f.parentNode;
                                r++
                            }
                        }
                        return d
                    }
                    g = ta.test(c) ||
                        typeof c !== "string" ? h(c, a || this.context) : 0;
                    for (e = 0, b = this.length; e < b; e++)
                        for (f = this[e]; f;)
                            if (g ? g.index(f) > -1 : h.find.matchesSelector(f, c)) {
                                d.push(f);
                                break
                            } else if (f = f.parentNode, !f || !f.ownerDocument || f === a || f.nodeType === 11) break;
                    d = d.length > 1 ? h.unique(d) : d;
                    return this.pushStack(d, "closest", c)
                },
                index: function(c) {
                    return !c ? this[0] && this[0].parentNode ? this.prevAll().length : -1 : typeof c === "string" ? h.inArray(this[0], h(c)) : h.inArray(c.jquery ? c[0] : c, this)
                },
                add: function(c, a) {
                    var d = typeof c === "string" ? h(c, a) :
                        h.makeArray(c && c.nodeType ? [c] : c),
                        e = h.merge(this.get(), d);
                    return this.pushStack(!d[0] || !d[0].parentNode || d[0].parentNode.nodeType === 11 || !e[0] || !e[0].parentNode || e[0].parentNode.nodeType === 11 ? e : h.unique(e))
                },
                andSelf: function() {
                    return this.add(this.prevObject)
                }
            });
            h.each({
                parent: function(c) {
                    return (c = c.parentNode) && c.nodeType !== 11 ? c : null
                },
                parents: function(c) {
                    return h.dir(c, "parentNode")
                },
                parentsUntil: function(c, a, d) {
                    return h.dir(c, "parentNode", d)
                },
                next: function(c) {
                    return h.nth(c, 2, "nextSibling")
                },
                prev: function(c) {
                    return h.nth(c,
                        2, "previousSibling")
                },
                nextAll: function(c) {
                    return h.dir(c, "nextSibling")
                },
                prevAll: function(c) {
                    return h.dir(c, "previousSibling")
                },
                nextUntil: function(c, a, d) {
                    return h.dir(c, "nextSibling", d)
                },
                prevUntil: function(c, a, d) {
                    return h.dir(c, "previousSibling", d)
                },
                siblings: function(c) {
                    return h.sibling(c.parentNode.firstChild, c)
                },
                children: function(c) {
                    return h.sibling(c.firstChild)
                },
                contents: function(c) {
                    return h.nodeName(c, "iframe") ? c.contentDocument || c.contentWindow.document : h.makeArray(c.childNodes)
                }
            }, function(c,
                a) {
                h.fn[c] = function(d, e) {
                    var b = h.map(this, a, d),
                        f = Xa.call(arguments);
                    Ua.test(c) || (e = d);
                    e && typeof e === "string" && (b = h.filter(e, b));
                    b = this.length > 1 && !Ya[c] ? h.unique(b) : b;
                    if ((this.length > 1 || Wa.test(e)) && Va.test(c)) b = b.reverse();
                    return this.pushStack(b, c, f.join(","))
                }
            });
            h.extend({
                filter: function(c, a, d) {
                    d && (c = ":not(" + c + ")");
                    return a.length === 1 ? h.find.matchesSelector(a[0], c) ? [a[0]] : [] : h.find.matches(c, a)
                },
                dir: function(c, a, d) {
                    for (var e = [], c = c[a]; c && c.nodeType !== 9 && (d === void 0 || c.nodeType !== 1 || !h(c).is(d));) c.nodeType ===
                        1 && e.push(c), c = c[a];
                    return e
                },
                nth: function(c, a, d) {
                    for (var a = a || 1, e = 0; c; c = c[d])
                        if (c.nodeType === 1 && ++e === a) break;
                    return c
                },
                sibling: function(c, a) {
                    for (var d = []; c; c = c.nextSibling) c.nodeType === 1 && c !== a && d.push(c);
                    return d
                }
            });
            var Za = / jQuery\d+="(?:\d+|null)"/g,
                ja = /^\s+/,
                ua = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/ig,
                va = /<([\w:]+)/,
                $a = /<tbody/i,
                ab = /<|&#?\w+;/,
                wa = /<(?:script|object|embed|option|style)/i,
                xa = /checked\s*(?:[^=]|=\s*.checked.)/i,
                bb = /\/(java|ecma)script/i,
                Ma = /^\s*<!(?:\[CDATA\[|\-\-)/,
                H = {
                    option: [1, "<select multiple='multiple'>", "</select>"],
                    legend: [1, "<fieldset>", "</fieldset>"],
                    thead: [1, "<table>", "</table>"],
                    tr: [2, "<table><tbody>", "</tbody></table>"],
                    td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
                    col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
                    area: [1, "<map>", "</map>"],
                    _default: [0, "", ""]
                };
            H.optgroup = H.option;
            H.tbody = H.tfoot = H.colgroup = H.caption = H.thead;
            H.th = H.td;
            if (!h.support.htmlSerialize) H._default = [1, "div<div>", "</div>"];
            h.fn.extend({
                text: function(c) {
                    return h.isFunction(c) ?
                        this.each(function(a) {
                            var d = h(this);
                            d.text(c.call(this, a, d.text()))
                        }) : typeof c !== "object" && c !== void 0 ? this.empty().append((this[0] && this[0].ownerDocument || v).createTextNode(c)) : h.text(this)
                },
                wrapAll: function(c) {
                    if (h.isFunction(c)) return this.each(function(a) {
                        h(this).wrapAll(c.call(this, a))
                    });
                    if (this[0]) {
                        var a = h(c, this[0].ownerDocument).eq(0).clone(!0);
                        this[0].parentNode && a.insertBefore(this[0]);
                        a.map(function() {
                            for (var c = this; c.firstChild && c.firstChild.nodeType === 1;) c = c.firstChild;
                            return c
                        }).append(this)
                    }
                    return this
                },
                wrapInner: function(c) {
                    return h.isFunction(c) ? this.each(function(a) {
                        h(this).wrapInner(c.call(this, a))
                    }) : this.each(function() {
                        var a = h(this),
                            d = a.contents();
                        d.length ? d.wrapAll(c) : a.append(c)
                    })
                },
                wrap: function(c) {
                    return this.each(function() {
                        h(this).wrapAll(c)
                    })
                },
                unwrap: function() {
                    return this.parent().each(function() {
                        h.nodeName(this, "body") || h(this).replaceWith(this.childNodes)
                    }).end()
                },
                append: function() {
                    return this.domManip(arguments, !0, function(c) {
                        this.nodeType === 1 && this.appendChild(c)
                    })
                },
                prepend: function() {
                    return this.domManip(arguments, !0, function(c) {
                        this.nodeType === 1 && this.insertBefore(c, this.firstChild)
                    })
                },
                before: function() {
                    if (this[0] && this[0].parentNode) return this.domManip(arguments, !1, function(c) {
                        this.parentNode.insertBefore(c, this)
                    });
                    else if (arguments.length) {
                        var c = h(arguments[0]);
                        c.push.apply(c, this.toArray());
                        return this.pushStack(c, "before", arguments)
                    }
                },
                after: function() {
                    if (this[0] && this[0].parentNode) return this.domManip(arguments, !1, function(c) {
                        this.parentNode.insertBefore(c, this.nextSibling)
                    });
                    else if (arguments.length) {
                        var c =
                            this.pushStack(this, "after", arguments);
                        c.push.apply(c, h(arguments[0]).toArray());
                        return c
                    }
                },
                remove: function(c, a) {
                    for (var d = 0, e;
                        (e = this[d]) != null; d++)
                        if (!c || h.filter(c, [e]).length) !a && e.nodeType === 1 && (h.cleanData(e.getElementsByTagName("*")), h.cleanData([e])), e.parentNode && e.parentNode.removeChild(e);
                    return this
                },
                empty: function() {
                    for (var c = 0, a;
                        (a = this[c]) != null; c++)
                        for (a.nodeType === 1 && h.cleanData(a.getElementsByTagName("*")); a.firstChild;) a.removeChild(a.firstChild);
                    return this
                },
                clone: function(c, a) {
                    c =
                        c == null ? !1 : c;
                    a = a == null ? c : a;
                    return this.map(function() {
                        return h.clone(this, c, a)
                    })
                },
                html: function(c) {
                    if (c === void 0) return this[0] && this[0].nodeType === 1 ? this[0].innerHTML.replace(Za, "") : null;
                    else if (typeof c === "string" && !wa.test(c) && (h.support.leadingWhitespace || !ja.test(c)) && !H[(va.exec(c) || ["", ""])[1].toLowerCase()]) {
                        c = c.replace(ua, "<$1></$2>");
                        try {
                            for (var a = 0, d = this.length; a < d; a++)
                                if (this[a].nodeType === 1) h.cleanData(this[a].getElementsByTagName("*")), this[a].innerHTML = c
                        } catch (e) {
                            this.empty().append(c)
                        }
                    } else h.isFunction(c) ?
                        this.each(function(a) {
                            var d = h(this);
                            d.html(c.call(this, a, d.html()))
                        }) : this.empty().append(c);
                    return this
                },
                replaceWith: function(c) {
                    if (this[0] && this[0].parentNode) {
                        if (h.isFunction(c)) return this.each(function(a) {
                            var d = h(this),
                                e = d.html();
                            d.replaceWith(c.call(this, a, e))
                        });
                        typeof c !== "string" && (c = h(c).detach());
                        return this.each(function() {
                            var a = this.nextSibling,
                                d = this.parentNode;
                            h(this).remove();
                            a ? h(a).before(c) : h(d).append(c)
                        })
                    } else return this.length ? this.pushStack(h(h.isFunction(c) ? c() : c), "replaceWith",
                        c) : this
                },
                detach: function(c) {
                    return this.remove(c, !0)
                },
                domManip: function(c, a, d) {
                    var e, b, f, g = c[0],
                        o = [];
                    if (!h.support.checkClone && arguments.length === 3 && typeof g === "string" && xa.test(g)) return this.each(function() {
                        h(this).domManip(c, a, d, !0)
                    });
                    if (h.isFunction(g)) return this.each(function(e) {
                        var b = h(this);
                        c[0] = g.call(this, e, a ? b.html() : void 0);
                        b.domManip(c, a, d)
                    });
                    if (this[0]) {
                        e = g && g.parentNode;
                        e = h.support.parentNode && e && e.nodeType === 11 && e.childNodes.length === this.length ? {
                            fragment: e
                        } : h.buildFragment(c, this,
                            o);
                        f = e.fragment;
                        if (b = f.childNodes.length === 1 ? f = f.firstChild : f.firstChild) {
                            a = a && h.nodeName(b, "tr");
                            b = 0;
                            for (var r = this.length, j = r - 1; b < r; b++) d.call(a ? h.nodeName(this[b], "table") ? this[b].getElementsByTagName("tbody")[0] || this[b].appendChild(this[b].ownerDocument.createElement("tbody")) : this[b] : this[b], e.cacheable || r > 1 && b < j ? h.clone(f, !0, !0) : f)
                        }
                        o.length && h.each(o, s)
                    }
                    return this
                }
            });
            h.buildFragment = function(c, a, d) {
                var e, b, f, g;
                a && a[0] && (g = a[0].ownerDocument || a[0]);
                g.createDocumentFragment || (g = v);
                if (c.length ===
                    1 && typeof c[0] === "string" && c[0].length < 512 && g === v && c[0].charAt(0) === "<" && !wa.test(c[0]) && (h.support.checkClone || !xa.test(c[0]))) b = !0, (f = h.fragments[c[0]]) && f !== 1 && (e = f);
                e || (e = g.createDocumentFragment(), h.clean(c, g, e, d));
                b && (h.fragments[c[0]] = f ? e : 1);
                return {
                    fragment: e,
                    cacheable: b
                }
            };
            h.fragments = {};
            h.each({
                appendTo: "append",
                prependTo: "prepend",
                insertBefore: "before",
                insertAfter: "after",
                replaceAll: "replaceWith"
            }, function(c, a) {
                h.fn[c] = function(d) {
                    var e = [],
                        d = h(d),
                        b = this.length === 1 && this[0].parentNode;
                    if (b &&
                        b.nodeType === 11 && b.childNodes.length === 1 && d.length === 1) return d[a](this[0]), this;
                    else {
                        for (var b = 0, f = d.length; b < f; b++) {
                            var g = (b > 0 ? this.clone(!0) : this).get();
                            h(d[b])[a](g);
                            e = e.concat(g)
                        }
                        return this.pushStack(e, c, d.selector)
                    }
                }
            });
            h.extend({
                clone: function(c, b, f) {
                    var g = c.cloneNode(!0),
                        o, r, s;
                    if ((!h.support.noCloneEvent || !h.support.noCloneChecked) && (c.nodeType === 1 || c.nodeType === 11) && !h.isXMLDoc(c)) {
                        e(c, g);
                        o = d(c);
                        r = d(g);
                        for (s = 0; o[s]; ++s) r[s] && e(o[s], r[s])
                    }
                    if (b && (a(c, g), f)) {
                        o = d(c);
                        r = d(g);
                        for (s = 0; o[s]; ++s) a(o[s],
                            r[s])
                    }
                    return g
                },
                clean: function(c, a, d, e) {
                    a = a || v;
                    typeof a.createElement === "undefined" && (a = a.ownerDocument || a[0] && a[0].ownerDocument || v);
                    for (var b = [], f, g = 0, o;
                        (o = c[g]) != null; g++)
                        if (typeof o === "number" && (o += ""), o) {
                            if (typeof o === "string")
                                if (ab.test(o)) {
                                    o = o.replace(ua, "<$1></$2>");
                                    f = (va.exec(o) || ["", ""])[1].toLowerCase();
                                    var s = H[f] || H._default,
                                        j = s[0],
                                        i = a.createElement("div");
                                    for (i.innerHTML = s[1] + o + s[2]; j--;) i = i.lastChild;
                                    if (!h.support.tbody) {
                                        j = $a.test(o);
                                        s = f === "table" && !j ? i.firstChild && i.firstChild.childNodes :
                                            s[1] === "<table>" && !j ? i.childNodes : [];
                                        for (f = s.length - 1; f >= 0; --f) h.nodeName(s[f], "tbody") && !s[f].childNodes.length && s[f].parentNode.removeChild(s[f])
                                    }!h.support.leadingWhitespace && ja.test(o) && i.insertBefore(a.createTextNode(ja.exec(o)[0]), i.firstChild);
                                    o = i.childNodes
                                } else o = a.createTextNode(o);
                            var l;
                            if (!h.support.appendChecked)
                                if (o[0] && typeof(l = o.length) === "number")
                                    for (f = 0; f < l; f++) r(o[f]);
                                else r(o);
                            o.nodeType ? b.push(o) : b = h.merge(b, o)
                        }
                    if (d) {
                        c = function(c) {
                            return !c.type || bb.test(c.type)
                        };
                        for (g = 0; b[g]; g++) e &&
                            h.nodeName(b[g], "script") && (!b[g].type || b[g].type.toLowerCase() === "text/javascript") ? e.push(b[g].parentNode ? b[g].parentNode.removeChild(b[g]) : b[g]) : (b[g].nodeType === 1 && (a = h.grep(b[g].getElementsByTagName("script"), c), b.splice.apply(b, [g + 1, 0].concat(a))), d.appendChild(b[g]))
                    }
                    return b
                },
                cleanData: function(c) {
                    for (var a, d, e = h.cache, b = h.expando, f = h.event.special, g = h.support.deleteExpando, o = 0, r;
                        (r = c[o]) != null; o++)
                        if (!r.nodeName || !h.noData[r.nodeName.toLowerCase()])
                            if (d = r[h.expando]) {
                                if ((a = e[d] && e[d][b]) &&
                                    a.events) {
                                    for (var s in a.events) f[s] ? h.event.remove(r, s) : h.removeEvent(r, s, a.handle);
                                    if (a.handle) a.handle.elem = null
                                }
                                g ? delete r[h.expando] : r.removeAttribute && r.removeAttribute(h.expando);
                                delete e[d]
                            }
                }
            });
            var ka = /alpha\([^)]*\)/i,
                cb = /opacity=([^)]*)/,
                db = /([A-Z]|^ms)/g,
                ya = /^-?\d+(?:px)?$/i,
                eb = /^-?\d/,
                fb = /^([\-+])=([\-+.\de]+)/,
                gb = {
                    position: "absolute",
                    visibility: "hidden",
                    display: "block"
                },
                Na = ["Left", "Right"],
                Oa = ["Top", "Bottom"],
                W, za, Aa;
            h.fn.css = function(c, a) {
                return arguments.length === 2 && a === void 0 ? this :
                    h.access(this, c, a, !0, function(c, a, d) {
                        return d !== void 0 ? h.style(c, a, d) : h.css(c, a)
                    })
            };
            h.extend({
                cssHooks: {
                    opacity: {
                        get: function(c, a) {
                            if (a) {
                                var d = W(c, "opacity", "opacity");
                                return d === "" ? "1" : d
                            } else return c.style.opacity
                        }
                    }
                },
                cssNumber: {
                    fillOpacity: !0,
                    fontWeight: !0,
                    lineHeight: !0,
                    opacity: !0,
                    orphans: !0,
                    widows: !0,
                    zIndex: !0,
                    zoom: !0
                },
                cssProps: {
                    "float": h.support.cssFloat ? "cssFloat" : "styleFloat"
                },
                style: function(c, a, d, e) {
                    if (c && !(c.nodeType === 3 || c.nodeType === 8 || !c.style)) {
                        var b, f = h.camelCase(a),
                            g = c.style,
                            o = h.cssHooks[f],
                            a = h.cssProps[f] || f;
                        if (d !== void 0) {
                            e = typeof d;
                            if (e === "string" && (b = fb.exec(d))) d = +(b[1] + 1) * +b[2] + parseFloat(h.css(c, a)), e = "number";
                            if (!(d == null || e === "number" && isNaN(d)))
                                if (e === "number" && !h.cssNumber[f] && (d += "px"), !o || !("set" in o) || (d = o.set(c, d)) !== void 0) try {
                                    g[a] = d
                                } catch (r) {}
                        } else return o && "get" in o && (b = o.get(c, !1, e)) !== void 0 ? b : g[a]
                    }
                },
                css: function(c, a, d) {
                    var e, b, a = h.camelCase(a);
                    b = h.cssHooks[a];
                    a = h.cssProps[a] || a;
                    a === "cssFloat" && (a = "float");
                    if (b && "get" in b && (e = b.get(c, !0, d)) !== void 0) return e;
                    else if (W) return W(c,
                        a)
                },
                swap: function(c, a, d) {
                    var e = {},
                        b;
                    for (b in a) e[b] = c.style[b], c.style[b] = a[b];
                    d.call(c);
                    for (b in a) c.style[b] = e[b]
                }
            });
            h.curCSS = h.css;
            h.each(["height", "width"], function(c, a) {
                h.cssHooks[a] = {
                    get: function(c, d, e) {
                        var b;
                        if (d) {
                            if (c.offsetWidth !== 0) return x(c, a, e);
                            else h.swap(c, gb, function() {
                                b = x(c, a, e)
                            });
                            return b
                        }
                    },
                    set: function(c, a) {
                        if (ya.test(a)) {
                            if (a = parseFloat(a), a >= 0) return a + "px"
                        } else return a
                    }
                }
            });
            if (!h.support.opacity) h.cssHooks.opacity = {
                get: function(c, a) {
                    return cb.test((a && c.currentStyle ? c.currentStyle.filter :
                        c.style.filter) || "") ? parseFloat(RegExp.$1) / 100 + "" : a ? "1" : ""
                },
                set: function(c, a) {
                    var d = c.style,
                        e = c.currentStyle,
                        b = h.isNaN(a) ? "" : "alpha(opacity=" + a * 100 + ")",
                        f = e && e.filter || d.filter || "";
                    d.zoom = 1;
                    if (a >= 1 && h.trim(f.replace(ka, "")) === "" && (d.removeAttribute("filter"), e && !e.filter)) return;
                    d.filter = ka.test(f) ? f.replace(ka, b) : f + " " + b
                }
            };
            h(function() {
                if (!h.support.reliableMarginRight) h.cssHooks.marginRight = {
                    get: function(c, a) {
                        var d;
                        h.swap(c, {
                            display: "inline-block"
                        }, function() {
                            d = a ? W(c, "margin-right", "marginRight") :
                                c.style.marginRight
                        });
                        return d
                    }
                }
            });
            v.defaultView && v.defaultView.getComputedStyle && (za = function(c, a) {
                var d, e, a = a.replace(db, "-$1").toLowerCase();
                if (e = c.ownerDocument.defaultView) {
                    if (e = e.getComputedStyle(c, null)) d = e.getPropertyValue(a), d === "" && !h.contains(c.ownerDocument.documentElement, c) && (d = h.style(c, a));
                    return d
                }
            });
            v.documentElement.currentStyle && (Aa = function(c, a) {
                var d, e = c.currentStyle && c.currentStyle[a],
                    b = c.runtimeStyle && c.runtimeStyle[a],
                    h = c.style;
                if (!ya.test(e) && eb.test(e)) {
                    d = h.left;
                    if (b) c.runtimeStyle.left =
                        c.currentStyle.left;
                    h.left = a === "fontSize" ? "1em" : e || 0;
                    e = h.pixelLeft + "px";
                    h.left = d;
                    if (b) c.runtimeStyle.left = b
                }
                return e === "" ? "auto" : e
            });
            W = za || Aa;
            if (h.expr && h.expr.filters) h.expr.filters.hidden = function(c) {
                var a = c.offsetHeight;
                return c.offsetWidth === 0 && a === 0 || !h.support.reliableHiddenOffsets && (c.style.display || h.css(c, "display")) === "none"
            }, h.expr.filters.visible = function(c) {
                return !h.expr.filters.hidden(c)
            };
            var hb = /%20/g,
                Pa = /\[\]$/,
                Ba = /\r?\n/g,
                ib = /#.*$/,
                jb = /^(.*?):[ \t]*([^\r\n]*)\r?$/mg,
                kb = /^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,
                lb = /^(?:GET|HEAD)$/,
                mb = /^\/\//,
                Ca = /\?/,
                nb = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
                ob = /^(?:select|textarea)/i,
                ma = /\s+/,
                pb = /([?&])_=[^&]*/,
                Da = /^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+))?)?/,
                Ea = h.fn.load,
                fa = {},
                Fa = {},
                U, V, Ga = ["*/"] + ["*"];
            try {
                U = O.href
            } catch (vb) {
                U = v.createElement("a"), U.href = "", U = U.href
            }
            V = Da.exec(U.toLowerCase()) || [];
            h.fn.extend({
                load: function(c, a, d) {
                    if (typeof c !== "string" && Ea) return Ea.apply(this, arguments);
                    else if (!this.length) return this;
                    var e = c.indexOf(" ");
                    if (e >= 0) var b =
                        c.slice(e, c.length),
                        c = c.slice(0, e);
                    e = "GET";
                    a && (h.isFunction(a) ? (d = a, a = void 0) : typeof a === "object" && (a = h.param(a, h.ajaxSettings.traditional), e = "POST"));
                    var f = this;
                    h.ajax({
                        url: c,
                        type: e,
                        dataType: "html",
                        data: a,
                        complete: function(c, a, e) {
                            e = c.responseText;
                            c.isResolved() && (c.done(function(c) {
                                e = c
                            }), f.html(b ? h("<div>").append(e.replace(nb, "")).find(b) : e));
                            d && f.each(d, [e, a, c])
                        }
                    });
                    return this
                },
                serialize: function() {
                    return h.param(this.serializeArray())
                },
                serializeArray: function() {
                    return this.map(function() {
                        return this.elements ?
                            h.makeArray(this.elements) : this
                    }).filter(function() {
                        return this.name && !this.disabled && (this.checked || ob.test(this.nodeName) || kb.test(this.type))
                    }).map(function(c, a) {
                        var d = h(this).val();
                        return d == null ? null : h.isArray(d) ? h.map(d, function(c) {
                            return {
                                name: a.name,
                                value: c.replace(Ba, "\r\n")
                            }
                        }) : {
                            name: a.name,
                            value: d.replace(Ba, "\r\n")
                        }
                    }).get()
                }
            });
            h.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "), function(c, a) {
                h.fn[a] = function(c) {
                    return this.bind(a, c)
                }
            });
            h.each(["get", "post"],
                function(c, a) {
                    h[a] = function(c, d, e, b) {
                        h.isFunction(d) && (b = b || e, e = d, d = void 0);
                        return h.ajax({
                            type: a,
                            url: c,
                            data: d,
                            success: e,
                            dataType: b
                        })
                    }
                });
            h.extend({
                getScript: function(c, a) {
                    return h.get(c, void 0, a, "script")
                },
                getJSON: function(c, a, d) {
                    return h.get(c, a, d, "json")
                },
                ajaxSetup: function(c, a) {
                    a ? t(c, h.ajaxSettings) : (a = c, c = h.ajaxSettings);
                    t(c, a);
                    return c
                },
                ajaxSettings: {
                    url: U,
                    isLocal: /^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/.test(V[1]),
                    global: !0,
                    type: "GET",
                    contentType: "application/x-www-form-urlencoded",
                    processData: !0,
                    async: !0,
                    accepts: {
                        xml: "application/xml, text/xml",
                        html: "text/html",
                        text: "text/plain",
                        json: "application/json, text/javascript",
                        "*": Ga
                    },
                    contents: {
                        xml: /xml/,
                        html: /html/,
                        json: /json/
                    },
                    responseFields: {
                        xml: "responseXML",
                        text: "responseText"
                    },
                    converters: {
                        "* text": window.String,
                        "text html": !0,
                        "text json": h.parseJSON,
                        "text xml": h.parseXML
                    },
                    flatOptions: {
                        context: !0,
                        url: !0
                    }
                },
                ajaxPrefilter: u(fa),
                ajaxTransport: u(Fa),
                ajax: function(c, a) {
                    function d(c, a, j, i) {
                        if (m !== 2) {
                            m = 2;
                            w && clearTimeout(w);
                            x = void 0;
                            l =
                                i || "";
                            t.readyState = c > 0 ? 4 : 0;
                            var q, u, k, i = a;
                            if (j) {
                                var z = e,
                                    F = t,
                                    y = z.contents,
                                    B = z.dataTypes,
                                    A = z.responseFields,
                                    v, p, C, D;
                                for (p in A) p in j && (F[A[p]] = j[p]);
                                for (; B[0] === "*";) B.shift(), v === void 0 && (v = z.mimeType || F.getResponseHeader("content-type"));
                                if (v)
                                    for (p in y)
                                        if (y[p] && y[p].test(v)) {
                                            B.unshift(p);
                                            break
                                        }
                                if (B[0] in j) C = B[0];
                                else {
                                    for (p in j) {
                                        if (!B[0] || z.converters[p + " " + B[0]]) {
                                            C = p;
                                            break
                                        }
                                        D || (D = p)
                                    }
                                    C = C || D
                                }
                                C ? (C !== B[0] && B.unshift(C), j = j[C]) : j = void 0
                            } else j = void 0;
                            if (c >= 200 && c < 300 || c === 304) {
                                if (e.ifModified) {
                                    if (v = t.getResponseHeader("Last-Modified")) h.lastModified[s] =
                                        v;
                                    if (v = t.getResponseHeader("Etag")) h.etag[s] = v
                                }
                                if (c === 304) i = "notmodified", q = !0;
                                else try {
                                    v = e;
                                    v.dataFilter && (j = v.dataFilter(j, v.dataType));
                                    var E = v.dataTypes;
                                    p = {};
                                    var I, M, O = E.length,
                                        K, J = E[0],
                                        L, R, G, S, H;
                                    for (I = 1; I < O; I++) {
                                        if (I === 1)
                                            for (M in v.converters) typeof M === "string" && (p[M.toLowerCase()] = v.converters[M]);
                                        L = J;
                                        J = E[I];
                                        if (J === "*") J = L;
                                        else if (L !== "*" && L !== J) {
                                            R = L + " " + J;
                                            G = p[R] || p["* " + J];
                                            if (!G)
                                                for (S in H = void 0, p)
                                                    if (K = S.split(" "), K[0] === L || K[0] === "*")
                                                        if (H = p[K[1] + " " + J]) {
                                                            S = p[S];
                                                            S === !0 ? G = H : H === !0 && (G = S);
                                                            break
                                                        }!G &&
                                                !H && h.error("No conversion from " + R.replace(" ", " to "));
                                            G !== !0 && (j = G ? G(j) : H(S(j)))
                                        }
                                    }
                                    u = j;
                                    i = "success";
                                    q = !0
                                } catch (Ia) {
                                    i = "parsererror", k = Ia
                                }
                            } else if (k = i, !i || c) i = "error", c < 0 && (c = 0);
                            t.status = c;
                            t.statusText = "" + (a || i);
                            q ? g.resolveWith(b, [u, i, t]) : g.rejectWith(b, [t, i, k]);
                            t.statusCode(r);
                            r = void 0;
                            n && f.trigger("ajax" + (q ? "Success" : "Error"), [t, e, q ? u : k]);
                            o.resolveWith(b, [t, i]);
                            n && (f.trigger("ajaxComplete", [t, e]), --h.active || h.event.trigger("ajaxStop"))
                        }
                    }
                    typeof c === "object" && (a = c, c = void 0);
                    var a = a || {},
                        e = h.ajaxSetup({},
                            a),
                        b = e.context || e,
                        f = b !== e && (b.nodeType || b instanceof h) ? h(b) : h.event,
                        g = h.Deferred(),
                        o = h._Deferred(),
                        r = e.statusCode || {},
                        s, j = {},
                        i = {},
                        l, u, x, w, k, m = 0,
                        n, z, t = {
                            readyState: 0,
                            setRequestHeader: function(c, a) {
                                if (!m) {
                                    var d = c.toLowerCase(),
                                        c = i[d] = i[d] || c;
                                    j[c] = a
                                }
                                return this
                            },
                            getAllResponseHeaders: function() {
                                return m === 2 ? l : null
                            },
                            getResponseHeader: function(c) {
                                var a;
                                if (m === 2) {
                                    if (!u)
                                        for (u = {}; a = jb.exec(l);) u[a[1].toLowerCase()] = a[2];
                                    a = u[c.toLowerCase()]
                                }
                                return a === void 0 ? null : a
                            },
                            overrideMimeType: function(c) {
                                if (!m) e.mimeType =
                                    c;
                                return this
                            },
                            abort: function(c) {
                                c = c || "abort";
                                x && x.abort(c);
                                d(0, c);
                                return this
                            }
                        };
                    g.promise(t);
                    t.success = t.done;
                    t.error = t.fail;
                    t.complete = o.done;
                    t.statusCode = function(c) {
                        if (c) {
                            var a;
                            if (m < 2)
                                for (a in c) r[a] = [r[a], c[a]];
                            else a = c[t.status], t.then(a, a)
                        }
                        return this
                    };
                    e.url = ((c || e.url) + "").replace(ib, "").replace(mb, V[1] + "//");
                    e.dataTypes = h.trim(e.dataType || "*").toLowerCase().split(ma);
                    if (e.crossDomain == null) k = Da.exec(e.url.toLowerCase()), e.crossDomain = !(!k || !(k[1] != V[1] || k[2] != V[2] || (k[3] || (k[1] === "http:" ?
                        80 : 443)) != (V[3] || (V[1] === "http:" ? 80 : 443))));
                    if (e.data && e.processData && typeof e.data !== "string") e.data = h.param(e.data, e.traditional);
                    y(fa, e, a, t);
                    if (m === 2) return !1;
                    n = e.global;
                    e.type = e.type.toUpperCase();
                    e.hasContent = !lb.test(e.type);
                    n && h.active++ === 0 && h.event.trigger("ajaxStart");
                    if (!e.hasContent && (e.data && (e.url += (Ca.test(e.url) ? "&" : "?") + e.data, delete e.data), s = e.url, e.cache === !1)) {
                        k = h.now();
                        var F = e.url.replace(pb, "$1_=" + k);
                        e.url = F + (F === e.url ? (Ca.test(e.url) ? "&" : "?") + "_=" + k : "")
                    }(e.data && e.hasContent &&
                        e.contentType !== !1 || a.contentType) && t.setRequestHeader("Content-Type", e.contentType);
                    e.ifModified && (s = s || e.url, h.lastModified[s] && t.setRequestHeader("If-Modified-Since", h.lastModified[s]), h.etag[s] && t.setRequestHeader("If-None-Match", h.etag[s]));
                    t.setRequestHeader("Accept", e.dataTypes[0] && e.accepts[e.dataTypes[0]] ? e.accepts[e.dataTypes[0]] + (e.dataTypes[0] !== "*" ? ", " + Ga + "; q=0.01" : "") : e.accepts["*"]);
                    for (z in e.headers) t.setRequestHeader(z, e.headers[z]);
                    if (e.beforeSend && (e.beforeSend.call(b, t, e) ===
                            !1 || m === 2)) return t.abort(), !1;
                    for (z in {
                            success: 1,
                            error: 1,
                            complete: 1
                        }) t[z](e[z]);
                    if (x = y(Fa, e, a, t)) {
                        t.readyState = 1;
                        n && f.trigger("ajaxSend", [t, e]);
                        e.async && e.timeout > 0 && (w = setTimeout(function() {
                            t.abort("timeout")
                        }, e.timeout));
                        try {
                            m = 1, x.send(j, d)
                        } catch (B) {
                            m < 2 ? d(-1, B) : h.error(B)
                        }
                    } else d(-1, "No Transport");
                    return t
                },
                param: function(c, a) {
                    var d = [],
                        e = function(c, a) {
                            a = h.isFunction(a) ? a() : a;
                            d[d.length] = encodeURIComponent(c) + "=" + encodeURIComponent(a)
                        };
                    if (a === void 0) a = h.ajaxSettings.traditional;
                    if (h.isArray(c) ||
                        c.jquery && !h.isPlainObject(c)) h.each(c, function() {
                        e(this.name, this.value)
                    });
                    else
                        for (var b in c) w(b, c[b], a, e);
                    return d.join("&").replace(hb, "+")
                }
            });
            h.extend({
                active: 0,
                lastModified: {},
                etag: {}
            });
            var qb = h.now(),
                ca = /(\=)\?(&|$)|\?\?/i;
            h.ajaxSetup({
                jsonp: "callback",
                jsonpCallback: function() {
                    return h.expando + "_" + qb++
                }
            });
            h.ajaxPrefilter("json jsonp", function(c, a, d) {
                a = c.contentType === "application/x-www-form-urlencoded" && typeof c.data === "string";
                if (c.dataTypes[0] === "jsonp" || c.jsonp !== !1 && (ca.test(c.url) || a &&
                        ca.test(c.data))) {
                    var e, b = c.jsonpCallback = h.isFunction(c.jsonpCallback) ? c.jsonpCallback() : c.jsonpCallback,
                        f = window[b],
                        g = c.url,
                        o = c.data,
                        r = "$1" + b + "$2";
                    c.jsonp !== !1 && (g = g.replace(ca, r), c.url === g && (a && (o = o.replace(ca, r)), c.data === o && (g += (/\?/.test(g) ? "&" : "?") + c.jsonp + "=" + b)));
                    c.url = g;
                    c.data = o;
                    window[b] = function(c) {
                        e = [c]
                    };
                    d.always(function() {
                        window[b] = f;
                        if (e && h.isFunction(f)) window[b](e[0])
                    });
                    c.converters["script json"] = function() {
                        e || h.error(b + " was not called");
                        return e[0]
                    };
                    c.dataTypes[0] = "json";
                    return "script"
                }
            });
            h.ajaxSetup({
                accepts: {
                    script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
                },
                contents: {
                    script: /javascript|ecmascript/
                },
                converters: {
                    "text script": function(c) {
                        h.globalEval(c);
                        return c
                    }
                }
            });
            h.ajaxPrefilter("script", function(c) {
                if (c.cache === void 0) c.cache = !1;
                if (c.crossDomain) c.type = "GET", c.global = !1
            });
            h.ajaxTransport("script", function(c) {
                if (c.crossDomain) {
                    var a, d = v.head || v.getElementsByTagName("head")[0] || v.documentElement;
                    return {
                        send: function(e, b) {
                            a = v.createElement("script");
                            a.async = "async";
                            if (c.scriptCharset) a.charset = c.scriptCharset;
                            a.src = c.url;
                            a.onload = a.onreadystatechange = function(c, e) {
                                if (e || !a.readyState || /loaded|complete/.test(a.readyState)) a.onload = a.onreadystatechange = null, d && a.parentNode && d.removeChild(a), a = void 0, e || b(200, "success")
                            };
                            d.insertBefore(a, d.firstChild)
                        },
                        abort: function() {
                            if (a) a.onload(0, 1)
                        }
                    }
                }
            });
            var la = window.ActiveXObject ? function() {
                    for (var c in Y) Y[c](0, 1)
                } : !1,
                rb = 0,
                Y;
            h.ajaxSettings.xhr = window.ActiveXObject ? function() {
                var c;
                if (!(c = !this.isLocal &&
                        z())) a: {
                    try {
                        c = new window.ActiveXObject("Microsoft.XMLHTTP");
                        break a
                    } catch (a) {}
                    c = void 0
                }
                return c
            } : z;
            (function(c) {
                h.extend(h.support, {
                    ajax: !!c,
                    cors: !!c && "withCredentials" in c
                })
            })(h.ajaxSettings.xhr());
            h.support.ajax && h.ajaxTransport(function(c) {
                if (!c.crossDomain || h.support.cors) {
                    var a;
                    return {
                        send: function(d, e) {
                            var b = c.xhr(),
                                f, g;
                            c.username ? b.open(c.type, c.url, c.async, c.username, c.password) : b.open(c.type, c.url, c.async);
                            if (c.xhrFields)
                                for (g in c.xhrFields) b[g] = c.xhrFields[g];
                            c.mimeType && b.overrideMimeType &&
                                b.overrideMimeType(c.mimeType);
                            !c.crossDomain && !d["X-Requested-With"] && (d["X-Requested-With"] = "XMLHttpRequest");
                            try {
                                for (g in d) b.setRequestHeader(g, d[g])
                            } catch (o) {}
                            b.send(c.hasContent && c.data || null);
                            a = function(d, g) {
                                var o, r, s, j, i;
                                try {
                                    if (a && (g || b.readyState === 4)) {
                                        a = void 0;
                                        if (f) b.onreadystatechange = h.noop, la && delete Y[f];
                                        if (g) b.readyState !== 4 && b.abort();
                                        else {
                                            o = b.status;
                                            s = b.getAllResponseHeaders();
                                            j = {};
                                            if ((i = b.responseXML) && i.documentElement) j.xml = i;
                                            j.text = b.responseText;
                                            try {
                                                r = b.statusText
                                            } catch (l) {
                                                r =
                                                    ""
                                            }!o && c.isLocal && !c.crossDomain ? o = j.text ? 200 : 404 : o === 1223 && (o = 204)
                                        }
                                    }
                                } catch (u) {
                                    g || e(-1, u)
                                }
                                j && e(o, r, j, s)
                            };
                            !c.async || b.readyState === 4 ? a() : (f = ++rb, la && (Y || (Y = {}, h(window).unload(la)), Y[f] = a), b.onreadystatechange = a)
                        },
                        abort: function() {
                            a && a(0, 1)
                        }
                    }
                }
            });
            var ga = {},
                N, X, sb = /^(?:toggle|show|hide)$/,
                tb = /^([+\-]=)?([\d+.\-]+)([a-z%]*)$/i,
                da, na = [
                    ["height", "marginTop", "marginBottom", "paddingTop", "paddingBottom"],
                    ["width", "marginLeft", "marginRight", "paddingLeft", "paddingRight"],
                    ["opacity"]
                ],
                aa;
            h.fn.extend({
                show: function(c,
                    a, d) {
                    if (c || c === 0) return this.animate(B("show", 3), c, a, d);
                    else {
                        for (var d = 0, e = this.length; d < e; d++)
                            if (c = this[d], c.style) {
                                a = c.style.display;
                                if (!h._data(c, "olddisplay") && a === "none") a = c.style.display = "";
                                a === "" && h.css(c, "display") === "none" && h._data(c, "olddisplay", C(c.nodeName))
                            }
                        for (d = 0; d < e; d++)
                            if (c = this[d], c.style && (a = c.style.display, a === "" || a === "none")) c.style.display = h._data(c, "olddisplay") || "";
                        return this
                    }
                },
                hide: function(c, a, d) {
                    if (c || c === 0) return this.animate(B("hide", 3), c, a, d);
                    else {
                        c = 0;
                        for (a = this.length; c <
                            a; c++) this[c].style && (d = h.css(this[c], "display"), d !== "none" && !h._data(this[c], "olddisplay") && h._data(this[c], "olddisplay", d));
                        for (c = 0; c < a; c++)
                            if (this[c].style) this[c].style.display = "none";
                        return this
                    }
                },
                _toggle: h.fn.toggle,
                toggle: function(c, a, d) {
                    var e = typeof c === "boolean";
                    h.isFunction(c) && h.isFunction(a) ? this._toggle.apply(this, arguments) : c == null || e ? this.each(function() {
                        var a = e ? c : h(this).is(":hidden");
                        h(this)[a ? "show" : "hide"]()
                    }) : this.animate(B("toggle", 3), c, a, d);
                    return this
                },
                fadeTo: function(c, a, d,
                    e) {
                    return this.filter(":hidden").css("opacity", 0).show().end().animate({
                        opacity: a
                    }, c, d, e)
                },
                animate: function(c, a, d, e) {
                    var b = h.speed(a, d, e);
                    if (h.isEmptyObject(c)) return this.each(b.complete, [!1]);
                    c = h.extend({}, c);
                    return this[b.queue === !1 ? "each" : "queue"](function() {
                        var q;
                        b.queue === !1 && h._mark(this);
                        var a = h.extend({}, b),
                            d = this.nodeType === 1,
                            e = d && h(this).is(":hidden"),
                            f, g, o, r, s;
                        a.animatedProperties = {};
                        for (o in c) {
                            f = h.camelCase(o);
                            o !== f && (c[f] = c[o], delete c[o]);
                            g = c[f];
                            h.isArray(g) ? (a.animatedProperties[f] =
                                g[1], q = c[f] = g[0], g = q) : a.animatedProperties[f] = a.specialEasing && a.specialEasing[f] || a.easing || "swing";
                            if (g === "hide" && e || g === "show" && !e) return a.complete.call(this);
                            if (d && (f === "height" || f === "width"))
                                if (a.overflow = [this.style.overflow, this.style.overflowX, this.style.overflowY], h.css(this, "display") === "inline" && h.css(this, "float") === "none") h.support.inlineBlockNeedsLayout ? (g = C(this.nodeName), g === "inline" ? this.style.display = "inline-block" : (this.style.display = "inline", this.style.zoom = 1)) : this.style.display =
                                    "inline-block"
                        }
                        if (a.overflow != null) this.style.overflow = "hidden";
                        for (o in c)
                            if (d = new h.fx(this, a, o), g = c[o], sb.test(g)) d[g === "toggle" ? e ? "show" : "hide" : g]();
                            else f = tb.exec(g), r = d.cur(), f ? (g = parseFloat(f[2]), s = f[3] || (h.cssNumber[o] ? "" : "px"), s !== "px" && (h.style(this, o, (g || 1) + s), r *= (g || 1) / d.cur(), h.style(this, o, r + s)), f[1] && (g = (f[1] === "-=" ? -1 : 1) * g + r), d.custom(r, g, s)) : d.custom(r, g, "");
                        return !0
                    })
                },
                stop: function(c, a) {
                    c && this.queue([]);
                    this.each(function() {
                        var c = h.timers,
                            d = c.length;
                        for (a || h._unmark(!0, this); d--;)
                            if (c[d].elem ===
                                this) {
                                if (a) c[d](!0);
                                c.splice(d, 1)
                            }
                    });
                    a || this.dequeue();
                    return this
                }
            });
            h.each({
                slideDown: B("show", 1),
                slideUp: B("hide", 1),
                slideToggle: B("toggle", 1),
                fadeIn: {
                    opacity: "show"
                },
                fadeOut: {
                    opacity: "hide"
                },
                fadeToggle: {
                    opacity: "toggle"
                }
            }, function(c, a) {
                h.fn[c] = function(c, d, e) {
                    return this.animate(a, c, d, e)
                }
            });
            h.extend({
                speed: function(c, a, d) {
                    var e = c && typeof c === "object" ? h.extend({}, c) : {
                        complete: d || !d && a || h.isFunction(c) && c,
                        duration: c,
                        easing: d && a || a && !h.isFunction(a) && a
                    };
                    e.duration = h.fx.off ? 0 : typeof e.duration ===
                        "number" ? e.duration : e.duration in h.fx.speeds ? h.fx.speeds[e.duration] : h.fx.speeds._default;
                    e.old = e.complete;
                    e.complete = function(c) {
                        h.isFunction(e.old) && e.old.call(this);
                        e.queue !== !1 ? h.dequeue(this) : c !== !1 && h._unmark(this)
                    };
                    return e
                },
                easing: {
                    linear: function(c, a, d, e) {
                        return d + e * c
                    },
                    swing: function(c, a, d, e) {
                        return (-Math.cos(c * Math.PI) / 2 + 0.5) * e + d
                    }
                },
                timers: [],
                fx: function(c, a, d) {
                    this.options = a;
                    this.elem = c;
                    this.prop = d;
                    a.orig = a.orig || {}
                }
            });
            h.fx.prototype = {
                update: function() {
                    this.options.step && this.options.step.call(this.elem,
                        this.now, this);
                    (h.fx.step[this.prop] || h.fx.step._default)(this)
                },
                cur: function() {
                    if (this.elem[this.prop] != null && (!this.elem.style || this.elem.style[this.prop] == null)) return this.elem[this.prop];
                    var c, a = h.css(this.elem, this.prop);
                    return isNaN(c = parseFloat(a)) ? !a || a === "auto" ? 0 : a : c
                },
                custom: function(c, a, d) {
                    function e(c) {
                        return b.step(c)
                    }
                    var b = this,
                        f = h.fx;
                    this.startTime = aa || A();
                    this.start = c;
                    this.end = a;
                    this.unit = d || this.unit || (h.cssNumber[this.prop] ? "" : "px");
                    this.now = this.start;
                    this.pos = this.state = 0;
                    e.elem =
                        this.elem;
                    e() && h.timers.push(e) && !da && (da = setInterval(f.tick, f.interval))
                },
                show: function() {
                    this.options.orig[this.prop] = h.style(this.elem, this.prop);
                    this.options.show = !0;
                    this.custom(this.prop === "width" || this.prop === "height" ? 1 : 0, this.cur());
                    h(this.elem).show()
                },
                hide: function() {
                    this.options.orig[this.prop] = h.style(this.elem, this.prop);
                    this.options.hide = !0;
                    this.custom(this.cur(), 0)
                },
                step: function(c) {
                    var a = aa || A(),
                        d = !0,
                        e = this.elem,
                        b = this.options,
                        f;
                    if (c || a >= b.duration + this.startTime) {
                        this.now = this.end;
                        this.pos = this.state = 1;
                        this.update();
                        b.animatedProperties[this.prop] = !0;
                        for (f in b.animatedProperties) b.animatedProperties[f] !== !0 && (d = !1);
                        if (d) {
                            b.overflow != null && !h.support.shrinkWrapBlocks && h.each(["", "X", "Y"], function(c, a) {
                                e.style["overflow" + a] = b.overflow[c]
                            });
                            b.hide && h(e).hide();
                            if (b.hide || b.show)
                                for (var g in b.animatedProperties) h.style(e, g, b.orig[g]);
                            b.complete.call(e)
                        }
                        return !1
                    } else b.duration == Infinity ? this.now = a : (c = a - this.startTime, this.state = c / b.duration, this.pos = h.easing[b.animatedProperties[this.prop]](this.state,
                        c, 0, 1, b.duration), this.now = this.start + (this.end - this.start) * this.pos), this.update();
                    return !0
                }
            };
            h.extend(h.fx, {
                tick: function() {
                    for (var c = h.timers, a = 0; a < c.length; ++a) c[a]() || c.splice(a--, 1);
                    c.length || h.fx.stop()
                },
                interval: 13,
                stop: function() {
                    clearInterval(da);
                    da = null
                },
                speeds: {
                    slow: 600,
                    fast: 200,
                    _default: 400
                },
                step: {
                    opacity: function(c) {
                        h.style(c.elem, "opacity", c.now)
                    },
                    _default: function(c) {
                        c.elem.style && c.elem.style[c.prop] != null ? c.elem.style[c.prop] = (c.prop === "width" || c.prop === "height" ? Math.max(0, c.now) :
                            c.now) + c.unit : c.elem[c.prop] = c.now
                    }
                }
            });
            if (h.expr && h.expr.filters) h.expr.filters.animated = function(c) {
                return h.grep(h.timers, function(a) {
                    return c === a.elem
                }).length
            };
            var ub = /^t(?:able|d|h)$/i,
                Ha = /^(?:body|html)$/i;
            h.fn.offset = "getBoundingClientRect" in v.documentElement ? function(c) {
                var a = this[0],
                    d;
                if (c) return this.each(function(a) {
                    h.offset.setOffset(this, c, a)
                });
                if (!a || !a.ownerDocument) return null;
                if (a === a.ownerDocument.body) return h.offset.bodyOffset(a);
                try {
                    d = a.getBoundingClientRect()
                } catch (e) {}
                var b =
                    a.ownerDocument,
                    f = b.documentElement;
                if (!d || !h.contains(f, a)) return d ? {
                    top: d.top,
                    left: d.left
                } : {
                    top: 0,
                    left: 0
                };
                a = b.body;
                b = p(b);
                return {
                    top: d.top + (b.pageYOffset || h.support.boxModel && f.scrollTop || a.scrollTop) - (f.clientTop || a.clientTop || 0),
                    left: d.left + (b.pageXOffset || h.support.boxModel && f.scrollLeft || a.scrollLeft) - (f.clientLeft || a.clientLeft || 0)
                }
            } : function(c) {
                var a = this[0];
                if (c) return this.each(function(a) {
                    h.offset.setOffset(this, c, a)
                });
                if (!a || !a.ownerDocument) return null;
                if (a === a.ownerDocument.body) return h.offset.bodyOffset(a);
                h.offset.initialize();
                var d, e = a.offsetParent,
                    b = a.ownerDocument,
                    f = b.documentElement,
                    g = b.body;
                d = (b = b.defaultView) ? b.getComputedStyle(a, null) : a.currentStyle;
                for (var o = a.offsetTop, r = a.offsetLeft;
                    (a = a.parentNode) && a !== g && a !== f;) {
                    if (h.offset.supportsFixedPosition && d.position === "fixed") break;
                    d = b ? b.getComputedStyle(a, null) : a.currentStyle;
                    o -= a.scrollTop;
                    r -= a.scrollLeft;
                    if (a === e) {
                        o += a.offsetTop;
                        r += a.offsetLeft;
                        if (h.offset.doesNotAddBorder && (!h.offset.doesAddBorderForTableAndCells || !ub.test(a.nodeName))) o +=
                            parseFloat(d.borderTopWidth) || 0, r += parseFloat(d.borderLeftWidth) || 0;
                        e = a.offsetParent
                    }
                    h.offset.subtractsBorderForOverflowNotVisible && d.overflow !== "visible" && (o += parseFloat(d.borderTopWidth) || 0, r += parseFloat(d.borderLeftWidth) || 0)
                }
                if (d.position === "relative" || d.position === "static") o += g.offsetTop, r += g.offsetLeft;
                h.offset.supportsFixedPosition && d.position === "fixed" && (o += Math.max(f.scrollTop, g.scrollTop), r += Math.max(f.scrollLeft, g.scrollLeft));
                return {
                    top: o,
                    left: r
                }
            };
            h.offset = {
                initialize: function() {
                    var c =
                        v.body,
                        a = v.createElement("div"),
                        d, e, b, f = parseFloat(h.css(c, "marginTop")) || 0;
                    h.extend(a.style, {
                        position: "absolute",
                        top: 0,
                        left: 0,
                        margin: 0,
                        border: 0,
                        width: "1px",
                        height: "1px",
                        visibility: "hidden"
                    });
                    a.innerHTML = "<div style='position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;'><div></div></div><table style='position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;' cellpadding='0' cellspacing='0'><tr><td></td></tr></table>";
                    c.insertBefore(a,
                        c.firstChild);
                    d = a.firstChild;
                    e = d.firstChild;
                    b = d.nextSibling.firstChild.firstChild;
                    this.doesNotAddBorder = e.offsetTop !== 5;
                    this.doesAddBorderForTableAndCells = b.offsetTop === 5;
                    e.style.position = "fixed";
                    e.style.top = "20px";
                    this.supportsFixedPosition = e.offsetTop === 20 || e.offsetTop === 15;
                    e.style.position = e.style.top = "";
                    d.style.overflow = "hidden";
                    d.style.position = "relative";
                    this.subtractsBorderForOverflowNotVisible = e.offsetTop === -5;
                    this.doesNotIncludeMarginInBodyOffset = c.offsetTop !== f;
                    c.removeChild(a);
                    h.offset.initialize =
                        h.noop
                },
                bodyOffset: function(c) {
                    var a = c.offsetTop,
                        d = c.offsetLeft;
                    h.offset.initialize();
                    h.offset.doesNotIncludeMarginInBodyOffset && (a += parseFloat(h.css(c, "marginTop")) || 0, d += parseFloat(h.css(c, "marginLeft")) || 0);
                    return {
                        top: a,
                        left: d
                    }
                },
                setOffset: function(c, a, d) {
                    var e = h.css(c, "position");
                    if (e === "static") c.style.position = "relative";
                    var b = h(c),
                        f = b.offset(),
                        g = h.css(c, "top"),
                        o = h.css(c, "left"),
                        r = {},
                        s = {};
                    (e === "absolute" || e === "fixed") && h.inArray("auto", [g, o]) > -1 ? (s = b.position(), e = s.top, o = s.left) : (e = parseFloat(g) ||
                        0, o = parseFloat(o) || 0);
                    h.isFunction(a) && (a = a.call(c, d, f));
                    if (a.top != null) r.top = a.top - f.top + e;
                    if (a.left != null) r.left = a.left - f.left + o;
                    "using" in a ? a.using.call(c, r) : b.css(r)
                }
            };
            h.fn.extend({
                position: function() {
                    if (!this[0]) return null;
                    var c = this[0],
                        a = this.offsetParent(),
                        d = this.offset(),
                        e = Ha.test(a[0].nodeName) ? {
                            top: 0,
                            left: 0
                        } : a.offset();
                    d.top -= parseFloat(h.css(c, "marginTop")) || 0;
                    d.left -= parseFloat(h.css(c, "marginLeft")) || 0;
                    e.top += parseFloat(h.css(a[0], "borderTopWidth")) || 0;
                    e.left += parseFloat(h.css(a[0],
                        "borderLeftWidth")) || 0;
                    return {
                        top: d.top - e.top,
                        left: d.left - e.left
                    }
                },
                offsetParent: function() {
                    return this.map(function() {
                        for (var a = this.offsetParent || v.body; a && !Ha.test(a.nodeName) && h.css(a, "position") === "static";) a = a.offsetParent;
                        return a
                    })
                }
            });
            h.each(["Left", "Top"], function(a, d) {
                var e = "scroll" + d;
                h.fn[e] = function(d) {
                    var b, f;
                    if (d === void 0) {
                        b = this[0];
                        return !b ? null : (f = p(b)) ? "pageXOffset" in f ? f[a ? "pageYOffset" : "pageXOffset"] : h.support.boxModel && f.document.documentElement[e] || f.document.body[e] : b[e]
                    }
                    return this.each(function() {
                        (f =
                            p(this)) ? f.scrollTo(!a ? d : h(f).scrollLeft(), a ? d : h(f).scrollTop()): this[e] = d
                    })
                }
            });
            h.each(["Height", "Width"], function(a, d) {
                var e = d.toLowerCase();
                h.fn["inner" + d] = function() {
                    var a = this[0];
                    return a && a.style ? parseFloat(h.css(a, e, "padding")) : null
                };
                h.fn["outer" + d] = function(a) {
                    var c = this[0];
                    return c && c.style ? parseFloat(h.css(c, e, a ? "margin" : "border")) : null
                };
                h.fn[e] = function(a) {
                    var c = this[0];
                    if (!c) return a == null ? null : this;
                    if (h.isFunction(a)) return this.each(function(c) {
                        var d = h(this);
                        d[e](a.call(this, c, d[e]()))
                    });
                    if (h.isWindow(c)) {
                        var b = c.document.documentElement["client" + d],
                            c = c.document.body;
                        return h.support.boxModel && b || c && c["client" + d] || b
                    } else return c.nodeType === 9 ? Math.max(c.documentElement["client" + d], c.body["scroll" + d], c.documentElement["scroll" + d], c.body["offset" + d], c.documentElement["offset" + d]) : a === void 0 ? (b = h.css(c, e), c = parseFloat(b), h.isNaN(c) ? b : c) : this.css(e, typeof a === "string" ? a : a + "px")
                }
            });
            h.fn.offsetNoIPadFix = h.fn.offset;
            h.fn.offsetIPadFix = h.fn.offset;
            if (/webkit.*mobile/i.test(I.userAgent) &&
                parseFloat(h.browser.version) < 532.9 && "getBoundingClientRect" in v.documentElement) h.fn.offsetIPadFix = function() {
                var a = this.offsetNoIPadFix();
                a && (a.top -= window.scrollY, a.left -= window.scrollX);
                return a
            }, h.fn.offset = h.fn.offsetIPadFix;
            return h
        })
    })
})(function() {
    var p = window.AmazonUIPageJS || P,
        b = p.attributeErrors;
    return b ? b("AmazonUIjQuery") : p
}());
(function(p) {
    p.execute(function() {
        p.when("jQuery").register("a-base", function(b) {
            return {
                version: function() {
                    return "3.0"
                },
                $: b
            }
        });
        p.when("a-base", "p-weblab").register("a-util", function(b, n) {
            var m = b.$,
                k = function() {
                    function a(d, b, f) {
                        if (d !== null)
                            if (Array.prototype.forEach && d.forEach === Array.prototype.forEach) d.forEach(b, f);
                            else if (d.length === +d.length)
                            for (var g = 0, j = d.length; g < j; g++) {
                                if (g in d && b.call(f, d[g], g, d) === e) break
                            } else
                                for (g in d)
                                    if (d.hasOwnProperty(g) && b.call(f, d[g], g, d) === {}) break
                    }
                    var e = {};
                    return {
                        each: a,
                        map: function(e, b, f) {
                            var g = [];
                            if (e === null) return g;
                            if (Array.prototype.map && e.map === Array.prototype.map) return e.map(b, f);
                            a(e, function(a, d, e) {
                                g[g.length] = b.call(f, a, d, e)
                            });
                            if (e.length === +e.length) g.length = e.length;
                            return g
                        },
                        reduce: function(e, b, f, g) {
                            var o = arguments.length > 2;
                            e === null && (e = []);
                            if (Array.prototype.reduce && e.reduce === Array.prototype.reduce) return o ? e.reduce(b, f) : e.reduce(b);
                            a(e, function(a, d, e) {
                                o ? f = b.call(g, f, a, d, e) : (f = a, o = !0)
                            });
                            o || p.error("Reduce of empty array with no initial value", "A.util",
                                "reduce");
                            return f
                        },
                        breaker: e
                    }
                }(),
                i = function() {
                    return {
                        throttle: function(d, e, b) {
                            var f, g, j, i = null,
                                l = 0;
                            b || (b = {});
                            var k = function() {
                                l = b.leading === !1 ? 0 : a.now();
                                i = null;
                                j = d.apply(f, g);
                                f = g = null
                            };
                            return function() {
                                var m = a.now();
                                !l && b.leading === !1 && (l = m);
                                var n = e - (m - l);
                                f = this;
                                g = arguments;
                                n <= 0 ? (clearTimeout(i), i = null, l = m, j = d.apply(f, g), f = g = null) : !i && b.trailing !== !1 && (i = setTimeout(k, n));
                                return j
                            }
                        },
                        debounce: function(d, e, b) {
                            var f, g, j, i, l, k = function() {
                                var m = a.now() - i;
                                m < e ? f = setTimeout(k, e - m) : (f = null, b || (l = d.apply(j,
                                    g), j = g = null))
                            };
                            return function() {
                                j = this;
                                g = arguments;
                                i = a.now();
                                var m = b && !f;
                                f || (f = setTimeout(k, e));
                                m && (l = d.apply(j, g), j = g = null);
                                return l
                            }
                        },
                        delay: function(a, e) {
                            var b = Array.prototype.slice.call(arguments, 2);
                            return setTimeout(function() {
                                return a.apply(null, b)
                            }, e)
                        },
                        interval: function(a, e) {
                            return setInterval(a, e)
                        }
                    }
                }(),
                l = function() {
                    var a, e;
                    a = /^\s+/;
                    e = /\s+$/;
                    return {
                        trim: function(b) {
                            return String.prototype.trim ? String.prototype.trim.call(b) : b.replace(a, "").replace(e, "")
                        },
                        contains: function(a, d) {
                            return ("" + a).indexOf(d) !==
                                -1
                        }
                    }
                }(),
                j = function() {
                    function a() {
                        for (var e = arguments[0], b = 1, f = arguments.length; b < f; b++) k.each(arguments[b], function(b, f) {
                            var g;
                            m.isArray(b) ? (g = !m.isArray(e[f]) && !m.isPlainObject(e[f]) ? [] : e[f], e[f] = a(g, b)) : m.isPlainObject(b) ? (g = !m.isPlainObject(e[f]) ? {} : e[f], e[f] = a(g, b)) : e[f] = b
                        });
                        return e
                    }

                    function e(a, d) {
                        var a = a || {},
                            d = d || {},
                            b = {},
                            f;
                        for (f in a) a.hasOwnProperty(f) && (b[f] = typeof a[f] === "object" && a[f] ? e(a[f], d[f]) : a[f] !== d[f]);
                        for (f in d) d.hasOwnProperty(f) && !b[f] && (b[f] = typeof d[f] === "object" && d[f] ? e(d[f],
                            a[f]) : d[f] !== a[f]);
                        return b
                    }

                    function b(a, d) {
                        var e;
                        if (a === d) return !0;
                        if (m.isArray(a)) {
                            if (!m.isArray(d) || a.length !== d.length) return !1;
                            for (e = a.length; e--;)
                                if (!b(a[e], d[e])) return !1;
                            return !0
                        }
                        if (m.isPlainObject(a)) {
                            if (!m.isPlainObject(d)) return !1;
                            for (e in a)
                                if (!b(a[e], d[e])) return !1;
                            return !0
                        }
                        return !1
                    }
                    return {
                        extend: a,
                        diff: e,
                        equals: b,
                        copy: function(e) {
                            return m.isArray(e) ? e.slice(0) : m.isPlainObject(e) ? a({}, e) : e
                        },
                        indexOfArray: function(a, d, e) {
                            if (Array.prototype.indexOf && a.indexOf === Array.prototype.indexOf) return a.indexOf(d,
                                e);
                            a && a instanceof Array || p.error("Invalid arr passed to A.indexOfArray: " + a, "A.util", "indexOfArray");
                            e = parseInt(e, 10);
                            e = isNaN(e) ? 0 : e;
                            if (!isFinite(e)) return -1;
                            for (var b = a.length; e < b; e++)
                                if (a[e] === d) return e;
                            return -1
                        },
                        isFiniteNumber: function(a) {
                            return typeof a === "number" && !isNaN(a) && isFinite(a)
                        },
                        objectIsEmpty: function(a) {
                            for (var d in a)
                                if (a.hasOwnProperty(d)) return !1;
                            return !0
                        }
                    }
                }(),
                f = function() {
                    return {
                        onScreen: function(a) {
                            var e = m(a);
                            if (!e.is(":visible")) return !1;
                            var b = m(window),
                                a = b.scrollTop(),
                                b = window.innerHeight ?
                                window.innerHeight : b.height(),
                                f = a + b;
                            a -= 100;
                            f += 100;
                            var g = e.offset().top,
                                e = e.height(),
                                j = g + e;
                            return g >= a && g < f || j > a && j <= f || e > b && g <= a && j >= f
                        }
                    }
                }(),
                g = function() {
                    return {
                        setCssImportant: function(a, e, b) {
                            a = a.jquery ? a[0] : a;
                            if (typeof a !== "undefined") a = a.style, a.cssText = a.cssText.replace(RegExp(e + "\\s*:\\s*[.^;]*(\\s*;)?", "gmi"), ""), a.cssText += e + ": " + b + " !important;"
                        }
                    }
                }(),
                a = function() {
                    return {
                        now: function() {
                            return Date.now()
                        }
                    }
                }(),
                e = function() {
                    return {
                        hasWeblab: function(a, e) {
                            var b = a.toUpperCase(),
                                f = e.toUpperCase();
                            return n[b] ? n[b] === f : !1
                        }
                    }
                }();
            return {
                now: a.now,
                extend: j.extend,
                copy: j.copy,
                diff: j.diff,
                equals: j.equals,
                objectIsEmpty: j.objectIsEmpty,
                indexOfArray: j.indexOfArray,
                isFiniteNumber: j.isFiniteNumber,
                parseJSON: function(a) {
                    return m.parseJSON(a)
                },
                throttle: i.throttle,
                debounce: i.debounce,
                delay: i.delay,
                interval: i.interval,
                trim: l.trim,
                contains: l.contains,
                map: k.map,
                reduce: k.reduce,
                each: k.each,
                breaker: k.breaker,
                onScreen: f.onScreen,
                setCssImportant: g.setCssImportant,
                hasWeblab: e.hasWeblab
            }
        });
        p.when("p-detect", "a-util").register("a-detect",
            function(b, n) {
                var m;
                try {
                    m = navigator.userAgent
                } catch (k) {
                    m = ""
                }
                var i = n.copy(b),
                    l = {};
                n.each({
                    isAmazonApp: function() {
                        return /Windowshop/.test(m)
                    },
                    isGen5App: function() {
                        return /Windowshop.*(?:KFOT|KFTH|KFJWA|KFJWI|KFTT)/.test(m)
                    },
                    androidVersion: function() {
                        var b = /(?:Android\s+|Windowshop.*Android\/)(\d+\.\d+(?:\.\d+)*)/.exec(m);
                        if (b[1]) return b[1]
                    },
                    isChrome: function() {
                        return /Chrome/.test(m)
                    },
                    chromeVersion: function() {
                        var b = /Chrome\/(\d+\.\d+(?:\.\d+)*)/.exec(m);
                        if (b[1]) return b[1]
                    },
                    isAndroidStockGuess: function() {
                        var b = !1;
                        i.capabilities.android && !/Chrome|Opera|Firefox|UCBrowser/.test(m) && (b = /AppleWebKit\/(\d+\.\d+)/.exec(m), b = b[1] && b[1] < "535");
                        return b
                    },
                    isFirefox: function() {
                        return /Firefox/.test(m)
                    },
                    isOldAndroid: function() {
                        return /Android\s[12]/.test(m)
                    },
                    isIE10: function() {
                        return /Trident/.test(m) && "onmspointerup" in document && !("onpointerup" in document)
                    },
                    isIE10Plus: function() {
                        return /Trident/.test(m) && ("onpointerup" in document || "onmspointerup" in document)
                    },
                    isIE11Plus: function() {
                        return /Trident/.test(m) && "onpointerup" in
                            document
                    },
                    isIETouchCapable: function() {
                        return i.capabilities.isIE10Plus && /Touch;/.test(m)
                    },
                    isMetroIEGuess: function() {
                        var b = !0;
                        try {
                            b = new ActiveXObject("htmlfile")
                        } catch (g) {
                            b = !1
                        }
                        return i.capabilities.isIE10Plus && !i.capabilities.mobile && !b
                    },
                    pointerPrefix: function() {
                        return "onmspointerup" in document || "onpointerup" in document ? "onpointerup" in document ? "pointer" : "MSPointer" : !1
                    },
                    actionMode: function() {
                        var b = i.capabilities.pointerPrefix;
                        return b ? b : i.capabilities.touch ? "touch" : "mouse"
                    }
                }, function(b, g) {
                    var a = i.capabilities,
                        e;
                    try {
                        e = b()
                    } catch (d) {
                        e = !1
                    }
                    a[g] = e
                });
                n.each({
                    start: {
                        mouse: "down",
                        touch: "start",
                        pointer: "down",
                        MSPointer: "Down"
                    },
                    end: {
                        mouse: "up",
                        touch: "end",
                        pointer: "up",
                        MSPointer: "Up"
                    },
                    move: {
                        mouse: "move",
                        touch: "move",
                        pointer: "move",
                        MSPointer: "Move"
                    },
                    enter: {
                        mouse: "enter",
                        touch: "enter",
                        pointer: "enter"
                    },
                    leave: {
                        mouse: "leave",
                        touch: "leave",
                        pointer: "leave"
                    },
                    cancel: {
                        touch: "cancel",
                        pointer: "cancel",
                        MSPointer: "Cancel"
                    },
                    over: {
                        mouse: "over",
                        pointer: "over",
                        MSPointer: "Over"
                    },
                    out: {
                        mouse: "out",
                        pointer: "out",
                        MSPointer: "Out"
                    }
                }, function(b,
                    g) {
                    var a = i.capabilities.actionMode,
                        e = typeof b === "string" ? b : b[a];
                    l[g] = e ? a + e : b.mouse === void 0 ? "" : "mouse" + b.mouse
                });
                i.action = l;
                var j = {};
                if (i.capabilities.pointerPrefix === "pointer") j.touch = "touch", j.pen = "pen", j.mouse = "mouse", j.unknown = "";
                else if (i.capabilities.pointerPrefix === "MSPointer") j.touch = 2, j.pen = 3, j.mouse = 4;
                i.pointerType = j;
                return i
            });
        p.when("a-util", "a-events").register("a-prefix", function(b, n) {
            function m(b) {
                return b.toLowerCase().replace(/-(.)/g, function(b, a) {
                    return a.toUpperCase()
                })
            }
            var k = {
                    transitionend: null
                },
                i = document.createElement("div").style,
                l = {},
                j = ["o", "ms", "moz", "webkit"];
            n.on("beforeReady", function() {
                if (window.addEventListener) {
                    var f = document.createElement("div"),
                        g = function(a) {
                            k.transitionend = a.type;
                            this.removeEventListener("webkitTransitionEnd", g, !1);
                            this.removeEventListener("transitionend", g, !1);
                            this.removeEventListener("otransitionend", g, !1);
                            this.removeEventListener("oTransitionEnd", g, !1)
                        };
                    f.setAttribute("style", "position:absolute;top:0px;z-index:-1;transition:top 1ms ease;-webkit-transition:top 1ms ease;-moz-transition:top 1ms ease;-o-transition:top 1ms ease;");
                    f.addEventListener("transitionend", g, !1);
                    f.addEventListener("webkitTransitionEnd", g, !1);
                    f.addEventListener("otransitionend", g, !1);
                    this.addEventListener("oTransitionEnd", g, !1);
                    document.body.appendChild(f);
                    b.delay(function() {
                        f.style.top = "100px";
                        b.delay(function() {
                            f.parentNode.removeChild(f);
                            f = g = null;
                            b.each(k, function() {})
                        }, 100)
                    }, 0)
                }
            });
            return {
                prefixes: {
                    getStyle: function(b) {
                        if (!l[b]) {
                            var g = m(b);
                            if (g in i) l[b] = g;
                            else
                                for (var g = g.charAt(0).toUpperCase() + g.slice(1), a = j.length; a--;) {
                                    var e = j[a] + g;
                                    e in i &&
                                        (l[b] = e)
                                }
                        }
                        return l[b]
                    },
                    getEvent: function(b) {
                        return b ? k[b.toLowerCase()] : void 0
                    }
                }
            }
        });
        p.register("a-defer", function() {
            function b(f) {
                var g = 0,
                    a = setTimeout(function() {
                        b(f)
                    }, 0);
                if (k || f.length === 0) clearTimeout(a), m = !1;
                else {
                    var e = Date.now();
                    try {
                        f.shift().call()
                    } catch (d) {
                        p.error("Deferred execution failed: " + d.message, "A.defer", "partialExecute")
                    }
                    j += Date.now() - e;
                    j > i && (g = l, j = 0);
                    setTimeout(function() {
                        clearTimeout(a);
                        b(f)
                    }, g)
                }
            }
            var n = [],
                m = !1,
                k = !1,
                i = 50,
                l = 50,
                j = 0;
            return {
                defer: function(f) {
                    n.push(f);
                    !m && !k && (m = !0, setTimeout(function() {
                            b(n)
                        },
                        0))
                },
                pauseDeferred: function() {
                    k = !0
                },
                executeDeferred: function() {
                    k = !1;
                    m = !0;
                    setTimeout(function() {
                        b(n)
                    }, 0)
                }
            }
        });
        p.when("a-base", "a-util", "p-detect").register("a-events", function(b, n, m) {
            function k(a, e) {
                e !== !1 && f.makeTopicTimeSliced(a);
                l[a] = !0;
                f.subscribe(a, function() {
                    p.register(a, function() {
                        var a = window.aPageStart || n.now();
                        return {
                            time: n.now() - a
                        }
                    })
                });
                f.publish(a);
                f.unsubscribe(a)
            }

            function i() {
                if (!l.beforeLoad || !l.load) k("beforeLoad"), k("load"), setTimeout(function() {
                        k("beforeAfterLoad");
                        k("afterLoad")
                    },
                    1500)
            }
            var b = b.$,
                l = {},
                j = b(window),
                f = function() {
                    function a(d) {
                        for (var e = setTimeout(a, 0), i = n.now(), l;
                            (l = f.shift()) !== void 0;) try {
                            if (l.fn.apply(window, l.args) === !1) {
                                clearTimeout(e);
                                for (var k = l.id, m = void 0, F = [], B = 0, C = f.length; B < C; B++) m = f[B].id, k !== m && F.push(f[B]);
                                f = F
                            }
                            if (d === !0 && n.now() - i >= g) {
                                clearTimeout(e);
                                n.delay(a, j);
                                return
                            }
                        } catch (E) {
                            p.error("Event execution failed for event " + l.topic + ": " + (E && E.message || E), "A.events", "partialPublish")
                        }
                        clearTimeout(e);
                        b = !1
                    }
                    var e = {},
                        d = 0,
                        b = !1,
                        f = [],
                        g = 50,
                        j = 15;
                    return {
                        publish: function(g) {
                            var j =
                                e[g];
                            if (j) {
                                var i = j.isTimeSliced,
                                    s = Array.prototype.slice.call(arguments, 1),
                                    l = d++,
                                    k = function(a) {
                                        f.push({
                                            topic: g,
                                            id: l,
                                            fn: a,
                                            args: s
                                        })
                                    };
                                if (i)
                                    for (var m;
                                        (m = j.shift()) !== void 0;) k(m);
                                else {
                                    m = 0;
                                    for (var n = j.length; m < n; m++) k(j[m])
                                }
                                b || (b = !0, a(i))
                            }
                        },
                        subscribe: function(a, d) {
                            e[a] || (e[a] = []);
                            if (typeof d === "function") return e[a].unshift(d), {
                                event: a,
                                callback: d
                            }
                        },
                        unsubscribe: function(a, d) {
                            for (var b, f = a.split(" ");
                                (b = f.pop()) !== void 0;)
                                if (e[b])
                                    if (d) {
                                        b = e[b];
                                        for (var g = 0, o = b.length; g < o; g++) b[g] === d && b.splice(g--, 1)
                                    } else e[b] = []
                        },
                        makeTopicTimeSliced: function(a) {
                            e[a] || (e[a] = []);
                            e[a].isTimeSliced = !0
                        }
                    }
                }(),
                g = function() {
                    var a = function(a, d, b) {
                        var g = a.split(" "),
                            j = [],
                            i = d;
                        for (b === !0 && (i = function() {
                                d.apply(window, arguments);
                                f.unsubscribe(a, i)
                            });
                            (b = g.pop()) !== void 0;) l[b] ? (f.subscribe(b, d), f.publish(b), f.unsubscribe(b)) : j.push(f.subscribe(b, i).event);
                        return {
                            event: j.join(" "),
                            callback: i
                        }
                    };
                    n.each("ready,load,unload,afterLoad,scroll,resize,orientationchange,zoom".split(","), function(e) {
                        a[e] = function() {
                            a.apply(window, [e].concat([].slice.call(arguments,
                                0)))
                        }
                    });
                    return a
                }();
            b(document).ready(function() {
                m.responsiveGridEnabled() && m.toggleResponsiveGrid(!0);
                k("beforeReady");
                k("ready");
                k("afterReady");
                document.readyState === "complete" && i()
            });
            j.load(i);
            j.unload(function() {
                k("unload")
            });
            return {
                on: g,
                one: function(a, e) {
                    var d = a.split(" ");
                    if (d.length > 1) p.error("A.one only accepts a single event name, but was provided with: " + d.length + ", (" + a + ")", "A.events", "one");
                    else return g(a, e, !0)
                },
                off: function(a, e) {
                    if (typeof a === "object") a = a.event, e = a.callback;
                    return f.unsubscribe(a,
                        e)
                },
                trigger: function() {
                    f.publish.apply(window, arguments)
                },
                events: {
                    defaults: {
                        input: "change",
                        select: "change",
                        a: "click",
                        button: "click",
                        form: "submit"
                    }
                }
            }
        });
        p.when("a-base", "a-util", "a-events").register("a-declarative", function(b, n, m) {
            function k(b) {
                var g = l(b.currentTarget),
                    a = l(b.target);
                if (b.type === "submit") {
                    var e = a.closest("form");
                    e.length && (a = e)
                }
                if (e = g.data("action")) e = e.split(" "), n.each(e, function(d) {
                    var e = j[d] || {},
                        r = g.data(d),
                        i = b.type,
                        i = {
                            $target: a,
                            $currentTarget: g,
                            targetTag: a.prop("tagName").toLowerCase(),
                            type: i,
                            action: d,
                            data: r,
                            $event: b,
                            $declarativeParent: g
                        },
                        d = "a:declarative:" + d;
                    m.trigger(d, i);
                    m.trigger(d + ":" + b.type, i);
                    d = !1;
                    r ? d = !!r.allowLinkDefault : e && (d = !!e.allowLinkDefault);
                    b.type === "click" && !d ? (e = a.closest("a"), e = e.length && (e[0].href === "#" || b.currentTarget === e[0] || e.parent(".a-declarative").length)) : e = !1;
                    e && b.preventDefault()
                })
            }

            function i() {
                var b, g, a, e;
                switch (arguments.length) {
                    case 2:
                        b = arguments[0];
                        e = arguments[1];
                        break;
                    case 3:
                        b = arguments[0];
                        g = arguments[1];
                        e = arguments[2];
                        break;
                    case 4:
                        b = arguments[0],
                            g = arguments[1], a = arguments[2], e = arguments[3]
                }
                b && (typeof b === "string" && (b = n.trim(b).split(" ")), n.each(b, function(d) {
                    var b = "a:declarative:" + d;
                    j[d] = a || {};
                    if (g) g = typeof g === "string" ? n.trim(g).split(" ") : g, n.each(g, function(a) {
                        m.on(b + ":" + a, e)
                    });
                    else m.on(b, e)
                }))
            }
            var l = b.$,
                j = {};
            l(document).delegate(".a-declarative", "click dblclick mousedown mouseup mouseenter mouseleave mousemove change submit touchstart touchend touchmove touchcancel keydown keyup keypress MSPointerDown pointerdown MSPointerUp pointerup MSPointerMove pointermove MSPointerCancel pointercancel MSPointerOver pointerenter MSPointerOut pointerleave",
                k).delegate(".a-gesture", "tap swipe swipe-horizontal swipe-vertical pan-horizontal pan-vertical doubleTap", k);
            i.create = function(b, g, a) {
                var e = b.jquery && b.length ? b : l(b);
                if (e.length && g) {
                    var d = e.data("action");
                    e.data("action", d ? d + " " + g : g).data(g, a ? a : {});
                    e.addClass("a-declarative")
                }
                return b
            };
            i.remove = function(b, g) {
                var a = b.jquery && b.length ? b : l(b),
                    e = a.data("action"),
                    g = g || e;
                if (a.length && e) {
                    for (var e = e.split(" "), d = e.length; d--;)(e[d] === g || e[d] === "") && e.splice(d, 1);
                    e.length ? a.data("action", e.join("")) : a.data("action",
                        null).removeClass("a-declarative");
                    a.data(g, null)
                }
                return b
            };
            return {
                declarative: i
            }
        });
        p.when("a-base", "a-util", "a-events", "a-declarative").register("a-state", function(b, n, m, k) {
            function i(a, e, d, b) {
                if (e === null || f.isArray(e) || f.isPlainObject(e)) {
                    var j = n.copy(g[a]);
                    !j || !e || b ? g[a] = n.copy(e) : n.extend(g[a], e);
                    b = n.diff(j, g[a]);
                    j = n.copy(g[a]);
                    d || m.trigger("a:state:update:" + a, j, b, e);
                    return j
                } else p.error("Invalid value passed to A.state with a namespace of " + a + ".  Value: " + e, "A.state", "updateNamespace")
            }

            function l(a,
                e, d) {
                if (e.length === 1) return a[e.shift()] = d, a;
                a[e.shift()] = l({}, e, d);
                return a
            }

            function j() {
                for (var a = document.getElementsByTagName("script"), e = 0, d = a.length; e < d; e++)
                    if (!f.data(a[e], "a-eval")) {
                        var b = f(a[e]),
                            j = b.attr("data-a-state");
                        if (j && (j = n.parseJSON(j), j.key)) {
                            b = n.parseJSON(b.html());
                            f.data(a[e], "a-eval", !0);
                            var s = g[j.key];
                            s && n.extend(b, s);
                            i(j.key, b)
                        }
                    }
            }
            var f = b.$,
                g = {};
            k.declarative("a-state", function(a) {
                var e = a.$target,
                    d = a.data.key,
                    b = a.data[a.type];
                !b && m.events.defaults[a.targetTag] === a.type && (b = e.attr("name"));
                b && d && (e.is("select") && (e = e.find(":selected")), typeof e.val() !== void 0 && typeof b === "string" && (a = e.val(), e.is("input[type=checkbox]") && !e.prop("checked") && (a = null), b = l({}, b.split("."), a)), i(d, b))
            });
            b = function(a, e, d) {
                return e === void 0 ? n.copy(g[a]) : i(a, e, !!d)
            };
            b.bind = function(a, e) {
                m.on("a:state:update:" + a, e)
            };
            b.replace = function(a, e, d) {
                return i(a, e, !!d, !0)
            };
            m.on("beforeReady", j);
            b.parse = j;
            return {
                state: b
            }
        });
        p.when("a-base", "a-util", "a-events", "a-declarative", "a-state").register("a-ajax", function(b, n, m,
            k, i) {
            function l(a) {
                return !a || typeof a === "string" ? "" : g.param(a)
            }

            function j(a, e) {
                a && a.length !== 0 && (typeof a === "string" && n.trim(a) === "" ? e && e(a) : (a[0] instanceof Array || (a = [a]), n.each(a, function(b) {
                    var f = d[b[0]];
                    f ? f.apply(window, b) : ((f = e) || p.error("There is no handler for the streaming ajax command: " + a[0], "A.ajax", "chunkHandler"), f(b))
                })))
            }

            function f(d, e) {
                var e = e || {},
                    b = e.headers || {};
                if (e.accepts !== a) b.Accept = e.accepts;
                if (e.contentType !== a) b["Content-Type"] = e.contentType;
                return o["a-ajax-update"]({
                    url: d,
                    cache: e.cache,
                    params: l(e.params),
                    method: e.method,
                    chunk: e.chunk,
                    success: e.success,
                    failure: e.failure || e.error,
                    abort: e.abort,
                    indicator: e.indicator,
                    timeout: e.timeout,
                    headers: b,
                    withCredentials: !!e.withCredentials
                })
            }
            var g = b.$,
                a, e = function() {
                    var a, d;
                    if (!window.XMLHttpRequest) window.XMLHttpRequest = function() {
                        return new ActiveXObject("Microsoft.XMLHTTP")
                    };
                    var e = function() {
                        function a() {
                            d.length > 0 ? d.pop().send() : e--
                        }
                        var d = [],
                            e = 0;
                        return {
                            add: function(a) {
                                e < 4 ? (a.send(), e++) : d.push(a)
                            },
                            complete: a,
                            abort: function(e) {
                                n.each(d,
                                    function(a, b) {
                                        if (a === e) return d.splice(b, 1), n.breaker
                                    });
                                a()
                            }
                        }
                    }();
                    a = 4;
                    d = function() {};
                    var b = function(d) {
                            var b = d.http,
                                f = d.responsePosition,
                                g = b.readyState === 3,
                                o = b.readyState === a && (b.status === 200 || b.status === 304);
                            if (g || o)
                                if (o = b.responseText, f < o.length) {
                                    var f = o.substring(f, o.length),
                                        o = f.split("&&&"),
                                        j = f.lastIndexOf("&&&");
                                    if (j === -1 && g) return;
                                    j < f.length - 3 && g && o.pop();
                                    n.each(o, function(a) {
                                        var e;
                                        if (n.trim(a) !== "") try {
                                            e = n.parseJSON(a)
                                        } catch (b) {
                                            n.delay(function() {
                                                p.error("Invalid streaming ajax JSON response: " +
                                                    a, "A.ajax", "streamingResponseHandler")
                                            }, 0)
                                        } else e = a;
                                        d.callbacks.chunk(e)
                                    });
                                    d.responsePosition += j
                                }
                            b.readyState === a && (clearInterval(d.pollTimer), clearTimeout(d.timeoutTimer), e.complete(), b.status !== 200 && b.status !== 304 ? d.callbacks.failure(d, b.statusText, b.statusText) : d.callbacks.success(null, b.statusText, d), m.trigger("a:pageUpdate"), m.trigger("a:ajax:complete"))
                        },
                        f = function(d) {
                            var b = d.http;
                            if (b.readyState === a) {
                                clearInterval(d.pollTimer);
                                clearTimeout(d.timeoutTimer);
                                e.complete();
                                var f = b.responseText;
                                try {
                                    var g = n.parseJSON(f);
                                    g && (f = g)
                                } catch (o) {}
                                b.status !== 200 && b.status !== 304 ? d.callbacks.failure(d, b.statusText, b.statusText) : d.callbacks.success(f, b.statusText, d);
                                m.trigger("a:ajax:complete")
                            }
                        };
                    return function() {
                        function g(d) {
                            if (d.http.readyState < a) {
                                clearInterval(d.pollTimer);
                                var b = "Request Timeout";
                                try {
                                    b = d.http.statusText
                                } catch (f) {}
                                d.callbacks.failure(d, b, b);
                                e.complete()
                            }
                        }

                        function o(a, d, e) {
                            e = e || {};
                            e = n.extend({}, i.all, i[d], e);
                            n.each(e, function(d, e) {
                                (d || d === "") && a.setRequestHeader(e, d)
                            });
                            return a
                        }

                        function j(a,
                            d, b, f, g, i, h, r, l, s) {
                            var k = a.http;
                            k.open(d, b);
                            o(k, d, l);
                            a.timeout = f;
                            a.callbacks.chunk = g || a.callbacks.chunk;
                            a.callbacks.success = i || a.callbacks.success;
                            a.callbacks.failure = h || a.callbacks.failure;
                            a.callbacks.abort = r || a.callbacks.abort;
                            if (s) k.withCredentials = !0;
                            e.add(a);
                            return {
                                abort: function() {
                                    a.abort()
                                }
                            }
                        }
                        var i = {
                                all: {
                                    "X-Requested-With": "XMLHttpRequest"
                                },
                                get: {
                                    Accept: "text/html,*/*"
                                },
                                post: {
                                    Accept: "text/html,*/*",
                                    "Content-Type": "application/x-www-form-urlencoded"
                                }
                            },
                            l = function() {
                                var a = new XMLHttpRequest;
                                this.pollTimer =
                                    null;
                                this.http = a;
                                this.responsePosition = 0;
                                this.buffer = "";
                                this.callbacks = {
                                    success: d,
                                    failure: d,
                                    chunk: d,
                                    abort: d
                                }
                            };
                        l.prototype = {
                            send: function() {
                                var a = this;
                                a.http.send(a.params);
                                a.pollTimer = setInterval(function() {
                                    if (a.http.readyState >= 2 && typeof a.http.responseText !== "unknown") {
                                        var d = a.http.getResponseHeader("Content-Type"),
                                            d = d ? d.toLowerCase() : "";
                                        (d.indexOf("application/json-amazonui-streaming") !== -1 || d.indexOf("application/amazonui-streaming-json") !== -1 ? b : f)(a)
                                    }
                                }, 25);
                                a.timeout = typeof a.timeout === "undefined" ?
                                    2E4 : a.timeout;
                                a.timeoutTimer = setTimeout(g, a.timeout, a)
                            },
                            get: function(a, d, e, b, f, g, h, o, i) {
                                if (d) {
                                    var r = a.indexOf("?"),
                                        l = a.charAt(a.length - 1);
                                    r > -1 ? l !== "?" && l !== "&" && (a += "&") : a += "?";
                                    a += d
                                }
                                return j(this, "get", a, e, b, f, g, h, o, i)
                            },
                            abort: function() {
                                this.http && this.http.abort();
                                clearInterval(this.pollTimer);
                                clearTimeout(this.timeoutTimer);
                                e.abort(this);
                                this.callbacks.abort(this)
                            },
                            post: function(a, d, e, b, f, g, h, o, i) {
                                this.params = d;
                                return j(this, "post", a, e, b, f, g, h, o, i)
                            }
                        };
                        return l
                    }()
                }(),
                d = {
                    update: function(a, d, e) {
                        g(d).html(e)
                    },
                    append: function(a, d, e) {
                        a = g(d);
                        a.html(a.html() + e)
                    },
                    prepend: function(a, d, e) {
                        a = g(d);
                        a.html(e + a.html())
                    },
                    state: function(a, d, e) {
                        i.state(d, e)
                    },
                    script: function(a, d) {
                        eval(d)
                    }
                },
                o = {
                    "a-ajax-update": function(a) {
                        var d = new e,
                            b = function() {
                                var a = window.ue;
                                a && a.tag && (a.tag("aui"), a.tag("aui:ajax"))
                            },
                            f = a.abort,
                            o = g(a.indicator);
                        o.show();
                        var i = typeof a.method === "string" && a.method.toLowerCase() === "post" ? "post" : "get";
                        i === "get" && a.cache === !1 && (a.params += [a.params === "" ? "" : "&", "_=", (new Date).getTime()].join(""));
                        return d[i](a.url,
                            a.params, a.timeout,
                            function(d) {
                                b();
                                j(d, a.chunk)
                            },
                            function() {
                                o.hide();
                                b();
                                a.success && a.success.apply(window, arguments)
                            },
                            function() {
                                o.hide();
                                b();
                                a.failure && a.failure.apply(window, arguments)
                            }, f, a.headers, a.withCredentials)
                    }
                };
            k.declarative("a-ajax-update", function(a) {
                var d = a.$target,
                    e = a.action,
                    b = a.data;
                if (b || m.events.defaults[a.targetTag] === a.type)
                    if (typeof b !== "object" || b[a.type]) {
                        var b = b || {},
                            f = b.url || d.attr("href") || d.attr("action"),
                            g = l(b.params),
                            j = d.attr("method") || b.method,
                            i = b.indicator,
                            b = b.timeout;
                        f || p.error("No ajax url provided.", "A.ajax", "declarativeHandler");
                        a.targetTag === "form" && a.type === m.events.defaults.form && (d = d.serialize(), g += d);
                        a.$event.preventDefault();
                        return o[e]({
                            url: f,
                            params: g,
                            method: j,
                            indicator: i,
                            operation: e,
                            timeout: b
                        })
                    }
            });
            return {
                ajax: f,
                get: function(a, d) {
                    d = d || {};
                    d.method = "get";
                    return f(a, d)
                },
                post: function(a, d) {
                    d = d || {};
                    d.method = "post";
                    return f(a, d)
                }
            }
        });
        p.when("a-base", "a-util", "p-detect", "a-prefix").register("a-animate", function(b, n, m, k) {
            function i(a, e, b) {
                a = a.jquery ? a[0] : a;
                e =
                    k.prefixes.getStyle(e);
                a.style[e] = b
            }

            function l(a) {
                var e = "",
                    b = m.capabilities.transform3d;
                a.top !== g && a.left !== g ? (e = "translate", b && (e += "3d"), e += "(" + a.left + ", " + a.top, b && (e += ", 0"), e += ")") : (a.top !== g ? e = "translateY(" + a.top + ")" : a.left !== g && (e = "translateX(" + a.left + ")"), b && (e += " translateZ(0)"));
                a.scale !== g && (e += " scale(" + a.scale + ")");
                return e
            }

            function j(d) {
                var e = {},
                    b = !1;
                n.each(a, function(a) {
                    a in d && (b = !0, e[a] = d[a], delete d[a])
                });
                return b ? e : null
            }

            function f(a, e, b) {
                m.capabilities.transform ? (typeof b === "string" &&
                    (b = parseInt(b, 10)), n.isFiniteNumber(b) || (b = 0), a = parseInt(a.css(e), 10), n.isFiniteNumber(a) || (a = 0), b -= a, b += "px") : n.isFiniteNumber(b) && (b += "px");
                return b
            }
            var g, a = ["top", "left", "scale"],
                b = {
                    animate: function(a, e, b, f, g) {
                        if (!a._a) a._a = 0;
                        a._a++;
                        var j = function() {
                            a._a--;
                            g && g()
                        };
                        a.queue("fx", [function() {
                            a.animate(e, {
                                duration: b,
                                easing: f === "linear" ? f : "swing",
                                complete: j,
                                queue: !1
                            })
                        }])
                    },
                    fadeIn: function(a, e, b, f) {
                        a.fadeIn({
                            duration: e,
                            easing: b === "linear" ? b : "swing",
                            complete: f,
                            queue: !1
                        })
                    },
                    fadeOut: function(a, e, b, f) {
                        var g =
                            a.css("opacity");
                        a.fadeOut({
                            duration: e,
                            easing: b === "linear" ? b : "swing",
                            complete: function() {
                                +g < 0.95 && a.css("opacity", g);
                                f && f()
                            },
                            queue: !1
                        })
                    },
                    fadeToggle: function(a, e, b, f) {
                        a.fadeToggle({
                            duration: e,
                            easing: b === "linear" ? b : "swing",
                            complete: f,
                            queue: !1
                        })
                    },
                    slideUp: function(a, e, b, f) {
                        a.slideUp({
                            duration: e,
                            easing: b === "linear" ? b : "swing",
                            complete: f,
                            queue: !1
                        })
                    },
                    slideDown: function(a, e, b, f) {
                        a.slideDown({
                            duration: e,
                            easing: b === "linear" ? b : "swing",
                            complete: f,
                            queue: !1
                        })
                    },
                    slideToggle: function(a, e, b, f) {
                        a.slideToggle({
                            duration: e,
                            easing: b === "linear" ? b : "swing",
                            complete: f,
                            queue: !1
                        })
                    },
                    isAnimated: function(a) {
                        a = a.jquery ? a[0] : a;
                        return a._a && a._a > 0
                    }
                },
                e = {
                    animate: function(a, e, b, k, x) {
                        var u = a[0],
                            e = n.copy(e),
                            b = b === g ? 250 : b,
                            k = k || "linear";
                        if (e.top !== g) e.top = f(a, "top", e.top);
                        if (e.left !== g) e.left = f(a, "left", e.left);
                        i(a, "transition", b < 4 ? "all 0ms" : "all " + b + "ms " + k);
                        if (b > 4) {
                            if (u._a === g) u._a = 0;
                            u._a++;
                            var p = function() {
                                u._a--;
                                u._a || i(a, "transition", "");
                                x && x()
                            };
                            n.delay(function() {
                                n.delay(p, b)
                            }, 0)
                        }
                        m.capabilities.transform && (k = j(e)) && i(a, "transform",
                            l({
                                top: k.top,
                                left: k.left,
                                scale: k.scale
                            }));
                        n.objectIsEmpty(e) || a.css(e);
                        b <= 4 && x && n.delay(x, 0)
                    },
                    fadeIn: function(a, e, b, f) {
                        if (a.css("display") === "none" || +a.css("opacity") < 0.05) {
                            var g = a.css("opacity") || 1;
                            if (!g || +g < 0.05) g = 1;
                            a.css("opacity", "0").show();
                            var j = this.animate;
                            n.delay(function() {
                                j(a, {
                                    opacity: g
                                }, e, b, function() {
                                    f && f()
                                })
                            }, 0)
                        } else f && f()
                    },
                    fadeOut: function(a, e, b, f) {
                        var g = a.css("opacity");
                        a.css("display") !== "none" && +g > 0.05 ? this.animate(a, {
                                opacity: 0
                            }, e, b, function() {
                                a.hide().css("opacity", g);
                                f && f()
                            }) :
                            f && f()
                    },
                    fadeToggle: function(a, e, b, f) {
                        (a.css("display") === "none" || +a.css("opacity") < 0.05 ? this.fadeIn : this.fadeOut).call(this, a, e, b, f)
                    },
                    slideUp: function(a, e, b, f) {
                        var g = this.animate;
                        a.css({
                            height: a.innerHeight(),
                            overflow: "hidden"
                        });
                        n.delay(function() {
                            g(a, {
                                height: 0
                            }, e, b, function() {
                                a.hide();
                                a.css({
                                    height: "",
                                    overflow: ""
                                });
                                f && f()
                            })
                        }, 0)
                    },
                    slideDown: function(a, e, b, f) {
                        var g = a.innerHeight(),
                            j = this.animate;
                        a.css({
                            height: 0,
                            overflow: "hidden"
                        });
                        a.show();
                        n.delay(function() {
                            j(a, {
                                height: g
                            }, e, b, function() {
                                f && f();
                                a.css({
                                    height: "",
                                    overflow: ""
                                })
                            })
                        }, 0)
                    },
                    slideToggle: function(a, e, b, f) {
                        (a.is(":visible") ? this.slideUp : this.slideDown).call(this, a, e, b, f)
                    },
                    isAnimated: function(a) {
                        a = a.jquery ? a[0] : a;
                        return a._a && a._a > 0
                    }
                };
            return m.capabilities.transition ? e : b
        });
        p.when("a-base", "a-util", "a-events", "a-defer", "p-detect").register("a-image", function(b, n, m, k, i) {
            function l(a) {
                var a = f(a),
                    e = a.data("a-dynamic-image");
                if (e && typeof e === "object") {
                    var b = a.data("a-dynamic-image-container");
                    typeof b === "undefined" && (b = a.closest(".a-dynamic-image-container"),
                        b.length === 0 && (b = a.parent()), a.data("a-dynamic-image-container", b));
                    var g = window.devicePixelRatio ? window.devicePixelRatio : 1,
                        o = b.width() * g,
                        j = b.height() * g,
                        i = Number.MAX_VALUE,
                        l = Number.MAX_VALUE,
                        k = a.attr("src") || "",
                        m, p = o / j;
                    n.each(e, function(a, d) {
                        var e = parseInt(a[0], 10),
                            b = parseInt(a[1], 10);
                        e -= j;
                        b -= o;
                        b = p >= 1 ? b : e;
                        Math.abs(b) < l && b >= 0 && (l = Math.abs(b), m = d);
                        Math.abs(b) < i && (i = Math.abs(b), k = d)
                    });
                    m && (k = m);
                    d.schedule(k, a);
                    d.fill();
                    return k
                }
            }

            function j() {
                f("img.a-dynamic-image").each(function() {
                    f(this).data("a-manual-replacement") ||
                        l(this)
                })
            }
            var f = b.$;
            f(window);
            var g = document.getElementsByTagName("img"),
                a = {},
                e = function() {
                    return {
                        canLoad: function() {
                            return !0
                        },
                        inFlight: 0,
                        limit: function() {
                            return 2
                        }
                    }
                }(),
                d = function() {
                    var d = [],
                        b = {};
                    return {
                        schedule: function(e, f) {
                            b[e] || (d.push(e), b[e] = !0);
                            a[e] = a[e] || [];
                            for (var g = 0; g < a[e].length; g++)
                                if (f.is(a[e][g])) return;
                            a[e].push(f)
                        },
                        fill: function() {
                            if (e.canLoad())
                                for (var a = 0; a < e.limit() - e.inFlight; a++)
                                    if (d.length > 0) {
                                        var f = d.shift();
                                        b[f] = !1;
                                        o.load(f)
                                    }
                        }
                    }
                }(),
                o = function() {
                    function b(d) {
                        var e = a[d];
                        e && e.length >
                            0 && n.each(e, function(a) {
                                k.defer(function() {
                                    a.attr("src", d)
                                })
                            })
                    }
                    var o = {};
                    return {
                        load: function(a) {
                            o[a] && b(a);
                            if (o[a] !== !1) {
                                var f = new Image;
                                f.onload = function() {
                                    e.inFlight--;
                                    b(a);
                                    o[a] = !0;
                                    d.fill()
                                };
                                f.onerror = function() {
                                    e.inFlight--;
                                    o[a] = !1;
                                    d.fill()
                                };
                                e.inFlight++;
                                k.defer(function() {
                                    f.src = a
                                })
                            }
                        },
                        poll: function() {
                            n.each(g, function(a) {
                                a = f(a);
                                !a.data("a-hires-loaded") && !a.is(":hidden") && n.onScreen(a) && !a.data("a-manual-replacement") && (a.data("a-hires") && d.schedule(a.data("a-hires"), a), a.data("a-hires-loaded", !0))
                            })
                        }
                    }
                }();
            i.capabilities.hires && m.on.ready(function() {
                n.interval(function() {
                    o.poll();
                    d.fill()
                }, 2E3)
            });
            m.on.ready(j);
            f(window).resize(j);
            return {
                loadHiResImage: function(a) {
                    var e = [];
                    f(a).each(function() {
                        var a = f(this),
                            b = a.data("a-hires");
                        b && (d.schedule(b, a), d.fill(), e.push(b));
                        a.data("a-hires-loaded", !0)
                    });
                    return e
                },
                loadDynamicImage: function(a) {
                    var d = [];
                    f(a).each(function() {
                        d.push(l(this))
                    });
                    return d
                },
                loadImageManually: function(a, d) {
                    var e = [];
                    f(a, d).each(function() {
                        var a = f(this);
                        if (!a.data("a-image-already-loaded")) {
                            a.data("a-image-already-loaded", !0);
                            var d = l(a),
                                b = f("<img>").attr("src", d || a.data("a-image-source"));
                            e.push(d);
                            var d = "" + this.className,
                                g = a.data("a-extra-classes");
                            g && (d += " " + g);
                            b.attr("class", d);
                            b.attr("id", this.id);
                            b.attr("style", a.attr("style"));
                            b.attr("alt", a.attr("alt"));
                            b.attr("usemap", a.attr("usemap"));
                            b.attr("title", a.attr("title"));
                            n.each(this.attributes, function(a) {
                                a && a.name && a.name.indexOf("data-") === 0 && b.attr(a.name, a.value)
                            });
                            b.data(a.data());
                            a.replaceWith(b)
                        }
                        return e
                    })
                },
                loadDescendantImagesManually: function(a, d) {
                    return this.loadImageManually(f(a,
                        d).find("div.a-manually-loaded").filter(function() {
                        return !f(this).data("a-image-already-loaded")
                    }))
                }
            }
        });
        p.when("a-util", "a-defer", "a-base", "a-events", "a-declarative", "a-state", "a-ajax", "a-animate", "a-image", "a-constants", "a-detect", "a-browser-events", "a-preload", "a-prefix", "a-request-animation-frame").register("A", function(b) {
            var n = {};
            b.each(arguments, function(m) {
                b.extend(n, m)
            });
            return n
        });
        p.register("a-constants", function() {
            return {
                constants: {
                    keycodes: {
                        BACKSPACE: 8,
                        TAB: 9,
                        ENTER: 13,
                        ESCAPE: 27,
                        SPACE: 32,
                        LEFT_ARROW: 37,
                        UP_ARROW: 38,
                        RIGHT_ARROW: 39,
                        DOWN_ARROW: 40,
                        DELETE: 46
                    },
                    NOOP: function() {}
                }
            }
        });
        p.when("jQuery", "a-detect", "a-events", "a-util", "a-defer").register("a-browser-events", function(b, n, m, k) {
            var i, l, j;

            function f() {
                return window.orientation === s ? a() > g() ? 90 : 0 : window.orientation
            }

            function g() {
                return window.innerHeight ? window.innerHeight : document.documentElement.clientHeight
            }

            function a() {
                return window.innerWidth ? window.innerWidth : document.documentElement.clientWidth
            }

            function e() {
                return window.innerWidth ?
                    Math.round(document.documentElement.clientWidth / window.innerWidth * 10) / 10 : 1
            }

            function d(d) {
                switch (d) {
                    case i:
                        d = "orientation,height,width,zoom,scrollLeft,scrollTop".split(",");
                        break;
                    case l:
                        d = ["scrollLeft", "scrollTop"];
                        break;
                    case j:
                        d = ["height", "width", "zoom", "scrollLeft", "scrollTop"];
                        break;
                    default:
                        d = ["orientation", "height", "width", "scrollLeft", "scrollTop"]
                }
                for (var b = {}, o, k;
                    (k = d.pop()) !== s;) o = u[k], k === "orientation" ? u[k] = f() : k === "height" ? u[k] = g() : k === "width" ? u[k] = a() : k === "scrollTop" ? u[k] = window.scrollY ?
                    window.scrollY : x.scrollTop() : k === "scrollLeft" ? u[k] = window.scrollX ? window.scrollX : x.scrollLeft() : k === "zoom" && (u[k] = e()), u[k] !== o && (b[k] = o);
                return b
            }

            function o(a) {
                if (a = A[a])
                    if (a.pollCounter = a.maxPollCount, !a.intervalId) a.intervalId = setInterval(a.handler, a.pollInterval)
            }

            function r(a) {
                if ((a = A[a]) && a.intervalId) clearInterval(a.intervalId), a.intervalId = 0
            }
            var s, x = b(window);
            l = "scroll";
            j = "zoom";
            i = "all";
            var u = {
                scrollLeft: 0,
                scrollTop: 0,
                height: g(),
                width: a(),
                orientation: f(),
                zoom: e()
            };
            m.on("beforeReady", function() {
                d(i)
            });
            var p, t = {
                    speed: 0,
                    degree: 0,
                    direction: "",
                    positionX: 0,
                    positionY: 0
                },
                w = [],
                z;
            x.bind("mousemove", k.throttle(function(a) {
                a = {
                    x: a.clientX,
                    y: a.clientY
                };
                if (z) {
                    var d = z,
                        e = Math.sqrt(Math.pow(a.x - d.x, 2) + Math.pow(a.y - d.y, 2)) / 50 * 10,
                        b = Math.atan2(a.y - d.y, a.x - d.x) / (Math.PI / 180),
                        f = d = 0;
                    w.push({
                        speed: e,
                        degree: b
                    });
                    w.length > 4 && (w = w.slice(-4));
                    e = w.length;
                    for (b = 0; b < e; b++) d += w[b].speed, f += w[b].degree;
                    d = Number((d / e).toFixed(2));
                    f = Math.round(f / e);
                    t = {
                        speed: d,
                        degree: f,
                        direction: f >= 0 ? f > 157.5 ? "W" : f > 112.5 ? "SW" : f > 67.5 ? "S" : f > 22.5 ? "SE" :
                            "E" : f < -157.5 ? "W" : f < -112.5 ? "NW" : f < -67.5 ? "N" : f < -22.5 ? "NE" : "E",
                        positionX: a.x,
                        positionY: a.y
                    };
                    z = a
                } else a && (z = a)
            }, 50));
            x.bind(l, k.throttle(function() {
                var a = d(l);
                m.trigger(l, u, a)
            }, 100));
            var A = {};
            k.each(["resize", j], function(a) {
                A[a] = {
                    handler: function() {},
                    lastViewport: k.copy(u),
                    maxPollCount: 5,
                    pollCounter: 5,
                    pollInterval: 100,
                    intervalId: 0
                }
            });
            A.resize.handler = function() {
                var a = [],
                    e = A.resize;
                d("resize");
                var b = k.diff(u, e.lastViewport);
                b.orientation && a.push("orientationchange");
                b.width || b.height ? a.push("resize") :
                    n.capabilities.isIETouchCapable && b.scrollTop && a.push("resize");
                if (a.length) e.lastViewport = k.copy(u), k.each(a, function(a) {
                    m.trigger(a, u, b)
                });
                --e.pollCounter === 0 && r("resize")
            };
            A.resize.pollInterval = 100;
            A.resize.maxPollCount = 10;
            x.bind("resize", function() {
                o("resize")
            });
            A.zoom.handler = function() {
                d(j);
                var a = A.zoom,
                    e = k.diff(u, a.lastViewport);
                if (e.zoom) a.lastViewport = k.copy(u), m.trigger(j, u, e);
                --a.pollCounter === 0 && r(j)
            };
            A.zoom.pollInterval = 200;
            n.capabilities.android && x.bind("touchcancel", function(a) {
                if (a.originalEvent.changedTouches.length ===
                    2) A.zoom.maxPollCount = 15, o(j)
            });
            n.capabilities.ios && x.bind("touchend", function(a) {
                if (a.originalEvent.touches.length === 1) A.zoom.maxPollCount = 1, o(j)
            });
            !n.capabilities.ios && !n.capabilities.android && x.bind("resize", function() {
                A.zoom.maxPollCount = 5;
                o(j)
            });
            return {
                viewport: function(a) {
                    a && d(i);
                    return k.copy(u)
                },
                cursor: function() {
                    return k.copy(t)
                },
                scrollBarWidth: function(a) {
                    if (a || (document && document.body && document.body.scrollHeight ? document.body.scrollHeight : 0) > g()) {
                        if (p === s) {
                            var a = b('<div style="visibility:hidden"><div style="width:100%"></div></div>'),
                                d = a.children(),
                                e;
                            a.appendTo("body");
                            e = a[0].offsetWidth;
                            a.css("overflow", "scroll");
                            d = d[0].offsetWidth;
                            a.remove();
                            p = e - d
                        }
                        return p > 0 ? p : 15
                    } else return 0
                }
            }
        });
        p.when("a-base", "a-events").register("a-preload", function(b, n) {
            function m() {
                if (u.length > 0) s = u;
                else if (s = x, s.length === 0 || !p) return !1;
                if (E >= C) return !1;
                E++;
                return !0
            }

            function k(a, d) {
                var e = function() {
                    if (a) {
                        var d = a.parentElement;
                        d && d.removeChild(a);
                        a = null
                    }
                };
                d && clearTimeout(d);
                E = E < 1 ? 0 : E - 1;
                t ? setTimeout(e, 5) : e();
                A ? g(j, 0) : j()
            }

            function i(a) {
                var d, e, b = a.indexOf("?"),
                    b = b > 0 ? b : a.length;
                (e = a.lastIndexOf(".", b)) && (d = a.substring(e + 1, b).toLowerCase());
                return d === "gz" ? i(a.substring(0, e)) : d
            }

            function l(a, d, e) {
                var b;
                if (t || w && !e) b = g(function() {
                    k(a, b)
                }, 2500 + Math.random() * 100);
                a.onerror = function() {
                    k(a, b)
                };
                a.onload = function() {
                    k(a, b)
                }
            }

            function j() {
                if (m()) {
                    var d = s.pop(),
                        b = i(d);
                    a: {
                        for (var f = J.length; f--;)
                            if (J[f] === b) {
                                b = !0;
                                break a
                            }
                        b = !1
                    }
                    t ? f = O : A ? (f = I, b || (B >= 10 ? f = v : B === 9 && (f = h))) : f = z ? b ? I : null : I;
                    var g;
                    if (f) {
                        g = f === I ? new Image : a.createElement(f);
                        g.style.display = "none";
                        if (f === I) l(g, f,
                            b, d), g.src = d;
                        else if (f === O) g.data = d, l(g, f, b, d);
                        else if (f === h) g.type = "text/cache", l(g, f, b, d), g.src = d;
                        else if (f === v) g.rel = "stylesheet", g.media = "speech", l(g, f, b, d), g.href = d;
                        if (!(A && f === I)) try {
                            e.appendChild(g)
                        } catch (o) {
                            k();
                            return
                        }
                        G && G.count && G.count("aui:preload_fulfilled", G.count("aui:preload_fulfilled") + 1);
                        E < C && j()
                    } else k()
                }
            }

            function f(a, d) {
                if (F) {
                    if (typeof a === "string") a = [a];
                    else if (typeof a !== "object" || a === null) return;
                    var e, b;
                    for (e = 0; e < a.length; e++)(b = a[e]) && typeof b !== "string" ? f(b, d) : b && b[0] !== " " &&
                        (d.splice(Math.round(Math.random() * d.length), 0, b), G && G.count && G.count("aui:preload_asks", G.count("aui:preload_asks") + 1))
                }
            }
            var g = setTimeout,
                a = document,
                e = a.documentElement,
                d = e.style,
                o = navigator,
                r = o.userAgent,
                s = [],
                x = [],
                u = [],
                p = !1,
                t = "MozAppearance" in d,
                w = !t && "webkitAppearance" in d,
                z = w && o.vendor.indexOf("Apple") === 0,
                A = !t && !w && (o.appName.indexOf("Microsoft") === 0 || r.indexOf("Trident/") > -1),
                F = w || t || A,
                d = !A ? -1 : /Trident\/([\d]+)/.exec(r) !== null ? parseFloat(RegExp.$1) : null,
                B = !A ? -1 : !d ? 6 : d + 4,
                C = typeof window.plCount !==
                "undefined" ? window.plCount() : A && B < 8 ? 2 : 5,
                E = 0,
                v = "LINK",
                I = "IMG",
                O = "OBJECT",
                h = "SCRIPT",
                J = ["gif", "jpeg", "jpg", "png"],
                G = window.ue;
            n.on.afterLoad(function() {
                p = !0;
                j()
            });
            return {
                preload: function(a, d) {
                    d ? d(a) : (f(a, x), j())
                }
            }
        });
        p.when("a-util").register("a-request-animation-frame", function(b) {
            for (var n = 0, m = ["ms", "moz", "webkit", "o"], k = 0; k < m.length && !window.requestAnimationFrame; ++k) window.requestAnimationFrame = window[m[k] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[m[k] + "CancelAnimationFrame"] ||
                window[m[k] + "CancelRequestAnimationFrame"];
            if (!window.requestAnimationFrame) window.requestAnimationFrame = function(i) {
                var l = b.now(),
                    j = Math.max(0, 16 - (l - n)),
                    f = window.setTimeout(function() {
                        i(l + j)
                    }, j);
                n = l + j;
                return f
            };
            if (!window.cancelAnimationFrame) window.cancelAnimationFrame = function(b) {
                clearTimeout(b)
            };
            return {
                requestAnimationFrame: function(b, l) {
                    return window.requestAnimationFrame(b, l)
                },
                cancelAnimationFrame: function(b) {
                    window.cancelAnimationFrame(b)
                }
            }
        })
    })
})(function() {
    var p = window.AmazonUIPageJS || P,
        b =
        p.attributeErrors;
    return b ? b("AmazonUIBaseJS") : p
}());
(function(p) {
    p.execute(function() {})
})(function() {
    var p = window.AmazonUIPageJS || P,
        b = p.attributeErrors;
    return b ? b("AmazonUITouchJS") : p
}());
(function(p) {
    p.execute(function() {
        p.when("A", "a-popover-base-factory").register("a-popover-base-apis", function(b, n) {
            return {
                show: function(b) {
                    var k = n.get(b.$trigger ? b.$trigger : b);
                    if (k) return k.show.apply(k, arguments)
                },
                hide: function(b) {
                    var k = n.get(b);
                    if (k) return k.unlock(1), k.hide.apply(k, arguments)
                },
                get: function(b) {
                    return n.get(b)
                },
                remove: function(b) {
                    return n.remove(b)
                }
            }
        });
        p.when("A", "a-popover-iframes", "a-popover-util", "a-popover-objectclass", "a-popover-data").register("a-popover-base-factory", function(b,
            n, m, k, i) {
            function l(a) {
                return d[a] ? d[a] : null
            }

            function j(a, d) {
                var b = null;
                if (typeof a === "number") b = l(a);
                else if (typeof a === "string")(b = e[a] ? e[a] : null) || (b = l(a));
                else if (typeof a === "object")
                    if (a.$popover) b = a;
                    else {
                        var f = g(a),
                            b = f.data("a-popover-id");
                        b || (b = f.find(".a-declarative").eq(0), b = b.length ? b.data("a-popover-id") : null);
                        b = l(b);
                        if (!b) {
                            var o = f.data("action");
                            if ((o = o ? f.data(o) : null) && o.name)
                                if ((b = e[o.name] ? e[o.name] : null) && (!d || b.type === d))
                                    if ((o = (o = b.attrs("currentDataStrategy")) ? i.getStrategyByName(o) :
                                            i.guessStrategyByAttrs(b.attrs())) && o.reusePopover) {
                                        if (b.$trigger[0] !== f[0]) b.$trigger.data("a-popover-id", null), b.$trigger = f
                                    } else b = null;
                            else b = null
                        }
                    }
                return b
            }

            function f() {
                r || (r = new k.PopoverClass({
                    id: -1,
                    $popover: o,
                    $trigger: o,
                    immersive: !0
                }, {
                    isActive: function() {
                        return !0
                    },
                    hideMethod: function() {
                        this.hideChildren()
                    },
                    showMethod: b.constants.NOOP
                }));
                return r
            }
            var g = b.$,
                a = 1,
                e = {},
                d = {},
                o = g("<div style='z-index:-1;position:absolute;' />").appendTo("body"),
                r;
            return {
                getRoot: f,
                get: function(a, d) {
                    var d = d ? d : this ?
                        this.type : null,
                        e = j(a, d);
                    return e && d && e.type !== d ? null : e
                },
                create: function(o, i) {
                    var m = g(o),
                        r = i.attributes || {},
                        t = i.variant || {},
                        w = i.actionCheck || !1;
                    m.data("a-popover-id");
                    var z = r.type,
                        p = null;
                    if (z && (!m.hasClass("a-declarative") || !m.data("action") || m.data("action").indexOf(z) === -1)) m = b.declarative.create(m, "a-" + z), o = m[0];
                    if (w && m.data("action") && m.data("action").indexOf(z) === -1) return null;
                    z && m && (p = j(m));
                    return p ? p.type !== z ? null : p : (w = g(o), m = null, r.type ? !w || !w.length ? t = null : (r = b.extend({
                        id: a++,
                        $trigger: w,
                        $triggerWrapper: null,
                        $iframe: n.get()
                    }, r), t = b.copy(t), m = new k.PopoverClass(r, t), d[m.id] = m, m.name && (e[m.name] = m), w.data("a-popover-id", m.id), t = m.$trigger.closest(".a-popover"), t = !m.attrs("immersive") && t.length ? l(t.data("a-popover-id")) || f() : f(), m.parent = t, t.children.push(m), t = m) : t = null, t)
                },
                remove: function(a, f) {
                    var g = this.get(a),
                        o = !1;
                    if (g) {
                        o = g.id;
                        if (g && o > -1) {
                            var j = b.indexOfArray(g.parent.children, g),
                                i = g.$container,
                                l = g.$trigger;
                            g.parent.children.splice(j, 1);
                            g.unlock().hide();
                            g.update({
                                content: ""
                            });
                            n.release(g.$iframe);
                            i && g.$container.remove();
                            l.data("a-popover-id", "");
                            g.name && delete e[g.name];
                            delete d[o];
                            o = !0
                        } else o = !1;
                        f && b.declarative.remove(g.$trigger[0], "a-" + f)
                    }
                    return o
                }
            }
        });
        p.when("A", "a-popover-util", "a-popover-base-factory").register("a-popover-base-handlers", function(b, n, m) {
            function k(b) {
                for (var j; b.length;) {
                    if (j = b.data("a-popover-id")) break;
                    b = b.parent()
                }
                return m.get(j)
            }
            var i = b.$;
            i(document).bind("click " + b.action.start, function(l) {
                var j = i(l.target),
                    f = l.originalEvent;
                if (!f || !f.pointerType || !(f.pointerType ===
                        b.pointerType.touch && f.type === "click"))
                    if (!j.hasClass("a-modal-scroller") && !(j[0].id === "a-popover-lgtbox" || j[0].nodeName.toLowerCase() === "html")) {
                        var g = function(a) {
                            return n.eventOccursWithin(l, a)
                        };
                        b.each(m.getRoot().children, function(a) {
                            if (a.isLoaded()) {
                                var e = n.search(a, g);
                                e ? e.hideChildren() : a.attrs("lightboxOptions") === null && !a.attrs("immersive") && a.unlock(1).hide()
                            }
                        })
                    }
            });
            b.declarative("a-popover-close", ["click", b.action.start], function(b) {
                var j = k(b.$target);
                j && (j.unlock().hide(), n.trigger("dismiss",
                    j));
                b.$event.preventDefault()
            });
            b.declarative("a-popover-a11y", "keydown", function(i) {
                var j = i.$event,
                    f = j.keyCode;
                if (f === b.constants.keycodes.TAB || b.constants.keycodes.ESCAPE)
                    if (i = k(i.$target))
                        if (f === b.constants.keycodes.ESCAPE) i.hide();
                        else if (f === b.constants.keycodes.TAB) f = document.activeElement, i.$startAnchor.length && f === i.$startAnchor[0] && j.shiftKey ? i.$endAnchor.focus() : i.$endAnchor.length && f === i.$endAnchor[0] && !j.shiftKey && i.$startAnchor.focus()
            });
            b.on("resize zoom", function() {
                m.getRoot().updatePosition()
            })
        });
        p.when("A", "a-popover-base-apis", "a-popover-base-handlers").register("a-popover-base", function(b, n) {
            return n
        });
        p.when("A", "a-popover-util", "a-popover-data", "a-popover-position", "a-popover-iframes", "a-popover-lightbox").register("a-popover-objectclass", function(b, n, m, k, i, l) {
            function j(j, k) {
                var m = -1,
                    w = [1],
                    x = -2;
                this.parent = null;
                this.children = [];
                this.dependencies = {};
                this.attributes = {
                    position: "triggerVertical",
                    alone: !1,
                    immersive: !1
                };
                var E = function(a, d) {
                        var e = this.isActive(),
                            o = this.getDataStrategy(),
                            j = !this.$popover,
                            i = d || j,
                            l = !1,
                            a = a || i;
                        if (!i)
                            for (var k = w.length; k-- && !i;) i = !s[w[k]];
                        if (i) i = t.apply(this), i = g(i), j || (o.unloadContent(this), this.$popover.remove(), l = !0), g("body").append(i), this.$container = i, this.$popover = this.$container.hasClass("a-popover") ? this.$container : this.$container.find(".a-popover"), this.$startAnchor = this.$popover.hasClass("a-popover-start") ? this.$popover : this.$popover.find(".a-popover-start"), this.$endAnchor = this.$popover.find(".a-popover-end"), this.$popover.attr("id", "a-popover-" +
                            this.id).data("a-popover-id", this.id);
                        this.attrs("immersive") || (i = parseInt(this.parent.$popover.css("z-index"), 10), b.isFiniteNumber(i) || (i = this.parent.attrs("immersive") ? 1010 : 0), this.$popover.css("z-index", Math.max(299, 100 + i)));
                        if (o.shouldRefreshContent(this) || a) l || o.unloadContent(this), o.loadContent(this, j);
                        this.dependencies.updateDimensions !== f && this.dependencies.updateDimensions.apply(this);
                        w = [];
                        e && v.call(this, [], !1);
                        return this
                    },
                    v = function(a, e) {
                        function g() {
                            j.updatePosition();
                            var d = j.attrs("navigate");
                            !e && d && j.attrs("navigate", !1);
                            l.apply(j, a);
                            e && n.trigger("show", j);
                            m && m.apply(j, a);
                            e && n.trigger("afterShow", j);
                            j.$popover.attr("aria-hidden", "false");
                            !e && d && j.attrs("navigate", d);
                            x = o
                        }
                        var j = this,
                            e = !!e,
                            i = j.dependencies,
                            l = i.showMethod !== f ? i.showMethod : u,
                            k = i.beforeShowMethod !== f ? i.beforeShowMethod : null,
                            m = i.afterShowMethod !== f ? i.afterShowMethod : null;
                        x = d;
                        j.attrs("originalFocus", document.activeElement);
                        j.$popover.css("visibility", "hidden").addClass("a-popover-hidden").show();
                        k && k.apply(j, a);
                        j.attrs("synchronous") ?
                            g() : b.delay(function() {
                                g()
                            }, 0)
                    };
                this.show = function() {
                    var d = this,
                        e = d.attrs("lightboxOptions") || null;
                    d.isActive() || (d.lock(a), e && l.lock(a), d.attrs("alone") && b.each(d.parent.children, function(a) {
                        a.isActive() && a.id !== d.id && a.unlock().hide()
                    }), n.trigger("beforeShow", d), (!d.$container || d.isDirty() || d.getDataStrategy().shouldRefreshContent(d)) && E.call(d), e && l.show(b.extend({
                        popover: d
                    }, e)), v.call(d, arguments, !0), b.delay(function() {
                        d.unlock(a);
                        e && l.unlock(a)
                    }, 0));
                    return this
                };
                this.hide = function() {
                    var a = this,
                        d = a.dependencies,
                        e = d.hideMethod !== f ? d.hideMethod : p,
                        g = d.beforeHideMethod !== f ? d.beforeHideMethod : null,
                        o = d.afterHideMethod !== f ? d.afterHideMethod : null,
                        j = a.attrs("lightboxOptions") || null;
                    !a.isLocked() && a.isActive() && (x = r, a.hideChildren(), n.trigger("beforeHide", a), g && g.apply(a, arguments), e.apply(a, arguments), i.release(a.$iframe), n.trigger("hide", a), b.delay(function() {
                        o && o.apply(a, arguments);
                        a.$popover.attr("aria-hidden", "true");
                        j && (a.parent.attrs("lightboxOptions") ? l.show(b.extend({
                                popover: a.parent
                            }, j)) :
                            l.hide(j));
                        n.trigger("afterHide", a);
                        x = -2
                    }, 0));
                    return this
                };
                this.update = function(a) {
                    var d = typeof a === "string" ? {
                            content: a
                        } : b.copy(a),
                        e = this.attrs(),
                        a = this.getDataStrategy();
                    b.each(d, function(a, d) {
                        (a && !e[d] || e[d] && e[d] !== a) && w.push(d)
                    });
                    this.isDirty() && (d = b.extend({}, e, d), this.attrs(d), this.getDataStrategy(d), this.$popover && a.unloadContent(this), this.isActive() && E.call(this, !0));
                    return this
                };
                this.refresh = function(a, d) {
                    return E.call(this, a || !0, d || !1)
                };
                this.isActive = function() {
                    return x >= d
                };
                this.isLoaded =
                    function() {
                        return x === o
                    };
                this.isDirty = function() {
                    return w.length > 0
                };
                this.lock = function(a) {
                    a || (a = e);
                    m < a && (m = a);
                    return this
                };
                this.unlock = function(a) {
                    a || (a = e);
                    m <= a && (m = -1);
                    return this
                };
                this.isLocked = function() {
                    return m !== -1
                };
                this.dependencies = k;
                this.attrs(j);
                b.extend(this, this.attributes)
            }
            var f, g = b.$,
                a = 1,
                e = 10,
                d = 1,
                o = 2,
                r = -1,
                s = {
                    name: !0,
                    url: !0,
                    content: !0,
                    width: !0,
                    height: !0,
                    "max-width": !0,
                    "max-height": !0,
                    "min-width": !0,
                    "min-height": !0
                },
                x = b.capabilities.mobile && b.capabilities.isIE10Plus,
                u = function() {
                    this.$popover.css({
                        visibility: "visible"
                    }).removeClass("a-popover-hidden");
                    this.focus()
                },
                p = function() {
                    var a = this.attrs("originalFocus");
                    this.$popover.hide().find(".a-lgtbox-vertical-scroll").removeClass("a-lgtbox-vertical-scroll");
                    a && a.focus()
                },
                t = function() {
                    var a = this.dependencies;
                    return a.skin !== f ? a.skin(this) : ""
                },
                w = j.prototype;
            w.getDataStrategy = function(a) {
                var d = this.dependencies;
                !a && !this.attrs("currentDataStrategy") && (a = this.attrs());
                if (a && (a = a.dataStrategy ? m.getStrategyByName(a.dataStrategy) : m.guessStrategyByAttrs(a))) d.dataStrategy = a, this.attrs("currentDataStrategy",
                    a.name);
                return d.dataStrategy
            };
            w.getContent = function() {
                return this.dependencies.getContent !== f ? this.dependencies.getContent.apply(this, arguments) : null
            };
            w.updateContent = function(a) {
                this.dependencies.updateContent !== f && this.dependencies.updateContent.apply(this, arguments);
                return this
            };
            w.ajax = function(a) {
                return this.update({
                    url: a
                })
            };
            w.updateChildrenPosition = function() {
                b.each(this.children, function(a) {
                    a.isActive() && a.updatePosition()
                });
                return this
            };
            w.updatePosition = function() {
                var a = this;
                if (a.id === -1) b.each(a.children,
                    function(a) {
                        a.isActive() && a.updatePosition()
                    });
                else {
                    var d = a.$popover;
                    b.capabilities.isMetroIEGuess && b.capabilities.isIETouchCapable ? d.css("opacity", 0.01) : d.css("visibility", "hidden");
                    var e = function() {
                        var e = d.find(".a-popover-inner").css({
                                height: "auto",
                                "overflow-y": "auto"
                            }),
                            f = a.attrs("position"),
                            o = {},
                            o = a.dependencies.positionStrategy ? k.customPosition(a, a.dependencies.positionStrategy) : k[f](a);
                        n.trigger("beforeUpdatePosition", a);
                        f = {
                            top: o.top + "px",
                            left: o.left + "px"
                        };
                        b.capabilities.isMetroIEGuess && b.capabilities.isIETouchCapable ?
                            f.opacity = 1 : f.visibility = "visible";
                        d.css(f);
                        g(document.activeElement).closest(a.$popover).length === 0 && a.focus();
                        if (e.length && (!e[0].style.height || e[0].style.height === "auto")) {
                            var j = d.outerHeight() || 0,
                                i = d.find(".a-popover-header").outerHeight(!0) || 0,
                                l = d.find(".a-popover-footer").outerHeight(!0) || 0,
                                f = e.outerHeight(!0) || 0,
                                j = j - i - l;
                            f > j && e.css({
                                height: j + "px",
                                "overflow-y": "scroll"
                            })
                        }
                        a.$iframe.height(d.outerHeight()).width(d.outerWidth()).css("z-index", parseInt(d.css("z-index"), 10) - 2).show().offset({
                            top: o.top,
                            left: o.left
                        });
                        n.trigger("afterUpdatePosition", a);
                        n.trigger("positionUpdated", a);
                        b.each(a.children, function(a) {
                            a.isActive() && a.updatePosition()
                        })
                    };
                    a.attrs("immersive") && (b.capabilities.mobile || b.capabilities.tablet) ? (d.css({
                        top: 0,
                        left: 0
                    }), b.delay(function() {
                        e()
                    }, 0)) : e()
                }
                return a
            };
            w.attrs = function(a, d) {
                var e = this;
                return d === f && typeof a !== "object" ? a ? typeof a === "string" ? this.attributes[a] !== f ? this.attributes[a] : null : null : this.attributes : (typeof a === "object" ? b.each(a, function(a, d) {
                        e.attrs(d, a)
                    }) : typeof a ===
                    "string" && (this.attributes[a] = d, e[a] = d), this)
            };
            w.hideChildren = function() {
                b.each(this.children, function(d) {
                    d.unlock(a);
                    d.hide()
                });
                return this
            };
            w.focus = function() {
                var a = this,
                    d = g(window),
                    e = d.scrollTop(),
                    f = a.$popover.offset().top;
                x && e > f && d.scrollTop(f);
                b.delay(function() {
                    a.$startAnchor.focus()
                }, 0);
                return this
            };
            return {
                PopoverClass: j
            }
        });
        p.when("jQuery", "ready").register("a-changeover", function(b) {
            b(document).delegate(".a-changeover:not(.a-changeover-manual)", "webkitAnimationEnd animationend click touchstart",
                function() {
                    this.style.display = "none"
                })
        });
        p.when("A", "a-popover-util").register("a-popover-ajax-strategy", function(b, n) {
            var m = b.$,
                k = m("html").hasClass("a-lt-ie8");
            return {
                name: "ajax",
                reusePopover: !1,
                loadContent: function(i, l) {
                    var j = i.attrs("url"),
                        f = i.attrs("timeout") || 1E4,
                        g = i.attrs("ajaxFailMsg") || "Sorry, content is not available.",
                        a = !!i.attrs("cache"),
                        e = i.attrs("spinnerTimer"),
                        d = i.attrs("ajaxHandler"),
                        o = i.attrs("content");
                    i.attrs("content", null);
                    o && !l ? (i.updateContent(o), e && clearTimeout(e), d && d.abort &&
                        d.abort()) : (e = b.delay(function() {
                        !i.attrs("content") && i.attrs("currentDataStrategy") === "ajax" && n.showSpinner(i)
                    }, k ? 0 : 100), d = b.ajax(j, {
                        type: "GET",
                        timeout: f,
                        cache: a,
                        success: function(a) {
                            !i.attrs("content") && i.attrs("currentDataStrategy") === "ajax" && (clearTimeout(e), n.trigger("ajaxSuccess", i), i.updateContent(a), i.isActive() && i.updatePosition(), n.trigger("ajaxContentLoaded", i))
                        },
                        error: function() {
                            !i.attrs("content") && i.attrs("currentDataStrategy") === "ajax" && (clearTimeout(e), n.trigger("ajaxFail", i), i.updateContent(g),
                                i.isActive() && i.updatePosition())
                        }
                    }), i.attrs({
                        spinnerTimer: e,
                        ajaxHandler: d
                    }));
                    return this
                },
                unloadContent: function(b) {
                    n.clearContent(b);
                    return this
                },
                shouldRefreshContent: function(b) {
                    return !b.attrs("manualRefresh")
                },
                isValidStrategy: function(b) {
                    return !!b.url
                }
            }
        });
        p.when("A", "a-popover-util").register("a-popover-inline-strategy", function(b, n) {
            return {
                name: "inline",
                reusePopover: !1,
                loadContent: function(b) {
                    var k = b.attrs("content");
                    k && b.attrs("content", null);
                    if (!k) var k = b.$trigger,
                        i = k.data("action"),
                        k = k.data(i) || {},
                        k = k.inlineContent ? k.inlineContent : null;
                    k || (k = b.attrs("inlineContent"));
                    b.updateContent(k);
                    return this
                },
                unloadContent: function(b) {
                    var k = b.getContent(),
                        k = k && k.length > 0 ? k.html() : b.attrs("inlineContent"),
                        i = b.$trigger,
                        l = i.data("action"),
                        j = i.data(l) || {};
                    j.inlineContent = k;
                    i.data(l, j);
                    n.clearContent(b);
                    return this
                },
                shouldRefreshContent: function(b) {
                    return b.isDirty()
                },
                isValidStrategy: function() {
                    return !0
                }
            }
        });
        p.when("A", "a-popover-util").register("a-popover-preload-strategy", function(b, n) {
            var m = b.$;
            return {
                name: "preload",
                reusePopover: !0,
                loadContent: function(b) {
                    var i = b.attrs("name"),
                        l = b.attrs("content");
                    b.attrs("content", null);
                    var j;
                    j = m("#a-popover-" + i);
                    j.detach();
                    if (j.length) {
                        j = j[0];
                        for (var f = document.createDocumentFragment(); j.firstChild;) f.appendChild(j.firstChild);
                        j = f
                    } else j = !1;
                    l ? b.updateContent(l) : i && b.updateContent(j);
                    return this
                },
                unloadContent: function(k) {
                    var i = k.attrs("name");
                    if (i) {
                        var l = k.getContent();
                        if (l && l.html()) {
                            var i = "a-popover-" + i,
                                j = m("#" + i);
                            j.length ? j = j[0] : (j = document.createElement("div"), j.id = i, j.className =
                                "a-popover-preload", document.body.appendChild(j));
                            i = j;
                            if (!b.trim(i.innerHTML))
                                if (l = l[0], typeof l === "string") m(i).html(l);
                                else {
                                    for (j = document.createDocumentFragment(); l.firstChild;) j.appendChild(l.firstChild);
                                    i.appendChild(j)
                                }
                            n.clearContent(k)
                        }
                    }
                    return this
                },
                shouldRefreshContent: function(b) {
                    var a;
                    a = (b = b.attrs("name")) ? m("#a-popover-" + b) : null, b = a;
                    return !(!b || !(b.length && b.html() !== ""))
                },
                isValidStrategy: function(b) {
                    return !b.name ? !1 : b.currentDataStrategy === "preload" ? !0 : !!m("#a-popover-" + b.name).length
                }
            }
        });
        p.when("A").register("a-dropdown-base-positions", function(b) {
            return {
                positionStrategy: function(n) {
                    var m = n.$popover,
                        k = n.$trigger,
                        i = n.measure,
                        n = m.find(".a-popover-inner");
                    n.css({
                        "min-width": "0px",
                        width: "auto",
                        height: "auto"
                    });
                    var l = k.closest(".a-button-dropdown");
                    l.length || (l = k.closest(".a-button-group"));
                    var k = i(m, l),
                        i = k.windowWidth - (k.triggerLeft + k.popoverWidth),
                        l = k.windowWidth - k.triggerLeft - k.triggerWidth,
                        j = k.triggerLeft,
                        f = {},
                        g = k.triggerTop - k.windowTop,
                        a = k.windowBottom - k.triggerBottom,
                        e = m.find(".a-popover-inner");
                    g > a && a < k.popoverHeight ? (a = g, f.top = g < k.popoverHeight ? k.triggerBottom - g : k.triggerBottom - k.popoverHeight) : f.top = k.triggerTop;
                    e.css("height", a < k.popoverHeight ? a - k.headerHeight + "px" : "auto");
                    k.popoverHeight > a ? e.addClass("a-lgtbox-vertical-scroll") : e.removeClass("a-lgtbox-vertical-scroll");
                    n.hasClass("a-lgtbox-vertical-scroll") && navigator.appVersion.indexOf("Windows") > -1 ? (g = Math.max(k.popoverWidth, k.triggerWidth) + b.scrollBarWidth(!0), n.width(g)) : n.css("min-width", k.triggerWidth + "px");
                    k.popoverWidth = m.width();
                    f.left = i < 50 && j > l ? k.triggerRight - k.popoverWidth : k.triggerLeft;
                    return f
                }
            }
        });
        p.when("A", "a-dropdown-base-positions").register("a-dropdown-base-variant-base", function(b, n) {
            return b.extend(n, {
                updateContent: function(b) {
                    typeof b === "string" ? this.$popover.find(".a-popover-inner").html(b) : b && this.$popover.find(".a-popover-inner").html("").append(b)
                },
                beforeShowMethod: function() {
                    var b = this.id + "_dropdown_combobox";
                    this.parent.lock(1);
                    this.$trigger.attr("aria-pressed", !0).attr("aria-owns", b);
                    this.$popover.find("ol,ul").eq(0).attr("id",
                        b)
                },
                afterShowMethod: function() {
                    var m = this.$popover,
                        k = m.find(".a-active");
                    b.delay(function() {
                        k.length ? k.closest("li").focus() : k = m.find("li").first().focus()
                    }, 0)
                },
                beforeHideMethod: function() {
                    this.parent.unlock(1)
                },
                afterHideMethod: function() {
                    this.$trigger.attr("aria-pressed", !1).focus();
                    this.$popover.css("width", "auto")
                }
            })
        });
        p.when("A", "a-dropdown-base-variant-base").register("a-dropdown-base-variant", function(b, n) {
            return n
        });
        p.when("A", "a-popover-base-factory", "a-dropdown-base-variant").register("a-dropdown-base-factory",
            function(b, n, m) {
                function k(f, a, e) {
                    var d = ['<li tabIndex="0" role="option" aria-selected="true"'],
                        o = f.data("aCssClass"),
                        i = f.data("aId"),
                        l = f.data("aHtmlContent"),
                        k = f.data("aImageSource"),
                        m = ['<a tabIndex="-1" href="javascript:void(0)" data-value="{&quot;stringVal&quot;:&quot;', f.val().replace(/"/g, "\\&quot;"), '&quot;}"'],
                        n = ["a-dropdown-link"],
                        t = ["a-dropdown-item"];
                    a && (n.push("a-active"), d.push(' aria-checked="true"'));
                    j && (b.capabilities.mobile || b.capabilities.tablet) && n.push("a-list-link-after-group");
                    j = !1;
                    o && t.push(o);
                    i && d.push(' id="' + i + '"');
                    d.push('aria-labelledby="');
                    d.push(e);
                    d.push('"');
                    m.push(' id="');
                    m.push(e);
                    m.push('"');
                    d.push(' class="' + t.join(" ") + '"');
                    d.push(">");
                    l ? a = l : (a = [], k && (n.push("a-option-has-image"), a.push('<img src="' + k + '" class="a-rich-option-image" />')), a.push(f.html()), a = a.join(""));
                    m.push(' class="');
                    m.push(n.join(" "));
                    m.push('">');
                    m.push(a);
                    m.push("</a>");
                    d.push(m.join(""));
                    d.push("</li>");
                    return d.join("")
                }

                function i(b) {
                    b.jquery || (b = l(b));
                    var a = b.children("optgroup,option:not(.a-prompt)"),
                        e = !1,
                        d = b[0],
                        o = b.attr("id") ? b.attr("id") : "dropdown" + f++,
                        i, m;
                    if (d.selectedIndex > -1) i = d.options[d.selectedIndex].value;
                    m = ['<ul tabIndex="-1" class="a-nostyle a-list-link', b.data("a-has-images") ? " a-box-list" : "", '" role="listbox" aria-multiselectable="false">'];
                    var n = 0;
                    a.each(function() {
                        var a = l(this);
                        a.is("optgroup") ? (a.children().each(function() {
                            m.push(k(l(this), i === this.value, o + "_" + n++))
                        }), m.push('<li tabIndex="-1" class="divider"><hr /></li>'), e = j = !0) : (m.push(k(a, i === this.value, o + "_" + n++)), e = !1)
                    });
                    e && m.pop();
                    m.push("</ul>");
                    return m.join("")
                }
                var l = b.$,
                    j = !1,
                    f = 1;
                return b.extend({
                    create: n.create,
                    remove: n.remove,
                    get: n.get
                }, {
                    type: "dropdown",
                    create: function(f, a, e) {
                        var d = a.$button,
                            o = a.$sourceSelect,
                            j = o[0],
                            l = d.find(".a-dropdown-label"),
                            k = o.data("aTouchHeader");
                        if (!k || !k.length && l.length) k = l.text();
                        return n.create(f, {
                            attributes: {
                                type: "dropdown",
                                header: k,
                                closeButtonLabel: a.closeButtonLabel ? a.closeButtonLabel : "Close",
                                inlineContent: o,
                                position: a.position,
                                alone: !0,
                                sourceSelect: o,
                                sourceButton: d,
                                name: o[0].name,
                                preventNameReuse: !0,
                                lightboxOptions: b.capabilities.mobile || b.capabilities.tablet ? {
                                    showDuration: b.capabilities.ios ? null : 0,
                                    hideDuration: 0
                                } : null
                            },
                            variant: b.extend({}, m, e, {
                                skin: function(a) {
                                    var d = e.subskin ? e.subskin(j) : i(j);
                                    a.attrs("inlineContent", d);
                                    return e.skin(a)
                                }
                            }),
                            actionCheck: !1
                        })
                    }
                })
            });
        p.when("A").register("a-dropdown-base-handlers", function() {});
        p.when("A", "a-dropdown-select-apis", "a-dropdown-base-factory", "a-dropdown-base-handlers", "a-popover-base").register("a-dropdown-base", function(b, n, m) {
            function k(g,
                a, e) {
                try {
                    g.$event.preventDefault()
                } catch (d) {}
                b.delay(function() {
                    var d = a.$button ? a.$button : a.getButtonFromEvent(g),
                        i = a.$select ? a.$select : a.getSelectFromEvent(g);
                    if (!d.hasClass("a-button-disabled")) {
                        j(i, a).isSynced() || l(f.extend({
                            $button: d,
                            $select: i
                        }, a));
                        var k = g.$declarativeParent,
                            i = b.extend({}, a, {
                                $button: d,
                                $sourceSelect: i
                            }),
                            n = m.create(k, i, e);
                        if (n && (n.show(), d.data("a-popover-id", n.id).data("popover", n).data("isPressed", !0), !n.hasOnLoad)) {
                            n.hasOnLoad = !0;
                            var u = [],
                                d = n.$popover.find("img");
                            d.length && (d.each(function(a,
                                d) {
                                if (!d.complete || !d.naturalWidth) {
                                    var e = f.Deferred();
                                    u.push(e);
                                    f(d).bind("load error", function() {
                                        e.resolve()
                                    })
                                }
                            }), u.length ? f.when.apply(f, u).done(function() {
                                n.updatePosition()
                            }) : n.updatePosition())
                        }
                    }
                })
            }

            function i(b) {
                var a = b.$button,
                    b = b.$select;
                a || (a = b.nextAll(".a-button-dropdown"));
                return b.length ? ((a = m.get(a)) && a.hide(), !0) : !1
            }

            function l(b) {
                var a = b.$button,
                    b = b.$select;
                a || (a = b.nextAll(".a-button-dropdown"));
                return b.length ? ((a = m.get(a)) && m.remove(a.id), b.data("a-info", null), !0) : !1
            }

            function j(g,
                a) {
                var e, d;
                e = a.$select ? a.$select : typeof g === "string" ? f("select#" + g) : g.jquery ? g : f(g);
                if (!e.length) return null;
                d = a.$button ? a.$button : a.getButtonFromSelect(e);
                e.data("a-select") ? d = e.data("a-select") : (d = b.extend({
                    hidePopover: i,
                    refreshPopover: l,
                    options: b.extend({
                        $select: e,
                        $button: d
                    }, a)
                }, n), e.data("a-select", d));
                return d
            }
            var f = b.$;
            return {
                toggleDropdown: function(b, a) {
                    var e = (a.$button ? a.$button : a.getButtonFromEvent(b)).data("popover");
                    e && e.$popover.is(":visible") ? e.hide() : k(b, a)
                },
                showDropdown: k,
                getSelect: j
            }
        });
        p.when("A", "jQuery").register("a-dropdown-options-apis", function() {
            return {
                update: function(b) {
                    typeof b !== "object" && p.error("input of options.update() function must be a hash");
                    this.hidePopover(this.options);
                    for (var n = 0, m = this.size(); n < m; n++) {
                        var k = this.options.elements[n],
                            i = k[0];
                        b.value && k.val(b.value);
                        b.selected !== void 0 && (!i.selected && b.selected ? this.options.$select.val(i.value) : i.selected && !b.selected && this.options.$select.val(""));
                        b.html_content && k.data("a-html-content", b.html_content);
                        b.image_source &&
                            k.data("a-image-source", b.image_source);
                        if (b.native_css_class) i.className = b.native_css_class;
                        b.css_class && k.data("a-css-class", b.css_class);
                        if (b.native_id) i.id = b.native_id;
                        b.id && k.data("a-id", b.id);
                        b.text && (k.text(b.text), i.selected && this.setSelectValue(i.value))
                    }
                    this.refreshPopover(this.options);
                    return this
                },
                remove: function() {
                    this.hidePopover(this.options);
                    for (var b = 0, n = this.size(); b < n; b++) {
                        var m = this.options.elements[b];
                        m.is(":selected") && this.setSelectValue("");
                        m.remove()
                    }
                    this.refreshPopover(this.options);
                    return !0
                },
                info: function() {
                    for (var b = [], n = 0, m = this.size(); n < m; n++) {
                        var k = this.options.elements[n];
                        b.push({
                            value: k[0].value,
                            text: k.text(),
                            selected: k[0].selected,
                            html_content: k.data("a-html-content"),
                            image_source: k.data("a-image-source"),
                            native_css_class: k[0].className,
                            css_class: k.data("a-css-class"),
                            native_id: k[0].id,
                            id: k.data("a-id")
                        })
                    }
                    return b
                },
                size: function() {
                    return this.options.elements.length
                }
            }
        });
        p.when("A", "jQuery", "a-dropdown-options-apis").register("a-dropdown-select-apis", function(b, n, m) {
            function k(b) {
                var f =
                    this.options.$select,
                    g = this.options.$button,
                    a = f[0];
                typeof b === "number" && (b = b.toString());
                for (var e = 0, d = a.options.length; e < d; e++)
                    if (a.options[e].value === b) break;
                e === d && b === "" && (e = 0);
                e < d && (g.find(".a-dropdown-prompt").html(a.options[e].innerHTML), g.css("min-width", e / a.options.length + "%"), f.val() !== b && (f.val(b), f.trigger("change", [l, !0])));
                return this
            }

            function i(b) {
                return b === l ? this.options.$select.val() : (this.setValue = k, this.setValue(b))
            }
            var l;
            return {
                isSynced: function() {
                    var j = this.options.$select,
                        f =
                        j.data("a-info"),
                        g = this.getOptions().info();
                    j.data("a-info", g);
                    return f ? b.equals(f, g) : !0
                },
                update: function(b) {
                    typeof b !== "object" && p.error("input of select.update() function must be a hash");
                    this.hidePopover(this.options);
                    var f = {
                            none: !0,
                            micro: !0,
                            mini: !0,
                            small: !0,
                            base: !0,
                            medium: !0,
                            large: !0,
                            "extra-large": !0,
                            "double-large": !0,
                            block: !0
                        },
                        g = this.options.$select,
                        a = g[0],
                        e = this.options.$button,
                        d = e[0],
                        o = g.siblings("label");
                    if (b.name) a.name = b.name;
                    if (b.option_prompt) {
                        var i = g.find(".a-prompt");
                        i.length ? (i.text(b.option_prompt),
                            i.prop("selected") && e.find(".a-dropdown-prompt").text(b.option_prompt)) : (g.prepend(n("<option class='a-prompt' />").text(b.option_prompt)), e.find(".a-dropdown-prompt").text(b.option_prompt))
                    }
                    b.has_images !== l && g.data("a-has-images", !!b.has_images);
                    b.button_size !== l && e.length && (b.button_size === "small" ? e.addClass("a-button-small") : e.removeClass("a-button-small"));
                    if (b.spacing !== l && f.hasOwnProperty(b.spacing)) f = /\ba-spacing-[a-z]+\b/g, a.className = a.className.replace(f, ""), d.className = d.className.replace(f,
                        ""), g.addClass("a-spacing-" + b.spacing), e.addClass("a-spacing-" + b.spacing);
                    if (b.grid_units !== l) f = /\ba-button-span\d{1,2}\b/g, a.className = a.className.replace(f, ""), d.className = d.className.replace(f, ""), isFinite(b.grid_units) && b.grid_units > 0 && b.grid_units < 13 && (g.addClass("a-button-span" + b.grid_units), e.addClass("a-button-span" + b.grid_units));
                    b.width_name && (b.width_named === "base" ? e.addClass("a-button-width-normal") : e.removeClass("a-button-width-normal"));
                    if (b.status) b.status === "disabled" ? (a.disabled = !0, e.addClass("a-button-disabled")) : (a.disabled = !1, e.removeClass("a-button-disabled"));
                    if (b.native_id && (a.id = b.native_id, o.length)) o[0].htmlFor = b.native_id;
                    if (b.id) d.id = b.id;
                    b.native_css_class && ((d = g.data("a-native-class")) && g.removeClass(d), g.addClass(b.native_css_class).data("a-native-class", b.native_css_class));
                    b.css_class && ((d = e.data("a-class")) && e.removeClass(d), e.addClass(b.css_class).data("a-class", b.css_class));
                    b.label_text !== l && (b.label_text === "" ? (e.find(".a-dropdown-label").remove(), g.siblings("label").remove()) :
                        (d = e.find(".a-dropdown-label"), d.length ? d.text(b.label_text) : e.find(".a-dropdown-prompt").before(n("<span class='a-dropdown-label' />").text(b.label_text)), o.length ? o.text(b.label_text) : g.before(n("<label for='" + a.id + "' class='a-native-dropdown' />").text(b.label_text))), e.css("min-width", b.label_text === "" ? "0.1%" : "0%"));
                    this.refreshPopover(this.options);
                    return this
                },
                setValue: k,
                val: i,
                getOptions: function(j) {
                    for (var f = [], g = this.options.$select, a = [], f = j === l ? g.children("optgroup, option:not(.a-prompt)") :
                            n.isArray(j) ? j : [j], j = 0, e = f.length; j < e; j++) {
                        var d = f[j],
                            o = [];
                        b.isFiniteNumber(d) ? o = g.children("optgroup, option:not(.a-prompt)").eq(d) : typeof d === "string" ? o = g.children("option#" + d) : typeof d === "object" && (o = d.jquery ? d : n(d));
                        o.length && a.push(o)
                    }
                    return b.extend({
                        hidePopover: this.hidePopover,
                        refreshPopover: this.refreshPopover,
                        setSelectValue: i,
                        options: b.extend({
                            elements: a
                        }, this.options)
                    }, m)
                },
                getOption: function(b) {
                    return this.getOptions(b)
                },
                addOptions: function(b, f) {
                    n.isArray(b) || (b = [b]);
                    for (var g = b.length; g--;) this.addOption(b[g],
                        f);
                    return this
                },
                addOption: function(b, f) {
                    var g = this.options.$select;
                    if (!b.native_id || !g.find("option#" + b.native_id).length) {
                        var a = g.children("optgroup, option:not(.a-prompt)"),
                            e = document.createElement("option"),
                            d = f && f > 0 && f <= a.length ? f : 0;
                        if (b.native_id) e.id = b.native_id;
                        a.length === 0 || d === a.length ? g[0].appendChild(e) : a.eq(d).before(e);
                        this.getOption(e).update(b)
                    }
                    return this
                },
                removeOptions: function(b) {
                    this.getOptions(b).remove();
                    return this
                },
                removeOption: function(b) {
                    return this.removeOptions(b)
                },
                appendOption: function(b) {
                    return this.addOption(b,
                        this.options.$select.children("optgroup, option:not(.a-prompt)").length)
                },
                appendOptions: function(b) {
                    if (n.isArray(b))
                        for (var f = 0, g = b.length; f < g; f++) this.addOption(b[f]);
                    return this
                }
            }
        });
        p.when("A", "a-dropdown-options", "a-dropdown-apis", "a-dropdown-handlers").register("a-dropdown", function(b, n, m) {
            var k = b.$;
            k(document).delegate(".a-native-dropdown", "change", function(i, l, j) {
                var f = n.getButtonFromEvent(i),
                    g = "",
                    a = this.options.length,
                    e = this.selectedIndex > -1 ? this.options[this.selectedIndex].value : "",
                    d = f.data("popover"),
                    i = !1,
                    o;
                if (f.length) {
                    for (f = f.eq(0); a--;)
                        if (o = this.options[a], o.value === e) {
                            g = o.innerHTML;
                            break
                        }
                    d && d.$popover && (d.$popover.find(".a-active").removeClass("a-active").closest("li").attr("aria-checked", !1), l === void 0 && (l = d.$popover.find('a[data-value="' + ('{"stringVal":"' + e + '"}') + '"]')));
                    l && l.length && (i = !0, l.addClass("a-active").closest("li").attr("aria-checked", !0));
                    f.find(".a-dropdown-prompt").html(g);
                    f.css("min-width", this.selectedIndex / this.options.length + "%");
                    d && (d.hide(), (f = m.getSelect(this)) && k(this).data("a-info",
                        f.getOptions().info()));
                    if (!j) j = this.name, f = this.id, l = {
                        auiItemNode: i ? l[0] : null,
                        nativeItemNode: this.options[this.selectedIndex],
                        selectNode: this,
                        id: f,
                        name: j,
                        value: this.value
                    }, j && j !== "" && (b.trigger("a:dropdown:" + j + ":select", l), b.trigger("a:dropdown:selected:" + j, l)), f && f !== "" && b.trigger("a:dropdown:" + f + ":select", l), b.trigger("a:dropdown:select", l)
                }
            }).delegate(".a-button-dropdown:not(.a-button-disabled)", "focusin", function() {
                k(this).find(".a-button-text").focus()
            });
            return m
        });
        p.when("A", "a-dropdown-base",
            "a-dropdown-options").register("a-dropdown-apis", function(b, n, m) {
            function k(b) {
                return n.getSelect(b, m)
            }
            var i = b.$;
            b.on("beforeReady", function() {
                i(".a-dropdown-container select").each(function() {
                    var b = k(this);
                    b && b.val(b.val())
                })
            });
            return {
                getSelect: k,
                updateOption: function(b, j) {
                    var f = i("option#" + b).closest("select");
                    k(f).getOption(b).update(j)
                },
                updateSelect: function(b, i) {
                    k(b).update(i)
                },
                setValue: function(b, i) {
                    k(b).setValue(i)
                }
            }
        });
        p.when("A", "a-popover-accessibility").register("a-dropdown-variant", function(b,
            n) {
            return {
                skin: function(b) {
                    var k = b.attrs("header") || "",
                        b = b.id;
                    return ['<div class="a-popover a-dropdown a-dropdown-common">', n.getStartAnchorHtml(b, "", k, !0), '<div class="a-popover-wrapper"><div class="a-popover-inner"></div></div>', n.getEndAnchorHtml(b, "", k, !0), "</div>"].join("")
                }
            }
        });
        p.when("A", "a-dropdown-base", "a-dropdown-variant", "a-dropdown-options", "a-dropdown-apis", "a-dropdown-base-factory").register("a-dropdown-handlers", function(b, n, m, k, i, l) {
            function j(b) {
                b.preventDefault();
                var b = f(this),
                    a =
                    l.get(b.closest(".a-popover"));
                if (b.hasClass("a-active")) a.hide();
                else {
                    var e = b.data("value").stringVal;
                    a.sourceSelect.val(e).trigger("change", [b])
                }
            }
            var f = b.$;
            b.declarative("a-dropdown-button", "click", function(f) {
                var a = k.getButtonFromEvent(f);
                n.showDropdown(f, b.extend({
                    $button: a
                }, k), m)
            });
            b.declarative("a-dropdown-button", "keydown", function(f) {
                var a = k.getButtonFromEvent(f),
                    e = b.constants.keycodes,
                    d = f.$event.which;
                (d === e.DOWN_ARROW || d === e.ENTER || d === e.SPACE) && n.showDropdown(f, b.extend({
                        $button: a
                    }, k),
                    m)
            });
            f(document).delegate(".a-popover.a-dropdown a", "click", j).delegate(".a-dropdown li", "keydown", function(g) {
                var a = f(this),
                    e = b.constants.keycodes;
                switch (g.which) {
                    case e.UP_ARROW:
                        g.preventDefault();
                        a.prev().focus();
                        break;
                    case e.DOWN_ARROW:
                        g.preventDefault();
                        a.next().focus();
                        break;
                    case e.ENTER:
                    case e.SPACE:
                        j.call(a.find("a")[0], g);
                        break;
                    case e.ESCAPE:
                        g.preventDefault(), g = l.get(a.closest(".a-popover")), g.sourceButton.find(".a-button-text").focus(), g.hide()
                }
            })
        });
        p.when("A").register("a-dropdown-options",
            function(b) {
                function n(b) {
                    return b.popover ? b.popover.$trigger.closest(".a-button-dropdown") : b.$target ? b.$target.closest(".a-button-dropdown") : m(b.target).nextAll(".a-button-dropdown")
                }
                var m = b.$;
                return {
                    getButtonFromEvent: n,
                    getButtonFromSelect: function(b) {
                        return b.nextAll(".a-button-dropdown")
                    },
                    getSelectFromEvent: function(b) {
                        b = n(b).prevAll("select").eq(0);
                        b.length || p.error("Cannot locate the <select> of dropdown");
                        return b
                    },
                    triggerSelector: ".a-button-dropdown"
                }
            });
        p.when("A", "a-popover-accessibility").register("a-dropdown-split-variant",
            function(b, n) {
                return {
                    skin: function(b) {
                        var k = b.attrs("header") || "",
                            b = b.id;
                        return ['<div class="a-popover a-splitdropdown a-dropdown-common">', n.getStartAnchorHtml(b, "", k, !0), '<div class="a-popover-wrapper">\n<div class="a-popover-inner"></div>\n</div>', n.getEndAnchorHtml(b, "", k, !0), "</div>"].join("\n")
                    }
                }
            });
        p.when("A", "a-dropdown-base", "a-dropdown-split-utils", "a-dropdown-split-variant", "a-dropdown-split-options", "a-dropdown-base-factory").register("a-dropdown-split-handlers", function(b, n, m, k, i, l) {
            var j =
                b.$;
            b.declarative("a-splitdropdown-button", "click", function(f) {
                var g = i.getButtonFromEvent(f);
                n.showDropdown(f, b.extend({
                    $button: g
                }, i), k)
            });
            b.declarative("a-splitdropdown-main", "click", function(b) {
                var g = b.$target.closest(".a-splitdropdown-container").find("select"),
                    a = g.attr("id"),
                    e = g.val();
                m.triggerEvent(a, g, e);
                b.$event.preventDefault()
            });
            b.declarative("a-splitdropdown-button", "keydown", function(f) {
                var g = i.getButtonFromEvent(f),
                    a = b.constants.keycodes,
                    e = f.$event.which;
                (e === a.DOWN_ARROW || e === a.ENTER ||
                    e === a.SPACE) && n.showDropdown(f, j.extend({
                    $button: g
                }, i), k)
            });
            j(document).delegate(".a-popover.a-splitdropdown a", "click", function(b) {
                var g = j(this),
                    a = g.data("value").stringVal,
                    g = l.get(g.closest(".a-popover")),
                    e = g.sourceSelect,
                    d = e.attr("id");
                g.hide();
                m.triggerEvent(d, e, a);
                b.preventDefault()
            }).delegate(".a-splitdropdown li", "keydown", function(f) {
                var g = j(this),
                    a = b.constants.keycodes;
                switch (f.which) {
                    case a.UP_ARROW:
                        f.preventDefault();
                        g.prev().focus();
                        break;
                    case a.DOWN_ARROW:
                        f.preventDefault();
                        g.next().focus();
                        break;
                    case a.ENTER:
                    case a.SPACE:
                        f.preventDefault();
                        g.find("a").trigger("click");
                        break;
                    case a.ESCAPE:
                        f.preventDefault(), f = l.get(g.closest(".a-popover")), f.sourceButton.find(".a-button-text").focus(), f.hide()
                }
            })
        });
        p.when("A").register("a-dropdown-split-options", function(b) {
            function n(b) {
                return b.popover ? b.popover.$trigger.closest(".a-button-splitdropdown") : b.$target ? b.$target.closest(".a-button-splitdropdown") : m(b.target).nextAll(".a-button-splitdropdown")
            }
            var m = b.$;
            return {
                getButtonFromEvent: n,
                getButtonFromSelect: function(b) {
                    return b.next(".a-button-group-splitdropdown").find(".a-button-splitdropdown")
                },
                getSelectFromEvent: function(b) {
                    b = n(b).closest(".a-splitdropdown-container").find("select");
                    b.length || p.error("cannot locate the <select> of the split dropdown");
                    return b
                }
            }
        });
        p.when("A").register("a-dropdown-split-utils", function(b) {
            return {
                triggerEvent: function(n, m, k) {
                    m = {
                        $select: m,
                        value: k,
                        id: n
                    };
                    b.trigger("a:splitdropdown:" + n + ":select", m);
                    b.trigger("a:splitdropdown:select", m)
                }
            }
        });
        p.when("A", "a-dropdown-base", "a-dropdown-split-options", "a-dropdown-split-utils", "a-dropdown-split-handlers").register("a-splitdropdown",
            function(b, n, m, k) {
                var i = b.$;
                i(document).delegate(".a-native-splitdropdown", "change", function(b, j, f) {
                    var b = i(this),
                        j = b.val(),
                        g = b.attr("id");
                    f || k.triggerEvent(g, b, j)
                }).delegate(".a-button-splitdropdown:not(.a-button-disabled)", "focusin", function() {
                    i(this).find(".a-button-text").focus()
                });
                return {
                    getSelect: function(b) {
                        return n.getSelect(b, m)
                    }
                }
            });
        p.when("A").register("a-popover-accessibility", function() {
            var b = function(b, m, k, i, l) {
                if (!m) return "";
                var j = {
                    "{{ANCHOR_NAME}}": "a-popover-" + b,
                    "{{AIRA_LABEL}}": i ?
                        'aria-label="' + i + '"' : 'aria-labelledby="a-popover-' + (k ? "header" : "content") + "-" + m + '"'
                };
                return (l ? '<span role="dialog" data-action="a-popover-a11y" class="{{ANCHOR_NAME}} a-offscreen a-declarative" tabindex="0" {{AIRA_LABEL}}></span>' : '<span role="dialog" class="{{ANCHOR_NAME}} a-offscreen" tabindex="0" {{AIRA_LABEL}}></span>').replace(/\{\{[\w_]*\}\}/g, function(b) {
                    return j[b]
                })
            };
            return {
                getStartAnchorHtml: function() {
                    [].splice.call(arguments, 0, 0, "start");
                    return b.apply(null, arguments)
                },
                getEndAnchorHtml: function() {
                    [].splice.call(arguments,
                        0, 0, "end");
                    return b.apply(null, arguments)
                }
            }
        });
        p.when("A", "a-popover-util").register("a-popover-ajax", function(b, n) {
            return {
                update: function(b, k, i) {
                    var l = {};
                    l.url = k;
                    if (i.timeout) l.timeout = i.timeout;
                    if (i.ajaxFailMsg) l.ajaxFailMsg = i.ajaxFailMsg;
                    if (i.cache) l.cache = i.cache;
                    b.update(l)
                },
                showSpinner: function(b) {
                    return n.showSpinner(b)
                }
            }
        });
        p.when("A", "a-popover-util", "a-popover-inline-strategy", "a-popover-preload-strategy", "a-popover-ajax-strategy").register("a-popover-data", function(b, n, m, k, i) {
            var l = [i, k,
                m
            ];
            return {
                guessStrategyByAttrs: function(b) {
                    for (var f = 0, g = l.length; f < g; f++) {
                        var a = l[f];
                        if (a.isValidStrategy(b)) return a
                    }
                },
                getStrategyByName: function(b) {
                    for (var f = 0, g = l.length; f < g; f++) {
                        var a = l[f];
                        if (a.name === b) return a
                    }
                    return null
                },
                showSpinner: n.showSpinner
            }
        });
        p.when("A", "ready").register("a-popover-iframes", function(b) {
            function n() {
                if (k) {
                    i++;
                    var b = document.createElement("iframe");
                    b.src = "javascript:false;";
                    b.id = "a-popover-iframe-" + i;
                    b.className = "a-popover-iframe";
                    b.style.cssText = "width: 0; height: 0; border: 0; opacity: 0; filter: alpha(opacity = 0); zoom: 1; display: none; position: absolute;";
                    b.frameborder = "0";
                    b.tabindex = "-1";
                    document.body.appendChild(b);
                    return m(b)
                } else return m()
            }
            var m = b.$;
            m("body");
            var k = document.documentElement.className.indexOf("a-ie6") > -1,
                i = 0,
                l = [],
                j = [];
            b.on.ready(function() {
                k && l.push(n())
            });
            return {
                get: function() {
                    if (k) {
                        var b = l.length === 0 ? n() : l.shift();
                        j.push(b);
                        return b
                    } else return m()
                },
                release: function(f) {
                    k && (f.hide(), b.each(j, function(b, a) {
                        f.is(b) && j.splice(1, a)
                    }), l.push(f))
                }
            }
        });
        p.when("A", "a-popover-lightbox-markup", "ready").register("a-popover-lightbox", function(b,
            n) {
            function m(a) {
                a.preventDefault();
                a.stopPropagation();
                a.stopImmediatePropagation();
                return !1
            }

            function k() {
                document.body.addEventListener("click", m, !0);
                r = !0
            }

            function i() {
                document.body.removeEventListener("click", m, !0);
                r = !1
            }
            var l = b.$,
                j = document.documentElement.className,
                f = j.indexOf("-ie") > -1,
                g = j.indexOf("a-lt-ie7") > -1,
                a = b.capabilities.isIE10Plus && b.capabilities.mobile,
                e = (b.capabilities.androidVersion + "").indexOf("4.") === 0,
                d = n.id,
                o = n.div,
                r = !1,
                s = null,
                x = -1,
                u = -1,
                p = -1,
                t = null;
            l(document).delegate("#" + d,
                "click " + b.action.start + " " + b.action.move,
                function(a) {
                    a.preventDefault()
                });
            b.declarative("a-popover-floating-close", b.capabilities.touch ? "touchend" : "click", function(a) {
                !r && a.$target.data("action") && a.$target.data("action").indexOf("a-popover-floating-close") > -1 && t && t.isActive() && (t.unlock().hide(), a.$event.preventDefault())
            });
            return {
                show: function(j) {
                    var m = l(window);
                    s || (l("body").append(o), s = l("#" + d));
                    j = j || {};
                    (b.capabilities.touch || b.capabilities.pointerPrefix) && k();
                    j.lockScroll && (u === -1 && (u = m.scrollTop(),
                        p = m.scrollLeft()), b.setCssImportant(l("body"), "margin-right", b.scrollBarWidth() + "px"), a || (f ? l("html, body").css("overflow", "hidden") : l("body").css("overflow", "hidden")));
                    var n = (t = j.popover || null) ? t.$popover.css("z-index") - 2 : -1;
                    n > 0 && (s.css("z-index", n), e && m.width());
                    if (typeof j.showDuration !== "number") j.showDuration = 200;
                    g && (u > -1 && s.css("top", u + "px"), p > -1 && s.css("left", p + "px"));
                    j.showDuration > 0 ? b.fadeIn(s, j.showDuration) : s.css("display", "block");
                    (b.capabilities.touch || b.capabilities.pointerPrefix) &&
                    b.delay(i, j.showDuration + 300)
                },
                hide: function(a) {
                    var d = l(window);
                    if (!(x > -1) && s) {
                        a = a || {};
                        (b.capabilities.touch || b.capabilities.pointerPrefix) && k();
                        if (typeof a.hideDuration !== "number") a.hideDuration = 250;
                        a.hideDuration > 0 ? b.fadeOut(s, a.duration, "linear", function() {
                            a.lockScroll && (l("html, body").css("overflow", ""), l("body").css("margin-right", ""), b.delay(function() {
                                u > 0 && (d.scrollTop(u), u = -1);
                                p > 0 && (d.scrollLeft(p), p = -1)
                            }, 100));
                            t = null
                        }) : (s.css("display", "none"), a.lockScroll && (l("html, body").css("overflow",
                            ""), l("body").css("margin-right", ""), u > 0 && (l(window).scrollTop(u), u = -1)), t = null);
                        s.css({
                            height: "",
                            width: ""
                        });
                        (b.capabilities.touch || b.capabilities.pointerPrefix) && b.delay(i, a.hideDuration + 350)
                    }
                },
                lock: function(a) {
                    a || (a = 10);
                    x < a && (x = a)
                },
                unlock: function(a) {
                    a || (a = 10);
                    x <= a && (x = -1)
                },
                LIGHTBOX_ID: d
            }
        });
        p.when("A", "ready").register("a-popover-lightbox-markup", function() {
            return {
                id: "a-popover-lgtbox",
                div: '<div id="a-popover-lgtbox" class="a-declarative" data-action="a-popover-floating-close" />'
            }
        });
        p.when("A",
            "ready").register("a-popover-navigate", function(b) {
            function n(b) {
                if (typeof b === "string") l = !0, window.location.hash = b;
                return window.location.hash || ""
            }
            var m = b.$,
                m = m(window),
                k = [],
                i = [],
                l = !1,
                j = {},
                f = !1;
            i.push(n());
            m.bind("hashchange", function(g) {
                g.preventDefault();
                f ? f = !1 : i.push(n());
                i.length >= 32 && i.shift();
                l ? l = !1 : b.trigger("a:popover:navigate", j[i[i.length - 1]])
            });
            b.on("a:popover:navigate", function(b) {
                b ? b.show({
                    preventNavigate: !0
                }) : (b = k.length - 1 >= 0 ? k[k.length - 1] : null) && b.popover.hide({
                    preventNavigate: !0
                })
            });
            b.on("a:popover:show", function(b) {
                k.push(b)
            });
            b.on("a:popover:hide", function() {
                k.pop()
            });
            return {
                forward: function(f) {
                    var a = f.name + "_" + b.now();
                    j["#" + a] = f;
                    n(a)
                },
                back: function() {
                    i.length > 0 && i.pop();
                    f = !0;
                    window.history.back()
                }
            }
        });
        p.when("A").register("a-popover-position", function(b) {
            function n(a, e) {
                var d = a.outerHeight(!0),
                    f = a.outerWidth(!0),
                    i = a.offset(),
                    k = e.offset(),
                    m;
                b.viewport().zoom === 1 ? m = {
                    top: 0,
                    left: 0
                } : (j || (j = l('<span id="a-popover-offset-tracker"></span>'), l("body").prepend(j)), m = j.offset());
                var n =
                    a.find(".a-popover-header"),
                    n = n.length ? n.outerHeight(!0) : 0;
                if (g) {
                    var p = window.pageYOffset - document.documentElement.scrollTop;
                    i.top -= p;
                    k.top -= p
                }
                i.left -= m.left;
                i.top -= m.top;
                k.left -= m.left;
                k.top -= m.top;
                var t, w;
                t = e[0];
                var p = b.viewport(),
                    z = p.scrollLeft,
                    A = p.scrollTop;
                t.getBoundingClientRect ? (w = t.getBoundingClientRect(), t = w.right - w.left, w = w.bottom - w.top) : (t = e.width(), w = e.height());
                return {
                    popoverHeight: d,
                    popoverWidth: f,
                    popoverLeft: i.left,
                    popoverTop: i.top,
                    popoverRight: i.left + f,
                    popoverBottom: i.top + d,
                    popoverVerticalCenter: i.top +
                        d / 2,
                    popoverHorizontalCenter: i.left + f / 2,
                    headerHeight: n,
                    triggerHeight: w,
                    triggerWidth: t + 1,
                    triggerLeft: k.left - 1,
                    triggerTop: k.top - 1,
                    triggerRight: k.left + t + 1,
                    triggerBottom: k.top + w + 1,
                    triggerVerticalCenter: k.top + w / 2,
                    triggerHorizontalCenter: k.left + t / 2,
                    windowHeight: p.height,
                    windowWidth: p.width,
                    windowTop: A,
                    windowLeft: z,
                    windowRight: z + p.width,
                    windowBottom: A + p.height,
                    zoomTop: m.top,
                    zoomLeft: m.left
                }
            }

            function m(a) {
                return a.removeClass("a-arrow-top a-arrow-bottom a-arrow-left a-arrow-right")
            }

            function k(a) {
                var b = {
                        deltaTop: 0
                    },
                    d = 0;
                b.top = a.triggerVerticalCenter - a.popoverHeight / 2;
                if (b.top < a.windowTop + f) d = Math.min(a.windowTop + f, a.triggerTop - f), b.deltaTop = b.top - d, b.top = d;
                else if (b.top + a.popoverHeight > a.windowBottom - f) d = Math.min(f, a.windowBottom - a.triggerBottom + f), b.deltaTop = b.top + a.popoverHeight - (a.windowBottom - d), b.top = a.windowBottom - d - a.popoverHeight;
                return b
            }

            function i(a) {
                var b = {
                        deltaLeft: 0
                    },
                    d = 0;
                b.left = a.triggerHorizontalCenter - a.popoverWidth / 2;
                if (b.left < f) d = Math.min(f, a.triggerLeft - f), b.deltaLeft = b.left - d, b.left = d;
                else if (b.left +
                    a.popoverWidth > a.windowRight - f) d = Math.min(f, a.windowWidth - a.triggerRight + f), b.deltaLeft = b.left + a.popoverWidth - (a.windowRight - d), b.left = a.windowRight - d - a.popoverWidth;
                return b
            }
            var l = b.$;
            l(window);
            var j = null,
                f = 20,
                g = b.capabilities.mobile && b.capabilities.isIE10Plus;
            return {
                windowCenter: function(a) {
                    var a = n(a.$popover, a.$trigger),
                        b = {};
                    b.top = (a.windowHeight - a.popoverHeight) / 2;
                    b.left = (a.windowWidth - a.popoverWidth) / 2;
                    if (b.top < 0) b.top = 0;
                    return b
                },
                windowTop: function(a) {
                    var a = n(a.$popover, a.$trigger),
                        b = {
                            top: 0
                        };
                    b.left = a.windowWidth / 2 - a.popoverWidth / 2;
                    return b
                },
                windowFullWidth: function() {
                    return {
                        top: 0,
                        left: 0
                    }
                },
                triggerRight: function(a, b) {
                    var d = a.$popover,
                        f = a.$trigger;
                    b || (b = n(d, f));
                    f = k(b);
                    f.left = b.triggerRight;
                    m(d).addClass("a-arrow-right");
                    d.find(".a-arrow-border").css("top", b.popoverHeight / 2 + f.deltaTop);
                    return f
                },
                triggerLeft: function(a, b) {
                    var d = a.$popover,
                        f = a.$trigger;
                    b || (b = n(d, f));
                    f = k(b);
                    f.left = b.triggerLeft - b.popoverWidth;
                    m(d).addClass("a-arrow-left");
                    d.find(".a-arrow-border").css("top", b.popoverHeight /
                        2 + f.deltaTop);
                    return f
                },
                triggerTop: function(a, b) {
                    var d = a.$popover,
                        f = a.$trigger;
                    b || (b = n(d, f));
                    f = i(b);
                    f.top = b.triggerTop - b.popoverHeight;
                    m(d).addClass("a-arrow-top");
                    d.find(".a-arrow-border").css("left", b.popoverWidth / 2 + f.deltaLeft);
                    return f
                },
                triggerBottom: function(a, b) {
                    var d = a.$popover,
                        f = a.$trigger;
                    b || (b = n(d, f));
                    f = i(b);
                    f.top = b.triggerBottom;
                    m(d).addClass("a-arrow-bottom");
                    d.find(".a-arrow-border").css("left", b.popoverWidth / 2 + f.deltaLeft);
                    return f
                },
                triggerHorizontal: function(a, b) {
                    var d = a.$popover,
                        g =
                        a.$trigger;
                    b || (b = n(d, g));
                    return b.triggerLeft - b.windowLeft > b.popoverWidth + f ? this.triggerLeft(a, b) : this.triggerRight(a, b)
                },
                triggerVertical: function(a, b) {
                    var d = a.$popover,
                        g = a.$trigger,
                        d = b ? b : n(d, g);
                    return d.triggerTop - d.windowTop > d.popoverHeight + f ? this.triggerTop(a, d) : this.triggerBottom(a, d)
                },
                triggerVerticalAlignLeft: function(a, b) {
                    var d = a.$popover,
                        g = a.$trigger;
                    b || (b = n(d, g));
                    var g = {},
                        i = 0,
                        j = 0,
                        l = b.windowBottom - b.triggerBottom;
                    g.left = b.triggerLeft;
                    g.top = l > b.popoverHeight ? b.triggerBottom + 3 : b.triggerTop - b.popoverHeight -
                        3;
                    if (g.left < f) j = Math.min(f, b.triggerLeft - f), i = g.left - j, g.left = j;
                    else if (g.left + b.popoverWidth > b.windowRight - f) j = Math.min(f, b.windowWidth - b.triggerRight + f), i = g.left + b.popoverWidth - (b.windowRight - j), g.left = b.windowRight - j - b.popoverWidth;
                    m(d).addClass(l > b.popoverHeight ? "a-arrow-bottom" : "a-arrow-top");
                    d.find(".a-arrow-border").css("left", b.triggerWidth / 2 + i);
                    return g
                },
                customPosition: function(a, b) {
                    return b.call(this, {
                        popover: a,
                        $popover: a.$popover,
                        $trigger: a.$trigger,
                        measure: n
                    })
                }
            }
        });
        p.when("A").register("a-popover-util",
            function(b) {
                function n(b, l) {
                    for (var j = b.children.length; j--;) {
                        var f = n(b.children[j], l);
                        if (f) return f
                    }
                    if (l(b)) return b
                }
                var m = b.$,
                    k = /^-?\d+(?:\.\d+)?$/;
                return {
                    trigger: function(i, l) {
                        b.trigger("a:popover:" + i, {
                            popover: l
                        });
                        l.name && b.trigger("a:popover:" + i + ":" + l.name, {
                            popover: l
                        })
                    },
                    extractDeclarativeParams: function(b, l) {
                        var j = m(b),
                            j = j.hasClass("a-declarative") ? j : j.find(".a-declarative").eq(0),
                            f = "a-" + l,
                            g = j.length ? j.data("action").indexOf(f) !== -1 : !1,
                            f = j ? j.data(f) : null;
                        return g ? {
                            attributes: f,
                            $trigger: j
                        } : null
                    },
                    eventOccursWithin: function(b, l) {
                        var j = m(b.target);
                        return j.closest(l.$trigger).length > 0 || j.closest(l.$popover).length > 0
                    },
                    search: n,
                    getCSSHash: function(i) {
                        var l = {};
                        b.each("height,width,max-height,max-width,min-height,min-width".split(","), function(j) {
                            if (i[j]) {
                                var f = i[j];
                                if (b.isFiniteNumber(f) || k.test(f)) f += "px";
                                l[j] = f
                            }
                        });
                        l.height && !l["max-height"] && (l["max-height"] = "none");
                        l.width && !l["max-width"] && (l["max-width"] = "none");
                        return l
                    },
                    clearContent: function(b) {
                        (b = b.getContent()) && b.empty()
                    },
                    showSpinner: function(b) {
                        b.updateContent('<div class="a-popover-loading-wrapper a-text-center"><div class="a-box a-color-base-background a-popover-loading"></div></div>');
                        b.updatePosition();
                        return b
                    }
                }
            });
        p.when("A", "a-popover-util").register("a-modal-variant-base", function(b, n) {
            var m = b.$,
                k = m("html").hasClass("a-lt-ie9");
            return {
                updateContent: function(b) {
                    typeof b === "string" ? this.$popover.find(".a-popover-inner").html(b) : b && this.$popover.find(".a-popover-inner").html("").append(b)
                },
                updateDimensions: function() {
                    var b = this.$popover,
                        l = n.getCSSHash(this.attrs());
                    b.css(l);
                    l.height ? b.addClass("a-popover-modal-fixed-height") : b.removeClass("a-popover-modal-fixed-height");
                    this.isActive() &&
                        this.updatePosition();
                    return this
                },
                getContent: function() {
                    return this.$popover ? this.$popover.find(".a-popover-inner") : null
                },
                showMethod: function() {
                    var i = this,
                        l = i.$popover;
                    !k && i.attrs("currentDataStrategy") !== "ajax" ? (l.css({
                        opacity: 0,
                        visibility: "visible"
                    }).removeClass("a-popover-hidden"), b.delay(function() {
                        b.animate(l, {
                            opacity: 1
                        }, 500, "linear");
                        i.focus()
                    }, 0)) : b.delay(function() {
                        l.css({
                            visibility: "visible"
                        }).removeClass("a-popover-hidden");
                        i.focus()
                    }, 0)
                },
                hideMethod: function() {
                    var i = this.attrs("originalFocus");
                    k ? this.$popover.hide().css("visibility", "hidden").find(".a-lgtbox-vertical-scroll").removeClass("a-lgtbox-vertical-scroll") : b.fadeOut(this.$popover, 250, "linear");
                    i && i.focus()
                }
            }
        });
        p.when("A", "a-modal-variant-base", "a-modal-positions", "a-popover-accessibility").register("a-modal-variant", function(b, n, m, k) {
            var i = b.$,
                i = i("html").hasClass("a-lt-ie9");
            return b.extend(n, b.capabilities.touch || b.capabilities.mobile || b.capabilities.tablet || i ? m.innerScroll : m.modalScroll, {
                skin: function(b) {
                    var j = b.attrs("id"),
                        f = b.attrs("header") || "",
                        g = b.attrs("footer"),
                        a = b.attrs("closeButton"),
                        e = b.attrs("closeButtonLabel") ? b.attrs("closeButtonLabel") : "",
                        b = b.attrs("popoverLabel") ? b.attrs("popoverLabel") : "",
                        a = a ? '<button data-action="a-popover-close" class="a-button-close a-declarative" aria-label="' + e + '"><i class="a-icon a-icon-close"></i></button>' : "",
                        g = g ? ['<div class="a-popover-footer">', g, "</div>"].join("") : "";
                    return ['<div class="a-modal-scroller a-declarative" data-action="a-popover-floating-close"><div class="a-popover a-popover-modal a-declarative" data-action="a-popover-a11y">',
                        k.getStartAnchorHtml(j, f, b), '<div class="a-popover-wrapper"><div class="a-popover-header">', a, '<h4 class="a-popover-header-content" id="a-popover-header-', j, '">', f, '</h4></div><div class="a-popover-inner" id="a-popover-content-', j, '"></div>', g, "</div>", k.getEndAnchorHtml(j, f, b), "</div></div>"
                    ].join("")
                }
            })
        });
        p.when("A", "a-popover-lightbox").register("a-modal-positions", function(b, n) {
            function m(b) {
                var g = b.$popover.closest(".a-modal-scroller");
                g.scrollTop(0).css("visibility", "visible");
                g.bind("scroll",
                    function() {
                        b.updateChildrenPosition()
                    })
            }

            function k() {
                var f = b.viewport();
                f.width / f.height > 2 && b.delay(function() {
                    document.activeElement.scrollIntoView();
                    window.scrollTo(window.pageXOffset, 0)
                }, 0)
            }
            var i = b.$,
                l = document.documentElement.className.indexOf("a-lt-ie7") > -1,
                j = b.capabilities.isIE10Plus && b.capabilities.mobile;
            return {
                innerScroll: {
                    positionStrategy: function(f) {
                        var g = f.popover,
                            a = f.$popover,
                            e = f.$trigger,
                            d = a.find(".a-popover-inner").css("height", "auto"),
                            o = a.closest(".a-modal-scroller"),
                            m = {},
                            s = b.viewport(!0),
                            p = s.height * 0.1,
                            s = s.height * 0.8,
                            u = g.attrs("height"),
                            g = g.attrs("min-height");
                        a.css({
                            height: u ? u : "",
                            "min-height": g ? g : ""
                        });
                        f = f.measure(a, e);
                        m.left = (f.windowWidth - f.popoverWidth) / 2;
                        if (m.left < 0) m.left = p, a.css("padding-right", p);
                        f.popoverHeight > s ? (e = a.find(".a-popover-header").outerHeight() || 0, g = a.find(".a-popover-footer").outerHeight() || 0, d.css({
                            height: s - e - g + "px",
                            "overflow-y": "auto"
                        }), a.css({
                            height: s,
                            "min-height": 0
                        }), m.top = p) : (m.top = (f.windowHeight - f.popoverHeight) / 2, d.css("height", "auto"));
                        m.left += f.zoomLeft;
                        m.top += f.zoomTop;
                        l && o.css("top", document.getElementById(n.LIGHTBOX_ID).style.top);
                        j && (o.css("top", i(window).scrollTop()), a.removeClass("a-popover-pan-y").addClass("a-popover-pan-x"), a = i(document).height(), d = i(document).width(), i("#" + n.LIGHTBOX_ID).css({
                            height: a,
                            width: d > f.popoverWidth ? d : f.popoverWidth + p
                        }));
                        b.capabilities.isMetroIEGuess && b.capabilities.isIETouchCapable && k();
                        return m
                    },
                    beforeShowMethod: b.constants.NOOP,
                    beforeHideMethod: b.constants.NOOP
                },
                modalScroll: {
                    positionStrategy: function(f) {
                        var g =
                            f.$popover,
                            a = f.$trigger,
                            e = g.closest(".a-modal-scroller"),
                            d = g.find(".a-popover-inner").css("height", "auto");
                        if (g.hasClass("a-popover-modal-fixed-height")) {
                            var o = g.find(".a-popover-footer");
                            d.css("padding-bottom", o.height() + 15)
                        }
                        var d = {},
                            j = b.viewport(!0),
                            i = j.height,
                            o = i * 0.1;
                        i *= 0.8;
                        var j = j.width * 0.8,
                            l = g.height(),
                            m = g.width(),
                            f = f.measure(g, a);
                        d.left = (f.windowWidth - m) / 2;
                        d.top = (f.windowHeight - l) / 2;
                        if (m > j) d.left = o, g.css("padding-right", o);
                        if (l > i)
                            if (e.length) d.top = 0, g.css({
                                position: "static",
                                margin: f.zoomTop +
                                    o + "px 0 " + o + "px " + (f.zoomLeft + d.left) + "px"
                            }), e.css("padding-bottom", "1px");
                            else {
                                if (m > j) d.left = o;
                                if (l > i) d.top = o
                            } else e.length && (g.css({
                            position: "absolute",
                            margin: "0px"
                        }), e.css("padding-bottom", "0px"));
                        d.left += f.zoomLeft;
                        d.top += f.zoomTop;
                        b.capabilities.isMetroIEGuess && b.capabilities.isIETouchCapable && k();
                        return d
                    },
                    beforeShowMethod: function() {
                        m(this)
                    },
                    beforeHideMethod: function() {
                        this.$popover.closest(".a-modal-scroller").css("visibility", "hidden").unbind("scroll")
                    }
                }
            }
        });
        p.when("A", "a-popover-base-factory",
            "a-modal-variant", "a-popover-util").register("a-modal-factory", function(b, n, m, k) {
            function i(b, a) {
                a = {
                    type: l,
                    alone: !0,
                    immersive: !0,
                    position: "windowCenter",
                    header: a.header,
                    footer: a.footer,
                    width: a.width,
                    height: a.height,
                    "max-width": a["max-width"],
                    "max-height": a["max-height"],
                    "min-width": a["min-width"],
                    "min-height": a["min-height"],
                    closeButton: a.closeButton === "false" || a.closeButton === !1 ? !1 : !0,
                    timeout: a.timeout,
                    lightboxOptions: {
                        lockScroll: !0,
                        showDuration: j || f ? 0 : null
                    },
                    data: a.data || {},
                    dataStrategy: a.dataStrategy,
                    url: a.url,
                    manualRefresh: !!a.manualRefresh,
                    ajaxFailMsg: a.ajaxFailMsg,
                    cache: a.cache === "false" || a.cache === !1 ? !1 : !0,
                    inlineContent: a.inlineContent ? a.inlineContent : a.content,
                    name: a.name,
                    closeButtonLabel: a.closeButtonLabel ? a.closeButtonLabel : "Close",
                    popoverLabel: a.popoverLabel
                };
                return n.create(b, {
                    attributes: a,
                    variant: m,
                    actionCheck: !0
                })
            }
            var l = "modal",
                j = document.documentElement.className.indexOf("a-lt-ie9") > -1,
                f = b.capabilities.mobile && b.capabilities.isIE10Plus;
            return {
                type: l,
                create: i,
                get: function(b) {
                    var a =
                        n.get(b, l);
                    !a && typeof b === "object" && (b = k.extractDeclarativeParams(b, l)) && (a = i(b.$trigger, b.attributes || {}));
                    return a
                },
                remove: function(b) {
                    return n.remove(b, l)
                }
            }
        });
        p.when("A", "a-popover-base-factory", "a-modal-factory").register("a-modal-handlers", function(b, n, m) {
            var k = b.$;
            b.declarative("a-modal", "click", function(b) {
                m.get(b.$declarativeParent).show();
                b.$event.preventDefault()
            });
            k(document).keydown(function(i) {
                if (i.keyCode === b.constants.keycodes.ESCAPE)
                    for (var i = n.getRoot(), l = i.children.length, j = !1; l-- &&
                        !j;) {
                        var f = i.children[l];
                        f.type === "modal" && f.isActive() && (f.unlock().hide(), j = !0)
                    }
            });
            k(document).delegate(".a-modal-scroller", "click " + b.action.start + " " + b.action.move, function(b) {
                b.target === this && b.preventDefault()
            })
        });
        p.when("A", "a-modal-factory", "a-popover-base", "a-modal-handlers").register("a-modal", function(b, n) {
            return n
        });
        p.when("A", "a-popover-util").register("a-popover-variant-base", function(b, n) {
            return {
                updateContent: function(b) {
                    typeof b === "string" ? this.$popover.find(".a-popover-content").html(b) :
                        b && this.$popover.find(".a-popover-content").html("").append(b)
                },
                updateDimensions: function() {
                    this.$popover.css(n.getCSSHash(this.attrs()));
                    this.isActive() && this.updatePosition();
                    return this
                },
                getContent: function() {
                    return this.$popover ? this.$popover.find(".a-popover-content") : null
                },
                hideMethod: function() {
                    b.fadeOut(this.$popover, 250, "linear")
                }
            }
        });
        p.when("A", "a-popover-variant-base", "a-popover-util", "a-popover-accessibility").register("a-popover-variant", function(b, n, m, k) {
            return b.extend(n, {
                skin: function(b) {
                    var l =
                        b.attrs("id"),
                        j = b.attrs("header"),
                        f = b.attrs("closeButton"),
                        g = b.attrs("closeButtonLabel") ? b.attrs("closeButtonLabel") : "",
                        b = b.attrs("popoverLabel") ? b.attrs("popoverLabel") : "",
                        f = f ? '<button data-action="a-popover-close" class="a-button-close a-declarative" aria-label="' + g + '"><i class="a-icon a-icon-close"></i></button>' : "",
                        g = j && j !== "" ? ['<div class="a-popover-header">', f, '<h4 class="a-popover-header-content" id="a-popover-header-', l, '">', j, "</h4></div>"].join("") : "";
                    return ['<div class="a-popover a-declarative" data-action="a-popover-container a-popover-a11y"><div class="a-popover-wrapper">',
                        k.getStartAnchorHtml(l, j, b), g, '<div class="a-popover-inner">', g === "" ? f : "", '<div class="a-popover-content" id="a-popover-content-', l, '"></div></div>', k.getEndAnchorHtml(l, j, b), '<div class="a-arrow-border"><div class="a-arrow"></div></div></div></div>'
                    ].join("")
                }
            })
        });
        p.when("A", "a-popover-base-factory", "a-popover-variant", "a-popover-util").register("a-popover-factory", function(b, n, m, k) {
            function i(b, f) {
                f = {
                    type: l,
                    alone: !0,
                    header: f.header,
                    width: f.width,
                    height: f.height,
                    "max-width": f["max-width"],
                    "max-height": f["max-height"],
                    "min-width": f["min-width"],
                    "min-height": f["min-height"],
                    closeButton: f.closeButton === "false" || f.closeButton === !1 ? !1 : !0,
                    position: f.position || "triggerVertical",
                    activate: f.activate || "onmouseover",
                    timeout: f.timeout,
                    data: f.data || {},
                    dataStrategy: f.dataStrategy,
                    url: f.url,
                    manualRefresh: !!f.manualRefresh,
                    ajaxFailMsg: f.ajaxFailMsg,
                    cache: f.cache === "false" || f.cache === !1 ? !1 : !0,
                    inlineContent: f.inlineContent ? f.inlineContent : f.content,
                    name: f.name,
                    closeButtonLabel: f.closeButtonLabel ? f.closeButtonLabel : "Close",
                    popoverLabel: f.popoverLabel
                };
                return n.create(b, {
                    attributes: f,
                    variant: m,
                    actionCheck: !0
                })
            }
            var l = "popover";
            return {
                type: l,
                create: i,
                get: function(b) {
                    var f = n.get(b, l);
                    !f && typeof b === "object" && (b = k.extractDeclarativeParams(b, l)) && (f = i(b.$trigger, b.attributes || {}));
                    return f
                },
                remove: function(b) {
                    return n.remove(b, l)
                }
            }
        });
        p.when("A", "a-popover-factory").register("a-popover-handlers", function(b, n) {
            function m(f) {
                if (f && !f.destroyTimer) f.destroyTimer = b.delay(function() {
                    f.hide()
                }, 250)
            }

            function k(b) {
                if (b) clearTimeout(b.destroyTimer), b.destroyTimer =
                    null, clearTimeout(b.parent.destroyTimer), b.parent.destroyTimer = null
            }
            var i = b.$,
                l = 2,
                j = 200,
                l = 2,
                j = 200;
            b.declarative("a-popover", "click", function(b) {
                var a = n.get(b.$declarativeParent);
                a && a.attrs("activate") === "onclick" && (a.show(), b.$event.preventDefault())
            });
            b.declarative("a-popover", "keydown", function(f) {
                f.$event.keyCode === b.constants.keycodes.ENTER && n.get(f.$declarativeParent).show()
            });
            var f;
            b.declarative("a-popover", "mouseenter", function(g) {
                var a = n.get(g.$declarativeParent);
                a && a.attrs("activate") ===
                    "onmouseover" && (k(a), f = b.delay(function() {
                        n.get(g.$declarativeParent).show()
                    }, j))
            });
            b.declarative("a-popover", "mousemove", function(f) {
                b.cursor().speed < l && (f = n.get(f.$declarativeParent)) && f.attrs("activate") === "onmouseover" && f.show()
            });
            b.declarative("a-popover", "mouseleave", function(b) {
                if ((b = n.get(b.$declarativeParent)) && b.attrs("activate") === "onmouseover") b && m(b), f && clearTimeout(f)
            });
            b.declarative("a-popover-container", "mouseenter", function(b) {
                (b = n.get(b.$declarativeParent)) && b.attrs("activate") ===
                    "onmouseover" && k(b)
            });
            b.declarative("a-popover-container", "mouseleave", function(f) {
                var a = n.get(f.$declarativeParent),
                    e = !0,
                    d = i(f.$event.relatedTarget);
                a && a.attrs("activate") === "onmouseover" && a.isActive() && (b.each(a.children, function(a) {
                    if (d.closest(a.$popover).length) return e = !1
                }), e && (m(a), !a.parent.immersive && d.closest(a.parent.$popover).length === 0 && m(a.parent)))
            })
        });
        p.when("A", "a-popover-factory", "a-popover-base", "a-popover-handlers").register("a-popover", function(b, n) {
            return n
        });
        p.when("A", "a-popover-base-factory",
            "a-secondary-view-variant", "p-detect", "a-popover-util").register("a-secondary-view-factory", function(b, n, m, k, i) {
            function l(b, d) {
                d.disableAnimation = d.disableAnimation || g;
                return n.create(b, {
                    attributes: {
                        type: f,
                        immersive: !0,
                        disableAnimation: a || d.disableAnimation,
                        synchronous: !!(a || d.synchronous && d.synchronous !== "false"),
                        animationLength: d.disableAnimation ? 0 : 300,
                        alternateBackground: d.alternateBackground || !1,
                        hideHeader: a || d.hideHeader || !1,
                        scrollable: d.scrollable || !0,
                        header: d.header,
                        backButtonText: d.backButtonText,
                        position: "windowFullWidth",
                        timeout: d.timeout,
                        dataStrategy: d.dataStrategy,
                        inlineContent: d.inlineContent ? d.inlineContent : d.content,
                        url: d.url,
                        manualRefresh: !!d.manualRefresh,
                        name: d.name,
                        cache: d.cache === "false" || d.cache === !1 ? !1 : !0,
                        data: d.data || {},
                        popoverLabel: d.popoverLabel
                    },
                    variant: m,
                    actionCheck: !0
                })
            }
            var j = b.$,
                f = "secondary-view",
                g = navigator.userAgent.match(/Android\s[12]/),
                a = !1;
            p.when("mash-will-load").execute(function() {
                a = !0
            });
            return {
                type: f,
                create: l,
                get: function(a) {
                    var b = n.get(a, f);
                    if (!b && typeof a ===
                        "object") {
                        var g = i.extractDeclarativeParams(a, f);
                        g && (b = l(g.$trigger, g.attributes || {}))
                    }
                    if (b && typeof a === "object") a = j(a), a = a.hasClass("a-declarative") ? a : a.find(".a-declarative").eq(0), g = "a-" + f, a = a ? a.data(g) : null, b.data = a.data;
                    return b
                },
                remove: function(a) {
                    return n.remove(a, f)
                }
            }
        });
        p.when("A", "a-popover-base", "a-secondary-view-factory", "a-secondary-view-handlers").register("a-secondary-view", function(b, n, m) {
            return m
        });
        p.when("A").register("a-tooltip-variant-base", function(b) {
            return {
                updateContent: function(b) {
                    this.$popover.find(".a-tooltip-inner").html(b)
                },
                getContent: function() {
                    return this.$popover ? this.$popover.find(".a-tooltip-inner") : null
                },
                hideMethod: function() {
                    b.fadeOut(this.$popover, 250, "linear")
                }
            }
        });
        p.when("A", "a-tooltip-variant-base").register("a-tooltip-variant", function(b, n) {
            return b.extend(n, {
                skin: function() {
                    return '<div role="tooltip" class="a-popover a-tooltip a-declarative" data-action="a-popover-close"><div class="a-tooltip-inner"></div><div class="a-arrow-border"><div class="a-arrow"></div></div></div>'
                }
            })
        });
        p.when("A", "a-popover-base-factory",
            "a-tooltip-variant", "a-popover-util").register("a-tooltip-factory", function(b, n, m, k) {
            function i(b, f) {
                f = {
                    type: l,
                    inlineContent: f.inlineContent ? f.inlineContent : f.content,
                    position: f.position || "triggerVertical",
                    activate: f.activate || "onmouseover"
                };
                return n.create(b, {
                    attributes: f,
                    variant: m,
                    actionCheck: !0
                })
            }
            var l = "tooltip";
            return {
                type: l,
                create: i,
                get: function(b) {
                    var f = n.get(b, l);
                    !f && typeof b === "object" && (b = k.extractDeclarativeParams(b, l)) && (f = i(b.$trigger, b.attributes || {}));
                    return f
                },
                remove: function(b) {
                    return n.remove(b,
                        l)
                }
            }
        });
        p.when("A", "a-tooltip-factory").register("a-tooltip-handlers", function(b, n) {
            b.declarative("a-tooltip", "click", function(b) {
                var k = n.get(b.$declarativeParent);
                k && k.attrs("activate") === "onclick" && (k.show(), b.$event.preventDefault())
            });
            b.declarative("a-tooltip", "mouseenter", function(b) {
                if ((b = n.get(b.$declarativeParent)) && b.attrs("activate") === "onmouseover")
                    if (b.show(), b.destroyTimer) clearTimeout(b.destroyTimer), b.destroyTimer = null
            });
            b.declarative("a-tooltip", "mouseleave", function(m) {
                var k = n.get(m.$declarativeParent);
                if (k && k.attrs("activate") === "onmouseover") k.destroyTimer = b.delay(function() {
                    k.hide()
                }, 125)
            })
        });
        p.when("A", "a-tooltip-factory", "a-popover-base", "a-tooltip-handlers").register("a-tooltip", function(b, n) {
            return n
        })
    })
})(function() {
    var p = window.AmazonUIPageJS || P,
        b = p.attributeErrors;
    return b ? b("AmazonUIPopoverJS") : p
}());
(function(p) {
    p.execute(function() {})
})(function() {
    var p = window.AmazonUIPageJS || P,
        b = p.attributeErrors;
    return b ? b("AmazonUIPopover") : p
}());
(function(p) {
    p.execute(function() {
        p.when("A").register("a-tabs", function(b) {
            var n = b.$;
            b.declarative("a-tabs", ["click"], function(m) {
                var k = m.$target.closest("li"),
                    i = m.data.name,
                    l = k.data("a-tab-name"),
                    j = k.closest(".a-tab-container").find(".a-box-tab");
                l && (n("li.a-active", k.closest(".a-tabs")).removeClass("a-active"), k.closest("li").addClass("a-active"), j.addClass("a-hidden"), j.filter('[data-a-name="' + l + '"]').removeClass("a-hidden"), k = {
                        $tab: k,
                        tabName: l,
                        tabSetName: i
                    }, b.trigger("a:tabs:" + i + ":select", {
                        selectedTab: k
                    }),
                    b.trigger("a:tabs:" + i + ":" + l + ":select", {
                        selectedTab: k
                    }), m.$event.preventDefault())
            })
        });
        p.when("A").register("a-accordion", function(b) {
            var n = "slideDown",
                m = "slideUp",
                k = 300;
            if (b.capabilities.mobile || b.capabilities.tablet) n = "show", m = "hide", k = 0;
            b.declarative("a-accordion", ["click"], function(i) {
                var l = i.$target.closest(".a-accordion"),
                    j = i.$target.closest(".a-box"),
                    f = l.find(".a-box").not(j),
                    g = l.data("a-accordion-name"),
                    a = j.data("a-accordion-row-name"),
                    l = l.hasClass("a-accordion-collapse");
                if (a) {
                    var e = j.find(".a-accordion-inner"),
                        d = !0;
                    if (j.hasClass("a-accordion-active"))
                        if (l) e[m]({
                            duration: k,
                            complete: function() {
                                j.removeClass("a-accordion-active").attr("aria-expanded", "false");
                                j.find(".a-icon.a-accordion-radio").removeClass("a-icon-radio-active").addClass("a-icon-radio-inactive")
                            }
                        });
                        else d = !1;
                    else f.find(".a-accordion-inner").attr("aria-expanded", "false")[m]({
                        duration: k,
                        complete: function() {
                            f.removeClass("a-accordion-active")
                        }
                    }), e.attr("aria-expanded", "true")[n]({
                        duration: k,
                        complete: function() {
                            j.addClass("a-accordion-active");
                            f.find(".a-icon.a-accordion-radio").removeClass("a-icon-radio-active").addClass("a-icon-radio-inactive");
                            j.find(".a-icon.a-accordion-radio").removeClass("a-icon-radio-inactive").addClass("a-icon-radio-active")
                        }
                    });
                    d && (l = {
                        $row: j,
                        rowName: a,
                        accordionName: g
                    }, b.trigger("a:accordion:select", {
                        selectedRow: l
                    }), b.trigger("a:accordion:" + g + ":select", {
                        selectedRow: l
                    }), b.trigger("a:accordion:" + g + ":" + a + ":select", {
                        selectedRow: l
                    }))
                }
                i.$event.preventDefault()
            })
        });
        p.when("A", "jQuery").register("a-expander", function(b,
            n) {
            var m, k, i;

            function l(a, b) {
                var d = a.closest("." + m),
                    f = d.data("a-expander-collapsed-height"),
                    g = a.attr("aria-expanded") === "true";
                a.toggleClass(k + "-expanded");
                f ? (d.css("height", g ? f : "auto"), a.attr("aria-expanded", g ? "false" : "true"), b()) : a.toggle(0, function() {
                    a.attr("aria-expanded", g ? "false" : "true");
                    b()
                })
            }

            function j() {
                n(".a-expander-partial-collapse-container").each(function() {
                    var a = n(this),
                        b = a.children("." + k),
                        d = a.data("a-expander-collapsed-height"),
                        f = a.children("." + i);
                    b.height() <= d ? f.css({
                        opacity: "0",
                        display: "none"
                    }) : (f.css({
                        opacity: "1",
                        display: "block"
                    }), b.css("padding-bottom", f.height()), b.attr("aria-expanded") !== "true" && a.css({
                        height: d,
                        "max-height": "none"
                    }))
                })
            }
            var f = {
                inline: {
                    expand: "a-icon-expand",
                    collapse: "a-icon-collapse"
                },
                section: {
                    expand: "a-icon-section-expand",
                    collapse: "a-icon-section-collapse"
                },
                extender: {
                    expand: "a-icon-extender-expand",
                    collapse: "a-icon-extender-collapse"
                }
            };
            m = "a-expander-container";
            k = "a-expander-content";
            i = "a-expander-header";
            var g = {};
            b.each(f, function(a, e) {
                g[e] = {};
                b.each(a,
                    function(a, b) {
                        g[e][b] = RegExp("\\b" + a + "\\b", "g")
                    })
            });
            b.declarative("a-expander-toggle", "click", function(a) {
                var e = a.$target.closest("." + m),
                    d = e.find("." + m),
                    o = e.data("a-expander-name"),
                    j;
                j = a.$currentTarget.hasClass(i) ? a.$currentTarget : e.find("." + i).not(d.find("." + i));
                var n = e.find("." + k).not(d.find("." + k));
                l(n, function() {
                    var i = j.find(".a-icon")[0],
                        l = null,
                        k = j.children(".a-expander-content-fade");
                    if (n.attr("aria-expanded") === "false") {
                        if (i) i.className = i.className.replace(g.inline.collapse, f.inline.expand).replace(g.section.collapse,
                            f.section.expand).replace(g.extender.collapse, f.extender.expand);
                        a.data && a.data.expand_prompt && (l = a.data.expand_prompt);
                        k.show();
                        i = "collapse"
                    } else {
                        if (i) i.className = i.className.replace(g.inline.expand, f.inline.collapse).replace(g.section.expand, f.section.collapse).replace(g.extender.expand, f.extender.collapse);
                        a.data && a.data.collapse_prompt && (l = a.data.collapse_prompt);
                        k.hide();
                        i = "expand"
                    }
                    l && l !== "" && j.find(".a-expander-prompt").not(d.find(".a-expander-prompt")).html(l);
                    l = {
                        $expander: e,
                        expanderName: o
                    };
                    b.trigger("a:expander:toggle", {
                        expander: l
                    });
                    b.trigger("a:expander:toggle:" + i, {
                        expander: l
                    });
                    o && (b.trigger("a:expander:" + o + ":toggle", {
                        expander: l
                    }), b.trigger("a:expander:" + o + ":toggle:" + i, {
                        expander: l
                    }))
                })
            });
            b.on("ready resize orientationchange a:popover:afterShow a:popover:ajaxContentLoaded", j);
            return {
                initializeExpanders: j
            }
        });
        p.when("A").register("a-form-controls-api", function(b) {
            var n = b.$,
                m = {
                    checkboxes: {
                        "multi-select": {
                            active: "a-icon-touch-multi-select-active",
                            inactive: "a-icon-touch-multi-select"
                        },
                        checkbox: {
                            active: "a-icon-checkbox-active" +
                                (b.capabilities.mobile || b.capabilities.tablet ? " a-icon-touch-checkbox-active" : ""),
                            inactive: "a-icon-checkbox-inactive" + (b.capabilities.mobile || b.capabilities.tablet ? " a-icon-touch-checkbox-inactive" : ""),
                            disabled: "a-icon-checkbox-disabled"
                        }
                    },
                    radio: {
                        active: "a-icon-radio-active" + (b.capabilities.mobile || b.capabilities.tablet ? " a-icon-touch-radio-active" : ""),
                        inactive: "a-icon-radio-inactive" + (b.capabilities.mobile || b.capabilities.tablet ? " a-icon-touch-radio-inactive" : ""),
                        disabled: "a-icon-radio-disabled"
                    }
                },
                k = 0,
                i = function(a) {
                    return a && a.jquery ? a : a && a.nodeType === 1 ? n(a) : null
                },
                l = function(a) {
                    return a.find("input").first()
                },
                j = function(a) {
                    if ((a = i(a)) && a.length === 1) {
                        var b = a.closest("form");
                        b.length === 0 && (b = a.closest("fieldset"), b.length === 0 && (b = n(document)));
                        return b
                    }
                },
                f = function(a, b, d) {
                    var a = i(a),
                        f = !!b,
                        g = !!d;
                    if (a && a.length === 1) {
                        var j = l(a),
                            k = a.find("i.a-icon").first(),
                            n = a.hasClass("a-touch-multi-select") ? "multi-select" : "checkbox";
                        a.data("a-checkbox-tabindex");
                        if (b !== void 0) {
                            var b = m.checkboxes[n].active,
                                p = m.checkboxes[n].inactive,
                                t = j.prop("checked");
                            k.toggleClass(b, f).toggleClass(p, !f);
                            a.attr("aria-checked", f);
                            t !== f && j.prop("checked", f).trigger("change")
                        }
                        if (d !== void 0 && n === "checkbox") d = m.checkboxes[n].disabled, f = j.prop("disabled"), k.toggleClass(d, g), a.attr("aria-disabled", g), f !== g && j.prop("disabled", g)
                    }
                },
                g = function(a, b, d) {
                    var a = i(a),
                        f = !!b,
                        g = !!d;
                    if (a && a.length === 1) {
                        var k = l(a),
                            n = a.find("i.a-icon").first(),
                            p = a.data("a-radio-tabindex"),
                            y = j(k),
                            t = k[0].name,
                            w = y.find('i[data-a-input-name="' + t + '"]');
                        y.find('input[name="' + t + '"]');
                        y =
                            w.closest(".a-radio-fancy, .a-touch-radio");
                        if (b !== void 0) {
                            var b = m.radio.active,
                                t = m.radio.inactive,
                                z = k.prop("checked");
                            f && (y.attr({
                                "aria-checked": !1,
                                tabindex: -1
                            }), w.addClass(t).removeClass(b));
                            a.attr({
                                "aria-checked": f,
                                tabindex: f ? p ? p : 0 : -1
                            });
                            n.toggleClass(b, f).toggleClass(t, !f);
                            z !== f && k.prop("checked", f).trigger("change")
                        }
                        if (d !== void 0) d = m.radio.disabled, f = k.prop("disabled"), n.toggleClass(d, g), a.attr("aria-disabled", g), f !== g && k.prop("disabled", g);
                        y.filter('[aria-checked="true"]').length === 0 && y.first().attr("tabindex",
                            p ? p : 0)
                    }
                };
            return {
                findFormElementContainer: j,
                toggleCheckboxState: function(a) {
                    if ((a = i(a)) && a.length === 1) {
                        var b = l(a);
                        f(a, !b[0].checked)
                    }
                },
                setCheckboxState: f,
                setRadioState: g,
                normalizeElement: function(a) {
                    if ((a = (a = i(a)) ? a : i(this)) && a.length === 1) {
                        var b = l(a),
                            d = b.attr("type"),
                            o = a.hasClass("a-touch-multi-select");
                        if (!a.attr("id") && !b.attr("id") && (!o || o && !a.parent().attr("id"))) o = "a-form-controls-autoid-" + k, a.attr("aria-labelledby", o).find(".a-checkbox-label, .a-radio-label, .a-touch-multi-select-item-label").attr("id",
                            o), k++;
                        switch (d) {
                            case "checkbox":
                                d = a.attr("tabindex");
                                a.data("a-checkbox-tabindex", d > -1 ? d : 0);
                                f(a, b[0].checked, b[0].disabled);
                                break;
                            case "radio":
                                g(a, b[0].checked, b[0].disabled)
                        }
                    }
                },
                normalizeRadioGroups: function(a) {
                    var b = {};
                    n(a).each(function(d, f) {
                        var g = n(f),
                            g = l(g),
                            i = g[0].name;
                        if (!(i === void 0 || b[i])) {
                            b[i] = !0;
                            var g = j(g).find('input[name="' + i + '"]').closest(a),
                                k = g.length,
                                m = 0,
                                p;
                            g.each(function(a, b) {
                                var d = n(b),
                                    e = d.attr("tabindex");
                                d.attr({
                                    "aria-posinset": a + 1,
                                    "aria-setsize": k
                                });
                                if (e > 0 && (m === 0 || e < m)) m = e;
                                d.attr("aria-checked") ===
                                    "true" && (p = d)
                            }).data("a-radio-tabindex", m);
                            p ? p.attr("tabindex", m) : g.first().attr("tabindex", m)
                        }
                    })
                },
                normalizeFieldsets: function(a) {
                    n(a).closest("fieldset").each(function(a, b) {
                        var f = n(b),
                            g = f.find("legend").first();
                        if (g.length) {
                            var i = g.attr("id");
                            i || (i = "a-form-controls-autoid-" + k, g.attr("id", i), k++);
                            f.attr("aria-describedby", i)
                        }
                    })
                }
            }
        });
        p.when("A", "a-form-controls-api").register("a-form-controls-handlers", function(b, n) {
            var m = b.$,
                k = b.constants.keycodes.UP_ARROW,
                i = b.constants.keycodes.DOWN_ARROW,
                l = b.constants.keycodes.LEFT_ARROW,
                j = b.constants.keycodes.RIGHT_ARROW,
                f = function() {
                    m(this).removeClass("a-hover-disable")
                },
                g = function(a) {
                    var e = m(this),
                        d = e.find("input"),
                        g = d.attr("type");
                    if (!d[0].disabled) {
                        switch (g) {
                            case "checkbox":
                                !b.capabilities.mobile && !b.capabilities.tablet && d[0].checked && a && a.type !== "keydown" && (e.addClass("a-hover-disable"), e.one("mouseleave", f));
                                n.setCheckboxState(e, !d[0].checked);
                                break;
                            case "radio":
                                n.setRadioState(e, !0)
                        }
                        a && a.preventDefault && a.preventDefault()
                    }
                };
            return {
                elementClicked: g,
                navigateRadiosWithArrows: function(a) {
                    var b =
                        m(this),
                        d = b.find("input")[0].name,
                        f = a.keyCode,
                        r;
                    if (f === k || f === i || f === l || f === j) {
                        var d = n.findFormElementContainer(b).find('.a-radio-fancy[data-a-input-name="' + d + '"], .a-touch-radio[data-a-input-name="' + d + '"]'),
                            s = d.length,
                            b = d.index(b);
                        if (b > 0 && (f === k || f === l)) r = d.eq(b - 1);
                        else if (s > b + 1 && (f === i || f === j)) r = d.eq(b + 1)
                    }
                    r && (g.call(r, a), r.focus(), r.attr("aria-disabled") === "true" && a && a.preventDefault && a.preventDefault())
                },
                accessibilityKeyPress: function(a) {
                    a.keyCode === b.constants.keycodes.SPACE && (a.preventDefault(),
                        a.stopPropagation())
                },
                formReset: function(a, e) {
                    var d = n.findFormElementContainer(a);
                    b.delay(function() {
                        d.find(e).each(n.normalizeElement)
                    }, 0)
                }
            }
        });
        p.when("A", "a-form-controls-api", "a-form-controls-handlers", "ready").register("a-form-controls", function(b, n, m) {
            function k(b) {
                m.formReset(b.currentTarget, l)
            }
            var i = b.$,
                l = ".a-radio-fancy, .a-checkbox-fancy";
            i("html").hasClass("a-lt-ie8") || (i(document).delegate(l, "click", m.elementClicked).delegate(l, "keypress", m.accessibilityKeyPress).delegate(l, "keydown", function(i) {
                i.keyCode ===
                    b.constants.keycodes.SPACE && m.elementClicked.call(this, i)
            }).delegate(".a-radio-fancy", "keydown", m.navigateRadiosWithArrows), b.on("a:pageUpdate beforeReady", function() {
                n.normalizeRadioGroups(".a-radio-fancy");
                n.normalizeFieldsets(l);
                i(document.body).find(l).each(n.normalizeElement);
                i("form").unbind("reset.a-form-controls-reset").bind("reset.a-form-controls-reset", k)
            }))
        });
        p.when("A", "jQuery").register("a-buttons", function(b, n) {
            var n = b.$,
                m = 0;
            b.declarative("a-button-group", ["click"], function(k) {
                var i =
                    k.$target.closest(".a-button:not(.a-button-disabled)");
                if (i.length) {
                    var l = k.$declarativeParent.find(".a-button"),
                        j = k.data && k.data.name ? k.data.name : !1,
                        k = k.$target.attr("name");
                    l.removeClass("a-button-selected").attr("aria-checked", "false");
                    i.addClass("a-button-selected").attr("aria-checked", "true");
                    if (k || j) i = {
                        $button: i,
                        buttonName: k,
                        buttonGroupName: j
                    }, j && (b.trigger("a:button-group:" + j + ":toggle", {
                        selectedButton: i
                    }), k && b.trigger("a:button-group:" + j + ":" + k + ":toggle", {
                        selectedButton: i
                    }))
                }
            });
            b.on("a:pageUpdate beforeReady",
                function() {
                    var b = n(".a-button:not([id])"),
                        i = n(".a-button-group,.a-button-toggle-group");
                    b.each(function() {
                        var b = n(this),
                            i = b.find(".a-button-text"),
                            f = b.find(".a-button-input"),
                            g = "a-autoid-" + m++;
                        b.attr("id", g);
                        i.length && (g = i[0].id ? i[0].id : g + "-announce", b.attr("aria-labelledby", g), f.attr("aria-labelledby", g), i.attr("id", g))
                    });
                    i.each(function() {
                        var b = n(this).find(".a-button[role='radio']"),
                            i = b.length,
                            f = 1;
                        b.each(function() {
                            n(this).attr({
                                "aria-posinset": f++,
                                "aria-setsize": i
                            })
                        })
                    })
                });
            n(document).delegate(".a-button-input, .a-button-text",
                "focusin",
                function() {
                    var b = n(this).closest(".a-button");
                    b.hasClass("a-button-disabled") || b.addClass("a-button-focus")
                }).delegate(".a-button-input, .a-button-text", "focusout", function() {
                n(this).closest(".a-button").removeClass("a-button-focus")
            })
        });
        p.when("a-switch-framework", "jQuery").register("a-switch", function(b, n) {
            var m = b.SWITCH_STATE,
                k = b.SWITCH_CONTAINER_CLASS,
                i = b.SWITCH_CLASS;
            return {
                getSwitch: function(l) {
                    function j(a) {
                        var e = g.data(m);
                        if (a === void 0) return e.isOn;
                        if (!e.isEnabled || f(g)) return !1;
                        b.setOnState(g, a);
                        return !0
                    }

                    function f() {
                        return g.data(m).isDragging
                    }
                    l.jquery || (l = n(l));
                    if (l.length === 0) return null;
                    l = l.eq(0);
                    l = l.closest("." + k);
                    if (l.length === 0) return null;
                    var g = l.children("." + i);
                    b.ensureInitialized(g);
                    return {
                        toggle: function() {
                            return j(!g.data(m).isOn)
                        },
                        isOn: j,
                        enabled: function(a) {
                            var e = g.data(m);
                            if (a === void 0) return e.isEnabled;
                            if (e.isEnabled === a) return !1;
                            b.setEnabled(g, a);
                            return !0
                        },
                        isDragging: f,
                        label: function(a) {
                            var b = g.data(m).label;
                            if (a === void 0) return b.text();
                            b.text(a)
                        }
                    }
                }
            }
        });
        p.when("A", "jQuery").register("a-switch-framework", function(b, n) {
            function m(a) {
                a.preventDefault();
                var d = a.data.$switch.data("a-switch-state"),
                    e = d.control;
                if (!b.isAnimated(e)) {
                    a = y(a) - d.initialX;
                    d.isOn && (a += d.rightBoundary);
                    var f = d.leftBoundary,
                        g = d.rightBoundary;
                    a < f ? a = f : a > g && (a = g);
                    if (a !== d.leftOffset) b.animate(e, {
                        left: a
                    }, 0), d.leftOffset = a, d.isDragging = !0, d.dragCount++
                }
            }

            function k(a) {
                a.preventDefault();
                if (b.capabilities.touch || a.which === 1) {
                    var a = a.data.$switch,
                        d = a.data("a-switch-state");
                    j(a, d.isDragging &&
                        d.dragCount > 1 ? d.leftOffset > d.midPoint : !d.isOn);
                    d.isDragging = !1;
                    u(a)
                }
            }

            function i(a, d, e) {
                e = {
                    switchState: a,
                    previousState: e
                };
                b.trigger("a:switch:" + d, e);
                a.name && b.trigger("a:switch:" + a.name + ":" + d, e)
            }

            function l(a) {
                if (!a.data("a-switch-state")) {
                    var b = a.siblings("input"),
                        d = a.closest(".a-switch-row"),
                        e = a.children("." + f),
                        i = a.siblings("." + g),
                        o = b.attr("name"),
                        j = d.hasClass("a-active"),
                        l = !d.hasClass("a-disabled"),
                        k = a.width() - e.width() - 1;
                    a.data("a-switch-state", {
                        input: b,
                        container: d,
                        control: e,
                        label: i,
                        isDragging: !1,
                        rightBoundary: k,
                        leftBoundary: -1,
                        midPoint: k / 2,
                        initialX: null,
                        leftOffset: j ? k : -1,
                        isOn: j,
                        isEnabled: l,
                        name: o,
                        dragCount: 0
                    })
                }
            }

            function j(a, d) {
                l(a);
                var e = a.data("a-switch-state"),
                    f = e.isOn,
                    g = d !== e.isOn;
                e.isOn = d;
                var o = e.isOn ? e.rightBoundary : e.leftBoundary;
                b.animate(e.control, {
                    left: o
                }, 300, "ease-out");
                e.leftOffset = o;
                o = e.container;
                e.isOn ? o.addClass("a-active") : o.removeClass("a-active");
                o = e.input;
                e.isOn ? o.attr("checked", "checked") : o.removeAttr("checked");
                g && i(e, "flip", f);
                d ? i(e, "on", f) : i(e, "off", f)
            }
            var f = "a-switch-control",
                g = "a-switch-label",
                a = function(a) {
                    a.bind("touchmove.a-switch-component", {
                        $switch: a
                    }, m);
                    a.bind("touchend.a-switch-component", {
                        $switch: a
                    }, k);
                    a.bind("touchcancel.a-switch-component", {
                        $switch: a
                    }, k);
                    a.bind("mouseup.a-switch-component", {
                        $switch: a
                    }, k)
                },
                e = function(a) {
                    a.unbind("touchmove.a-switch-component");
                    a.unbind("touchend.a-switch-component");
                    a.unbind("touchcancel.a-switch-component");
                    a.unbind("mouseup.a-switch-component")
                },
                d = function(a) {
                    return (a.originalEvent.touches[0] || a.originalEvent.changedTouches[0]).pageX
                },
                o = function(a) {
                    n("body").bind("mousemove.a-switch-component", {
                        $switch: a
                    }, m);
                    n("body").bind("mouseup.a-switch-component", {
                        $switch: a
                    }, k)
                },
                r = function() {
                    n("body").unbind("mousemove.a-switch-component", m);
                    n("body").unbind("mouseup.a-switch-component", k)
                },
                s = function(a) {
                    return a.pageX
                },
                p = null,
                u = null,
                y = null;
            b.capabilities.touch ? (p = a, u = e, y = d) : (p = o, u = r, y = s);
            b.declarative("a-switch", b.capabilities.touch ? "touchstart" : "mousedown", function(a) {
                var d = a.$event;
                d.preventDefault();
                if (b.capabilities.touch || d.which ===
                    1) {
                    a = a.$declarativeParent;
                    l(a);
                    var e = a.data("a-switch-state");
                    e.dragCount = 0;
                    e.isDragging = !1;
                    if (e.isEnabled) e.initialX = y(d), p(a)
                }
            });
            b.declarative("a-switch-label", "click", function(a) {
                a.$event.preventDefault();
                a = a.$target.siblings(".a-switch");
                l(a);
                var b = a.data("a-switch-state");
                j(a, !b.isOn)
            });
            return {
                ensureInitialized: l,
                setOnState: j,
                setEnabled: function(a, b) {
                    l(a);
                    var d = a.data("a-switch-state"),
                        e = d.container;
                    b ? e.removeClass("a-disabled") : e.addClass("a-disabled");
                    d.isEnabled = b
                },
                SWITCH_STATE: "a-switch-state",
                SWITCH_CONTAINER_CLASS: "a-switch-row",
                SWITCH_CLASS: "a-switch"
            }
        })
    })
})(function() {
    var p = window.AmazonUIPageJS || P,
        b = p.attributeErrors;
    return b ? b("AmazonUIComponents") : p
}());
(function(p) {
    p.execute(function() {})
})(function() {
    var p = window.AmazonUIPageJS || P,
        b = p.attributeErrors;
    return b ? b("AmazonUICompatJS") : p
}());
(function(p) {
    p.execute(function() {
        p.register("a-carousel-utils", function() {
            function b(b) {
                return typeof b === "string"
            }

            function n(b) {
                return b && b.nodeType !== void 0
            }

            function m(i) {
                return !i ? null : b(i) || n(i) ? i : m(i.content)
            }

            function k(i) {
                if (i) b(i) || n(i) ? i = !0 : i.content = k(i.content);
                return i
            }
            return {
                isString: b,
                isElement: n,
                getElementFromItem: m,
                clearElementFromItem: k,
                addElementToDom: function(i, k) {
                    k && (b(k) ? i.html(k) : n(k) && i.empty().append(k), k !== !0 && i.removeClass("a-carousel-card-empty"))
                }
            }
        });
        p.when("A", "jQuery").register("a-carousel-measure",
            function(b, n) {
                return function(m) {
                    function k(i, j, f) {
                        var g, a, e, d;
                        j.jquery || (j = n(j));
                        for (b.each(f, function(b) {
                                if (b === "top" || b === "left") return a = j.offset(), !1
                            });
                            (g = f.pop()) !== void 0;) e = i[g], i[g] = g === "left" || g === "top" ? a[g] : g.indexOf("outer") > -1 ? j[g](!0) : j["outer" + g.charAt(0).toUpperCase() + g.substr(1)](), i[g] !== e && (d === void 0 && (d = {}), d[g] = e);
                        return d
                    }
                    var i = {
                        carousel: {
                            height: 0,
                            width: 0,
                            outerHeight: 0,
                            outerWidth: 0
                        },
                        viewport: {
                            height: 0,
                            width: 0,
                            outerHeight: 0,
                            outerWidth: 0
                        },
                        items: [],
                        getFirstCardWidth: function() {
                            return this.items[0] ===
                                void 0 || !b.isFiniteNumber(this.items[0].width) ? 160 : this.items[0].width
                        }
                    };
                    m.measure = function(l) {
                        var j = this.dom.$carousel,
                            f = this.dom.$viewport,
                            g = {};
                        l && (l = l.split(" "));
                        if (!l || b.indexOfArray(l, "carousel") > -1) g.carousel = k(i.carousel, j, "top,left,height,width,outerHeight,outerWidth".split(","));
                        if (!l || b.indexOfArray(l, "viewport") > -1) g.viewport = k(i.viewport, f, ["height", "width", "outerHeight", "outerWidth"]);
                        if (!l || b.indexOfArray(l, "items") > -1) i.items = [], g.items = {}, j.children("li").each(function(a, b) {
                            i.items[a] = {};
                            var d = k(i.items[a], b, "top,left,height,width,outerHeight,outerWidth".split(","));
                            d !== void 0 && (g.items[a] = d)
                        });
                        return g
                    };
                    m.getItemOffset = function(b) {
                        var j = i.items;
                        b--;
                        if (j && j.length) {
                            if (b < j.length) {
                                for (var f = 0, g = j[0].outerWidth, a = 0; a < b; a++) f += j[a] ? j[a].outerWidth : g;
                                b > 0 && this.getAttr("first_item_flush_left") && (f += m.getAttr("currentGutter"));
                                return f
                            }
                        } else return 0
                    };
                    m.getDimensions = function() {
                        return b.copy(i)
                    };
                    m.updateDimensionsCache = function(k) {
                        b.extend(i, k)
                    };
                    m.getViewportWidth = function() {
                        try {
                            return i.viewport.width
                        } catch (b) {}
                    }
                }
            });
        p.when("A", "jQuery").register("a-carousel-attributes", function(b, n) {
            return function(m, k) {
                var i = {},
                    l = {},
                    j = {};
                b.extend(i, k);
                m.onChange = function(f, g) {
                    for (var a = f.split(" "), e = a.length, d; e--;) d = a[e], l[d] || (l[d] = []), n.isFunction(g) && b.indexOfArray(l[d], g) === -1 && l[d].push(g);
                    return this
                };
                m.unbind = function(f, g) {
                    if (l[f] && g) {
                        var a = b.indexOfArray(l[f], g);
                        a > -1 && l[f].splice(a, 1)
                    }
                    return this
                };
                m.once = function(b, g) {
                    var a = function() {
                        g.apply(null, arguments);
                        m.unbind(b, a)
                    };
                    return m.onChange(b, a)
                };
                m.setAttr = function(f,
                    g, a) {
                    var e = i[f];
                    i[f] = g;
                    if (!a && !j[f] && !b.equals(g, e)) {
                        j[f] = !0;
                        g = b.copy(g);
                        e = b.copy(e);
                        if (l[f])
                            for (var a = b.copy(l[f]), d = 0, o = a.length; d < o; d++) a[d](g, e, m, f);
                        g = {
                            newValue: g,
                            oldValue: e,
                            carousel: m
                        };
                        b.trigger("a:carousel:change:" + f, g);
                        i.name && b.trigger("a:carousel:" + i.name + ":change:" + f, g);
                        j[f] = !1
                    }
                    return this
                };
                m.getAttr = function(f) {
                    return b.copy(i[f])
                }
            }
        });
        p.when("A", "jQuery", "a-carousel-measure", "a-carousel-attributes", "a-carousel-strategies").register("a-carousel-base", function(b, n, m, k, i) {
            function l(b) {
                b.onChange(g,
                    function(e, g) {
                        var i = b.getAttr(a),
                            j = Math.ceil(i / e);
                        j === 1 && i > 1 ? j = 2 : j < 1 && (j = 1);
                        b.setAttr("pageNumber", j);
                        b.setAttr(f, Math.ceil(b.getAttr("set_size") / e));
                        i = b.getAttr("ajax");
                        e > g && (i && i.prefetch_next_page ? b.strategies.ajax.wantNextPage(b) : b.strategies.ajax.wantCurrentPage(b))
                    });
                b.onChange("set_size", function(a, i) {
                    var j = b.getAttr(g),
                        k = b.getAttr(e);
                    b.setAttr(f, Math.ceil(a / j));
                    a < i ? (k.splice(a, Number.MAX_VALUE), b.setAttr(e, k)) : b.strategies.ajax.wantCurrentPage && b.strategies.ajax.wantCurrentPage(b)
                });
                b.onChange(a,
                    function(a) {
                        b.dom.$container.find("input[name='firstVisibleItem']").val(a)
                    });
                b.onChange("pageNumber", function(a) {
                    a > 0 && a <= b.getAttr(f) && b.setAttr("currentlyWrapping", !1)
                })
            }

            function j(a, e, f) {
                if (arguments.length !== 0) {
                    a.jquery || (a = n(a));
                    this.dom = {
                        $container: a,
                        $viewport: a.hasClass("a-carousel-viewport") ? a : a.find(".a-carousel-viewport"),
                        $carousel: a.find(".a-carousel")
                    };
                    var g = {
                        totalPages: 1E3,
                        pageNumber: 1,
                        pageSize: 0,
                        firstVisibleItem: 1,
                        maintain_state: !0,
                        px: 0,
                        auto_adjust_height: !0,
                        ajax: {}
                    };
                    b.extend(g, f);
                    g.maintain_state = !!g.maintain_state;
                    if (g.id_list) {
                        if (!g.set_size) g.set_size = g.id_list.length
                    } else g.id_list = [];
                    if (!g.set_size) {
                        var i = this.dom.$carousel.children("li"),
                            j = parseInt(i.first().attr("aria-setsize"), 10);
                        g.set_size = b.isFiniteNumber(j) && j > 0 ? j : i.length
                    }
                    var l = [];
                    this.dom.$carousel.children("li").each(function(a, b) {
                        n(b).attr({
                            "aria-posinset": a + 1,
                            "aria-setsize": j
                        });
                        l.push(b.innerHTML)
                    });
                    g.fetchedItems = l;
                    m(this);
                    k(this, g);
                    this.strategies = e;
                    return this
                }
            }
            var f = "totalPages",
                g = "pageSize",
                a = "firstVisibleItem",
                e = "fetchedItems";
            b.each(i, function(a, b) {
                j.prototype["set" + b.charAt(0).toUpperCase() + b.slice(1) + "Strategy"] = function(a) {
                    this.strategies[name] = a;
                    typeof a.init === "function" && a.init(this)
                }
            });
            i = j.prototype;
            i.gotoNextPage = function(a) {
                this.getAttr("transitionPaused") || this.strategies.transition.gotoNextPage(this, a)
            };
            i.gotoPrevPage = function(a) {
                this.getAttr("transitionPaused") || this.strategies.transition.gotoPrevPage(this, a)
            };
            i.gotoPage = function(a, b) {
                this.getAttr("transitionPaused") || this.strategies.transition.gotoPage(this,
                    a, b)
            };
            i.gotoIndex = function(a, b) {
                this.getAttr("transitionPaused") || this.strategies.transition.gotoIndex(this, a, b)
            };
            i.gotoPixel = function(a, b) {
                this.getAttr("transitionPaused") || this.strategies.transition.gotoPixel(this, a, b)
            };
            i.resize = function() {
                this.strategies.display.resize(this, this.measure("carousel viewport"))
            };
            i.pause = function() {
                this.setAttr("transitionPaused", !0)
            };
            i.resume = function() {
                this.setAttr("transitionPaused", !1)
            };
            i.triggerEvent = function(a, e) {
                e = e || {};
                e.carousel = this;
                b.trigger("a:carousel:" +
                    a, e);
                var f = this.getAttr("name");
                f && b.trigger("a:carousel:" + f + ":" + a, e)
            };
            i.getStaticLoader = function() {
                return ""
            };
            i.getEmptyCard = function(a, b) {
                return ['<li class="a-carousel-card a-carousel-card-empty" role="listitem" aria-setsize="', b, '" aria-posinset="', a, '">', this.getStaticLoader(), "</li>"].join("")
            };
            i.init = function() {
                var d = this,
                    e = d.strategies,
                    i = d.dom.$viewport[0];
                if (i && !i.id) i.id = "anonCarousel" + d.__id;
                for (var i = d.dom.$carousel[0], j = i.childNodes, k = j.length; k--;) j[k].tagName && j[k].tagName.toLowerCase() ===
                    "li" || i.removeChild(j[k]);
                if (d.getAttr("set_size") < 1) return e.ajax.init(d), !1;
                d.measure();
                b.each(d.strategies, function(a) {
                    a.init(d)
                });
                e = d.getAttr(g);
                i = d.getAttr("set_size");
                e = Math.ceil(i / e);
                d.setAttr(f, e);
                l(d);
                d.triggerEvent("init");
                b.each(d.strategies, function(a) {
                    a.afterInit && a.afterInit(d)
                });
                d.triggerEvent("afterInit");
                e = d.getAttr(a);
                if (e === 1 && d.getAttr("maintain_state") && (e = parseInt(d.dom.$container.find("input[name='firstVisibleItem']").val(), 10), !b.isFiniteNumber(e) || !(e > 0 && e <= i))) e = 1;
                if (e > 1) {
                    i =
                        700;
                    j = Math.ceil(e / d.getAttr(g));
                    for (k = 2; k < j; k++) i += 700 / k;
                    d.gotoIndex(e, {
                        animationDuration: i,
                        easingFunction: "ease"
                    })
                }
                return !0
            };
            return j
        });
        p.when("A", "jQuery", "a-carousel-base").register("a-carousel-mobile", function(b, n, m) {
            function k(b) {
                var f = b.getAttr("loaderHeight");
                f || ((f = b.getAttr("maxHeight")) ? (f *= 0.9, f = Math.min(f, 90), f = Math.max(f, 120)) : f = 90, b.setAttr("loaderHeight", f));
                return f
            }

            function i(i, f, g) {
                m.call(this, i, f, g);
                if (arguments.length !== 0) return this.getAttr("circular") === l && this.setAttr("circular", !1), this.getAttr("show_partial_next") === l && this.setAttr("show_partial_next", !0), this.getAttr("hide_off_screen") === l && this.setAttr("hide_off_screen", !1), this.getAttr("springiness") === l && this.setAttr("springiness", 0.8), this.getAttr("touch_easing") === l && this.setAttr("touch_easing", "cubic-bezier(0.215, 0.610, 0.355, 1.000)"), this.init = function() {
                    var a = this;
                    if (m.prototype.init.call(a)) {
                        a.dom.$carousel.children("li").children(".a-loading-static").css("height", k(a) + "px");
                        var e = a.dom.$viewport;
                        (b.capabilities.touch ||
                            b.capabilities.pointerPrefix) && a.getAttr("transitionStrategy") !== "none" && p.when("a-touch").execute(function() {
                            e.addClass("a-gesture a-gesture-horizontal").bind("pan-horizontal swipe-horizontal", function() {
                                return !1
                            });
                            b.on("a:swipe-horizontal:" + e[0].id, function(b) {
                                if (!a.getAttr("transitionPaused") && a.strategies.transition.onSwipe) a.strategies.transition.onSwipe(a, b)
                            });
                            if (!a.getAttr("disable_panning")) b.on("a:pan-horizontal:" + e[0].id, function(b) {
                                if (!a.getAttr("transitionPaused") && a.strategies.transition.onPan) a.strategies.transition.onPan(a,
                                    b)
                            })
                        });
                        if ((b.capabilities.isIE10 || b.capabilities.isIE11Plus) && a.getAttr("transitionStrategy") !== "none") {
                            var d = function(a) {
                                a.stopPropagation();
                                a.preventDefault();
                                document.body.removeEventListener("click", d, !0)
                            };
                            e.bind(b.action.start, function() {
                                e.bind("swipe-horizontal.a-ssiec pan-horizontal.a-ssiec", function() {
                                    e.unbind(".a-ssiec");
                                    e.bind(b.action.end + ".a-ssiec", function() {
                                        e.unbind(".a-ssiec");
                                        document.body && document.body.addEventListener("click", d, !0)
                                    })
                                })
                            })
                        }
                        return !0
                    } else return !1
                }, this
            }
            var l;
            i.prototype =
                new m;
            i.prototype.constructor = i;
            i.prototype.getStaticLoader = function() {
                return '<div class="a-loading-static" style="height:' + k(this) + 'px"><div class="a-loading-static-inner"></div></div>'
            };
            return i
        });
        p.when("A", "jQuery", "a-carousel-base").register("a-carousel-desktop", function(b, n, m) {
            function k(b) {
                var g = b.getAttr("set_size") <= b.getAttr("pageSize"),
                    a = b.getAttr("transitionStrategy") === "none";
                b.getAttr("totalPages") === 1 && b.getAttr(j) > 1 && b.gotoPage(1, {
                    startover: !0,
                    animationDuration: 0
                });
                b.dom.$container.find(".a-carousel-left, .a-carousel-right, .a-carousel-pagination").css("visibility",
                    g || a ? "hidden" : "visible")
            }

            function i(f, g, a) {
                m.call(this, f, g, a);
                if (arguments.length !== 0) {
                    var e = this;
                    e.getAttr("circular") === l && this.setAttr("circular", !0);
                    e.getAttr("hide_off_screen") === l && this.setAttr("hide_off_screen", !0);
                    e.onChange("totalPages", function(a) {
                        e.dom.$container.find(".a-carousel-page-max").html(a);
                        a < e.getAttr(j) && e.gotoPage(a)
                    });
                    e.onChange(j, function(a) {
                        var b = e.dom.$container,
                            f = b.find(".a-carousel-restart-container");
                        a > 1 ? f.show() : f.hide();
                        b.find(".a-carousel-page-current").html(a)
                    });
                    e.init = function() {
                        var a = this;
                        if (m.prototype.init.call(a)) {
                            k(this);
                            a.onChange("pageSize set_size", function() {
                                k(a)
                            });
                            a.getAttr(j) < 2 && a.dom.$container.find(".a-carousel-restart-container").hide();
                            var e = a.dom.$container.find(".a-carousel-button");
                            if (e.length) {
                                var f = e.eq(0).position().top + "px";
                                e.css("top", f)
                            }
                            var g = !1;
                            a.dom.$container.delegate(".a-carousel-goto-nextpage", "click dblclick", function(e) {
                                g || (g = !0, e.preventDefault(), a.gotoNextPage(), b.delay(function() {
                                    g = !1
                                }, 5))
                            }).delegate(".a-carousel-goto-prevpage",
                                "click dblclick",
                                function(e) {
                                    g || (g = !0, e.preventDefault(), a.gotoPrevPage(), b.delay(function() {
                                        g = !1
                                    }, 5))
                                }).delegate(".a-carousel-goto-nextpage", "keydown", function(e) {
                                if (e.which === b.constants.keycodes.ENTER || e.which === b.constants.keycodes.SPACE) e.preventDefault(), a.gotoNextPage(), a.dom.$viewport.focus()
                            }).delegate(".a-carousel-goto-prevpage", "keydown", function(e) {
                                if (e.which === b.constants.keycodes.ENTER || e.which === b.constants.keycodes.SPACE) e.preventDefault(), a.gotoPrevPage(), a.dom.$viewport.focus()
                            }).delegate(".a-carousel-restart",
                                "click",
                                function(b) {
                                    b.preventDefault();
                                    b = {
                                        startover: !0
                                    };
                                    a.getAttr(j) > 5 ? b.animationDuration = 1250 : b.animationSpeed = a.getDimensions().viewport.width * 5;
                                    a.gotoPage(1, b)
                                });
                            a.dom.$container.find(".a-carousel-page-max").html(this.getAttr("totalPages"));
                            var i = a.dom.$viewport;
                            (b.capabilities.touch || b.capabilities.pointerPrefix) && a.getAttr("transitionStrategy") !== "none" && p.when("a-touch").execute(function() {
                                i.addClass("a-gesture a-gesture-horizontal").bind("pan-horizontal swipe-horizontal", function() {
                                    return !1
                                });
                                b.on("a:swipe-horizontal:" + i[0].id, function(b) {
                                    if (!a.getAttr("transitionPaused") && a.strategies.transition.onSwipe) a.strategies.transition.onSwipe(a, b)
                                });
                                if (!a.getAttr("disable_panning")) b.on("a:pan-horizontal:" + i[0].id, function(b) {
                                    if (!a.getAttr("transitionPaused") && a.strategies.transition.onPan) a.strategies.transition.onPan(a, b)
                                })
                            });
                            if ((b.capabilities.isIE10 || b.capabilities.isIE11Plus) && a.getAttr("transitionStrategy") !== "none") {
                                var l = function(a) {
                                    a.stopPropagation();
                                    a.preventDefault();
                                    document.body.removeEventListener("click",
                                        l, !0)
                                };
                                i.bind(b.action.start, function() {
                                    i.bind("swipe-horizontal.a-ssiec pan-horizontal.a-ssiec", function() {
                                        i.unbind(".a-ssiec");
                                        i.bind(b.action.end + ".a-ssiec", function() {
                                            i.unbind(".a-ssiec");
                                            document.body && document.body.addEventListener("click", l, !0)
                                        })
                                    })
                                })
                            }
                            return !0
                        } else return !1
                    };
                    return e
                }
            }
            var l, j = "pageNumber";
            i.prototype = new m;
            return i.prototype.constructor = i
        });
        p.when("A", "a-carousel-desktop", "a-carousel-mobile").register("a-carousel-classes", function(b, n, m) {
            return {
                desktop: n,
                mobile: m,
                "default": b.capabilities.mobile ||
                    b.capabilities.tablet ? "mobile" : "desktop"
            }
        });
        p.when("A", "jQuery", "p-detect").register("a-carousel-stretchygoodness", function(b, n) {
            function m(a, d, e, i) {
                a.getAttr(f) && (d -= e / 10);
                var j = a.getAttr(g);
                a.getAttr("set_size");
                for (var a = 0, o = !0; d > 0;) a++, d -= i && o ? e : e + j, o = !1;
                d < 0 && a--;
                return b.isFiniteNumber(a) && a > 0 ? a : 1
            }

            function k(a, d, e, g, i, j, o) {
                a.getAttr(y) === "stretch" && g > j && (g = j);
                d -= e * g;
                a.getAttr(f) ? (a = d - i * (g + 1), o && (a += i), o = a / e, d -= e * (o > 0.5 ? 0.5 : o)) : o && (d += i);
                e = Math.ceil(d / (g + 1));
                if (!b.isFiniteNumber(e) || e < i) e = i;
                return e
            }

            function i(a) {
                if (a.getAttr("auto_adjust_height"))
                    if (a.getAttr(x)) a.once(x, function() {
                        i(a)
                    });
                    else {
                        var g = a.getAttr(r),
                            j = a.getDimensions();
                        if (!g || !b.isFiniteNumber(g)) g = 1;
                        var k = g,
                            l = a.getAttr(e),
                            m = l * (a.getAttr(d) - 1),
                            l = m + l - 1,
                            j = j.items,
                            n = j.length,
                            p;
                        for (a.getAttr(f) && l++; m <= l && m < n; m++)(p = j[m]) && p.outerHeight > k && (k = j[m].outerHeight || j[m].height);
                        k > g && (a.updateDimensionsCache({
                            viewport: {
                                height: k,
                                outerHeight: k
                            }
                        }), a.setAttr(r, k), g === 1 ? a.dom.$viewport.height(k) : b.animate(a.dom.$viewport, {
                                height: k
                            }, a.getAttr(o),
                            "linear"))
                    } else a.dom.$viewport.css("height", "")
            }

            function l(a) {
                a.onChange(d, function() {
                    a.getAttr(u) && a.dom.$carousel.children("li").css("visibility", "")
                });
                a.onChange(e, function(b, d) {
                    b > d && i(a)
                });
                a.onChange("loading", function(b) {
                    b || i(a)
                });
                a.onChange(p, function() {
                    i(a)
                });
                a.onChange(x, function(b) {
                    if (!b && a.getAttr(u)) {
                        var d = a.getAttr(p) - 1,
                            g = d + a.getAttr(e) - 1;
                        a.getAttr(f) && g++;
                        a.dom.$carousel.children("li").each(function(a, b) {
                            var e = a >= d && a <= g;
                            n(b).css("visibility", e ? "" : "hidden").attr("aria-hidden", e ? "false" :
                                "true")
                        })
                    }
                });
                a.onChange(y + " " + g, function() {
                    j(a)
                });
                a.onChange(g, function() {
                    j(a)
                })
            }

            function j(b) {
                var d = b.getDimensions(),
                    f = d.viewport.width,
                    d = d.getFirstCardWidth(),
                    i = b.getAttr(g),
                    j = b.getAttr("set_size"),
                    o = b.getAttr(t),
                    l = m(b, f, d, o),
                    n = k(b, f, d, l, i, j, o);
                b.setAttr(a, n);
                b.setAttr(e, l);
                var r = b.dom.$carousel,
                    x = r.children("li"),
                    i = x.length,
                    h = b.getAttr(p) - 1,
                    J = h + l - 1;
                b.getAttr(u) && J++;
                var G = b.getAttr(u),
                    M = n + "px",
                    R = d + "px",
                    L;
                x.each(function(a, b) {
                    L = !G || a >= h && a < J;
                    b.style.marginLeft = o && a === 0 ? 0 : M;
                    b.style.visibility = L ?
                        "" : "hidden";
                    b.style.width = R;
                    b.setAttribute("aria-hidden", L ? "false" : "true")
                });
                var K, Q;
                b.getAttr(t) ? (n = x.first().outerWidth(!0), x.length > 1 && (K = x.eq(1).outerWidth(!0)), Q = (i - 1) * K + n) : (n = K = x.first().outerWidth(!0), Q = i * K);
                if (l >= j) {
                    Q = f;
                    var Z = b.getAttr(y);
                    r.toggleClass("a-text-right", Z === "right");
                    r.toggleClass("a-text-center", Z === "center");
                    Z === "center" && x.first().css("margin-left", 0)
                } else r.removeClass("a-text-right a-text-center");
                Q = l >= j ? f : Q;
                r.css("width", Q + "px");
                f = {
                    carousel: {
                        width: Q,
                        outerWidth: r.outerWidth()
                    },
                    items: []
                };
                for (j = 0; j < i; j++) f.items.push({
                    width: d,
                    outerWidth: j === 0 ? n : K
                });
                b.updateDimensionsCache(f);
                b.gotoIndex(b.getAttr(p), {
                    animationDuration: 0
                });
                b.triggerEvent("repaint")
            }
            var f = "show_partial_next",
                g = "minimum_gutter_width",
                a = "currentGutter",
                e = "pageSize",
                d = "pageNumber",
                o = "height_animation_speed",
                r = "maxHeight",
                p = "firstVisibleItem",
                x = "animating",
                u = "hide_off_screen",
                y = "single_page_align",
                t = "first_item_flush_left";
            return {
                repaint: j,
                init: function(d) {
                    var k = d.getAttr(g);
                    b.isFiniteNumber(k) || (k = 15, d.setAttr(g,
                        k));
                    d.setAttr(a, k);
                    k = d.getAttr(o);
                    b.isFiniteNumber(k) || d.setAttr(o, 200);
                    d.setAttr(t, !!d.getAttr(t));
                    d.setAttr(f, !!d.getAttr(f));
                    j(d);
                    d.getAttr("transitionStrategy") !== "none" && i(d);
                    k = d.getDimensions();
                    d.dom.$container.find(".a-carousel-left, .a-carousel-right, .a-carousel-viewport").css("height", Math.max(k.viewport.height, k.items[0] ? k.items[0].height : 0) + "px");
                    k = d.getAttr(p);
                    k > 1 && (d.setAttr(p, k), k = Math.ceil(k / d.getAttr(e)), d.gotoPage(k));
                    l(d)
                },
                resize: function(a, b) {
                    b.viewport && b.viewport.width !== void 0 &&
                        j(a)
                }
            }
        });
        p.when("A", "jQuery", "p-detect", "a-carousel-utils").register("a-carousel-display-swap", function(b, n, m, k) {
            function i(a) {
                if (a.getAttr("auto_adjust_height")) {
                    var d = a.getAttr(r);
                    if (!d || !b.isFiniteNumber(d)) d = 1;
                    var e = d;
                    a.dom.$carousel.children("li").not(".a-carousel-card-empty").each(function(a, b) {
                        var d = n(b).outerHeight();
                        e = Math.max(d, e)
                    });
                    e > d && (a.setAttr(r, e), m.capabilities.transition ? d === 1 ? a.dom.$viewport.height(e) : b.animate(a.dom.$viewport, {
                            height: e
                        }, a.getAttr(o), "linear") : a.dom.$viewport.height(e),
                        a.updateDimensionsCache({
                            viewport: {
                                height: e,
                                outerHeight: e
                            }
                        }))
                } else a.dom.$viewport.css("height", "")
            }

            function l(a, b) {
                for (var d = a.dom.$carousel[0], e = a.dom.$carousel.children("li").get(), f; e.length > b;) f = e.pop(), d.removeChild(f)
            }

            function j(j) {
                j.onChange(p, function() {
                    i(j)
                });
                j.onChange(y, function(a) {
                    a || i(j)
                });
                j.onChange(e, function(b, d) {
                    if (b > d) {
                        d === 0 && l(j);
                        var e = j.getAttr("set_size"),
                            f = j.getDimensions().getFirstCardWidth(),
                            g = j.getAttr(a),
                            o = j.getAttr(x),
                            m = j.getAttr(p) - 1,
                            r = j.dom.$carousel.children("li"),
                            u =
                            document.createDocumentFragment(),
                            h;
                        if (n.isArray(o)) {
                            for (var t = r.length; t < b; t++) h = t + m, r = n(['<li class="a-carousel-card a-carousel-card-empty" role="listitem" aria-setsize="', e, '" aria-posinset="', h + 1, '" style="width:', f, "px; margin-left:", g, 'px;">', j.getStaticLoader()].join("")), o[h] && k.addElementToDom(r, k.getElementFromItem(o[h])), h >= e && r.removeClass("a-carousel-card-empty"), u.appendChild(r[0]);
                            j.dom.$carousel.append(u)
                        }
                        i(j)
                    } else b < d && l(j)
                });
                j.onChange("set_size", function(a, e) {
                    var g = j.getAttr(d),
                        i = j.getAttr(u),
                        o = j.dom.$carousel.children("li");
                    o.attr("aria-setsize", a);
                    g === i && a > e && (o.length && j.dom.$carousel.children("li").each(function(a, d) {
                        if (!b.trim(d.innerHTML)) d.className += " a-carousel-card-empty", d.innerHTML = j.getStaticLoader()
                    }), e === 0 && f(j))
                });
                j.onChange(t + " " + g, function() {
                    f(j)
                });
                j.onChange(g, function() {
                    f(j)
                })
            }

            function f(d) {
                var f = d.getDimensions(),
                    i = f.viewport.width,
                    j = f.getFirstCardWidth(),
                    o = d.getAttr(g),
                    f = d.getAttr("set_size"),
                    k;
                k = d.getAttr(g);
                d.getAttr("set_size");
                k = Math.max(Math.floor(i /
                    (j + k)), 1);
                k = b.isFiniteNumber(k) ? k : 1;
                var m, n = k;
                d.getAttr(t) === "stretch" && n > f && (n = f);
                n = Math.ceil((i - j * n) / (n + 1));
                b.isFiniteNumber(n) || (n = o);
                m = n;
                d.setAttr(a, m);
                d.setAttr(e, k);
                var n = d.dom.$carousel,
                    r = n.children("li"),
                    o = r.length;
                j += m;
                var p = o * j;
                l(d, Math.min(k, f));
                r.css("margin-left", m + "px");
                k >= f ? (p = i, i = d.getAttr(t), n.toggleClass("a-text-right", i === "right"), n.toggleClass("a-text-center", i === "center"), i === "center" && r.first().css("margin-left", 0)) : n.removeClass("a-text-right a-text-center");
                for (i = {
                        carousel: {
                            width: p,
                            outerWidth: n.outerWidth()
                        },
                        items: []
                    }; o--;) i.items.push({
                    outerWidth: j
                });
                d.updateDimensionsCache(i);
                d.triggerEvent("repaint")
            }
            var g = "minimum_gutter_width",
                a = "currentGutter",
                e = "pageSize",
                d = "pageNumber",
                o = "height_animation_speed",
                r = "maxHeight",
                p = "firstVisibleItem",
                x = "fetchedItems",
                u = "totalPages",
                y = "loading",
                t = "single_page_align";
            return {
                repaint: f,
                init: function(d) {
                    var i = d.getAttr(g);
                    i || (i = 15, d.setAttr(g, i));
                    d.setAttr(a, i);
                    i = d.getAttr(o);
                    b.isFiniteNumber(i) || d.setAttr(o, 200);
                    j(d);
                    f(d);
                    i = d.getDimensions();
                    d.dom.$container.find(".a-carousel-left, .a-carousel-right, .a-carousel-viewport").css("height", Math.max(i.viewport.height, i.items[0] ? i.items[0].height : 0) + "px");
                    i = d.getAttr(p);
                    i > 1 && (d.setAttr(p, i), i = Math.ceil(i / d.getAttr(e)), d.gotoPage(i))
                },
                resize: function(a, b) {
                    b.viewport && b.viewport.width !== void 0 && f(a)
                }
            }
        });
        p.when("A", "jQuery").register("a-carousel-display-single", function(b) {
            function n(a) {
                if (a.getAttr("auto_adjust_height"))
                    if (a.getAttr(f)) a.once(f, function() {
                        n(a)
                    });
                    else a.dom.$viewport.css("height",
                        "auto"), b.delay(function() {
                        a.dom.$viewport.height(a.dom.$viewport.height())
                    }, 0);
                else a.dom.$viewport.css("height", "")
            }

            function m(a) {
                a.getAttr(g) || (a.dom.$viewport.delegate("img", "load", function() {
                    n(a)
                }), a.onChange("loading", function(b) {
                    b || n(a)
                }), a.onChange(l, function() {
                    k(a)
                }))
            }

            function k(a) {
                var b = a.getDimensions(),
                    d = b.viewport.width,
                    f = a.getAttr(i),
                    g = a.getAttr(l),
                    k = a.getAttr("set_size");
                d -= g * 2;
                f && (d -= g + b.viewport.width / 3);
                a.dom.$carousel.children("li").css({
                    width: d + "px",
                    margin: "0 " + g + "px"
                });
                b = d + g *
                    2;
                f = b * k;
                a.dom.$carousel.width(f);
                for (f = {
                        carousel: {
                            width: f
                        },
                        items: []
                    }; k--;) f.items[k] = {
                    width: d,
                    outerWidth: b
                };
                a.updateDimensionsCache(f);
                a.gotoIndex(a.getAttr(j), {
                    animationDuration: 0
                });
                a.triggerEvent("repaint")
            }
            var i = "show_partial_next",
                l = "minimum_gutter_width",
                j = "firstVisibleItem",
                f = "animating",
                g = "fixed_height";
            return {
                repaint: k,
                init: function(a) {
                    var e = a.getAttr(l);
                    a.setAttr(l, b.isFiniteNumber(e) ? e : 14);
                    a.setAttr(i, !!a.getAttr(i));
                    a.setAttr("pageSize", 1);
                    a.dom.$carousel.children(":not(li:first-child)").remove();
                    a.setAttr("pageSize", 1);
                    e = a.getAttr(g);
                    b.isFiniteNumber(e) ? a.dom.$viewport.height(e) : a.setAttr(g, !1);
                    a.dom.$carousel.children("li").css("visibility", "visible");
                    m(a);
                    this.repaint(a);
                    n(a)
                },
                resize: function(a, b) {
                    b.viewport && b.viewport.width !== void 0 && (this.repaint(a), a.getAttr(g) || n(a))
                }
            }
        });
        p.when("a-carousel-stretchygoodness", "a-carousel-display-swap", "a-carousel-display-single").register("a-carousel-strategies-display", function(b, n, m) {
            return {
                swap: n,
                single: m,
                stretchyGoodness: b,
                "default": "stretchyGoodness"
            }
        });
        p.when("A", "jQuery", "a-carousel-utils").register("a-carousel-transition-swap", function(b, n, m) {
            function k(a, d) {
                a.getAttr(l);
                a.getAttr(g);
                var f = a.getAttr(j),
                    i = a.getAttr("delay_time");
                a.setAttr(e, !0);
                var k = a.dom.$carousel.children("li");
                k.each(function(g, j) {
                    var o = n(j),
                        l = d[g + f - 1];
                    o.hasClass(p) && l && b.delay(function() {
                        m.addElementToDom(o, m.getElementFromItem(l));
                        g === k.length - 1 && a.setAttr(e, !1)
                    }, 0 + i)
                })
            }

            function i(e, i, k) {
                var k = k || {},
                    n = e.getAttr(l);
                if (i !== n) {
                    var w = e.getAttr(o),
                        z = e.getAttr(r),
                        A = e.getAttr("circular"),
                        F = e.getAttr(g),
                        B = k.delayTime || e.getAttr("delay_time"),
                        C = (typeof k.direction === "number" ? k.direction ? k.direction < 0 ? -1 : 1 : isNaN(k.direction) ? NaN : 0 : NaN) || NaN;
                    !A && i < 1 ? i = 1 : !A && i > z ? i = z : A && i < 1 ? i = z : A && i > z && (i = 1);
                    C || (C = n < i ? 1 : -1);
                    k.startover && (C = B = 1);
                    e.setAttr(l, i);
                    var E = F * (i - 1),
                        v = C === 1 ? 0 : F - 1;
                    e.setAttr(d, !0);
                    var I = b.interval(function() {
                        var b = E + v;
                        if (I !== e.getAttr(f)) clearInterval(I);
                        else if (C === -1 && v < 0 || C === 1 && v >= F) e.setAttr(f, void 0), e.setAttr(j, E + 1), e.setAttr(d, !1);
                        else {
                            var g = e.dom.$carousel.children("li").eq(v);
                            g.attr("aria-posinset", b + 1);
                            var i = e.getAttr(a)[b];
                            i ? m.addElementToDom(g, m.getElementFromItem(i)) : b < w ? g.html(e.getStaticLoader()).addClass(p) : g.empty().removeClass(p);
                            v += C
                        }
                    }, B);
                    e.setAttr(f, I)
                }
            }
            var l = "pageNumber",
                j = "firstVisibleItem",
                f = "responsiveTimerId",
                g = "pageSize",
                a = "fetchedItems",
                e = "loading",
                d = "animating",
                o = "set_size",
                r = "totalPages",
                p = "a-carousel-card-empty";
            return {
                init: function(d) {
                    var e = d.getAttr("delay_time");
                    b.isFiniteNumber(e) || d.setAttr("delay_time", 50);
                    d.onChange(f, function(a, b) {
                        b !== a && clearInterval(b)
                    });
                    d.onChange(a, function(a) {
                        k(d, a)
                    })
                },
                gotoIndex: function(a, b, d) {
                    var d = d || {},
                        e = a.getAttr(g),
                        b = Math.ceil(b / e);
                    i(a, b, d)
                },
                gotoNextPage: function(a, b) {
                    var b = b || {},
                        d = a.getAttr(l);
                    b.direction = -1;
                    i(a, ++d, b)
                },
                gotoPrevPage: function(a, b) {
                    var b = b || {},
                        d = a.getAttr(l);
                    b.direction = 1;
                    i(a, --d, b)
                },
                gotoPage: i
            }
        });
        p.when("A", "jQuery", "a-carousel-utils").register("a-carousel-transition-slide", function(b, n, m) {
            function k(b) {
                var d = b.dom.$carousel.children("li").length,
                    i = d + 1,
                    j = b.getAttr(a),
                    k = j - d;
                if (k > 0) {
                    for (var k = i + k - 1, l = []; i <=
                        k; i++) l.push(b.getEmptyCard(i, j));
                    b.dom.$carousel.append(l.join(""));
                    b.setAttr(g, !0);
                    for (var k = b.getAttr(f), l = b.dom.$carousel.children("li"), n, i = d; i < j; i++)
                        if (n = k[i]) {
                            var p = m.getElementFromItem(n),
                                d = l.eq(i);
                            m.addElementToDom(d, p);
                            k[i] = m.clearElementFromItem(n)
                        }
                    b.strategies.display.repaint && b.strategies.display.repaint(b);
                    b.setAttr(f, k, !0);
                    b.setAttr(g, !1)
                }
            }

            function i(a, b, k) {
                if (a.getAttr(j)) a.once(j, function() {
                    i(a, b, k)
                });
                else {
                    var l = a.getDimensions().items;
                    if (!k || b.length >= k.length) {
                        a.setAttr(g, !0);
                        for (var n =
                                a.dom.$carousel.children("li"), p = b.length, u, y; p--;)
                            if (y = b[p], y !== k[p] && y) {
                                var t = m.getElementFromItem(y);
                                u = n.eq(p);
                                u.length && (m.addElementToDom(u, t), l[p] = {
                                    width: u.outerWidth(),
                                    outerWidth: u.outerWidth(!0),
                                    height: u.outerHeight(),
                                    outerHeight: u.outerHeight(!0)
                                }, b[p] = m.clearElementFromItem(y))
                            }
                    }
                    a.setAttr(f, b);
                    a.updateDimensionsCache({
                        items: l
                    });
                    a.setAttr(g, !1)
                }
            }
            var l = b.capabilities.touch ? 2E3 : 3E3,
                j = "animating",
                f = "fetchedItems",
                g = "loading",
                a = "set_size";
            return {
                wrapToFirst: function(a) {
                    var b = a.getAttr("pageSize"),
                        f = a.getDimensions().getFirstCardWidth(),
                        g = this;
                    a.gotoPixel(b * f * -1, {
                        animationDuration: 0,
                        callback: function() {
                            a.setAttr("currentlyWrapping", !1);
                            g.gotoPage(a, 1)
                        }
                    })
                },
                wrapToLast: function(a) {
                    a.getAttr("pageSize");
                    var b = a.getAttr("totalPages"),
                        f = this,
                        g = a.getDimensions().carousel.width;
                    a.gotoPixel(g, {
                        animationDuration: 0,
                        callback: function() {
                            a.setAttr("currentlyWrapping", !1);
                            f.gotoPage(a, b)
                        }
                    })
                },
                gotoPage: function(a, b, f) {
                    f = f || {};
                    (f.animationDuration === void 0 || f.animationDuration > 0) && !f.silent && a.setAttr(j, !0);
                    var g = a.getAttr("totalPages");
                    b > 0 && b <= g && a.setAttr("pageNumber", b);
                    var i = a.getAttr("circular");
                    if (!i && b < 1) b = 1, f.animationDuration = Math.pow(a.getAttr("animation_speed") * a.getAttr("springiness"));
                    else if (!i && b > g) b = g, f.animationDuration = Math.pow(a.getAttr("animation_speed"), a.getAttr("springiness"));
                    this.gotoIndex(a, a.getAttr("pageSize") * (b - 1) + 1, f)
                },
                gotoIndex: function(e, d, f) {
                    f = f || {};
                    (f.animationDuration === void 0 || f.animationDuration > 0) && !f.silent && e.setAttr(j, !0);
                    var g = e.getAttr("circular") && !e.getAttr("currentlyWrapping"),
                        i = f.callback,
                        k = this,
                        l = !1,
                        m = e.getViewportWidth(),
                        n = Math.ceil(d / e.getAttr("pageSize")),
                        p;
                    n !== e.getAttr("pageNumber") && n > 0 && n <= e.getAttr("totalPages") && e.setAttr("pageNumber", n);
                    e.setAttr("firstVisibleItem", d);
                    d < 1 ? g && (l = m * -1, p = function() {
                        i && i();
                        k.wrapToLast(e)
                    }) : d > e.getAttr(a) ? g && (l = e.getAttr("px") + m, p = function() {
                        i && i();
                        k.wrapToFirst(e)
                    }) : l = e.getItemOffset(d);
                    p ? (e.setAttr("currentlyWrapping", !0), f.callback = p, f.easingFunction = f.easingFunction || e.getAttr("wrap_easing"), f.animationSpeed = (b.isFiniteNumber(f.animationSpeed) ?
                        f.animationSpeed : e.getAttr("animation_speed")) * 1.3) : f.callback = i;
                    l !== !1 && this.gotoPixel(e, l, f)
                },
                gotoPixel: function(a, d, f) {
                    var g = a.getAttr("px");
                    if (d !== g) {
                        var f = f || {},
                            i = f.easingFunction || "ease-out",
                            k = f.callback;
                        a.getViewportWidth();
                        var l;
                        f.animationDuration !== void 0 ? l = f.animationDuration : (l = b.isFiniteNumber(f.animationSpeed) ? f.animationSpeed : a.getAttr("animation_speed"), g = Math.abs(d - g), l = l === 0 ? 0 : Math.floor(g / l * 1E3));
                        l > 0 && !f.silent && a.setAttr(j, !0);
                        b.isFiniteNumber(d) ? (g = l > 0 ? function() {
                            k && k();
                            a.setAttr(j,
                                b.isAnimated(a.dom.$carousel), f.silent)
                        } : k, a.setAttr("px", d), b.animate(a.dom.$carousel, {
                            left: d * -1
                        }, l, i, g)) : p.error("Target pixel is not a finite number", "a-carousel-transition-slide", "gotoPixel")
                    }
                },
                gotoNextPage: function(a, b) {
                    var f = a.getAttr("pageNumber");
                    this.gotoPage(a, ++f, b)
                },
                gotoPrevPage: function(a, b) {
                    var f = a.getAttr("pageNumber");
                    this.gotoPage(a, --f, b)
                },
                onSwipe: function(a, d) {
                    if (!a.getAttr("currentlyWrapping")) {
                        var f = a.getAttr("firstVisibleItem"),
                            g = a.getAttr("pageSize"),
                            i = a.getAttr("pageNumber"),
                            j = d.velocityX < 0,
                            k = f;
                        j && i < a.getAttr("totalPages") ? k = f + g : !j && i > 1 && (k = f - g);
                        g = a.getAttr("px");
                        i = a.getItemOffset(k);
                        g = Math.abs((j ? g - i : g + i) * 1E3 / d.velocityX);
                        g = Math.max(g, 300);
                        g = Math.min(g, b.viewport().width * 1.2);
                        g = {
                            animationDuration: g,
                            easingFunction: a.getAttr("touch_easing")
                        };
                        k === f && !a.getAttr("circular") ? (g.animationSpeed = b.viewport().width * 0.95, delete g.animationDuration, a.gotoIndex(k, g)) : j ? a.gotoNextPage(g) : a.gotoPrevPage(g)
                    }
                },
                onPan: function(a, d) {
                    if (!a.getAttr("currentlyWrapping")) {
                        a.setAttr(j, !0);
                        var f =
                            a.getItemOffset(a.getAttr("firstVisibleItem")),
                            g = f - d.touchDeltaX,
                            i = a.getAttr("circular"),
                            k = a.getAttr("pageNumber"),
                            l = a.getAttr("totalPages");
                        if (d.ended) {
                            var f = {
                                    easingFunction: a.getAttr("touch_easing"),
                                    animationSpeed: b.viewport().width * 0.95,
                                    silent: !0
                                },
                                g = d.touchDeltaX,
                                m = Math.abs(g) < a.getViewportWidth() * 0.4;
                            !i && (g < 0 && l === k || g > 0 && k === 1) || m ? a.gotoPage(k, f) : g < 0 ? a.gotoNextPage(f) : a.gotoPrevPage(f)
                        } else {
                            if (!i && (i = a.getAttr("springiness"), g < 0 && d.touchDeltaX > 0 || k === l && d.touchDeltaX < 0)) k = Math.pow(Math.abs(d.touchDeltaX),
                                i), g = g <= 0 ? k * -1 : f + k;
                            a.gotoPixel(g, {
                                easingFunction: a.getAttr("touch_easing"),
                                animationDuration: 0,
                                silent: !0
                            })
                        }
                    }
                },
                init: function(e) {
                    var d = e.getAttr("animation_speed");
                    b.isFiniteNumber(d) || e.setAttr("animation_speed", l);
                    e.getAttr("wrap_easing") === void 0 && e.setAttr("wrap_easing", "linear");
                    k(e);
                    e.onChange(f, function(a, b) {
                        i(e, a, b)
                    });
                    e.onChange(a, function(a, b) {
                        a > b && k(e)
                    })
                }
            }
        });
        p.when("A", "jQuery", "a-carousel-transition-slide", "a-carousel-transition-swap").register("a-carousel-strategies-transition", function(b,
            n, m, k) {
            return {
                slideHorizontal: m,
                swap: k,
                none: {
                    gotoIndex: b.constants.NOOP,
                    gotoNextpage: b.constants.NOOP,
                    gotoPrevPage: b.constants.NOOP,
                    gotoPage: b.constants.NOOP,
                    init: function(b) {
                        b.setAttr("hide_off_screen", !1);
                        b.setAttr("auto_adjust_height", !1);
                        b.dom.$carousel.children("li").css("visibility", "").attr("aria-hidden", "false")
                    }
                },
                "default": "slideHorizontal"
            }
        });
        p.when("A").register("a-carousel-ajax-standard", function(b) {
            function n(g, a, e) {
                e._ = b.now();
                g.triggerEvent("beforeAjax", {
                    url: a,
                    params: e
                });
                b.get(a, {
                    success: function(b) {
                        e.needSetSize &&
                            ((!b || !b.length) && p.error("Carousel requires a set_size and none was returned by the fallback AJAX request", "a-carousel-ajax-standard", "sendRequest"), g.setAttr(j, b[0].setSize ? b[0].setSize : b.length));
                        for (var l = g.getAttr("fetchedItems"), m;
                            (m = b.pop()) !== k;) l[e.offset + b.length] = m;
                        e.needSetSize && g.init();
                        g.setAttr("fetchedItems", l);
                        g.setAttr(f, !1);
                        e.needSetSize && g.getAttr(i) >= l.length && g.strategies.ajax.wantCurrentPage(g);
                        g.triggerEvent("ajaxSuccess", {
                            url: a,
                            params: e
                        })
                    },
                    params: e
                })
            }

            function m(b) {
                var a = b.getAttr(l);
                a && (clearTimeout(a), b.setAttr(l, null))
            }
            var k, i = "pageSize",
                l = "requestTimer",
                j = "set_size",
                f = "ajaxLock";
            return {
                getItems: function(f, a, e) {
                    var d = f.getAttr("ajax");
                    f.setAttr(l, b.delay(n, d.fetch_delay, f, a, e))
                },
                wantNextPage: function(b) {
                    m(b);
                    if (b.getAttr("ajax").prefetch_next_page) {
                        var a = b.getAttr(i),
                            e = a * 2;
                        b.getAttr("show_partial_next") && e++;
                        this.want(b, (b.getAttr("pageNumber") - 1) * a, e)
                    } else this.wantCurrentPage(b)
                },
                wantPrevPage: function(b) {
                    m(b);
                    if (b.getAttr("ajax").prefetch_next_page) {
                        var a = b.getAttr(i),
                            e =
                            a * 2;
                        b.getAttr("show_partial_next") && e++;
                        this.want(b, (b.getAttr("pageNumber") - 2) * a, e)
                    } else this.wantCurrentPage(b)
                },
                wantCurrentPage: function(b) {
                    m(b);
                    var a = b.getAttr(i),
                        e = b.getAttr("show_partial_next") ? a + 1 : a;
                    this.want(b, (b.getAttr("pageNumber") - 1) * a, e)
                },
                want: function(b, a, e) {
                    if (!b.getAttr(f)) {
                        m(b);
                        var d = b.getAttr("ajax"),
                            i = b.getAttr(j);
                        if (d.url) {
                            var k = b.getAttr("fetchedItems"),
                                l = d.id_list;
                            l || (l = []);
                            var n = a > -1 ? a : 0,
                                a = a + e - 1,
                                p = d.params || {},
                                y = [],
                                t = [];
                            if (i === 0) l.length && (i = l), p.needSetSize = "true", b.setAttr(f, !0);
                            for (e === -1 && i && (a = i); n <= a && n < i;) k[n] || ((e = l[n]) && y.push(e), t.push(n), k[n] = !1), n++;
                            b.setAttr("fetchedItems", k, {
                                silent: !0
                            });
                            p.count = t.length;
                            p.offset = t[0] || 0;
                            y.length > 0 && (p[d.id_param_name] = y.join(","));
                            (t.length > 0 || p.needSetSize) && this.getItems(b, d.url, p)
                        }
                    }
                },
                init: function(f) {
                    var a = f.getAttr("ajax");
                    if (!b.isFiniteNumber(a.fetch_delay)) a.fetch_delay = 500;
                    a.id_param_name = a.id_param_name || "ids";
                    a.prefetch_next_page = a.prefetch_next_page === k ? !0 : !!a.prefetch_next_page;
                    f.setAttr("ajax", a);
                    f.getAttr(j) ||
                        this.want(f, 0, -1)
                },
                afterInit: function(b) {
                    b.strategies.ajax.wantCurrentPage(b);
                    b.onChange("pageNumber", function(a, e) {
                        a > e ? b.strategies.ajax.wantNextPage(b) : b.strategies.ajax.wantPrevPage(b)
                    })
                }
            }
        });
        p.when("A", "a-carousel-ajax-standard").register("a-carousel-strategies-ajax", function(b, n) {
            return {
                standard: n,
                none: {
                    wantNextPage: b.constants.NOOP,
                    wantPrevPage: b.constants.NOOP,
                    wantCurrentPage: b.constants.NOOP,
                    want: b.constants.NOOP,
                    init: b.constants.NOOP
                },
                "default": "standard"
            }
        });
        p.when("a-carousel-strategies-display",
            "a-carousel-strategies-transition", "a-carousel-strategies-ajax").register("a-carousel-strategies", function(b, n, m) {
            return {
                display: b,
                transition: n,
                ajax: m
            }
        });
        p.when("A", "jQuery", "a-carousel-classes", "a-carousel-strategies").register("a-carousel-framework", function(b, n, m, k) {
            function i(a, b) {
                p.error(b.message, "a-carousel-framework", a)
            }

            function l(a, d, e, f) {
                var g;
                try {
                    g = new d(a, e, f), g.__id = ++z, a.data("a-carousel", g), a.removeClass("a-carousel-static"), b.onScreen(a) ? b.delay(j, 10, g) : x.push(g), f.name && (y[f.name] =
                        g)
                } catch (k) {
                    i("createCarousel", k)
                }
            }

            function j(a) {
                for (var d = x.length; d--;)
                    if (x[d] === a) {
                        x.splice(d, 1);
                        break
                    }
                try {
                    a.init();
                    s.push(a);
                    a.__initialized = !0;
                    a.dom.$container.addClass("a-carousel-initialized");
                    var e = a.getAttr("name");
                    e && w[e] && b.each(w[e], function(b) {
                        b(a)
                    })
                } catch (f) {
                    i("initializeCarousel", f)
                }
            }

            function f(a, b) {
                var d = b[a + "Strategy"];
                d || (d = k[a]["default"]);
                return k[a][d]
            }

            function g(a) {
                for (var b = a.length, d; b--;)
                    if (d = a[b], !d.dom.$container.length || !t.find(d.dom.$container).length)(d = d.getAttr("name")) &&
                        delete y[d], a.splice(b, 1)
            }

            function a() {
                g(x);
                g(s)
            }

            function e(a) {
                var b = a.data("a-carousel-options") || {};
                b.displayStrategy = a.data("a-display-strategy");
                b.transitionStrategy = a.data("a-transition-strategy");
                b.ajaxStrategy = a.data("a-ajax-strategy");
                b.carouselClass = a.data("a-class");
                var a = f("display", b),
                    d = f("transition", b),
                    e = f("ajax", b),
                    g = b.carouselClass;
                g || (g = m["default"]);
                g = m[g];
                if (!(g === r || a === r || d === r || e === r)) return {
                    carouselClass: g,
                    strategies: {
                        display: a,
                        transition: d,
                        ajax: e
                    },
                    opts: b
                }
            }

            function d() {
                n(".a-carousel-static").each(function() {
                    var a =
                        n(this),
                        b = e(a);
                    b && l(a, b.carouselClass, b.strategies, b.opts)
                })
            }

            function o() {
                b.each(x, function(a) {
                    b.onScreen(a.dom.$container) && j(a)
                })
            }
            var r, s = [],
                x = [],
                u = !1,
                y = {},
                t = n(document),
                w = {},
                z = 0;
            b.on("resize orientationchange", function(d, e) {
                a();
                if (e.height || e.width) b.delay(function() {
                    b.each(s, function(a) {
                        try {
                            a.resize()
                        } catch (b) {
                            i("Carousel " + (a.name ? "named " + a.name : "") + " resize handler", b)
                        }
                    })
                }, b.capabilities.mobile || b.capabilities.tablet ? 100 : 0)
            });
            b.on("a:popover:afterSlideOut", function() {
                b.each(s, function(a) {
                    try {
                        a.resize()
                    } catch (b) {
                        i("Carousel " +
                            (a.name ? "named " + a.name : "") + " resize handler triggered from afterSlideOut callback", b)
                    }
                })
            });
            b.on("a:carousel:change:name", function(a) {
                if (a.newValue) y[a.newValue] = a.carousel;
                a.oldValue && delete y[a.oldValue]
            });
            b.on("a:pageUpdate beforeReady", d);
            b.on("a:pageUpdate", a);
            b.on("scroll", function() {
                d();
                o()
            });
            b.declarative("a-tabs", "click", function() {
                b.delay(o, 50)
            });
            b.on("a:popover:afterShow", function() {
                b.delay(o, 50)
            });
            b.on("a:popover:ajaxContentLoaded", function() {
                b.delay(function() {
                    a();
                    d()
                }, 50)
            });
            b.on.ready(function() {
                u = !0
            });
            var A = {
                getCarousel: function(a) {
                    a.jquery || (a = n(a));
                    var b = a.closest(".a-carousel-container").data("a-carousel");
                    if (!b) {
                        var d = e(a);
                        d && (b = l(a, d.carouselClass, d.strategies, d.opts))
                    }
                    return b
                },
                getCarouselByName: function(a) {
                    return y[a]
                },
                createAll: function() {
                    a();
                    d()
                },
                initializeAll: function() {
                    a();
                    o()
                },
                kill: function(a) {
                    a.jquery || (a = n(a));
                    if (a.length && (a = a.closest(".a-carousel-container"), a.length)) {
                        var d = a.data("a-carousel");
                        if (d) {
                            var e = b.indexOfArray(s, d);
                            e > -1 ? (s[e].name && delete y[s[e].name], s.splice(e,
                                1)) : (e = b.indexOfArray(x, d), e > -1 && (x[e].name && delete y[x[e].name], x.splice(e, 1)))
                        }
                        a.remove()
                    }
                },
                registerStrategy: function(a, b, e) {
                    if (!k[a]) k.type = {};
                    k[a][b] && p.error("Attempted to register a " + a + " strategy which already exists: " + b, "a-carousel-framework", "registerStrategy");
                    k[a][b] = e;
                    u && d()
                },
                registerCarouselClass: function(a, b) {
                    m[a] && p.error("Attempted to register a carousel class which already exists: " + a, "a-carousel-framework", "registerCarouselClass");
                    n.isFunction(b) || p.error("Attempted to register carousel class " +
                        a + " without a constructor function.", "a-carousel-framework", "registerCarouselClass");
                    m[a] = b;
                    u && d()
                },
                getAllCarousels: function() {
                    return s.concat(x)
                },
                onInit: function(a, b) {
                    if (a && (w[a] || (w[a] = []), n.isFunction(b))) {
                        w[a].push(b);
                        var d = y[a];
                        d && d.__initialized && b(d)
                    }
                }
            };
            Object.freeze !== r && Object.freeze(A);
            return A
        })
    })
})(function() {
    var p = window.AmazonUIPageJS || P,
        b = p.attributeErrors;
    return b ? b("AmazonUICarousel") : p
}());
(function(p) {
    p.execute(function() {})
})(function() {
    var p = window.AmazonUIPageJS || P,
        b = p.attributeErrors;
    return b ? b("AmazonUI") : p
}());