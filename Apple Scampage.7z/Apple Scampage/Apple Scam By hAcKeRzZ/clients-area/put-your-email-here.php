<?php
	$mailto = "your@email.com"; //put your email here
?>