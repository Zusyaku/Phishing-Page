--2021-04-08 02:26:37--  https://static.chasecdn.com/web/library/blue-core/dist/2.29.0/blue/js/main.js
Resolving static.chasecdn.com (static.chasecdn.com)... 23.41.188.192
Connecting to static.chasecdn.com (static.chasecdn.com)|23.41.188.192|:443... connected.
HTTP request sent, awaiting response... 200 OK
Length: unspecified [application/javascript]
Saving to: ‘main.js.1’

     0K .......... .......... .......... .......... ..........  295K
    50K .......... .......... .......... .......... ..........  479K
   100K .......... .......... .......... ..                     251K=0.4s

2021-04-08 02:26:38 (329 KB/s) - ‘main.js.1’ saved [135867]

