/*!CK:503968592!*//*1443538988,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["M4VbM"]); }

__d('ResetScrollOnUnload',['CSS','Run'],function a(b,c,d,e,f,g,h,i){if(c.__markCompiled)c.__markCompiled();var j={init:function(k){i.onUnload(function(){h.hide(k);window.scrollTo(0,0);});}};f.exports=j;},null);