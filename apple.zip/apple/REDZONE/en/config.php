<?php
$bilsnd = "normanziggy12@gmail.com";
?>