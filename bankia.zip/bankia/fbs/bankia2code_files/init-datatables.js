/*Al crear un DataTable las creamos como variables para poder hacer referencia a ellas como objetos*/

var tablaMovCuentas = $('#movimientos').DataTable({
    "ajax": './data/movimientos.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false,
    "columns": [
    {
        "className":      'details-control',
        "orderable":      false,
        "data":           null,
        "defaultContent": ''
    },
    { "data": "fechaContable" },
    { "data": "fechaValor" },
    { 
        "data": "descripcion",
        "render":function(data,type,full){
            return "<a href='#'>"+data+"</a>";
        } 
    },
    { "data": "importe" },
    { "data": "saldo" }
    ]
} );

var tablaMovDepositos = $('#depositosMovimientos').DataTable({
    "ajax": './data/movimientos.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false,
    "columns": [
    {
        "className":      'details-control',
        "orderable":      false,
        "data":           null,
        "defaultContent": ''
    },
    { "data": "fechaContable" },
    { "data": "fechaValor" },
    { "data": "descripcion",
        "render":function(data,type,full){
            return "<a href='#'>"+data+"</a>";
        } 
    },
    { "data": "importe" },
    { "data": "saldo" }
    ]
} );

var tablaHalCash = $('#halCash').DataTable({
    "ajax": './data/halCash.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false,
    "columns": [
    {
        "className":      'details-control',
        "orderable":      false,
        "data":           null,
        "defaultContent": ''
    },
    { "data": "emision","width":"25%" },
    { "data": "caducidad","width":"25%" },
    { "data": "concepto","width":"50%",
        "render":function(data,type,full){
            return "<a href='transferencias-movil-consulta-detalles.php'>"+data+"</a>";
        } 
    }
    ]
} );

var tablaRemuneracion = $('#renumeracion').DataTable( {
    "ajax": './data/renumeracion.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false
} );

var tablaCorrespondencia = $('#correspondencia').DataTable( {
    "ajax": './data/correspondencia.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false
} );

var tablaAvalDetalles = $('#avalDetalles').DataTable( {
    "ajax": './data/avales-detalles.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false,
    "columns": [
        {
            "className":      'details-control',
            "orderable":      false,
            "data":           null,
            "defaultContent": ''
        },
        { "data": "concepto" },
        { 
            "data": "facturado",
            "render": function(data,type,full){
                    return "<span class='green-number-xs'>"+data+"</span>";
                }
        },
        { "data": "signo" },
        { 
            "data": "pendiente",
            "render": function(data,type,full){
                    if(parseFloat(data) != 0.00){
                       return "<span class='red-number-xs'>"+data+"&nbsp;EUR</span>"; 
                   }else{
                        return "<span class='green-number-xs'>"+data+"&nbsp;EUR</span>";
                   }
                }
        }
    ]
} );

var tablaTransferencias = $('#transferencias').DataTable( {
    "ajax": './data/transferencias.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false,
    "columns": [
    {
        "className":      'details-control',
        "orderable":      false,
        "data":           null,
        "defaultContent": ''
    },
    { "data": "fechaOperacion" },
    { "data" : "beneficiario"  },
    { 
        "data": "importe",
        "render": function(data,type,full){
                return "<span class='green-number-xs'>"+data+"</span>";
            }
    }
    ]
} );

var tablaTransferenciasPeriodicas = $('#transferenciasPeriodicas').DataTable( {
    "ajax": './data/transferenciasPeriodicas.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false,
    "columns": [
    {
        "className":      'details-control',
        "orderable":      false,
        "data":           null,
        "defaultContent": ''
    },
    { "data" : "origen" },
    { "data" : "destino"},
    { 
        "data": "importe",
        "render": function(data,type,full){
                return "<span class='green-number-xs'>"+data+"</span>";
            }
     }
    ]
} );

var tablaGastosSectores = $('#gastosSectores').DataTable( {
    "ajax": './data/gastosSectores.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "bPaginate": false,
    "info": false,
    "columns": [
    { "data": "campo1" },
    { "data": "campo2" },
    { "data": "campo3" },
    { "data": "campo4" },
    { "data": "campo5" },
    { "data": "campo6" },
    { "data": "campo7" }
    ]
} );

var tablaGastosSectoresMedia = $('#gastosSectoresMedia').DataTable( {
    "ajax": './data/gastosSectoresMedia.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "bPaginate": false,
    "info": false,
    "columns": [
    { "data": "campo1" },
    { "data": "campo2" },
    { "data": "campo3" },
    { "data": "campo4" }
    ],
    "fnInitComplete": function() {
      tablaGastosSectoresMedia.columns.adjust().draw();
    }
} );

var tablaOtrasPropiedades = $('#otras-propiedades').DataTable( {
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false
} );

var tablaMovTar = $('#movTarjeta').DataTable({
    "ajax": './data/movTarjetas.txt',
    "searching": false,
    "lengthChange": false,
    "responsive": true,
    "info": false,
    "columns": [
    {
        "className":      'details-control',
        "orderable":      false,
        "data":           null,
        "defaultContent": ''
    },
    { "data": "fechaOperacion" },
    { "data": "concepto" },
    { "data": "importe" }
    ]
} );

var tablaPagos = $('#pagoRecibos').DataTable( {
    "ajax": './data/pagos-pendientes.txt',
    "searching": false,
    "lengthChange": false,
    "info": false,
    "columns": [
        { "data": "fecha" },
        { "data": "emisor" },
        { "data": "fechaLimite" },
        { "data": "importe" }
    ],
    "responsive": true
} );

var liquidacionAvales = $('#liquidacionAvales').DataTable( {
    "ajax": './data/liquidacionAvales.txt',
    "searching": false,
    "lengthChange": false,
    "info": false,
    "columns": [
        {
            "className":      'details-control',
            "orderable":      false,
            "data":           null,
            "defaultContent": ''
        },
        { "data": "fecha" },
        { 
            "data": "importe",
            "render": function(data,type,full){
                var importe = data.toLowerCase().split("e")[0];
                importe = parseFloat(importe);
                if(importe > 0){
                    return "<span class='green-number-xs'>"+data+"</span>";
                }else{
                    return "<span class='red-number-xs'>"+data+"</span>";
                }
            } 
        },
        { 
            "data": "tipo",
            "render": function(data,type,full){
                return "<a href='prestamos-avales-liquidaciones-detalles.php'>"+data+"</a>"; 
            }
        },
        { "data": "situacion" },
        { "data": "periodo" }
    ],
    "responsive": true
} );

var tablaDomiciliaciones = $('#consultaDomiciliacion').DataTable( {
    "ajax": './data/consultaRecibos.txt',
    "searching": false,
    "lengthChange": false,
    "info": false,
    "bPaginate": false,
    "order": [[ 0, "desc" ]],
    "columns": [
        { "data": "fecha" },
        { "data": "operacion" },
        { "data": "importe" },
        {
            "data" : "operacion",
            "render": function(data,type,full){
                var splitFecha = full.fecha.split("/");
                var cad_fecha  = splitFecha[1]+"/"+splitFecha[0]+"/"+splitFecha[2];
                var inicio     = new Date(cad_fecha);
                var hoy        = new Date();
                var diff       = Math.ceil(Math.abs(inicio.getTime() - hoy.getTime()) / (1000 * 3600 * 24));
                if(diff < 56 ){
                    if(data === "Operacion Correcta"){
                    return "<a href='recibos-devolver.php'>Devolver recibo</a>";
                    }else if(data === "Pendiente de adeudo"){
                       return "<a href='recibos-rechazar.php'>Rechazar recibo</a>";
                    }
                }else{
                    return "";
                }
            }
        }
    ],
    "responsive": true,
    "fnInitComplete": function() {
      tablaDomiciliaciones.columns.adjust().draw();
    }
} );

var bancaMovil = $('#bancaMovil').DataTable({
    "ajax": './data/bancaMovil.txt',
    "searching": false,
    "lengthChange": false,
    "info": false,
    "columns": [
        {
            "className":      'details-control',
            "orderable":      false,
            "data":           null,
            "defaultContent": ''
        },
        { "data": "cuenta" },
        { "data": "alias" },
        { "data": "oculto" }
    ],
    "responsive": true
});

var bancaMovilMod = $('#bancaMovilMod').DataTable({
    "ajax": './data/bancaMovil.txt',
    "searching": false,
    "lengthChange": false,
    "info": false,
    "columns": [
        {
            "className":      'details-control',
            "orderable":      false,
            "data":           null,
            "defaultContent": ''
        },
        { "data": "cuenta" },
        { "data": "alias" },
        { 
            "data": "oculto",
            "render": function(data,type,full){

                return "<input type='checkbox' name='ocultar"+full.cuenta+"' value='ocultar'>"; 
            }
         }
    ],
    "responsive": true
});

//Evento para mostrar informacion adicional


/*Nos dice si el navegador en el que se abre es de un dispositivo movil, BLACKBERRY FALLA, sin probar en webOS(Firefox), IEMOBILE(Windows Phone), y Opera Mini*/
if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
    $('.contentInfo tbody').on('click', 'tr', function () {
        //Obtenemos el tr que dispara el evento
        var tr = $(this);

        //Llamamos a esta funcion para averiguar la variable que hace referencia
        var table = conocerTabla(tr.parents("table"));

        //Obtenemos el objeto que contiene informacion de esa fila
        var row = table.row(this);

        if($('.contentInfo').hasClass('collapsed')){
            //Si la tabla se encuentra en responsive buscamos el contendor y le a�adimos la informacion por el final
            //EN LA INFORMACION EXTRAIDA DE LA DB SE TIENE QUE OBTENER UN CAMPO CON INFORMACION ADICIONAL, NOMBRADO COMO: otraInformacion
            if($("tr.child td.child ul").length>0){
                var masInfo='<li><span class="dtr-title">Otra informacion:</span> <span class="dtr-data">'+row.data().otraInformacion+'</span></li>';
                $(this).next("tr.child").find("ul").append(masInfo);
            }
        }else{
            //Si la tabla puede mostrar todo el contenido, comprobamos el estado de la informacion adicional, oculta o mostrandose, si esta oculta llamamos a la funcion para crear el contenido adicional.
            if ( row.child.isShown() ) {
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                row.child( crearChild( row.data() ) ).show();
                tr.addClass('shown');
            }
        }
    } );
}else{
    //EVENTOS MOUSENTER o MOUSELEAVE
    $('#transferenciasPeriodicas tbody').on('click', 'tr', function () {
        window.location="transferencias-periodicas-detalles.php";
    } );

    $('#transferencias tbody').on('click', 'tr', function () {
        window.location="transferencias-detalles.php";
    } );
    
    $('.contentInfo tbody').on('mouseenter', 'tr', function () {
        //Obtenemos el tr que dispara el evento
        var tr = $(this);

        //Llamamos a esta funcion para averiguar la variable que hace referencia
        var table = conocerTabla(tr.parents("table"));

        //Obtenemos el objeto que contiene informacion de esa fila
        var row = table.row(this);

        if($('.contentInfo').hasClass('collapsed')){
            //Si la tabla se encuentra en responsive buscamos el contendor y le a�adimos la informacion por el final
            //EN LA INFORMACION EXTRAIDA DE LA DB SE TIENE QUE OBTENER UN CAMPO CON INFORMACION ADICIONAL, NOMBRADO COMO: otraInformacion
            if($("tr.child td.child ul").length>0){
                var masInfo='<li><span class="dtr-title">Otra informacion:</span> <span class="dtr-data">'+row.data().otraInformacion+'</span></li>';
                $(this).next("tr.child").find("ul").append(masInfo);
            }
        }else{
            //Si la tabla puede mostrar todo el contenido, comprobamos el estado de la informacion adicional, oculta o mostrandose, si esta oculta llamamos a la funcion para crear el contenido adicional.
            if ( row.child.isShown() ) {
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                row.child( crearChild( row.data() ) ).show();
                tr.addClass('shown');
            }
        }
    } );

    $('.contentInfo tbody').on('mouseleave', 'tr', function () {
            //Obtenemos el tr que dispara el evento
            var tr = $(this);

            //Llamamos a esta funcion para averiguar la variable que hace referencia
            var table = conocerTabla(tr.parents("table"));

            //Obtenemos el objeto que contiene informacion de esa fila
            var row = table.row(this);
    //Si la tabla puede mostrar todo el contenido, comprobamos el estado de la informacion adicional, oculta o mostrandose, si esta oculta llamamos a la funcion para crear el contenido adicional.
                if ( row.child.isShown() ) {
                    row.child.hide();
                    tr.removeClass('shown');
                }
        } );
}
function conocerTabla (tabla){
    //Retornamos la variable que hace referencia a la tabla que ha lanzado la funcion.
    var id = $(tabla).attr('id');
    switch(id){
        case "pagoRecibos":
            return tablaPagos;
            break;
        case "movTarjeta":
            return tablaMovTar;
            break;
        case "movimientos":
            return tablaMovCuentas;
            break;
        case "depositosMovimientos":
            return tablaMovDepositos;
            break;
        case "consultaDomiciliacion":
            return tablaDomiciliaciones;
            break;
        case "transferencias":
            return tablaTransferencias;
            break;
        case "transferenciasPeriodicas":
            return tablaTransferenciasPeriodicas;
            break;
        case "halCash":
            return tablaHalCash;
            break;
    }
}

function crearChild ( obj ) {
    //Crea contenido adicional a partir de la informacion obtenida desde el objeto JSON
    //EN LA INFORMACION EXTRAIDA DE LA DB SE TIENE QUE OBTENER UN CAMPO CON INFORMACION ADICIONAL, NOMBRADO COMO: otraInformacion
    return '<tr class="child">'+
            '<td>Otra informacion:</td>'+
            '<td>'+obj.otraInformacion+'</td>'+
        '</tr>';
}

