# phishing
This is an phishing tool template made using basic knowledge of web Development.

## About
Instagram Phishing for educational Purposes ONLY.
This Phising will come handy for social-engineering techniques.

## Undetected
The way i coded it with php allows me to use the phishing template and the instagram cannot even detect it so when you access the profile you hooked it will not log you out and ask you to verify your identity because it did not detect that the profile has been phished. 

## TODO
All u need to do is downlaod all the files.<br>
Host it using an local sever such as ngrok or you can host it using an online server.<br>
If you are hosting using local server paste these files in htdocs folder and run ngrok and thus your Phishing website is been hosted.<br>
Enjoy it!!!!


## License

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
