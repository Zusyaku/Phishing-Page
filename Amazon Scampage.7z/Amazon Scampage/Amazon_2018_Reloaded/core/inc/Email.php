<?php

/* Recipients, Supports multi values seperated by comma */
$recipients = array(
	"email1@gmail.com",
	);

?>