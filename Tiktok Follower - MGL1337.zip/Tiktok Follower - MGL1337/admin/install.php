<?php
//-----------Your Email
$admin  = "magelang1337@gmail.com";
$result = "magelang1337@gmail.com";

//-----------Your ADMINname
$name = "Admin";


//-----------Your Password
$pass_word = "admin12345";
?>
