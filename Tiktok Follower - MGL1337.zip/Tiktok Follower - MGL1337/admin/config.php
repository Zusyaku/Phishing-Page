<?php 

  include 'install.php';

//---------------------  Don't touch it !!! --------------------------------
$wrong_password_Error = " Your password is wrong .";
$help = "Check your email <b>( $admin )</b> , to find your password .";
$permession_Error = "You have no permission to access to this file/page .";
$account_is_on = "vic.php?account=on";
$account_is_off = "vic.php?account=off";
//--------------------------------------------------------------------------
?>
