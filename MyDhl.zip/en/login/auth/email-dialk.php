<?php

$to = "farideelghezouani@gmail.com,Lazarus1998@hotmail.com";

?>