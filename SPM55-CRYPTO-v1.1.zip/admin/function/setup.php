<?php
$title = "SPM55";
$site_url = "https://spm55.net/";
$setting = array('auto_refresh' => "on");
?>