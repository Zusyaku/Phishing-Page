<?php
session_start();
require_once('main.php');
require_once('get_setting.php');
if (!isset($_POST['email'])) {
    exit(header("HTTP/1.0 404 Not Found"));
}
require_once('files/done.php');
?>