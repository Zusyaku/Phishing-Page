
var da = (document.all) ? 1 : 0;
var pr = (window.print) ? 1 : 0;
var mac = (navigator.userAgent.indexOf("Mac") != -1);

if (da && !pr && !mac) with (document) {
	writeln('<OBJECT ID="WB" WIDTH="0" HEIGHT="0" CLASSID="clsid:8856F961-340A-11D0-A96B-00C04FD705A2"></OBJECT>');
	writeln('<' + 'SCRIPT LANGUAGE="VBScript">');
	writeln('Sub window_onunload');
	writeln('  On Error Resume Next');
	writeln('  Set WB = nothing'); 
	writeln('End Sub');
	writeln('Sub vbPrintPage');
	writeln('  OLECMDID_PRINT = 6');
	writeln('  OLECMDEXECOPT_DONTPROMPTUSER = 2');
	writeln('  OLECMDEXECOPT_PROMPTUSER = 1');
	writeln('  On Error Resume Next');
	writeln('  WB.ExecWB OLECMDID_PRINT, OLECMDEXECOPT_DONTPROMPTUSER');
	writeln('End Sub');
	writeln('<' + '/SCRIPT>');
}

var clicked = 0;
var objectIDCurr = 'parte1';
var isDHTML = 0;
var isID = 0;
var isAll = 0;
var isLayers = 0;


if (document.getElementById) {
	isID = 1;
	isDHTML = 1;
} else {
	if (document.all) {
		isAll = 1;
		isDHTML = 1;
	} else {
		browserVersion = parseInt(navigator.appVersion);
		if ((navigator.appName.indexOf('Netscape') != -1) && (browserVersion == 4)) {
			isLayers = 1;
			isDHTML = 1;
		}
	}
}

MENSAJE_DIRECION_APERTURA_CLASICA_COSTO_CERO = "Debes completar la direcci�n a la cual enviaremos tus estados de cuenta";
MENSAJE_DIRECION_APERTURA_MOVIL_CORRIENTE_MAESTRA = "Debes indicar la direcci�n a la cual enviaremos tus estados de cuenta";
MENSAJE_DIRECION_APERTURA_CUENTA_PLAZO = "Debes indicar la direcci�n a la cual enviaremos tus estados de cuenta";
String.prototype.superTrim = superTrim;

function llenaSlider(arrayLinks){
	var ret = "";
	for(var i = 0;i<arrayLinks.length-1;i++){
		ret += "<a href='"+arrayLinks[i][0]+"' target='_blank' >";
		ret += "<img src='images/banner/"+arrayLinks[i][1]+"' alt=''  data-transition='fade' />";
		ret += "</a>";
	}
	return ret;
}

function abreventanaMax( aURL, aWinName )
{
   var wOpen;
   var sOptions;

   sOptions = 'directories=no,status=yes,toolbar=no,menubar=no,scrollbars=yes';
   sOptions = sOptions + ',resizable=yes,location=no,maximize=yes';
   sOptions = sOptions + ',width=' + (screen.availWidth - 12).toString();
   sOptions = sOptions + ',height=' + (screen.availHeight - 122).toString();
   sOptions = sOptions + ',screenX=0,screenY=0,left=0,top=0';

   wOpen = window.open( '', aWinName, sOptions );
   wOpen.location = aURL;
   wOpen.focus();
   wOpen.moveTo( 0, 0 );
   wOpen.resizeTo( screen.availWidth, screen.availHeight );
   return wOpen;
}


function closesession() {
	setInterval("window.close()",5000);
	return true;
}

function Cierre(){
	window.open('','_self','');
    window.close();
}
function substituicaracter(pString,pCaracter1,pCaracter2)
{
 tamanho = pString.length
 for (x=1;x<tamanho;x++) 
 {
 
  while (pString.indexOf(pCaracter1) > -1)
  {
   pString = pString.replace(pCaracter1,pCaracter2)
  } 
 
  pString = pString
 }
 return pString
}

function validaDireccion(tipo){

	var MENSAJE = "";
	
	if (tipo == '1')
		MENSAJE = MENSAJE_DIRECION_APERTURA_CLASICA_COSTO_CERO;
	else if (tipo == '2')
		MENSAJE = MENSAJE_DIRECION_APERTURA_MOVIL_CORRIENTE_MAESTRA;
	else
		MENSAJE = MENSAJE_DIRECION_APERTURA_CUENTA_PLAZO;

	var valid = cTrim(document.form1.AV_CALLE.value," ");			
	if (valid == "Ninguno"){
		alert(MENSAJE);
		document.form1.AV_CALLE.focus();
		return false;
	}


	var valid = cTrim(document.form1.NOMBRE_CALLE.value," ");			
	if (valid == ""){
		document.form1.NOMBRE_CALLE.value = valid;
		alert(MENSAJE);
		document.form1.NOMBRE_CALLE.focus();
		return false;
	}
	
	valid = cTrim(document.form1.NUMERO.value," ");
	if (valid == ""){
		document.form1.NUMERO.value = valid;	
		alert(MENSAJE);
		document.form1.NUMERO.focus();
		return false;
	}	
	
	valid = cTrim(document.form1.NUMERO_DEPTO.value," ");
	if (valid == ""){	
		document.form1.NUMERO_DEPTO.value = valid;
		valid = cTrim(document.form1.DEPTO_INTERIOR.value," ");
		if (valid != "Ninguno"){
			alert(MENSAJE);
			document.form1.NUMERO_DEPTO.focus();
			return false;
		}	
	}
	
	valid = cTrim(document.form1.DEPTO_INTERIOR.value," ");
	if (valid == "Ninguno"){
		valid = cTrim(document.form1.NUMERO_DEPTO.value," ");
		if (valid != ""){
			alert(MENSAJE);
			document.form1.DEPTO_INTERIOR.focus();
			return false;
		}	
	}
	
	
	valid = cTrim(document.form1.NOMBRE_RESIDENCIA.value," ");
	if (valid == ""){	
		document.form1.NOMBRE_RESIDENCIA.value = valid;
		valid = cTrim(document.form1.URB_RESIDENCIA.value," ");
		if (valid != "Ninguno"){
			alert(MENSAJE);
			document.form1.NOMBRE_RESIDENCIA.focus();
			return false;
		}	
	}
	
	valid = cTrim(document.form1.URB_RESIDENCIA.value," ");
	if (valid == "Ninguno"){
		valid = cTrim(document.form1.NOMBRE_RESIDENCIA.value," ");
		if (valid != ""){
			alert(MENSAJE);
			document.form1.URB_RESIDENCIA.focus();
			return false;
		}	
	}
	
	
	valid = cTrim(document.form1.NOMBRE_SECTOR_ETAPA.value," ");
	if (valid == ""){	
		document.form1.NOMBRE_SECTOR_ETAPA.value = valid;
		valid = cTrim(document.form1.ETAPA_SECTOR.value," ");
		if (valid != "Ninguno"){
			alert(MENSAJE);
			document.form1.NOMBRE_SECTOR_ETAPA.focus();
			return false;
		}	
	}
	
	valid = cTrim(document.form1.ETAPA_SECTOR.value," ");
	if (valid == "Ninguno"){	
		valid = cTrim(document.form1.NOMBRE_SECTOR_ETAPA.value," ");
		if (valid != ""){
			alert(MENSAJE);
			document.form1.ETAPA_SECTOR.focus();
			return false;
		}	
	}
	
	
	
	
	return true;
}


function changecheckalias_a(){

         if ( document.form1.CHECK_DELETE_ALIAS.checked == true) {
             document.form1.CHECK_ALIAS.checked = false;
             document.form1.CHECK_ALIAS.value = "OFF";
             document.form1.ALIAS.value = document.form1.ALIAS_ATUAL.value;
         }  else{
             document.form1.CHECK_ALIAS.checked = true;
             document.form1.CHECK_DELETE_ALIAS.checked = false;
             document.form1.CHECK_ALIAS.value = "ON";
         }
         document.form1.ALIAS.disabled = true;
}

function changecheckalias_b(){
	document.form1.CHECK_ALIAS.checked = true;
	document.form1.CHECK_ALIAS.blur();
	document.form1.CHECK_DELETE_ALIAS.checked = false;
	document.form1.CHECK_ALIAS.value = "ON";
	document.form1.ALIAS.disabled = false;
}

function changecheckalias_c(){
	document.form1.CHECK_DELETE_ALIAS.checked = true;
	document.form1.CHECK_DELETE_ALIAS.blur();
	document.form1.CHECK_ALIAS.checked = false;
	document.form1.CHECK_ALIAS.value = "OFF";
	document.form1.ALIAS.value = document.form1.ALIASANTIGO.value;
	document.form1.ALIAS.disabled = true;
}

function checkalias() {
	   var var_alias = cTrim(document.form1.ALIAS.value," ");
	   var aliasflag = document.form1.ALIASFLAG.value;        
         if ( ( var_alias != "" ) && (aliasflag == "0"))
         document.form1.CHECK_ALIAS.checked = true;
         if ( document.form1.CHECK_ALIAS.checked == true ) {
            if (var_alias == "") {
                alert("Por favor, ingresa con qu� nombre quieres grabar tu operaci�n frecuente.");
                document.form1.ALIAS.focus();
                return false;
            }
            if (!EsCadAlfaNumericForConstancia(document.form1.ALIAS.value)) {
                alert("El campo nombre contiene valores que no son v�lidos. Por favor corr�gelo.")
                document.form1.ALIAS.focus();
                return false;
            }
        }
               
        if (aliasflag != "0"){
            if ( document.form1.CHECK_DELETE_ALIAS.checked == false) {
                document.form1.CHECK_DELETE_ALIAS.value = "OFF";
                if (document.form1.ALIAS.value=="") {
                   document.form1.CHECK_ALIAS.checked = false;
                } else {
                   document.form1.CHECK_ALIAS.checked = true;
                }
            }
            else{
               document.form1.CHECK_DELETE_ALIAS.value = "ON";
            }
        }
        if (document.form1.CHECK_ALIAS.checked == true) {
            document.form1.CHECK_ALIAS.value = "ON";
        } else {
            document.form1.CHECK_ALIAS.value = "OFF";
        }
        return true;
}

function checkTelefono (telefono) {
	if (!EsNumero (telefono)) {
		alert("El n�mero de tel�fono que has ingresado no es el correcto. Por favor vuelve a intentarlo.");
		return false;
	}
	if (telefono.length < 6) {
		alert("El n�mero de tel�fono debe tener por lo menos 6 caracteres.");
		return false;
	}
	return true;

}

function emailCheck(emailStr) {
emailStr = emailStr.toLowerCase();
var checkTLD=1;
var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum)$/;
var emailPat=/^(.+)@(.+)$/;
var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";
var validChars="\[^\\s" + specialChars + "\]";
var quotedUser="(\"[^\"]*\")";
var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;
var atom=validChars + '+';
var word="(" + atom + "|" + quotedUser + ")";
var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
var matchArray=emailStr.match(emailPat);

if (matchArray==null) {
return false;
}

var user=matchArray[1];
var domain=matchArray[2];

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {
return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {
return false;
   }
}

if (user.match(userPat)==null) {
return false;
}

var IPArray=domain.match(ipDomainPat);
if (IPArray!=null) {
for (var i=1;i<=4;i++) {
if (IPArray[i]>255) {
return false;
   }
}
return true;
}

var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {
return false;
   }
}

if (checkTLD && domArr[domArr.length-1].length!=2 && 
domArr[domArr.length-1].search(knownDomsPat)==-1) {
return false;
}

if (len<2) {
return false;
}
return true;
}

function emailCheck2(emailStr) {
emailStr = emailStr.toLowerCase();
var checkTLD=1;
var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum)$/;
var emailPat=/^(.+)@(.+)$/;
var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";
var validChars="\[^\\s" + specialChars + "\]";
var quotedUser="(\"[^\"]*\")";
var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;
var atom=validChars + '+';
var word="(" + atom + "|" + quotedUser + ")";
var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
var matchArray=emailStr.match(emailPat);
var er = new RegExp(/^((?:\w+[^\w\s@]?)+)@((?:[^\.@\s]+\.)+[a-z]{2,6}|(?:\d{1,3}\.){3}\d{1,3})$/);

if(!er.test(emailStr)) {
	return false;
}

if (matchArray==null) {
return false;
}

var user=matchArray[1];
var domain=matchArray[2];

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {
return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {
return false;
   }
}

if (user.match(userPat)==null) {
return false;
}

var IPArray=domain.match(ipDomainPat);
if (IPArray!=null) {
for (var i=1;i<=4;i++) {
if (IPArray[i]>255) {
return false;
   }
}
return true;
}

var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {
return false;
   }
}

if (checkTLD && domArr[domArr.length-1].length!=2 && 
domArr[domArr.length-1].search(knownDomsPat)==-1) {
return false;
}

if (len<2) {
return false;
}
return true;
}


function validAddress(field) {
  var str = field.value; // email string
  if (emailCheck(str) == true){
	return true;
  }
  alert("El correo " + "\"" + str + "\" que has ingresado tiene un formato no v�lido. Int�ntalo nuevamente.");
  return false;
}

function validAddressWithMessage(field, message) {
  if (message == '') {
	return validAddress2(field);
  }

  var str = field; // email string
  if (emailCheck(str) == true){
	return true;
  }
  alert(message);
  return false;
}

function validAddress2(field) {
  var str = field; // email string
  if (emailCheck(str) == true){
	return true;
  }
  alert("El correo " + "\"" + str + "\" que has ingresado tiene un formato no v�lido. Int�ntalo nuevamente.");
  return false;
}


function postConstanciaConsolidada() {
	var param = [];
	param['messageCorreoTO'] = 'El formato del correo en el campo \'Correo a\' no es correcto. Int�ntalo nuevamente.';
	param['messageCorreoCOPY'] = 'El formato del correo en el campo \'Con copia a\' no es correcto. Int�ntalo nuevamente.';
	postConstanciaBase(param);
}

function postConstancia() {
	var param = [];
	param['messageCorreoTO'] = '';
	param['messageCorreoCOPY'] = '';
	postConstanciaBase(param);
}

function postConstanciaTTIB() {
	var param = [];
	param['messageCorreoTO'] = '';
	param['messageCorreoCOPY'] = '';
	param['messageTTIB'] = 'El destinatario no ha sido ingresado.';
	postConstanciaBase(param);
}

function postConstanciaBase(parametros) {
    if (constanciaMessageOk(document.form1.writeMessage.value) == false) {
		return;
    }
 	var re = /\n/g;
 	var re2 = substituicaracter(document.form1.writeMessageVisible.value, "\r", "");
	var stringArray = re2.split(re);
	
	var result = "";
	result = stringArray[0];
	for (var i=1; i < stringArray.length; i++) {
		result = result +  "#" + stringArray[i];
    }
    
   	document.form1.writeMessage.value = result;

	// VALIDA��O DE CORREIOS DO TO
	correos = new Array();
	tmpCorreos = "";
    if (document.form1.toAddress.value != ""){
		//Formata Separa��es
		tmpCorreos = substituicaracter(document.form1.toAddress.value," ",";");
		tmpCorreos = substituicaracter(tmpCorreos,",",";");
		while(tmpCorreos.indexOf(";;") != -1){
			tmpCorreos =  tmpCorreos.replace(";;",";");
		}
		if (tmpCorreos.charAt(0) == ";"){
			tmpCorreos = tmpCorreos.substr(1);
		}
		if (tmpCorreos.charAt(tmpCorreos.length-1) == ";"){
			tmpCorreos = tmpCorreos.substr(0,tmpCorreos.length-1);
		}
		document.form1.toAddress.value = tmpCorreos;
		//Formata Separa��es

		correos = tmpCorreos.split(";");
		//Correio Dummy para n�o dar erro de propriedade de Array no caso de s� haver 1 E-Mail
		correos[correos.length] = "dummy@email.com";

		//Contagemn e valida��o de @s
		countarrobas = 0;
		for (i=0; i<tmpCorreos.length; i++){
			if (tmpCorreos.charAt(i) == "@"){
				countarrobas++;
			}
		}
		if ((tmpCorreos.indexOf(";") == -1) && (countarrobas > 1)){
			alert("Entre con un espacio (\" \"), comma (\",\") o punto y comma (\";\") entre los correos electr�nicos.");
			return;
		}
		//Contagemn e valida��o de @s

		if (correos.length > 2){
			for (i=0;i<correos.length-1;i++){
			    if (!validAddressWithMessage(correos[i], parametros['messageCorreoTO'])){
		    		return;
			    }
			}
		} else {
		    if (!validAddressWithMessage(correos[0], parametros['messageCorreoTO'])){
	    		return;
		    }
		}
    }
    else{ // VALIDA��O DE CORREIOS DO TO
    	alert("El destinatario no ha sido ingresado.");
    	return;
    }    
	
	
	// VALIDA��O DE CORREIOS DO CARBON COPY
	correos = new Array();
	tmpCorreos = "";
    if (document.form1.toAddressCpy.value != ""){
		//Formata Separa��es
		tmpCorreos = substituicaracter(document.form1.toAddressCpy.value," ",";");
		tmpCorreos = substituicaracter(tmpCorreos,",",";");
		while(tmpCorreos.indexOf(";;") != -1){
			tmpCorreos =  tmpCorreos.replace(";;",";");
		}
		if (tmpCorreos.charAt(0) == ";"){
			tmpCorreos = tmpCorreos.substr(1);
		}
		if (tmpCorreos.charAt(tmpCorreos.length-1) == ";"){
			tmpCorreos = tmpCorreos.substr(0,tmpCorreos.length-1);
		}
		document.form1.toAddressCpy.value = tmpCorreos;
		//Formata Separa��es

		correos = tmpCorreos.split(";");
		//Correio Dummy para n�o dar erro de propriedade de Array no caso de s� haver 1 E-Mail
		correos[correos.length] = "dummy@email.com";

		//Contagemn e valida��o de @s
		countarrobas = 0;
		for (i=0; i<tmpCorreos.length; i++){
			if (tmpCorreos.charAt(i) == "@"){
				countarrobas++;
			}
		}
		if ((tmpCorreos.indexOf(";") == -1) && (countarrobas > 1)){
			alert("Entre con un espacio (\" \"), comma (\",\") o punto y comma (\";\") entre los correos electr�nicos.");
			return;
		}
		//Contagemn e valida��o de @s

		if (correos.length > 2){
			for (i=0;i<correos.length-1;i++){
			    if (!validAddressWithMessage(correos[i], parametros['messageCorreoCOPY'])){
		    		return;
			    }
			}
		} else {
		    if (!validAddressWithMessage(correos[0], parametros['messageCorreoCOPY'])){
	    		return;
		    }
		}
		

    }
	// VALIDA��O DE CORREIOS DO CARBON COPY
	
    var tel   = cTrim(document.form1.PHONEFAX.value," ");
    document.form1.PHONEFAX.value = tel;
    if (document.form1.PHONEFAX.value != ''){
        document.form1.fax.checked = true;
    }
    var check = document.form1.fax.checked;
    if (check == true){
        if (document.form1.PHONEFAX.value == ''){
            alert("El tel�fono que has ingresado no es correcto. Int�ntalo nuevamente.");
            document.form1.PHONEFAX.focus();
            return;
        }
        if (!EsNumero(document.form1.PHONEFAX.value)){
            alert("El tel�fono que has ingresado contiene valores que no son v�lidos. Por favor, int�ntalo nuevamente.");
            document.form1.PHONEFAX.focus();
            return;
        }
    }
    document.form1.TRANSACTION.value = document.form1.transactionForPost.value;
    document.form1.enviar.disabled = true;
    document.form1.submit();
}

function validacontrato() {
	return document.form1.rbAceptaContrato[0].checked;
}

function limparContrato() {
	document.form1.contrato.disabled = true;
	document.form1.contrato.value = "";
}



function rightLeftTrim(inputString) {
    if (typeof inputString != "string") {
        return inputString;
    }
    var retValue = inputString;
    var ch = retValue.substring(0, 1);
    while (ch == " ") { // Check for spaces at the beginning of the string
        retValue = retValue.substring(1, retValue.length);
        ch = retValue.substring(0, 1);
    }
    ch = retValue.substring(retValue.length-1, retValue.length);
    while (ch == " ") { // Check for spaces at the end of the string
        retValue = retValue.substring(0, retValue.length-1);
        ch = retValue.substring(retValue.length-1, retValue.length);
    }
    return retValue; // Return the trimmed string back to the user
}

function cTrim(cad, car){
	//Descripcion:	Elimina los caracteres 'car' que encuentre en la cadena 'cad'
	var i;
	var cad2="";
	for(i=0;i<cad.length;i++)
		if(cad.charAt(i)!=car)
			cad2 += cad.charAt(i);
	return cad2;
}

function esNumeroSinEspaciosEnBlanco(cad) {
	cad= rightLeftTrim(cad);
	var bIsNum= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsNum; i++)
		bIsNum= bIsNum && IsNumeric(cad.charAt(i));
	return bIsNum;
}
/*Codigo para Validaciones en lado cliente.
Autor :	Dixan Martinez*/
function EsSoloNumero (cad) {
	for (i=0; i< cad.length; i++) {
		if (!IsNumeric (cad.charAt(i)))  {
			return false;
		}
	}
	return true ;
}

function EsNumero(cad)
{
	cad= cTrim(cad," ");
	var bIsNum= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsNum; i++)
		bIsNum= bIsNum && IsNumeric(cad.charAt(i));
	return bIsNum;
}

function EsTelefono(cad)
{
	cad= cTrim(cad," ");
	var bIsNum= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsNum; i++)
		bIsNum= (bIsNum && IsNumeric(cad.charAt(i))) || (bIsNum && cad.charAt(i) == '-') || (bIsNum && cad.charAt(i) == '(') || (bIsNum && cad.charAt(i) == ')');
	return bIsNum;
}

function EsCuentaNew(cad)
{
	//cad= cTrim(cad," ");
	var bIsNum= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsNum; i++) {
		bIsNum = ((bIsNum && EsCadAlfaNumeric(cad.charAt(i))) && cad.charAt(i) != '-' && cad.charAt(i) != ' ');
	}
	return bIsNum;
}

function EsCadAlfaNoVacia(cad)
{
	cad= cTrim(cad," ");
	var bIsAlf= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsAlf; i++)
		bIsAlf= bIsAlf && IsSpLetter(cad.charAt(i));
	return bIsAlf;
}
function EsCadAlfaNumeric(cad)
{
	cad= rightLeftTrim(cad);
	var bIsAlfNum= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsAlfNum; i++)
		bIsAlfNum= bIsAlfNum && (EsChAlfaNum(cad.charAt(i)) && (cad.charAt(i) != ' '));
	return bIsAlfNum;
}

function EsCadAlfaNumericWithBlank(cad)
{
	cad= rightLeftTrim(cad);
	var bIsAlfNum= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsAlfNum; i++) {
		bIsAlfNum= bIsAlfNum && (EsChAlfaNum(cad.charAt(i)) || (cad.charAt(i) == ' '));
	}
	return bIsAlfNum;
}

function EsCadAlfaNumericConGuion(cad)
{
	cad= cTrim(cad," ");
	var bIsAlfNum= true;
	var i;
	for (i=0; i<cad.length && bIsAlfNum; i++)
		bIsAlfNum= bIsAlfNum && (EsChAlfaNum(cad.charAt(i)) ||
								 cad.charAt(i) == '-');
	return bIsAlfNum;
}
function EsCadAlfaNumericForConstancia(cad)
{
//	cad= cTrim(cad," ");
//	var bIsAlfNum= true;
	var bIsAlfNum= true;
	var ch_Ok = false;
	var ch2_Ok = false;
	var i;
	for (i=0; i<cad.length && bIsAlfNum; i++) {
//		bIsAlfNum= bIsAlfNum && (EsChAlfaNum(cad.charAt(i)) ||
//						     cad.charAt(i) == '-' ||
//						     cad.charAt(i) == ' ' ||
//						     cad.charAt(i) == '.' ||
//						     cad.chatAt(i) == '\n');
		bIsAlfNum = bIsAlfNum && (cad.charAt(i) != '>' &&
					  cad.charAt(i) != '<' &&
					  cad.charAt(i) != "'" &&
					  cad.charAt(i) != '&');
		
			if  (EsChAlfaNum( cad.charAt(i) ) )  {
			   ch_Ok = true;
			}
			
			if (IsSpLetter(cad.charAt(i) ) )  {
			   ch2_Ok = true;
			}
			
	}
	if ( (!ch_Ok) || (!ch2_Ok))
		bIsAlfNum = false;
		
	return bIsAlfNum;
}
function constanciaMessageOk(message) {
	var msg = cTrim(message," ");
	
	if (msg != ""){
	    if (EsCadAlfaNumericForConstancia(message) == false) {
	        alert("Caracteres inv�lidos en el mensaje. Las letras, los n�meros, el gui�n y el espacio en blanco son caracteres v�lidos");
	
    	    return false;
        }
    }
    return true;
}

function EsChAlfaNumConChEspecialyDiagonal(event){
	 //Caracteres considerados especiales para este metodo: /(diagonal)
	var tecla;
	
	// Obt�m o evento. No caso do Firefox, este
	// evento � passado como argumento, e no caso do IE,
	// deve ser obtido atrav�s do objeto window.
	if (!event) {
		var event = window.event; 
	}
	
	if(event.which) {
		tecla=event.which;
	} else {
		tecla=event.keyCode;
	}
	
	var caracter = String.fromCharCode(tecla);
	
	if(EsChAlfaNumConChEspecial(event) || caracter == '/') {
		return true;
	}else {
		return false;
	}
}

function EsChAlfaNumConChEspecial(event){
	 
	//Caracteres considerados especiales para este metodo: �(minuscula), �(maiscula), :(dos puntos), '(apostrofe) y espacio
	
	var tecla;
	
	// Obt�m o evento. No caso do Firefox, este
	// evento � passado como argumento, e no caso do IE,
	// deve ser obtido atrav�s do objeto window.
	if (!event) {
		var event = window.event; 
	}
	
	if(event.which) {
		tecla=event.which;
	} else {
		tecla=event.keyCode;
	}
	
	var caracter = String.fromCharCode(tecla);
	
	if(EsChAlfaNum(caracter) || caracter == '�' || caracter == '�' || caracter == ':' || caracter == '\'' || caracter == ' ') {
		return true;
	}else {
		// Se forem algumas teclas como:
		// backspaece (tecla = 8)
		// delete (tecla = 46)
		// home (tecla = 36)
		// end (tecla = 35)
		// tab (tecla = 9)
		if(tecla == 8 || tecla == 46 || tecla == 36 || tecla == 35 || tecla == 9){
			return true;
		}else{
			return false;
		}
	}
}

function EsChAlfaNum(ch){
	return IsNumeric(ch) || (('A'<=ch) && (ch<='Z')) || (('a'<=ch) && (ch<='z'));
}

function IsNumeric(ch){
	//Descripcion:	Devuelve true si ch es digito
	return  (ch>="0" && ch<="9");
}

function IsSpLetter(ch){
	/*Descripcion	:	Devuelve true si ch es letra del alfabeto espa�ol*/
//	return ( ( ('A'<=ch) && (ch<='Z') ) || ( ('a'<=ch) && (ch<='z') ) );
	return ( ( ('A'<=ch) && (ch<='Z') ) || ( ('a'<=ch) && (ch<='z') )
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�')
			 || (ch=='�') || (ch=='�'));
}

function EsCadAlfaNumSpec(cad)
{
	cad= rightLeftTrim(cad);
	var bIsAlfNum= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsAlfNum; i++)
		bIsAlfNum= bIsAlfNum && ((IsSpLetter(cad.charAt(i)) ||
											(EsChAlfaNum(cad.charAt(i))) ||
										 	(cad.charAt(i) == '&') || 
								 			(cad.charAt(i) == '-') || 
								 			(cad.charAt(i) == '.') || 
								 			(cad.charAt(i) == '(') || 
								 			(cad.charAt(i) == ')') || 
								 			(cad.charAt(i) == '#'))&& (cad.charAt(i) != ' '));
	return bIsAlfNum;
}

function EsCadAlfaNumSpecExt(cad)
{
	cad= rightLeftTrim(cad);
	var bIsAlfNum= (cad.length > 0);
	var i;
	for (i=0; i<cad.length && bIsAlfNum; i++)
		bIsAlfNum= bIsAlfNum && ((IsSpLetter(cad.charAt(i)) ||
											(EsChAlfaNum(cad.charAt(i))) ||
										 	(cad.charAt(i) == '&') || 
								 			(cad.charAt(i) == '-') || 
								 			(cad.charAt(i) == '.')));
	return bIsAlfNum;
}


function EsFloat(cad) {
	var ExPunto=false;
	var ExComa=false;
	var ContDec=0;	//Contador de digitos Despues del punto
	var ContDigD=0;	//Contador de digitos Despues de la coma
	var ContDigA=0;	//Contador de digitos Antes de la coma o el punto
	var letra="";
	var i=1;
	var pos ; // Posicion Punto
	cad=cTrim(cad," ");		//elimina " "
	pos = cad.indexOf(".");
	if (pos != -1 && pos != 0)
		 cad =  cad.substring(0,pos + 3);
	if (cad.charAt(0)=="+")
		cad=cad.substring(1,cad.length);	//elimina "+"
	for (i=0; i<cad.length; i++) {
		letra=cad.charAt(i);
		if (letra=="."){
			if (!ExPunto && ((ExComa && ContDigD==3)||(!ExComa && ContDigA>0)) )
				ExPunto=true;
			else
				return false;
			}
		else if (letra==","){
			if (!ExPunto && !ExComa && ContDigA>0)
				ExComa=true;
			else
				return false;
			}
		else if (letra >= "0" && letra <= "9"){
			if (ExPunto && (ContDec++>=2))		//S�lo dos decimales
				//continue;
				return false;
			else if (ExComa && !ExPunto && (ContDigD++>=3))	//S�lo tres digitos despues de coma
				return false;
			else if(!ExComa && !ExPunto)
				ContDigA++;
			}
		else
			return false;
	   }
	if (ExComa && ContDigD<3) return false;
	//elimina ceros al inicio
	while((cad.charAt(0)=="0") && (cad.charAt(1)!=".") && (cad.length>1))
		cad=cad.substring(1,cad.length);
	return true;
}

function EsMontoCorrecto (cad) {
	var ExPunto=false;
	var ExComa=false;
	var ContDec=0;	//Contador de digitos Despues del punto
	var ContDigD=0;	//Contador de digitos Despues de la coma
	var ContDigA=0;	//Contador de digitos Antes de la coma o el punto
	var letra="";
	var i=1;
	var pos ; // Posicion Punto
	cad=cTrim(cad," ");		//elimina " "
	pos = cad.indexOf(".");
	if (pos != -1 && pos != 0){
          if (cad.length > (pos+3))
              return false;
        }
	if (cad.charAt(0)=="+")
		cad=cad.substring(1,cad.length);	//elimina "+"
	for (i=0; i<cad.length; i++) {
		letra=cad.charAt(i);
		if (letra=="."){
			if (!ExPunto){// && ((ExComa && ContDigD==3)||(!ExComa && ContDigA>0)) )
				ExPunto=true;
                        }
			else
				return false;
		}
        	else if (letra==","){
			if (!ExPunto && !ExComa && ContDigA>0){
				ExComa=true;
                        }
                        else if (ExComa && ContDigD==3){
                            ContDigD = 0;
                        }
			else
				return false;
		}
		else if (letra >= "0" && letra <= "9"){
			if (ExPunto && (ContDec++>=2))		//S�lo dos decimales
				//continue;
				return false;
			else if (ExComa && !ExPunto && (ContDigD++>=3))	//S�lo tres digitos despues de coma
				return false;
			else if(!ExComa && !ExPunto)
				ContDigA++;
		}
		else
			return false;
	   }
	if (ExComa && ContDigD<3){
           return false;
        }
	//elimina ceros al inicio
	while((cad.charAt(0)=="0") && (cad.charAt(1)!=".") && (cad.length>1))
		cad=cad.substring(1,cad.length);
	return true;
}

function Es (cad) {
	var ExPunto=false;
	var ExComa=false;
	var ContDec=0;	//Contador de digitos Despues del punto
	var ContDigD=0;	//Contador de digitos Despues de la coma
	var ContDigA=0;	//Contador de digitos Antes de la coma o el punto
	var letra="";
	var i=1;
	var pos ; // Posicion Punto
	cad=cTrim(cad," ");		//elimina " "
	pos = cad.indexOf(".");
	if (pos != -1 && pos != 0){
          if (cad.length > (pos+3))
              return false;
        }
	if (cad.charAt(0)=="+")
		cad=cad.substring(1,cad.length);	//elimina "+"
	for (i=0; i<cad.length; i++) {
		letra=cad.charAt(i);
		if (letra=="."){
			if (!ExPunto){// && ((ExComa && ContDigD==3)||(!ExComa && ContDigA>0)) )
				ExPunto=true;
                        }
			else
				return false;
		}
        	else if (letra==","){
			if (!ExPunto && !ExComa && ContDigA>0){
				ExComa=true;
                        }
                        else if (ExComa && ContDigD==3){
                            ContDigD = 0;
                        }
			else
				return false;
		}
		else if (letra >= "0" && letra <= "9"){
			if (ExPunto && (ContDec++>=2))		//S�lo dos decimales
				//continue;
				return false;
			else if (ExComa && !ExPunto && (ContDigD++>=3))	//S�lo tres digitos despues de coma
				return false;
			else if(!ExComa && !ExPunto)
				ContDigA++;
		}
		else
			return false;
	   }
	if (ExComa && ContDigD<3){
           return false;
        }
	//elimina ceros al inicio
	while((cad.charAt(0)=="0") && (cad.charAt(1)!=".") && (cad.length>1))
		cad=cad.substring(1,cad.length);
	return true;
}


function formataMonto(cad){
    var exPunto = false;	
	cad  = cTrim(cad," ");

	while((cad.charAt(0)=="0") && (cad.charAt(1)!=".") && (cad.length>1))
		cad=cad.substring(1,cad.length);	
		
	for(i=0;i<cad.length;i++)
		if(cad.charAt(i)=='.')
			exPunto = true;

	if(exPunto)
	   cad  = cTrim(cad,",");
	else
	  cad  = cad.replace(",",".");
		
	   
	return cad;
}


function montoCorrecto(cad){
    var cad2 = null;
		   
	cad = formataMonto(cad);
	
	if (cad==""){
		alert("El monto debe contener un valor.");
		return null;
	}			
	
	if(!EsMontoCorrecto(cad)) {
      alert("El monto que has ingresado no es correcto. Por favor vuelve a intentarlo.");
      return null;
    }
            	
	if(!EsFloat(cad)) {
		alert("El monto que has ingresado no es correcto. Por favor vuelve a intentarlo.");
		return null;
	}    

	if (parseFloat(cad) > 999999999.99){ 
		alert("Por favor, ingresa un monto menor.");
		return null;
	}
	
	cad  = cTrim(cTrim(cad," "), ",");			
	   
    if (cad==""){
      alert("El monto debe contener un valor.");
    }
       
    else
    {
      cad2=cTrim(cad,",");
      cad2=Poner_Decimales(cad2);
      
      if (cad2 <1.00){
        alert("El monto m�nimo para esta operaci�n es de S/ 1.00 � US$ 1.00.");
        cad2 = null;
      }else if (cad2>9999999999999){
        alert("Por favor, ingresa un monto menor.");
        cad2 = null;
      }
    }
    
    return cad2;
}

function validaMontoTTIB(cad){
    var cad2 = null;
		   
	cad = formataMonto(cad);
	
	if (cad==""){
		alert("El monto debe contener un valor.");
		return null;
	}			
            	
	if(!EsFloat(cad)) {
		alert("El monto ingresado no es v�lido. Por favor, int�ntalo nuevamente.");
		return null;
	}    

	if (parseFloat(cad) > 999999999.99){ 
		alert("Por favor, ingresa un monto menor.");
		return null;
	}
	
	cad  = cTrim(cTrim(cad," "), ",");			
	   
    if (cad==""){
      alert("El monto debe contener un valor.");
    }
       
    else
    {
      cad2=cTrim(cad,",");
      cad2=Poner_Decimales(cad2);
      
      if (cad2 <1.00){
        alert("El monto ingresado no es v�lido. Por favor, int�ntalo nuevamente.");
        cad2 = null;
      }else if (cad2>9999999999999){
        alert("Por favor, ingresa un monto menor.");
        cad2 = null;
      }
    }
    
    return cad2;
}

function EsFecha(miDia,miMes,miAno){
    test = new Date(miAno,miMes-1,miDia);
    if ( (miAno.length != 4) || (!EsNumero(miAno)) ){
      return false;
    }else if (miAno < 1900){
      return false;
    }
    if ( (miMes-1 == test.getMonth()) && (miDia == test.getDate()) ){
      return true;
    }else {
      return false;
    }
}

function Poner_Decimales(MontoEnviar){
/*
	Coloca el punto decimal y los dos ceros en caso que
	el cliente no los haya puesto
					HEGA.
*/
 var pos
 var numdec
 var tamano
 var tamdec
	// Quitamos los espacios en blanco
	MontoEnviar=cTrim(MontoEnviar," ");
 	tamano = MontoEnviar.length;
 	 	
 	
 	if (tamano>0){
   	  pos1 = MontoEnviar.substring(0,1);
   	  if (pos1 == '0'){
	 	 pos = MontoEnviar.indexOf(".");
   	     MontoEnviar = MontoEnviar.substring(pos-1,tamano);
   	  }
   	}
	pos = MontoEnviar.indexOf(".");
	switch (pos){
		case 0  :
			  // No hay parte entera pero si hay
			  // un punto, le coloco "0"
			    MontoEnviar = "0" + MontoEnviar;
			break;
		case -1 :
			   // No hay parte decimal ni punto pero
			   // si entera. Le coloco ".00"
			      MontoEnviar = MontoEnviar + ".00";
			 break;
		default :
             // Solo ha ingresado un d�gito decimal.
			 // Le completo el segundo con "0".
			 if (MontoEnviar.length-pos-2 == 0)
			 	MontoEnviar = MontoEnviar + "0";
			 else
				// No ha ingresado parte decimal pero si el
				// punto. Le agrego "00"
				if (MontoEnviar.length-pos == 1)
				  MontoEnviar = MontoEnviar + "00";
				else
				  MontoEnviar =  MontoEnviar.substring(0,pos + 3);
			break;
	}
	return MontoEnviar;
}



function formatEuropeanChars(europeanString) {
var planeString="";
europeanString = rightLeftTrim(europeanString);
//europeanString = cTrim(europeanString, " ");
var i;
 for (i = 0; i < europeanString.length; i++) {
    ch = europeanString.charAt(i);
    if (ch == '�' || ch=='�') {
        ch2 = 'a';
    } else if (ch == '�' || ch == '�') {
        ch2 = 'A';
    } else if (ch == '�' || ch == '�' || ch=='�') {
        ch2 = 'e';
    } else if (ch == '�' || ch == '�' || ch=='�') {
        ch2 = 'E';
    } else if (ch=='�') {
        ch2 = 'i';
    } else if (ch=='�') {
        ch2  = 'I';
    } else if (ch=='�' || ch=='�' || ch=='�') {
        ch2 = 'o';
    } else if (ch=='�' || ch=='�' || ch=='�') {
        ch2 = 'O';
    } else if (ch=='�' || ch=='�') {
        ch2 = 'u';
    } else if (ch=='�' || ch=='�') {
        ch2 = 'U';
    } else if (ch=='�') {
        ch2 = 'n';
    } else if (ch=='�') {
        ch2 = 'N';
	    } else if (ch=='�') {
		  ch2 = 'c';
	    } else if (ch=='�') {
		  ch2 = 'C';
    } else {
		  ch2 = ch;
	    }
    planeString = planeString + ch2;
 }
 return planeString;
}


function claveFollowRules(clave) {
	return true;
}

function IsEmailChar (ch)  {
	if (IsLetter (ch) || IsNumeric(ch) 
			|| ch == "_" 
			|| ch == "-" 
			|| ch == "@" 
			|| ch == "."
			|| ch == ";" ) {
		return true;
	}
	return false;
}

function IsLetter (ch) {
	return (
				(('A'<=ch) && (ch<='Z') )
			|| 	(('a'<=ch) && (ch<='z'))
			);
}

function checkEmail(email){

    var i;
    var ch;
    var ret  = false;
    var ret2 = false;
    var col  = 0;
    
    for (i = 0; i < email.length; i++) {
        ch = email.charAt(i);
        if (ch == '@') {
            ret = true;
            break;
        }
    }
    
   if (ret == true){
        for (i = col; i < email.length; i++) {
            ch = email.charAt(i);
            if (ch == '.') {
                ret2 = true;
                col = i+1;
                break;
            }
        }
    }
    
    if (ret2 == false)
       return false;
    
    if (col !=  email.length){  
	    for (i = col ; i < email.length; i++) {
			if (!IsEmailChar(email.charAt(i))) {
				return false;
			}
		}
	}else
		return false;
       
    
    
    for (i = 0 ; i < email.length; i++) {
		if (!IsEmailChar(email.charAt(i))) {
			return false;
		}
	}
	
    return ret;
}

function getMonth(month)
{
    if (month == '01'){
	return 'enero';
    }else if (month == '02'){
        return 'febrero';
    }else if (month == '03'){
        return 'marzo';
    }else if (month == '04'){
        return 'abril';
    }else if (month == '05'){
        return 'mayo';
    }else if (month == '06'){
        return 'junio';
    }else if (month == '07'){
        return 'julio';
    }else if (month == '08'){
        return 'agosto';
    }else if (month == '09'){
        return 'septiembre';
    }else if (month == '10'){
        return 'octubre';
    }else if (month == '11'){
        return 'noviembre';
    }else if (month == '12'){
        return 'diciembre';
    }else
        return '';
}

function superTrim() {
	return( this.replace( /^\s+|\s+$/gi, "" ).replace( /\s{2,}/gi, " " ));
}


function validaEspaco(e) {
	var alias = document.form1.ALIAS.value;
	alias = alias.superTrim();
	document.form1.ALIAS.value = alias;
}

function checkEnterKey(e)  {
	var CR= 13;
	var NS = (window.Event) ? 1 : 0;
	var keycode = (NS) ? e.which : e.keyCode;
	return (keycode == CR);
}

function bNavegador() {
  var nav= 'nose'
  if( navigator.appName )
  {
	if( navigator.appName == "Microsoft Internet Explorer")
		nav=	'ie';
	if( navigator.appName == "Netscape")
		nav=	'ns';
  }
  return nav;
}

function calcTopLeftVentana(vw, vh)  {
  var top, left;
  var sw=640, sh=480;
  var nav = bNavegador()
  if( window.screen && window.screen.availHeight )  {
	sh = window.screen.availHeight - 63
	if( nav=='ns' ) sh = sh - 11
		w = window.screen.availWidth - 10
  }
  left= (sw-vw)/2
  top=	(sh-vh)/2
  return ('left=' + left + ',top=' + top)
}

function ventanaVisita() {
	window.open('demo/ventana.html','','scrollbars=no,width=700,height=526,top=0,left=0, toolbar=no, menubar=no');
}

function ventanaPreguntas() {
	window.open('#','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(780,550)+',width=780,height=550');
	//	window.open('preguntas/preguntas.html','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(600,470)+',width=600,height=470');
}

function ventanaPreguntasLegales()	{
	window.open('#','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(780,550)+',width=780,height=550');
	//window.open('legales/8.html','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(600,470)+',width=600,height=470');
}

function ventanaInfos(){
	window.open('#','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(780,550)+',width=780,height=550');
	//window.open('legales/8.html','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(600,470)+',width=600,height=470');
}

function ventanaInfoTelefonica(){
	window.open('#','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(780,550)+',width=780,height=550');
	//window.open('legales/8.html','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(600,470)+',width=600,height=470');
}

function ventanaPreguntasCOnline() {
	window.open('/enlinea/info/preguntas/2.html','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(600,470)+',width=600,height=470');
}

function ventanaPreguntasPagoTelefono() {
	window.open('/enlinea/info/preguntas/41.html','','scrollbars=yes,resizable=yes,'+ calcTopLeftVentana(600,470)+',width=600,height=470');
}

function ventanaProductos() {
	if (screen.width >  800)  {
		window.open( '#','','scrollbars=no,width=980,height=680,top=0,left=0, toolbar=no, menubar=no');
	} else {
		window.open( '#','','scrollbars=no,width=760,height=530,top=0,left=0, toolbar=no, menubar=no');
	}


}

function ventanaCredicargo() {
	if (screen.width >  800)  {
		window.open( '#','','scrollbars=yes,width=980,height=680,top=10,left=10, toolbar=no, menubar=no');
	} else {
		window.open( '#','','scrollbars=yes,width=760,height=530,top=10,left=10, toolbar=no, menubar=no');	
	}
}

function ventanaCelular() {
	if (screen.width >  800)  {
		window.open("#","","status=yes,toolbar=no,scrollbars=yes,resizable=yes,width=980,height=680,top=10,left=10");
	} else {
		window.open("#","","status=yes,toolbar=no,scrollbars=yes,resizable=yes,width=760,height=530,top=10,left=10");
	}
}

function replaceChars(entry, charOut, charIn) {
	temp = "" + entry; // temporary holder
	if (temp.indexOf(charOut) > -1) {
		pos= temp.indexOf(charOut);
		temp = "" + (temp.substring(0, pos) + charIn + 
		temp.substring((pos + charOut.length), temp.length));
	}	
	return temp;
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function CerrarSession(nombform)
{
	with(nombform)
	{
		action="redir.dll";
		opcion.value="99";
		submit();
	}	
}

function findDOM(objectID,withStyle) {
	if (withStyle == 1) {
		if (isID) { return (document.getElementById(objectID).style) ; }
		else { 
			if (isAll) { return (document.all[objectID].style); }
		else {
			if (isLayers) { return (document.layers[objectID]); }
		};}
	}
	else {
		if (isID) { return (document.getElementById(objectID)) ; }
		else { 
			if (isAll) { return (document.all[objectID]); }
		else {
			if (isLayers) { return (document.layers[objectID]); }
		};}
	}
}

function genRandomArray( keyPad ){
	var domNew = findDOM("teclado" + keyPad, 1);
	domNew.visibility = "visible";
}

function disableRightClick() {
	return false;
}
  
function onPadClick( keyPad, padPos, hiddenField1, shownField1, hiddenField2, shownField2, lengthField){
    if (notAllowConsecutiveButtonClicks()) {

    	
        clicked = 0;

		var nome;
	 	if( padPos == -1 ){  	
			hiddenField1.value = "";
	        shownField1.value = "";
	        if( keyPad == 2 ){
				hiddenField2.value = "";
	    		shownField2.value = "";
	    		document.form1.RDPASSWORD1.checked = true;        		
	    		document.form1.RDPASSWORD2.checked = false;  
	        }                
			return;
		}    
	
	  	if (shownField1.value.length >= lengthField){ 		
	    	if( keyPad == 2 ){
		    	field = cTrim(shownField2.value, " ");
	     	    if (field.length >= lengthField) {
					return;	
	     	    }     	 	   
		  	 	shownField1 =  shownField2;
	     		hiddenField1 = hiddenField2;    	     
	  		    document.form1.RDPASSWORD1.checked = false;  
		    	document.form1.RDPASSWORD2.checked = true;     
		  	} else {	  	
					return;	
		    }
	    }
	  	
		hiddenField1.value += padPos;
	
		shownField1.value += "*";
		if (shownField1.value.length >= lengthField) {
			if (keyPad == 2) {
	  		    document.form1.RDPASSWORD1.checked = false;  
		    	document.form1.RDPASSWORD2.checked = true;     
			}
		}
		
	}

}

function onPadClickToken( keyPad, padPos, hiddenField1, shownField1, hiddenField2, shownField2, hiddenField3, shownField3, lengthField){
    if (notAllowConsecutiveButtonClicks()) {
        clicked = 0;

        var nome;
	 	if( padPos == -1 ){  	
			hiddenField1.value = "";
	        shownField1.value = "";
	        if( keyPad == 2 ) {
    			hiddenField2.value = "";
        		shownField2.value = "";
    			hiddenField3.value = "";
        		shownField3.value = "";
        		document.form1.RDPASSWORD1.checked = true;
        		document.form1.RDPASSWORD2.checked = false;
        		document.form1.RDPASSWORD3.checked = false;
        	}

			return;
		}
		
		if ((shownField1.value.length >= lengthField) && (shownField2.value.length >= lengthField)) {
		    if (shownField3.value.length >= lengthField) {
                return;
		    }
        	document.form1.RDPASSWORD1.checked = false;
        	document.form1.RDPASSWORD2.checked = false;
        	document.form1.RDPASSWORD3.checked = true;
        	hiddenField3.value += padPos;
        	shownField3.value += "*";
        	return;
		} else if ((shownField1.value.length >= lengthField) && (shownField2.value.length < lengthField)) {
    		document.form1.RDPASSWORD1.checked = false;
    		document.form1.RDPASSWORD2.checked = true;
    		document.form1.RDPASSWORD3.checked = false;
    		hiddenField2.value += padPos;
    		shownField2.value += "*";
    		return;
		}
		
		hiddenField1.value += padPos;
		shownField1.value += "*";
		
	}
}
function onPadClickBlockClave4(keyPad, padPos, hiddenField1, shownField1, hiddenField2, shownField2, lengthField){
		var perfil = document.form1.CARDTYPE_SHOW.value;
	
		if(padPos != -1) {
			if ((perfil == '04' || perfil == '05' || perfil == '06' || perfil == '09') && (document.form1.clave.value.length >= 4)) {
				return;
			}
		}
		
		onPadClick( keyPad, padPos, hiddenField1, shownField1, hiddenField2, shownField2, lengthField);
}
  
function onRadClick( hidden, shown ){
  	ghiddenField = hidden;
  	gshownField = shown;
}

function campanhaPopUps (urlid,idc,bin,flagclave,camid,chamaCumpleAnos) {
    /* ********* la funcionalidad de Campa�as desde ViaBCP est� deshabilitada (Abril/2014) ********* */
    /*

	if (typeof(campanhaPopUps)=='function') {
		if (flagclave == '6') 
			flagclave = '1';
		else
			flagclave = '0';

		if (bin == '40031001') {
			bin = '400310';
		}
		
		if (bin == '40998001') {
			bin = '409980';
		} 
		
		var servidor = new String('#');
		var laurl = new String();
		var w=1,h=1;
		laurl = servidor+'popups.asp?urlid='+urlid+'&idc='+idc+'&bin='+bin+'&flagclave='+flagclave+'&camid='+camid
		//alert (laurl);
		window.open(laurl,'POPUPCAM','status=no,resizable=yes,toolbar=no,scrollbars=no,top=10000,left=10000,width=' + w + ',height=' + h);
		
		if(chamaCumpleAnos == 'S') {
			camid = 192;
			//laurl = servidor+'popups.asp?urlid='+urlid+'&idc='+idc+'&bin='+bin+'&flagclave=1&camid='+camid;
			laurl = servidor+'popups.asp?urlid=1&id='+idc+'&bin='+bin+'&flagclave=1&camid=ADEE5064ADB70D6';
			//alert (laurl);
			window.open(laurl,'POPUPCAM','status=no,resizable=yes,toolbar=no,scrollbars=no,top=10000,left=10000,width=' + w + ',height=' + h);
		}
	}
	                */ 
                return; 

}


function notAllowConsecutiveButtonClicks() {
	document.form1.EVENTO.value = '1';
	if (clicked == 0) {
			clicked = 1;
		 return true;
	} else {
		 alert("Se est� procesando tu operaci�n. Por favor, haz click en OK para continuar.");
		 return false;
	}
}

function tryCallNovaPagina(pagina) {
	if (notAllowConsecutiveButtonClicks()) {
		NovaPagina(pagina);
	}
}

function enviaConstanciaPeq (tam) {
	var var_height = tam;
	features = 'scrollbars=yes,resizable=no,width=690,height='+var_height;
	dlg = window.open ("","constancia",features);
	document.constancia.submit();
}

function constancia(transacao) {
	document.form1.TRANSACTION.value = transacao;
	window.open('servlet/EvMobileServerWEB?TRANSACTION='+document.form1.TRANSACTION.value + '&#38;_session_=' + document.form1._session_.value, 'constancia','scrollbars=yes,width=780,height=550,top=0,left=0, toolbar=no, menubar=no');
}

function enviaConstancia () {
	features = 'toolbar=no,location=no,directories=no,status=no,menubar=no,' +'scrollbars=yes,resizable=no,width=700,height=550';
	dlg = window.open ("","constancia",features);
	document.constancia.submit();
}

function enviaConstancia (widthParam,heightParam) {
	features = 'toolbar=no,location=no,directories=no,status=no,menubar=no,' +'scrollbars=yes,resizable=no,width='+widthParam+',height='+heightParam;
	dlg = window.open ("","constancia",features);
	document.constancia.submit();
}

function unicode( str ) {
	var uniChars = '';
	var uniCodes = "";
	uniChars+= '�' ; uniCodes+= 'B0';
	uniChars+= '�' ; uniCodes+= 'B2';
	uniChars+= '�' ; uniCodes+= 'E0';
	uniChars+= '�' ; uniCodes+= 'E2';
	uniChars+= '�' ; uniCodes+= 'E7';
	uniChars+= '�' ; uniCodes+= 'E8';
	uniChars+= '�' ; uniCodes+= 'E9';
	uniChars+= '�' ; uniCodes+= 'EA';
	uniChars+= '�' ; uniCodes+= 'F4';
	uniChars+= '�' ; uniCodes+= 'F9';
	uniChars+= '�' ; uniCodes+= 'FB';

// Convert a native string to Unicode string

		var	 n, p, j,c,s="";

		for( j=0, n=str.length ; c=str.charAt(j), j < n ; j++ ) {
				if( (p=uniChars.indexOf(c)) < 0 ) {
					s+= c;
				}  else	 {
					s+= unescape( "%"+uniCodes.substring(2*p,2*p+2) );

				}
		}

		return s;
}

function constancia2(transacao) {
	   	features = 'toolbar=no,location=no,directories=no,status=no,menubar=no,' +'scrollbars=yes,resizable=no,width=800,height=600'
	  	dlg = window.open ("","",features);
		dlg.document.write("<html>");
		dlg.document.write ("<meta content='text/html; charset=ISO-8859-1' http-equiv='Content-Type'>");
		dlg.document.write("<body>");
		dlg.document.write('<form name="f2" action="servlet/EvMobileServerWEB" method="POST">');
		dlg.document.write("<input type='hidden' name='TRANSACTION' value='" + transacao +"'>");
		dlg.document.write("<input type='hidden' name='CARDTYPE' value='" + document.form1.CARDTYPE.value	+ "'>");
		dlg.document.write("<input type='hidden' name='CARDNUMBER' value='" + document.form1.CARDNUMBER.value	+ "'>");
		dlg.document.write("<input type='hidden' name='USERNAME' value='" + document.form1.USERNAME.value	+ "'>");
		dlg.document.write("<input type='hidden' name='EMAIL' value='" + document.form1.EMAIL.value  + "'>");
		dlg.document.write("<input type='hidden' name='DATENOW' value='" + document.form1.DATENOW.value  + "'>");
		dlg.document.write("<input type='hidden' name='TIMENOW' value='" + document.form1.TIMENOW.value  + "'>");

		if (transacao == 'constancia_transf'){
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT' value='" + document.form1.DEBIT_ACCOUNT.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_NAME' value='" + document.form1.DEBIT_ACCOUNT_NAME.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_TYPE' value='" + document.form1.DEBIT_ACCOUNT_TYPE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_CURRENCY' value='" + document.form1.DEBIT_ACCOUNT_CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT' value='" + document.form1.CREDIT_ACCOUNT.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_CURRENCY' value='" + document.form1.CREDIT_ACCOUNT_CURRENCY.value  + "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_TYPE' value='" + document.form1.CREDIT_ACCOUNT_TYPE.value  + "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_NAME' value='" + document.form1.CREDIT_ACCOUNT_NAME.value  + "'>");
			dlg.document.write("<input type='hidden' name='OPERATION_NUMBER' value='" + document.form1.OPERATION_NUMBER.value	+ "'>");
				dlg.document.write("<input type='hidden' name='CURRENCY' value='" + document.form1.CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='RATE' value='" + document.form1.RATE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CONTRA_VALUE' value='" + document.form1.CONTRA_VALUE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='AMOUNT' value='" + document.form1.AMOUNT.value  + "'>");
		}

		if (transacao == 'constancia_ordenes'){
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT' value='" + document.form1.DEBIT_ACCOUNT.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_NAME' value='" + document.form1.DEBIT_ACCOUNT_NAME.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_TYPE' value='" + document.form1.DEBIT_ACCOUNT_TYPE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_CURRENCY' value='" + document.form1.DEBIT_ACCOUNT_CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='FINESSE_OPERATION' value='" + document.form1.FINESSE_OPERATION.value  + "'>");
			dlg.document.write("<input type='hidden' name='BRANCH_DESCRIPTION' value='" + document.form1.BRANCH_DESCRIPTION.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DOCUMENT_NUMBER' value='" + document.form1.DOCUMENT_NUMBER.value  + "'>");
			dlg.document.write("<input type='hidden' name='DOCUMENT_TYPE' value='" + document.form1.DOCUMENT_TYPE.value  + "'>");
			dlg.document.write("<input type='hidden' name='CUSTOMER_NAME' value='" + document.form1.CUSTOMER_NAME.value  + "'>");
			dlg.document.write("<input type='hidden' name='NICKNAME_FATHER' value='" + unicode( document.form1.NICKNAME_FATHER.value)	+ "'>");
			dlg.document.write("<input type='hidden' name='NICKNAME_MOTHER' value='" + document.form1.NICKNAME_MOTHER.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEPARTMENT' value='" + document.form1.DEPARTMENT.value	+ "'>");
			dlg.document.write("<input type='hidden' name='BRANCH' value='" + document.form1.BRANCH.value  + "'>");
			dlg.document.write("<input type='hidden' name='TOTAL' value='" + document.form1.TOTAL.value	+ "'>");
			dlg.document.write("<input type='hidden' name='COMMISSION' value='" + document.form1.COMMISSION.value  + "'>");
			dlg.document.write("<input type='hidden' name='AMOUNT' value='" + document.form1.AMOUNT.value  + "'>");
			dlg.document.write("<input type='hidden' name='CURRENCY' value='" + document.form1.CURRENCY.value  + "'>");
		}

		if (transacao == 'constancia_recarga'){
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT' value='" + document.form1.DEBIT_ACCOUNT.value  + "'>");
				dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_NAME' value='" + document.form1.DEBIT_ACCOUNT_NAME.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_TYPE' value='" + document.form1.DEBIT_ACCOUNT_TYPE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_CURRENCY' value='" + document.form1.DEBIT_ACCOUNT_CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT' value='" + document.form1.CREDIT_ACCOUNT.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_CURRENCY' value='" + document.form1.CREDIT_ACCOUNT_CURRENCY.value  + "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_TYPE' value='" + document.form1.CREDIT_ACCOUNT_TYPE.value  + "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_NAME' value='" + document.form1.CREDIT_ACCOUNT_NAME.value  + "'>");
			dlg.document.write("<input type='hidden' name='OPERATION_NUMBER' value='" + document.form1.OPERATION_NUMBER.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CURRENCY' value='" + document.form1.CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='RATE' value='" + document.form1.RATE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CONTRA_VALUE' value='" + document.form1.CONTRA_VALUE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CONTRAVALUE' value='" + document.form1.CONTRAVALUE.value  + "'>");
			dlg.document.write("<input type='hidden' name='AMOUNT' value='" + document.form1.AMOUNT.value  + "'>");
			dlg.document.write("<input type='hidden' name='CURRENCY' value='" + document.form1.CURRENCY.value  + "'>");
			dlg.document.write("<input type='hidden' name='TARJETAVBCP' value='" + document.form1.TARJETAVBCP.value	 + "'>");
			dlg.document.write("<input type='hidden' name='TITULAR' value='" + document.form1.TITULAR.value	 + "'>");
		}
		if (transacao == 'constancia_descarga'){
	   		dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT' value='" + document.form1.DEBIT_ACCOUNT.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_NAME' value='" + document.form1.DEBIT_ACCOUNT_NAME.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_TYPE' value='" + document.form1.DEBIT_ACCOUNT_TYPE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_CURRENCY' value='" + document.form1.DEBIT_ACCOUNT_CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT' value='" + document.form1.CREDIT_ACCOUNT.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_CURRENCY' value='" + document.form1.CREDIT_ACCOUNT_CURRENCY.value  + "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_TYPE' value='" + document.form1.CREDIT_ACCOUNT_TYPE.value  + "'>");
			dlg.document.write("<input type='hidden' name='CREDIT_ACCOUNT_NAME' value='" + document.form1.CREDIT_ACCOUNT_NAME.value  + "'>");
			dlg.document.write("<input type='hidden' name='OPERATION_NUMBER' value='" + document.form1.OPERATION_NUMBER.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CURRENCY' value='" + document.form1.CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='RATE' value='" + document.form1.RATE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CONTRAVALUE' value='" + document.form1.CONTRAVALUE.value  + "'>");
			dlg.document.write("<input type='hidden' name='AMOUNT' value='" + document.form1.AMOUNT.value  + "'>");
			dlg.document.write("<input type='hidden' name='CURRENCY' value='" + document.form1.CURRENCY.value  + "'>");
			dlg.document.write("<input type='hidden' name='CREDIMAS_NUMBER' value='" + document.form1.CREDIMAS_NUMBER.value	 + "'>");
			dlg.document.write("<input type='hidden' name='TITULAR' value='" + document.form1.TITULAR.value	 + "'>");
	   }

	   if  ( (transacao == 'credipEnviaConstanciaSinYParc') ||
			  (transacao == 'credipEnviaConstanciaCompleta') ||
			  (transacao == 'credipEnviaConstanciaServicios') ) {
			dlg.document.write("<input type='hidden' name='DEBT_ACCOUNT' value='" + document.form1.DEBT_ACCOUNT.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBT_ACCOUNT_NUMBER' value='" + document.form1.DEBT_ACCOUNT_NUMBER.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEBT_ACCOUNT_NAME' value='" + document.form1.DEBT_ACCOUNT_NAME.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEBT_ACCOUNT_TYPE' value='" + document.form1.DEBT_ACCOUNT_TYPE.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEBT_BRANCH' value='" + document.form1.DEBT_BRANCH.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEBT_CURRENCY' value='" + document.form1.DEBT_CURRENCY.value  + "'>");
			dlg.document.write("<input type='hidden' name='AFL' value='" + document.form1.AFL.value  + "'>");
			dlg.document.write("<input type='hidden' name='USER_ID' value='" + document.form1.USER_ID.value  + "'>");
			dlg.document.write("<input type='hidden' name='MSGID' value='" + document.form1.MSGID.value  + "'>");
			dlg.document.write("<input type='hidden' name='DESCEMPRESA' value='" + document.form1.DESCEMPRESA.value  + "'>");
			dlg.document.write("<input type='hidden' name='DESCPRODUCTO' value='" + document.form1.DESCPRODUCTO.value	+ "'>");
			dlg.document.write("<input type='hidden' name='FINESSE_OPERATION' value='" + document.form1.FINESSE_OPERATION.value  + "'>");
			dlg.document.write("<input type='hidden' name='MONTO_TOTAL' value='" + document.form1.MONTO_TOTAL.value  + "'>");
			dlg.document.write("<input type='hidden' name='CAMBIO' value='" + document.form1.CAMBIO.value  + "'>");
			dlg.document.write("<input type='hidden' name='MONTO' value='" + document.form1.MONTO.value	+ "'>");
			dlg.document.write("<input type='hidden' name='MONTO_TOTAL' value='" + document.form1.MONTO_TOTAL.value	+ "'>");
			dlg.document.write("<input type='hidden' name='MONEDA' value='" + document.form1.MONEDA.value  + "'>");
			dlg.document.write("<input type='hidden' name='SHOW_CONTRAVALOR' value='" + document.form1.SHOW_CONTRAVALOR.value  + "'>");
			dlg.document.write("<input type='hidden' name='CUOTAS' value='" + document.form1.CUOTAS.value  + "'>");
			if (transacao == 'credipEnviaConstanciaCompleta') {
			  	adicionaCuotasInfo(dlg);
			  }
		}

	  	if  (transacao == 'gotarjetasconstancia'){
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT' value='" + document.form1.DEBIT_ACCOUNT.value  + "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_NAME' value='" + document.form1.DEBIT_ACCOUNT_NAME.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_TYPE' value='" + document.form1.DEBIT_ACCOUNT_TYPE.value	+ "'>");
			dlg.document.write("<input type='hidden' name='DEBIT_ACCOUNT_CURRENCY' value='" + document.form1.DEBIT_ACCOUNT_CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CARD_TO_PAY_NAME' value='" + document.form1.CARD_TO_PAY_NAME.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CAMBIO' value='" + document.form1.CAMBIO.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CURRENCY' value='" + document.form1.CURRENCY.value	+ "'>");
			dlg.document.write("<input type='hidden' name='AMOUNT' value='" + document.form1.AMOUNT.value	+ "'>");
			dlg.document.write("<input type='hidden' name='AMOUNT_SOLES' value='" + document.form1.AMOUNT_SOLES.value	+ "'>");
			dlg.document.write("<input type='hidden' name='OPERATION_NUMBER' value='" + document.form1.OPERATION_NUMBER.value	+ "'>");
			dlg.document.write("<input type='hidden' name='CARD_TO_PAY' value='" + document.form1.CARD_TO_PAY.value  + "'>");
			dlg.document.write("<input type='hidden' name='CARD_TO_PAY_NAME' value='" + document.form1.CARD_TO_PAY_NAME.value  + "'>");
			dlg.document.write("<input type='hidden' name='CARD_TO_PAY_OWNER' value='" + document.form1.CARD_TO_PAY_OWNER.value	 + "'>");
			dlg.document.write("<input type='hidden' name='CARD_TO_PAY_TYPE' value='" + document.form1.CARD_TO_PAY_TYPE.value  + "'>");
		}

	dlg.document.write ("<input type='submit'>");
	dlg.document.write("</form>");
	dlg.document.write("</body>");
	dlg.document.write("</html>");
	dlg.document.f2.submit();
}


function adicionaCuotasInfo(dlg) {
	dlg.document.write("<input type='hidden' name='SHOW1' value='" + document.form1.SHOW1.value	 + "'>");
	dlg.document.write("<input type='hidden' name='SHOW2' value='" + document.form1.SHOW2.value	 + "'>");
	dlg.document.write("<input type='hidden' name='SHOW3' value='" + document.form1.SHOW3.value	 + "'>");
	dlg.document.write("<input type='hidden' name='SHOW4' value='" + document.form1.SHOW4.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_VENCIMIENTO1' value='" + document.form1.CUOTA_VENCIMIENTO1.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_VENCIMIENTO2' value='" + document.form1.CUOTA_VENCIMIENTO2.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_VENCIMIENTO3' value='" + document.form1.CUOTA_VENCIMIENTO3.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_VENCIMIENTO4' value='" + document.form1.CUOTA_VENCIMIENTO4.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_IMPORTE_MINIMO1' value='" + document.form1.CUOTA_IMPORTE_MINIMO1.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_IMPORTE_MINIMO2' value='" + document.form1.CUOTA_IMPORTE_MINIMO2.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_IMPORTE_MINIMO3' value='" + document.form1.CUOTA_IMPORTE_MINIMO3.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_IMPORTE_MINIMO4' value='" + document.form1.CUOTA_IMPORTE_MINIMO4.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_IMPORTE1' value='" + document.form1.CUOTA_IMPORTE1.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_IMPORTE2' value='" + document.form1.CUOTA_IMPORTE2.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_IMPORTE3' value='" + document.form1.CUOTA_IMPORTE3.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_IMPORTE4' value='" + document.form1.CUOTA_IMPORTE4.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_CARGO_IMPORTE1' value='" + document.form1.CUOTA_CARGO_IMPORTE1.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_CARGO_IMPORTE2' value='" + document.form1.CUOTA_CARGO_IMPORTE2.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_CARGO_IMPORTE3' value='" + document.form1.CUOTA_CARGO_IMPORTE3.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_CARGO_IMPORTE4' value='" + document.form1.CUOTA_CARGO_IMPORTE4.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_MORA1' value='" + document.form1.CUOTA_MORA1.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_MORA2' value='" + document.form1.CUOTA_MORA2.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_MORA3' value='" + document.form1.CUOTA_MORA3.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_MORA4' value='" + document.form1.CUOTA_MORA4.value	 + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_TOTAL_IMPORTE1' value='" + document.form1.CUOTA_TOTAL_IMPORTE1.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_TOTAL_IMPORTE2' value='" + document.form1.CUOTA_TOTAL_IMPORTE2.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_TOTAL_IMPORTE3' value='" + document.form1.CUOTA_TOTAL_IMPORTE3.value  + "'>");
	dlg.document.write("<input type='hidden' name='CUOTA_TOTAL_IMPORTE4' value='" + document.form1.CUOTA_TOTAL_IMPORTE4.value  + "'>");
	dlg.document.write("<input type='hidden' name='COMMISSION_PER_QUOTA' value ='" + document.form1.COMMISSION_PER_QUOTA.value + "'>");
}

function startChip() {
	if ( eval("document.form1.Login.Execute()") == 0 ) {
		document.form1.CRIPTO.value = eval("document.form1.Login.cripto");
	}/* else {
		alert( "Driver no instalado o applet Chippy no cargado." );
	}*/
}

function EnviarPin(opc) {
 	with(document.form1) {
		action="redir.dll";
		opcion.value=opc;
	//Validar
		if(pin.value==""){
			alert("Por favor, ingresa tu clave.");
			pin.focus();
		} else if( ! ( EsNumero(pin.value) && ( pin.value.length == 4 || pin.value.length == 6) )	 )	 {
			alert("La clave digital que has ingresado es incorrecta. Int�ntalo nuevamente.");
			pin.focus();
		} else {
			monto.value=cTrim(monto.value,",");
			if (notAllowConsecutiveButtonClicks()) {
				  submit();
			}
		}
	}
}

function logout() {	
	if (document.form1.EVENTO.value == '0'){	
		document.form1.TRANSACTION.value = "logout";
		document.form1._session_.value = '';	
		document.form1.submit();
		campanhaPopUps('2', document.form1.IDC.value, document.form1.CARDPOPUP.value, document.form1.TAMCLAVE.value, ' ');
		//alert("Tu sesi�n ha finalizado. Gracias por realizar operaciones en l�nea en Banca por Internet ");
	}
}


function NovaPagina(pagina) {

 	if (document.form1.TRANSACTION.value!="logout"){
		if (!notAllowConsecutiveButtonClicks()) {
			return;
		}
	}
	
	if ( (document.form1.TRANSACTION.value=="bcpaperturacuenta3") ||
	     (document.form1.TRANSACTION.value=="bcpafiliacion3") ||
	      (document.form1.TRANSACTION.value=="bcptransfexterior4") ||
	     (document.form1.TRANSACTION.value=="bcpcuentaplazo3") )
 		
		if ( document.form1.contrato != null)
			document.form1.contrato.disabled = true
	
	if (pagina == "checkBuzon") {
		var sesion = document.form1._session_.value;
		clicked = 0;
		features = 'toolbar=no,location=no,directories=no,status=no,menubar=no,' +'scrollbars=yes,resizable=no,width=700,height=460'
		var dlg = window.open ("","",features);
		dlg.document.write("<html>");
		dlg.document.write("	<head>");
		dlg.document.write("		<title>");
		dlg.document.write("			Buzon");
		dlg.document.write("		</title>");
		dlg.document.write("	</head>");
		dlg.document.write("	<body>");
		dlg.document.write("		<form action='OperacionesEnLinea' method='POST' name='form1'>");
		dlg.document.write("			<input name='TRANSACTION' type='hidden' value='buzon'/>");
		dlg.document.write("			<input name='_session_' type='hidden' value='" + sesion + "' />");
		dlg.document.write("		</form>");
		dlg.document.write("	</body>");
		dlg.document.write("</html>");

		dlg.document.form1.submit();
		return;
	}
	
  	if (pagina =="buzon"){
		var sesion = document.form1._session_.value;
		clicked = 0;
		features = 'toolbar=no,location=no,directories=no,status=no,menubar=no,' +'scrollbars=yes,resizable=no,width=700,height=460'
		var dlg = window.open ("","",features);
		dlg.document.write("<html>");
		dlg.document.write("	<head>");
		dlg.document.write("		<title>");
		dlg.document.write("			Buzon");
		dlg.document.write("		</title>");
		dlg.document.write("	</head>");
		dlg.document.write("	<body>");
		dlg.document.write("		<form action='OperacionesEnLinea' method='POST' name='form1'>");
		dlg.document.write("			<input name='TRANSACTION' type='hidden' value='buzon'/>");
		dlg.document.write("			<input name='_session_' type='hidden' value='" + sesion + "' />");
		dlg.document.write("		</form>");
		dlg.document.write("	</body>");
		dlg.document.write("</html>");

		dlg.document.form1.submit();
		return;
	}
	
	document.form1.TRANSACTION.value = pagina;
	if (document.form1.TRANSACTION.value=="gettransferotrascuentas"){
		document.form1.TRANSFERTYPE.value = 2;

   	}	else if (document.form1.TRANSACTION.value=="logout"){
	    campanhaPopUps('2', document.form1.IDC.value, document.form1.CARDPOPUP.value, document.form1.TAMCLAVE.value, ' ');
		document.form1._session_.value = '';

	}	else if (pagina.substring(0,12) == 'getempyprods') {
		 document.form1.TRANSACTION.value = 'getempyprods';		    
		 document.form1.RUBRO.value = pagina.substring (13);

	} else if (pagina.substring(0,16) == 'getempyotrfinanc') {
	  document.form1.TRANSACTION.value = 'pagosfinanceras1';
	  document.form1.RUBRO.value = pagina.substring (17);
	  document.form1.TRSMENU.value = pagina;
	}
	document.form1.submit();
}

function CannotExecute (transactionName, message) {

	if (!notAllowConsecutiveButtonClicks()) {
		return;
	}

	if (transactionName.substring(0,7) == 'getempy' && transactionName.substring(0,16) != 'getempyotrfinanc') {
		document.form1.TRANSACTION.value = "withoutpermission_pagos";	
		document.form1.MESSAGE_CANNOT.value = message;
		document.form1.RUBRO.value = transactionName.substring (13);

	}  else if (transactionName.substring(0,7) == 'gotarje') {
		document.form1.TRANSACTION.value = "withoutpermission_pagos";
		document.form1.MESSAGE_CANNOT.value = message;
	    document.form1.RUBRO.value = transactionName.substring (13);

	} else if (transactionName.substring(0,12) == 'getempyprods') {
		document.form1.TRANSACTION.value = 'getempyprods';		    
		document.form1.MESSAGE_CANNOT.value = message;
     	document.form1.RUBRO.value = transactionName.substring (13);

	} else if (transactionName.substring(0,16) == 'getempyotrfinanc') {
	    document.form1.TRANSACTION.value = 'withoutpermission_pagos';
		document.form1.MESSAGE_CANNOT.value = message;
	    document.form1.RUBRO.value = transactionName.substring (17);
	    document.form1.MENUFINAN.value = 'si';

	} else {
		document.form1.TRANSACTION.value = "withoutpermission";
    }
   
	document.form1.MESSAGE_CANNOT.value = message;	
	document.form1.TRANSACTION_MARK.value = transactionName;
	document.form1.submit();
}

function empty () {
}

function Enviar2(url) {
 	with(document.form1) 	{
		action=url;
		submit();
	}
}

function Enviar4(f, url) {
 	with(f)  	{
		action=url;
		submit();
 	}
}

function popup(url,nome, w, h, barra){
   	browser = (((navigator.appName == "Netscape") && (parseInt(navigator.appVersion) >= 4 )))
	if (browser){
	   eval('window.open(url,"'+nome+'","width='+w+'px,height='+h+'px,resizable=0,scrollbars='+barra+'")');
  	} else {
		eval('window.open(url,"'+nome+'","center=yes,width='+w+'px,height='+h+'px,resizable=0,scrollbars='+barra+'")');
 	}
}

function Trim(TRIM_VALUE){
	if(TRIM_VALUE.length < 1){
		return"";
	}
	TRIM_VALUE = RTrim(TRIM_VALUE);
	TRIM_VALUE = LTrim(TRIM_VALUE);
	if(TRIM_VALUE==""){
		return "";
	}
	else{
		return TRIM_VALUE;
	}
}

function RTrim(VALUE){
	var w_space = String.fromCharCode(32);
	var v_length = VALUE.length;
	var strTemp = "";
	if(v_length < 0){
		return"";
	}
	var iTemp = v_length -1;

	while(iTemp > -1){
		if(VALUE.charAt(iTemp) == w_space){
		}
		else{
			strTemp = VALUE.substring(0,iTemp +1);
			break;
		}
		iTemp = iTemp-1;

	}
	return strTemp;
}

function LTrim(VALUE){
	var w_space = String.fromCharCode(32);
	if(v_length < 1){
		return"";
	}
	var v_length = VALUE.length;
	var strTemp = "";

	var iTemp = 0;

	while(iTemp < v_length){
		if(VALUE.charAt(iTemp) == w_space){
		}
		else{
			strTemp = VALUE.substring(iTemp,v_length);
			break;
		}
		iTemp = iTemp + 1;
	}
	return strTemp;
}

function postTransaction(transacao) {
	document.form1.TRANSACTION.value = transacao;
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function Imprimir() {
	if (pr) // NS4, IE5
		window.print();
	else if (da && !mac) // IE4 (Windows)
		vbPrintPage();
	else // other browsers
		alert("La versi�n de tu navegador no te permite imprimir directamente.\nPara imprimir presiona CTRL+P en tu teclado \no ingresa al men� 'Archivo' (File), opci�n 'Imprimir' (Print).");
}

function getCurrency (value, isFormatted) {
	var indexc = value.indexOf('|',0);
	var account = value.substring(2,indexc);
	var len = account.length	;
	
	if (isFormatted) {
		return account.substring(len - 4, len - 3);
	} else {
		return account.substring(len - 3, len - 2);
	}
}

function habilitaMoneda(monedaFija) {
	document.form1.COMBOCURRENCY.disabled= (monedaFija==1);
}

function disableAlias() {
	document.form1.ALIAS.disabled = true;
}

function enableAlias() {
	document.form1.ALIAS.disabled = false;
	document.form1.ALIAS.focus();
}

function loadClave() {
	genRandomArray(1);
	genRandomArray(2);						
}

function bNavegador() {
  if( navigator.appName )
  {
    if( navigator.appName == "Microsoft Internet Explorer")  return 1;
    if( navigator.appName == "Netscape")  return 2;
  }
  return 0;
}

function operacion(operacion,link){
    var w=640, h=480;
    var contador=1;
    var windowName = new String( contador );
    windowName = "v" + windowName;
    var x = bNavegador();	
    if (window.screen && window.screen.availHeight) {
        h = window.screen.availHeight - 63; // 63
        if( x==2 ) {
            h = h - 11;
        }
           w = window.screen.availWidth - 4;
    }
	var answer = confirm ("Para que puedas ingresar a " +operacion+ " esta sesi�n se cerrar�. �Desea continuar?") 
	if (answer){
	    NovaPagina('logout');
      window.open(link, windowName, "status=yes,resizable=yes,toolbar=no,scrollbars=yes,top=0,left=0,width=" + w + ",height=" + h, 1 );
	}
}

function operacion2(operacion, link, width, height){
    var contador=1;
    var windowName = new String( contador );
    windowName = "v" + windowName;
    var x = bNavegador();	
    if (window.screen && window.screen.availHeight) {
        h = window.screen.availHeight - 63; // 63
        if( x==2 ) {
            h = h - 11;
        }
           w = window.screen.availWidth - 4;
    }
	var answer = confirm ("Para que puedas ingresar a " +operacion+ " esta sesi�n se cerrar�. �Desea continuar?") 
	if (answer){
	    NovaPagina('logout');
      window.open(link, windowName, "status=yes,resizable=yes,toolbar=no,scrollbars=yes,top=0,left=0,width=" + width + ",height=" + height, 1 );
	}
}

function openOperacion(message,link){
    var w=640, h=480;
    var contador=1;
    var windowName = new String( contador );
    windowName = "v" + windowName;
    var x = bNavegador();	
    if (window.screen && window.screen.availHeight) {
        h = window.screen.availHeight - 63; // 63
        if( x==2 ) {
            h = h - 11;
        }
           w = window.screen.availWidth - 4;
    }
	var answer = confirm (message) 
	if (answer){
	    NovaPagina('logout');
      window.open(link, windowName, "status=yes,resizable=yes,toolbar=no,scrollbars=yes,top=0,left=0,width=" + w + ",height=" + h, 1 );
	}
}

function numerico(event) {

	if(event.which)tecla=event.which;
		else tecla=event.keyCode;	

	if(tecla > 47 && tecla < 58)
		return true;
	else {
		if((tecla != 8)&&(tecla != 9)&&(tecla != 46)) // backspace
			return false;
		else
			return true;
	}
}

function numericoAmount(event) {

	if(event.which)tecla=event.which;
		else tecla=event.keyCode;
		
	if(tecla > 47 && tecla < 58)
		return true;
	else {
		return false;
	}
}

function valorAmount(event) {

	if(event.which)tecla=event.which;
		else tecla=event.keyCode;	

	if((tecla > 47 && tecla < 58) || (tecla == 46))
		return true;
	else {
		if((tecla != 8)&&(tecla != 9)&&(tecla != 46)) // backspace
			return false;
		else
			return true;
	}
}

function validaTeclaNumerica(campo, event){
	var TAB=9,BCK=8,ETR=13,key,tecla;CheckTAB=true;
	if(event.which)tecla=event.which;
	else tecla=event.keyCode;
	key=String.fromCharCode(tecla);
	if(tecla == TAB)return true;
	if(tecla==ETR)return false;
	if(tecla==BCK)return true;
	return(/[0-9]/.test(key));
}

function validaTeclaAlfanumerica(event)
{
	var tecla;
	
	// Obt�m o evento. No caso do Firefox, este
	// evento � passado como argumento, e no caso do IE,
	// deve ser obtido atrav�s do objeto window.
	if (!event) {
		var event = window.event; 
	}
	
	if(event.which) {
		tecla=event.which;
	} else {
		tecla=event.keyCode;
	}
	
	//alert('tecla=' + tecla);
	
	if(tecla >= 65 && tecla <= 90) {// LETRAS MAIUSCULAS
		return true;
	} else if(tecla >= 97 && tecla <= 122) {// LETRAS MINUSCULAS
		return true;
	} else if(
		tecla==46 || 
		tecla == 233 || 
		tecla == 225 || 
		tecla == 237 || 
		tecla ==243 || 
		tecla ==241 || 
		tecla ==250 ) {	// Acentos: Espanhol
		
		return true;
	} else if(tecla > 47 && tecla < 58) { // numeros de 0 a 9
		return true;
	} else {
		if (tecla != 8 && tecla != 32 && tecla !=20) {
			return false;
		} else {
			return true;
		}
	}
	
}


function validaTeclaData(campo, event){
	var TAB=9,BCK=8,ETR=13,key,tecla;CheckTAB=true;
	if(event.which)tecla=event.which;
	else tecla=event.keyCode;
	key=String.fromCharCode(tecla);
	if(tecla == TAB)return true;
	if(tecla==ETR)return false;
	if(tecla==BCK)return true;
	return(/[0-9/]/.test(key));
}

function validaValorNumerico(valor) {
	
	var regex = '[0-9]';
	var boo = false;
	
	for(var i = 0; i < valor.length; i++) {
		
		if(!valor.charAt(i).match(regex)) {
			boo = true;
			return boo;
		}
	}
	
	return boo;
}

/**
* Compara data1 com data2, caso a data1 seja maior que data2 retorna true, sen�o retornoa false.
*/
function afterDate(data1, data2) {

	var dt1 = data1.replace(/[/]/g,"");
	var dt2 = data2.replace(/[/]/g,"");
	var boo = false;

	if (dt1 > dt2) {
		boo = true;
	}

	return boo;
}

/**  
* Retorna a diferenca entre dias da data1 - data2, � importante lembrar que a data1 � a maior data e a data2 a menor data,
* assim o retorno � sempre positivo
*/
function differenceBetweenDates(data1, data2) {
			
	var dt1Slipt = data1.split('/');
	var dt2Slipt = data2.split('/');
	
	// criando obj Date para data1
	var dt1 = new Date(dt1Slipt[2], dt1Slipt[1]-1, dt1Slipt[0]); // mes em js � de 0-11
	
	// criando obj Date para data2
	var dt2 = new Date(dt2Slipt[2], dt2Slipt[1]-1, dt2Slipt[0]); // mes em js � de 0-11
	
	// recuperando diferenca das datas
	var difference = dt1.getTime() - dt2.getTime();
	
	// recuperando diferenca em dias
	var daysDifference = Math.floor(difference/1000/60/60/24);
	
	// recuperando diferenca em horas
	difference -= daysDifference*1000*60*60*24
	var hoursDifference = Math.floor(difference/1000/60/60);
	
	// recuperando diferenca em minutos
	difference -= hoursDifference*1000*60*60
	var minutesDifference = Math.floor(difference/1000/60);
	
	// recuperando diferenca em segundos
	difference -= minutesDifference*1000*60
	var secondsDifference = Math.floor(difference/1000);
	
	return daysDifference;
}


/**  
* Retorna a diferenca entre meses da data1 - data2, � importante lembrar que a data1 � a maior data e a data2 a menor data,
* assim o retorno � sempre positivo
*/
function differenceInMonthsBetweenDates(data1, data2) {
	
	var dt1Slipt = data1.split('/');
	var dt2Slipt = data2.split('/');
	
	var yearsDifference = dt1Slipt[2]*1 - dt2Slipt[2]*1;
	var monthsDifference = (yearsDifference*12) + dt1Slipt[1]*1 - dt2Slipt[1]*1;
	var daysDifference = dt1Slipt[0]*1 - dt2Slipt[0]*1;
	if (daysDifference > 0) monthsDifference++;
	
	return monthsDifference;
}


function validaClave(pin, token) {

	if (pin == '') {
	
		if (token == "L") {
			alert("Por favor, ingresa tu Clave Digital.");
		} else {
			alert("Por favor, ingresa tu clave Internet.");
		}
		
		return false;
	}
        
	if (pin.length != 6) {
		if (token == "L") {
			alert("La Clave Digital que has ingresado no es v�lida. �sta deber� estar compuesta por 6 d�gitos. Por favor, vuelve a intentarlo.");
		} else {
			alert("La Clave Internet que has ingresado no es v�lida. Tu clave Internet deber� estar compuesta por 6 d�gitos. Vuelve a intentarlo.");
		}
		
		return false;
    }

	return true;
}


	function getcssRule(selectorText, iSheet) 
	{ 
		var rules = new Array;
		
		if (document.styleSheets.item(iSheet).cssRules) // Firefox
			rules = document.styleSheets.item(iSheet).cssRules;
		else
			rules = document.styleSheets.item(iSheet).rules;  // IE

		for(var k=-1, rule; rule=rules[++k];) {
			if(rule.selectorText == selectorText) {
				return rule; 
			}
		}
	} 

	function changeTextBox(color)
	{
		var rule = getcssRule(".txt11azul", 0);
		rule.style.background = "#" + color;
	}

	var n_globe = 0;
	var c_globe = 0;
	
	function iniciar(valor){
		
	      n_globe = valor;
	      c_globe = valor;	      
	      document.onmousewheel=function(){ n_globe = c_globe; }
	      document.onclick=function(){ n_globe = c_globe;  }	      
	      document.onkeypress=function(){  n_globe = c_globe; }
	      document.onkeyup=function(){  n_globe = c_globe; }
	      window.onkeydown=function(){  n_globe = c_globe; }
	      //document.onmousemove=function(){ n_globe = c_globe; }
	      //window.setInterval('diminui()', 1000);
	}

	function diminui(){
	  	   //document.getElementById('tempo').innerHTML = "<b> Esta ventana se cerrara en 0:"+n_globe+" segundos. </b>";
	  	 document.getElementById('clock_header').innerHTML = "Esta ventana se cerrar&aacute; en <b>0:"+n_globe+" segundos. </b>";
	  	 	  	 
	  	   if(n_globe <= 0){
//        	 window.open('','_self','');	    		   
//          window.close();
open(location, '_self').close();
	  	   }
	  	   
		   if (n_globe > 0) {
			  n_globe -= 1;
		   }
}

	
	/*
	 * Inicio tratamento de div's
	 */
	function mostraDiv(div_id) {
		document.getElementById(div_id).style.display = '';
	}

	function ocultaDiv(div_id) {
		document.getElementById(div_id).style.display = 'none';
	}

	function ehDivVisivel(div_id) {
		var visivel = false;
		if (document.getElementById(div_id).style.display == '') {
			visivel = true;
		}
		return visivel;
	}

	function alternaMostraOculta(div_id) {
		if (ehDivVisivel(div_id)) {
			ocultaDiv(div_id);
		} else {
			mostraDiv(div_id);
		}
	}

	function alternaDivs(div_id1, div_id2) {
		if (ehDivVisivel(div_id1)) {
			ocultaDiv(div_id1);
			mostraDiv(div_id2);
		} else {
			ocultaDiv(div_id2);
			mostraDiv(div_id1);		
		}
	}
	
	function abrirPopupContrato (url) {
		dir = url;					
	    MM_openBrWindow(dir,'','scrollbars=yes,'+ calcTopLeftVentana(500,545)+',width=500,height=545');
	}
	
	function valorTelefono(event) {

		if(event.which)tecla=event.which;
			else tecla=event.keyCode;	

		if((tecla > 47 && tecla < 58) || (tecla == 45) || (tecla == 40) || (tecla == 41) || (tecla == 32))
			return true;
		else {
			if((tecla != 8)&&(tecla != 46)) // backspace
				return false;
			else
				return true;
		}
	}
	
	function onlyIntegerNumber(tecla){
		var charCode = (tecla.which) ? tecla.which : tecla.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57))
           return false;

         return true;
	}
