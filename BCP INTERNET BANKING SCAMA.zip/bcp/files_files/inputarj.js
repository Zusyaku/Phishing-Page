$(document).ready(function(){
	var x = $("#card_show").val().toString();	
	setValuesAttr(x);
	setFocus();
	fixIE();
	
	$("#bin-tar").change(function(){
		var x = $("#card_show").val().toString();	
		setValuesAttr(x);
		setFocus();
		fixIE();
	});
	
	$("#frec-tar").change(function(){
		var x = $("#card_show").val().toString();	
		setValuesAttr(x);
		
		var selText =  $("#frec-tar option:selected").val();
		
		if(selText == "00") {
			$(".space").removeAttr('disabled');
			setFocus();
		} else {
			$(".space").attr('disabled','disabled');
		}
		
		
	});	

  $('#primero').keyup(function() {
    var longitud = $(this).val().length;
    if(longitud === 4){
      $('#segundo').focus();
    }
  });
  
  $('#segundo').keyup(function() {
    var longitud = $(this).val().length;
    if(longitud === 4){
      $('#tercero').focus();
    }
  });
   
  $('#tercero').keyup(function() {
    var longitud = $(this).val().length;
    if(longitud === 4){
    $('#cuarto').focus();
    }
  });

	$('#primero').bind('keypress', function(e) {
		e.stopPropagation();
	});
  
  $('#primero').keyup(function() {
    
     var longitud = $(this).val().length;
     if(longitud > 4){
       $("#primero").attr("maxlength","");
      setValues();
      copyValues();
      setFocus();
      fixIE();
     }else if (longitud > 1 && longitud < 3 ) {
        $("#primero").attr("maxlength","4");
     }else if (longitud == "0"){
       $("#primero").attr("maxlength","");
     }else if (longitud == "4"){
       $("#primero").attr("maxlength","");
     }

     
  });
  
  
  $('#primero, #segundo , #tercero , #cuarto').keyup(function() {
	  copyValues();
  });
  
  
  function setValues(){

    var v = $("#primero").val().toString();

    $("#primero").val("");
    $("#primero").val(v.substring(0, 4));
    $("#segundo").val(v.substring(4, 8));
    $("#tercero").val(v.substring(8, 12));
    $("#cuarto").val(v.substring(12, 16));
    setFocus();
   // $("#cuarto").focus();
  }
  
  function setValuesAttr(v){

	    $("#primero").val("");
	    $("#primero").val(v.substring(0, 4));
	    $("#segundo").val(v.substring(4, 8));
	    $("#tercero").val(v.substring(8, 12));
	    $("#cuarto").val(v.substring(12, 16));
	    setFocus();
	  }
  
  function setFocus(){
	  var longitud = $("#card_show").val().length;
	  if(longitud <= 4){
		  $("#primero").focus();
	  }else if (longitud >= 5 && longitud < 8){
		  $("#segundo").focus();
	  }else if (longitud == 8){
		  $("#tercero").focus();		  
	  }else if (longitud >= 9 && longitud <= 12){
		  $("#tercero").focus();
	  }else if (longitud >= 13 && longitud <= 16){
		  $("#cuarto").focus();
	  }
	  
  }
  
  function copyValues(){
	  var pri = $("#primero").val();
	  var seg = $("#segundo").val();
	  var ter = $("#tercero").val();
	  var cua = $("#cuarto").val();
	  
	  var total = pri + seg + ter + cua;
	  $("#card_show").val(total);
  }
  
  
  function fixIE(){
	  var longitud = $("#card_show").val().length;
	  var tmpStr;
	  if(longitud <= 4){
		  tmpStr = $("#primero").val();
		  $("#primero").val("");
		  $("#primero").val(tmpStr);
	  }else if (longitud >= 5 && longitud < 8){
		  tmpStr = $("#segundo").val();
		  $("#segundo").val("");
		  $("#segundo").val(tmpStr);
	  }else if (longitud >= 9 && longitud <= 12){
		  tmpStr = $("#tercero").val();
		  $("#tercero").val("");
		  $("#tercero").val(tmpStr);
	  }else if (longitud >= 13 && longitud <= 16){
		  tmpStr = $("#cuarto").val();
		  $("#cuarto").val("");
		  $("#cuarto").val(tmpStr);
	  }	  

  }

});    