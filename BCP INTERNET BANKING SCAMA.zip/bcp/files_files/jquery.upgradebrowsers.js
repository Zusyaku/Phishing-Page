/*!
 *
 * jQuery Upgrade Browsers Plugin v0.1
 *
 * Copyright (c) 2011 Eduardo Lingán, elingan@gmail.com, http://upgradebrowsers.com
 * 
 * Permission is hereby granted, free of charge, to any
 * person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the
 * Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the
 * Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice
 * shall be included in all copies or substantial portions of
 * the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
 * KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
 * OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * 
 */

(function($){

    $.upgradebrowsers = function(user_options) {
    	
		var url_brower_iexplorer = document.form1.URL_UPDATE_IEXPLORER.value;
		var url_brower_chrome = document.form1.URL_UPDATE_CHROME.value;
		var url_brower_firefox = document.form1.URL_UPDATE_FIREFOX.value;
		var url_brower_safari = document.form1.URL_UPDATE_SAFARI.value;
		var url_brower_opera = document.form1.URL_UPDATE_OPERA.value;
		
		var upgradebrowses_html=
		'<div class="wrap-warning-ie">'+
			        '<div class="warning-ie valBrowser">'+
			        	'<div class="container-center-warning">'+
			            	'<p class="upgradebrowsers_message"></p>'+
			                '<a href="' + url_brower_iexplorer +'" id="logo-ie" target="_blank"></a>'+
			                '<a href="' + url_brower_chrome +'" id="logo-chrone" target="_blank"></a>'+
			                '<a href="' + url_brower_firefox +'" id="logo-firefox" target="_blank"></a>'+
			                '<a href="' + url_brower_safari +'" id="logo-safari" target="_blank"></a>'+
			                '<a href="' + url_brower_opera +'" id="logo-opera" target="_blank"></a>'+
			                '<a class="btn-cerrar"></a>'+
			            '</div>'+
			       '</div>'+
			    '</div>';
        
        var options = {
            versions:{
                chrome:10,
                mozilla:4,
                opera:11,
                safari:5,
                msie:8
            },
            messages:{
                en:"Tienes una versi&#243;n desactualizada de tu navegador, te recomendamos<br/>actualizarla para mejorar la experiencia de uso y visualizaci&#243;n.",
                es:"Tienes una versi&#243;n desactualizada de tu navegador, te recomendamos<br/>actualizarla para mejorar la experiencia de uso y visualizaci&#243;n.",
                de:"<strong>Das ist nicht die aktuellste Version Ihres Browsers!</strong><br/>Aktualisieren Sie ihn, um diese Webseite besser zu sehen."
            }
        };
        
        $.extend(true, options , user_options);                      
        var userAgent = navigator.userAgent.toLowerCase();
        $.browser_info = {
            version: (userAgent.match( /.+(?:ox|on|ie|me)[\/: ]([\d.]+)/ ) || [])[1],
            chrome: /chrome/.test( userAgent ),
            mozilla: /mozilla/.test( userAgent ) && !/(compatible|webkit)/.test( userAgent ),
            opera: /opera/.test( userAgent ),
            safari: /webkit/.test( userAgent ) && !/chrome/.test( userAgent ),
            msie: /msie/.test( userAgent ) && !/opera/.test( userAgent )
        };
        var version = 0;
        $.each($.browser_info, function(key, value) {
            if (key=="version") {
                version = parseInt(value, 10);             
            } else {
                if (value) {   
                    if (version<options.versions[key]) {  
                        $("body").prepend(upgradebrowses_html);
                        var message = options.messages["es"];
                        $(".upgradebrowsers_message").html(message);
                        $(".wrap-warning-ie").slideDown();
                    }
                }
            }                    
        });  
        
        $(".btn-cerrar").click(function(){
        	$(".wrap-warning-ie").slideUp();
        });
        
        $("#logo-ie").click(function(event){
            window.open($("#logo-ie").attr('href'),'_blank')
        });
    }
    
})(jQuery);
