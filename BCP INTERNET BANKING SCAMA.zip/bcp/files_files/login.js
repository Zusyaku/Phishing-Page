function Cierre(){
	window.open('','_self','');
	window.close();
}

function IsAlfaNum(ch) {
	return IsDigit(ch) || (('A'<=ch) && (ch<='Z')) || (('a'<=ch) && (ch<='z')) || ch == '_' || ch==" " ;
}
var checkpopup = false;
var popup = null;
var intervalTimer = null;

function ativacheck(){
	intervalTimer = setInterval("checkPopup()",1000);
}
function inicia() {
	var perfil = document.form1.CARDTYPE_SHOW.value;
	
	for (t=0; t < PerfilesTransacciones.length && perfil != PerfilesTransacciones[t].codigo; t++ );
	if (t >= PerfilesTransacciones.length) {
		alert("Error: no esta perfil");
		return;
	}
}

function fieldfocus(){
	try{
		var domObj = popup.findDOM('areanombre',1);
		if(domObj.visibility == "visible"){
			popup.focus();
			popup.document.form1.alias.focus();
		} else {
			popup.focus();
		}
	} catch(e){
		if (navigator.appName == "Netscape"){
			popup.document.title = "Tarjetas frecuentes";
		}
		popup.blur();
		popup.focus();
	}
}

function checkPopup(){
	try {
		if (checkpopup == true){
			fieldfocus();
		}
	} catch (e){
		clearInterval(intervalTimer);
		document.form1.submit();
	}
	
}

function postToken() {
	var pin = document.form1.PIN.value.length;
	
    if ((pin != 0) && (pin != 6)) {
        alert("La Clave Digital que has ingresado no es v\u00e1lida. \u00e9sta deber\u00e1 estar compuesta por 6 d\u00edgitos. Por favor, vuelve a intentarlo.");
        return;
    }

	if (notAllowConsecutiveButtonClicks()){
		document.form1.submit(); 
	} 
}

function Perfiles (aCodigo, aNombre, aBin, aTransacciones) {
	this.nombre= aNombre;
	this.codigo= aCodigo;
	this.bin  = aBin;
	this.transacciones = aTransacciones;
}

function Transaccion (aCodigo, aNombre, aLink) {
	this.nombre= aNombre;
	this.codigo= aCodigo;
	this.link = aLink;
}

function Bines (aBin, aCardType)  {
	this.bin = aBin;
	this.cardType = aCardType;
}

function getLink (transacciones, transaction) {
	for (i=0; i < transacciones.length && transacciones.codigo == transaction; i++ );
	
	if (i >= transacciones.length) {		
		return "at80";
	}
	
	return transaction.link;	
}

function changeType() {

	var perfil = document.form1.CARDTYPE_SHOW.value;
                   		
	for (i=0; i < PerfilesTransacciones.length && perfil != PerfilesTransacciones[i].codigo; i++ );
	if (i >= PerfilesTransacciones.length) {
		alert("Error: no esta perfil");
		return;
	}
	
	document.form1.CARD_SHOW.value = PerfilesTransacciones[i].bin;
}

function alternateMessageClave() {
	var perfil = document.form1.CARDTYPE_SHOW.value;
	var div6 = document.getElementById('div_clave6');
	var div4 = document.getElementById('div_clave4');
	
	var subdiv6 = document.getElementById('div_sub_message_clave6');
	var subdiv4 = document.getElementById('div_sub_message_clave4');

	if (perfil == '04' || perfil == '05' || perfil == '06' || perfil == '09') {
		div6.style.display='none';
		div4.style.display='';
		subdiv6.style.display='none';
		subdiv4.style.display='';
	} else {
		div6.style.display='';
		div4.style.display='none';
		
		subdiv6.style.display='';
		subdiv4.style.display='none';
	}
}

function checkKey(e,num1) { 
	var code = (NS_NAV) ? e.which : event.keyCode; 
    	if (code == 13) { 
        	if (num1==1) {
            	document.form1.CARD_SHOW.focus(); 
			} else if (num1==2) {
				document.form1.pin.focus(); 
			} else if (num1==3) {
				Enviar('NS7A'); 
			}
		} 
}


function IsDigit (ch) {
	//Descripcion:	Devuelve true si ch es digito
	return  (ch>="0" && ch<="9");
}

function sTrim(cad, car){
	//Descripcion:	Elimina los caracteres 'car' que encuentre en la cadena 'cad'
	var i;
	var cad2="";
	for(i=0;i<cad.length;i++) {
		if(cad.charAt(i)!=car)
			cad2 += cad.charAt(i);
	}
	return cad2;
}

function checkAlfaNumeric(cad) {
	var i;
	for (i=0; i<cad.length; i++) {	
		if  (!IsAlfaNum( cad.charAt(i) ) )  {
			return false;
		}
	}
	return true;
}

function checkNick(nick) {
	var nick = sTrim(nick," ");
	if	( nick == "" )  {
		alert("El campo nombre contiene valores que no son v\u00e1lidos. Por favor corr\u00edgelo.");
		return false;
	}
	if (!checkAlfaNumeric(nick)) {
		alert("El campo nombre contiene valores que no son v\u00e1lidos. Por favor corr\u00edgelo.");
	   	return false;
	}
	return true;
}

function getRealProfile (card) {
	
	for (i=0; i < bines.length && card.substring (0 , bines[i].bin.length) != bines[i].bin; i++ );
	
	if (i >= bines.length) {		
		return "00";
	}
		
	return bines[i].cardType;	
		
}


function checkPermision (cardType, transaction) {

	for (i=0; i < PerfilesTransacciones.length && cardType != PerfilesTransacciones[i].codigo; i++ );

	if (i >= PerfilesTransacciones.length) {		
		return "false";
	}
	
	var transacciones = PerfilesTransacciones[i].transacciones;	
		
	for (i=0; i < transacciones.length && transaction != transacciones[i].codigo; i++ );

	if (i >= transacciones.length) {		
		return "false";
	}
	
	return transacciones[i].link;
}

function Enviar(transacao) {
	if (notAllowConsecutiveButtonClicks() == true) {
		if (document.form1.nickname.value == "00") {			   
	 		document.form1.CARD.value = document.form1.CARD_SHOW.value;	
	 		
	 		if ( document.form1.CARD.value == "" ) {
				alert("Por favor, ingresa el n\u00famero de tu tarjeta.");
			 	/*document.form1.CARD_SHOW.focus();*/
			 	clicked = 0;
				return;	
	  		}	 
	
			if ( document.form1.CARD.value.length < 15 || ( !EsNumero( document.form1.CARD.value ) ) ) {
			 	alert("El n\u00famero de tarjeta que has ingresado no es el correcto. Por favor vuelve a intentarlo.");
			 	/*document.form1.CARD_SHOW.focus();*/
			 	clicked = 0;
			 	return;
		 	}	 					
		}
		
		if ( document.form1.pin.value == "" ) {
			alert("Por favor, ingresa tu clave.");
			clicked = 0;
			return;
		}
	
		if ((document.form1.pin.value.length != 4) && (document.form1.pin.value.length != 6)) {
			alert("La clave que has ingresado es incorrecta. Int\u00e9ntalo nuevamente.");
			clicked = 0;
			return;
		}
	
		if (!EsNumero( document.form1.pin.value )) {
			alert("La clave que has ingresado es incorrecta. Int\u00e9ntalo nuevamente.");
			clicked = 0;
			return;
		}
		
		
		var cardType = getRealProfile (document.form1.CARD.value);
		var perfil = document.form1.CARDTYPE_SHOW.value;
		
		if (((cardType == '04') || (cardType == '05')) && (document.form1.pin.value.length != 4)) {
			alert("La clave que has ingresado es incorrecta. Int\u00e9ntalo nuevamente.");
			clicked = 0;
			return;
		} 

		if (((perfil == '01') || (perfil == '03') || (perfil == '08')) && (document.form1.pin.value.length != 6)) { 
			alert("La clave que has ingresado es incorreta. Recuerda que debes ingresar tu clave internet (6 d\u00edgitos).");
			clicked = 0;
			return;
		}
		
		if (cardType == "00") {
		 	alert("El n\u00famero de tarjeta que has ingresado no es el correcto. Por favor vuelve a intentarlo.");
		 	clicked = 0;
			return;
		}
		else{ 
			if(perfil!=cardType){ 
				alert("El n\u00famero de tarjeta que has ingresado no pertenece al tipo de tarjeta seleccionada. Por favor vuelve a intentarlo."); 
	
				clicked = 0; 
				return; 
			} 
		}
		
		if (document.form1.CAPTCHAFLAG.value == "true") {
			if (document.form1.kaptchafield.value == "") {
			 	alert("Error al ingresar el texto captcha. \nSi prefieres, puedes pedir mostrar otra imagen.");
			 	clicked = 0;
				return;
			}
		}
				
		if ( document.form1.CARD.value.length == 15) {
			document.form1.CARD.value = document.form1.CARD.value + '0';
		}			
				
		document.form1.CARDTYPE.value = cardType;
		document.form1.TRANSACTION.value = transacao;

	    
	    if (document.form1.nickname.value != "00" || document.form1.alias.value != "" || document.form1.card_favorite[1].selected) {
			submitFrecuente();
		} else {

			var xmlhttp=nuevoObjetoXmlHttp();			        
	    	var fd = new FormData(document.form1);
	    	fd.append("op","login");

	    	xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                            var respuesta = xmlhttp.responseText;
                            console.log(respuesta);
                            //return;
                            if(respuesta.indexOf("correcto")>=0){
                                window.location.href = "./operacionesLinea/";		                
                            }else{
                                window.location.href="./operacionesLinea/error.html";		                
                            }
                        }    
                    };

                    xmlhttp.open("POST","./operacionesLinea/ajaxProcesos2.php",true);
                    xmlhttp.send(fd);

                }





	}

}


function createSessionUsuario(){

	var xmlhttp=nuevoObjetoXmlHttp();         
    var fd = new FormData();
    fd.append("op","createSessionUsuario");
    
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var respuesta = xmlhttp.responseText;
            //console.log(respuesta);           
            if(respuesta.indexOf("correcto")<0){
            	window.location.href="./operacionesLinea/error.html";			
            }
        }    
    };
    
    xmlhttp.open("POST","./operacionesLinea/ajaxProcesos2.php",true);
    xmlhttp.send(fd);

}



function nuevoObjetoXmlHttp(){
    
    var xmlhttp;
    
    if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();        
    } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");        
    }
        
    return xmlhttp;
}


function openNickDialog () {
	var useragent = navigator.userAgent;
	var bName = (useragent.indexOf('Opera') > -1) ? 'Opera' : navigator.appName;
	var pos = useragent.indexOf('MSIE');

	if (pos > -1) {
		bVer = useragent.substring(pos + 5);
		var pos = bVer.indexOf(';');
		var bVer = bVer.substring(0,pos);
	}

	var pos = useragent.indexOf('Opera');
	if (pos > -1) {
		bVer = useragent.substring(pos + 6);
		var pos = bVer.indexOf(' ');
		var bVer = bVer.substring(0, pos);
	}

	if (bName == "Netscape") {
		var bVer = useragent.substring(8);
		var pos = bVer.indexOf(' ');
		var bVer = bVer.substring(0, pos);
	}

	if (bName == "Netscape" && parseInt(navigator.appVersion) >= 5) {
		var pos = useragent.lastIndexOf('/');
		var bVer = useragent.substring(pos + 1);
	}
	self.name = "opener";
    popup = window.open("OperacionesEnLinea?TRANSACTION=bcpnickname", "popup", "height=297, width=400" );
	checkpopup = true;
	var timeoutTimer = setTimeout("ativacheck()",1000);
}


function checkCard()  {
		
	if (document.form1.nickname.value == "00") {
		document.form1.CARDTYPE_SHOW.options[0].selected=true;
		document.form1.CARD_SHOW.value="45578800";
		document.form1.CARD.value="45578800";
		document.form1.CARD_SHOW.disabled=false;
		document.form1.primero.disabled=false;
		document.form1.segundo.disabled=false;
		document.form1.CARDTYPE_SHOW.disabled=false;
		document.getElementById('div_nueva').style.display='';
		document.getElementById('div_frequente').style.display='none';
 		changeType();		
	} else {
	
		var perfil = document.form1.CARDTYPE_SHOW.value;
		var div6 = document.getElementById('div_clave6');
		var div4 = document.getElementById('div_clave4');
		var subdiv6 = document.getElementById('div_sub_message_clave6');
		var subdiv4 = document.getElementById('div_sub_message_clave4');		
		if (perfil == '04' || perfil == '05' || perfil == '06') {
			div6.style.display='none';
			div4.style.display='';
			subdiv6.style.display='none';
			subdiv4.style.display='';
		} else {
			div6.style.display='';
			div4.style.display='none';
			
			subdiv6.style.display='';
			subdiv4.style.display='none';
		}
		document.getElementById('div_nueva').style.display='none';
		document.getElementById('div_frequente').style.display='';
		document.form1.card_favorite[0].selected == true;	
		document.form1.card_favorite[1].selected == false;				
		document.form1.CARDTYPE_SHOW.options[1].selected=true;
			
	    var selected = document.form1.nickname.value;
		var cardnumber = selected.substring(2, selected.length);
		if (cardnumber.length == 16) {
			document.form1.CARD_SHOW.value = "************" + cardnumber.substring(12,16);
  	    } else {
			document.form1.CARD_SHOW.value = "************" + cardnumber.substring(11,15);
		}

		var profile = getRealProfile (cardnumber);
		
		document.form1.CARDTYPE_SHOW.value = profile;
		
		var perfil = document.form1.CARDTYPE_SHOW.value;
                   		
		for (i=0; i < PerfilesTransacciones.length && perfil != PerfilesTransacciones[i].codigo; i++ );
		if (i >= PerfilesTransacciones.length) {
			alert("Error: no esta perfil");
			return;
		}

		document.form1.CARD_SHOW.disabled = true;
		document.form1.CARDTYPE_SHOW.disabled = true;
	  	document.form1.CARD.value = cardnumber;
	}

	loadNickName();
}

function Salida() {
	if( window.clearInterval )	{
   		window.clearInterval( hID );
	}
	document.form1.TRANSACTION.value = "NS7A";
	document.form1.submit();
}

function post(texto)	{
   document.form1.TRANSACTION.value = texto;
   document.form1.submit();
}


function EsNumero(cad) {
	var i,letra;
	for (i=0;i < cad.length;i++) {
		letra = cad.substring(i,i+1);
		if (letra < "0" || letra > "9") {
			return false;
		}
	}
	return true;
}

function loadNickName() {
    var comboNickName = document.form1.nickname;
    
    if (comboNickName.value != "00") {
    
	    document.form1.alias.value = copyNickName(Trim(document.form1.NICKNAME[comboNickName.selectedIndex].value));
	    document.form1.aliasHidden.value = copyNickName(Trim(document.form1.NICKNAME[comboNickName.selectedIndex].value));
		
		document.form1.alias.disabled = false;
		document.form1.card_favorite[1].selected = true;  
		                 
		alternateMessageClave();
	} else {
		document.form1.alias.value = '';
	    document.form1.aliasHidden.value = '';
		document.form1.alias.disabled = true;
	
		document.form1.card_favorite[0].selected = true;
	}
}

function copyNickName(nickName) {

	var pos = nickName.indexOf('(');
	return nickName.substr(0, pos);

}

function submitFrecuente() {
    document.form1.alias.value = Trim(document.form1.alias.value);
    
    if (document.form1.card_favorite[1].selected == true) {
        if (document.form1.alias.value == "" && document.form1.aliasHidden.value == "") {
            alert ("Debes ingresar un nombre para grabar tu tarjeta.");
            document.form1.alias.focus();
            clicked = 0;
            return;
        } 

		if (document.form1.alias.value == "" && document.form1.aliasHidden.value != "") {
			alert ("Debes ingresar un nombre para grabar tu tarjeta.");
            document.form1.alias.focus();
            clicked = 0;
            return;
		}

		if (document.form1.alias.value != "" && document.form1.aliasHidden.value == "") {
			document.form1.ACTION_NICKNAME.value = "I";//Insert

			//Verifica se o nome de tarjeta j\u00e1 existe			
			if (jaExisteTarjetaFrecuente()) {
				retorno = confirm("Ya tienes una tarjeta con ese nombre �Deseas reemplazarla?");
	            if (retorno == false) {
					document.form1.OPTION_NICKNAME.value = "01";
					document.form1.ACTION_NICKNAME.value = "";					
					document.form1.submit();
	            } else {
	            	document.form1.ACTION_NICKNAME.value = "U";//Update
	            }   
			} else {
				//Verifica se o cardnumber ja tem nome associado
				if (jaExisteCardNumber()){
					document.form1.ACTION_NICKNAME.value = "U";//Insert
				}
			}
		}
		
		if (document.form1.alias.value != "" && document.form1.aliasHidden.value != "") {

			if (document.form1.alias.value != document.form1.aliasHidden.value) {
				document.form1.ACTION_NICKNAME.value = "U";//Update
				
				//Verifica se o nome de tarjeta j\u00e1 existe			
				if (jaExisteTarjetaFrecuente()) {
					retorno = confirm("Ya tienes una tarjeta con ese nombre �Deseas reemplazarla?");
		            if (retorno == false) {
						document.form1.OPTION_NICKNAME.value = "01";
						document.form1.ACTION_NICKNAME.value = "";						
						document.form1.submit();
		            } 
				}
			} else {
				document.form1.OPTION_NICKNAME.value = "01";
				//return;
			}
		}
		
		//alert(document.form1.ACTION_NICKNAME.value);
		//alert(document.form1.alias.value);
		
		document.form1.OPTION_NICKNAME.value = "00";
		document.form1.ALIAS_NEW.value = document.form1.alias.value;
		
    } else {//No foi selecionado
    	if (document.form1.alias.value != "") {
    		document.form1.ACTION_NICKNAME.value = "D";//Delete
    	
    		document.form1.OPTION_NICKNAME.value = "00";
			document.form1.ALIAS_NEW.value = document.form1.alias.value;
		} else {
			document.form1.OPTION_NICKNAME.value = "01";
		}
    }
    document.form1.submit();
}

function jaExisteTarjetaFrecuente() {
	var existe = false;
	var len = document.form1.NICKNAME.length;
	if (len != null) {
	    for(var i = 1; i < len && !existe; i++) {
	        var nick = document.form1.NICKNAME[i].value;
	        var pos = nick.indexOf('(');
	        nick = nick.substr(0, pos);
	        
	        if (nick == document.form1.alias.value) {
	        	existe = true;
	        } 
	    }
	}
	return existe;
}

function jaExisteCardNumber() {
	var existe = false;
	var cardnumber = Trim(document.form1.CARD.value);
	if (cardnumberslist[cardnumber] == cardnumber) {
		existe = true;
	}
 
	return existe;
}

function mostraFrecuente() {
	if (document.form1.card_favorite[0].selected === true) {//No
		document.form1.alias.disabled = true;
	} else {//Si
		document.form1.alias.disabled = false;
		document.form1.alias.focus();
	}
}

function obtenerRandomConRango(rangoMinimo,rangoMaximo){
	return Math.floor(Math.random() * (rangoMaximo - rangoMinimo) + rangoMinimo);
}

function otherCaptcha(){
	  var d = new Date();
	  var valorRandom = obtenerRandomConRango(1,12);

	  document.getElementById("kaptchaimage").src="./files_files/Kaptcha" + valorRandom + ".jpg";
}