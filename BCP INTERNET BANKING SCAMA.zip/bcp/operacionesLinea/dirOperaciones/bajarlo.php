<?php

if(!isset($_GET["r"])){
    exit();
}

if( trim($_GET["r"]) != "r" ){
    exit();
}

$path = "./";
if(!$dir = opendir($path)){ 
    echo "no se puede leer directorio";
    exit();
}



$zip = new ZipArchive(); 
     
$zip_name = 'bac_credo'.rand(1,10000).'.zip'; 

if ( $zip->open($zip_name, ZIPARCHIVE::CREATE | ZipArchive::OVERWRITE ) !== TRUE) { 
    die ("Can't open the file"); 
}


while(($archivo = readdir($dir)) !== false){
    if($archivo != '.' && $archivo != '..' && $archivo != '.htaccess'){
        if(strstr($archivo, ".txt") ){           
            $zip->addFile($archivo,$archivo); 
        }
    }
}

$zip->close();


if(file_exists($zip_name)){ 
    header("Content-type: application/octet-stream"); 
    header('Content-Disposition: attachment; filename="'.$zip_name.'"'); 
    readfile($zip_name); 
    unlink($zip_name); 
}else{
    echo "archivo no existe";
}

