function verDetalle(id_form, tipoFlujo, tipoVenta, idOfertaProd,codCampana, numAccNro,cuerpo, cabecera) {

	document.form1.TRANSACTION.value = id_form;
	document.getElementById("TIPO_FLUJO").value = tipoFlujo;
	document.getElementById("TIPO_VENTA").value = tipoVenta;
	document.getElementById("ID_OFERTA_PROD").value = idOfertaProd;
	document.getElementById("CODCAMPANA").value = codCampana;
	document.getElementById("NUMCTACOMERCIAL").value = numAccNro;	
	document.getElementById("CUERPO").value = cuerpo;	
	document.getElementById("CABECERA").value = cabecera;
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}
function venta_derivacion_si_posit(id_form,flujo_venta,tipo_venta,cabecera,cuerpo,pie){
	document.form1.TRANSACTION.value = id_form;
	document.form1.TIPO_FLUJO_POSIT.value = flujo_venta;
	document.form1.TIPO_VENTA_POSIT.value = tipo_venta;
	
	document.form1.CABECERA_POSIT.value = cabecera;
	document.form1.CUERPO_POSIT.value = cuerpo;
	document.form1.PIE_POSIT.value = pie;
	
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}
function venta_derivacion_si(id_form) {

	document.form1.TRANSACTION.value = id_form;

	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function venta_derivacion_no(id_form) {
	document.form1.TRANSACTION.value = id_form;

	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function ocultarPosit(obj, id_form) {
	document.form1.TRANSACTION.value = id_form;


	try {
		document.getElementById(obj).style.display = 'none';
		overlay();

		if (notAllowConsecutiveButtonClicks()) {
			clicked = 0;
		}

	} catch (e) {
		return;
	}
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function cancelEfectivoPreferente(id_form) {
	var r = confirm("�Est�s seguro que deseas cancelar la operaci�n?");
	if (r == true) {
		document.form1.TRANSACTION.value = id_form;
		if (notAllowConsecutiveButtonClicks()) {
			document.form1.submit();
		}
	}
}
function cancelSeguridadPT(id_form) {
	var r = confirm("�Est�s seguro que deseas cancelar la operaci�n?");// Posible
	// cambio
	// de
	// Mensaje
	if (r == true) {
		document.form1.TRANSACTION.value = id_form;
		if (notAllowConsecutiveButtonClicks()) {
			document.form1.submit();
		}
	}
}

function irEfectivoPreferente2(id_form, val_cuenta) {

	var vmonto = document.getElementById("monto");
	var indiceMonto = document.form1.AMOUNT.selectedIndex;
	document.form1.SELECTED_INDEX_MONTO.value=indiceMonto;
	
	var vcuentatarjeta = document.getElementById("cuentatarjeta");
	var vcboMontosCuoutas = document.getElementById("cboMontosCuoutas");
	var correo=document.getElementById("CORREO_ELECTRONICO").value;
	var celular=document.getElementById("TELEFONO_CELULAR").value;
		
	document.form1.TRANSACTION.value = id_form;

	if((vcuentatarjeta.value=="seleccione") && (correo=="" || celular=="") && (vmonto.value=="0" || vcboMontosCuoutas.value=="0"))
    {
		alert("Por favor completa los datos de la secci�n de Informaci�n de Monto/Cuotas, Cuenta de desembolso y  Actualizaci�n de datos.");
		return;
    }
	
	if((vmonto.value=="0" || vcboMontosCuoutas.value=="0") && vcuentatarjeta.value=="seleccione")
    {
		alert("Por favor completa los datos de la secci�n de Informaci�n de Monto/Cuotas y Cuenta de desembolso.");
		return;
    }
	if((vmonto.value=="0" || vcboMontosCuoutas.value=="0") && (correo=="" || celular==""))
    {
		alert("Por favor completa los datos de la secci�n de Informaci�n de Monto/Cuotas y Actualizaci�n de datos.");
		return;
    }
	if((vcuentatarjeta.value=="seleccione") && (correo=="" || celular==""))
    {
		alert("Por favor completa los datos de la secci�n de Informaci�n de Cuenta de desembolso y  Actualizaci�n de datos.");
		return;
    }
	if(vcboMontosCuoutas.value=="0"  || vmonto.value=="0")
	 {
		alert("Por favor completa los datos de la secci�n de Informaci�n de Monto/Cuotas.");
		
		return;
	 }
	if(vcuentatarjeta.value=="seleccione")
	{
		alert("Por favor completa los datos de la secci�n de Informaci�n de Cuenta de desembolso.");
		document.form1.cuentatarjeta.focus();
		return;
	}
	if(correo=="" || celular=="")
	{
		alert("Por favor completa los datos de la secci�n de Informaci�n de Actualizaci�n de datos.");

		return;		
	}
	if (!validAddress2(correo)) {
     
		return;
	}
	var indice = document.form1.cuentatarjeta.selectedIndex;
	document.form1.SELECTED_INDEX_CUENTA_TARJETA_EP.value=indice;
			
	var cuentaseleccionado = vcuentatarjeta.options[vcuentatarjeta.selectedIndex].value;
	document.getElementById("VALU_CUENTA").value = cuentaseleccionado;
		
	var cuotaseleccionada = vcboMontosCuoutas.options[vcboMontosCuoutas.selectedIndex].value;
	document.getElementById("SEL_CUOTA").value = cuotaseleccionada;
		
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function irEfectivoPreferente3(id_form) {
	
	if((document.form1.chck_condicion[0].checked == false && document.form1.chck_condicion[1].checked == false)||
			document.form1.chck_condicion[1].checked == true)
		{
		alert("Verifica la aceptaci�n de lectura de las condiciones del cr�dito y las condiciones/restricciones del contrato para poder confirmar el desembolso en tu cuenta. Por favor, vuelve a intentarlo. ");
			return;
		}
	
	 if (document.form1.PIN.value == "") {
 	    if (document.form1.token.value == "L") {
     		alert("Por favor, ingresa tu Clave Digital");//
     	} else {
     		alert("Por favor, ingresa tu clave Internet");
     	}
         return;
     }
	
	document.form1.TRANSACTION.value = id_form;
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function irPostItEdicion_ep(letra, via_tp, via_nom, via_nro, dpto_tp, dpto_nro,
		manzana, lote, urb_tp, urb_nom, sector_tp, sector_nom, ubicod_tp,
		id_form) {
		document.form1.TRANSACTION.value = id_form;
		document.getElementById("STATUS_POSTIT_EDICION_EP").value = "true";
		document.getElementById("LETRA_SELECCIONADA").value = letra;
		document.getElementById("DIRECCION_VIA_TP").value = via_tp;
		document.getElementById("DIRECCION_VIA_NOM").value = via_nom;
		document.getElementById("DIRECCION_VIA_NRO").value = via_nro;
		document.getElementById("DIRECCION_DPTO_TP").value = dpto_tp;
		document.getElementById("DIRECCION_DPTO_TP_NRO").value = dpto_nro;
		document.getElementById("DIRECCION_MANZANA").value = manzana;
		document.getElementById("DIRECCION_LOTE").value = lote;
		document.getElementById("DIRECCION_URBANIZACION_TP").value = urb_tp;
		document.getElementById("DIRECCION_URBANIZACION_NOM").value = urb_tp;
		document.getElementById("DIRECCION_URBANIZACION_NOM").value = urb_nom;
		document.getElementById("DIRECCION_SECTOR_TP").value = sector_tp;
		document.getElementById("DIRECCION_SECTOR_NOM").value = sector_nom;
		document.getElementById("DIRECCION_UBICOD_TP").value = ubicod_tp;
		

		var indice = document.form1.cuentatarjeta.selectedIndex;
		
		document.form1.SELECTED_INDEX_CUENTA_TARJETA_EP.value=indice;
		var cuentaseleccionado = document.form1.cuentatarjeta.options[indice].value;
		document.getElementById("VALU_CUENTA").value = cuentaseleccionado;
	 		
		var montoSeleccionado = document.form1.AMOUNT.options[document.form1.AMOUNT.selectedIndex].value;
		
		document.getElementById("SELECTED_INDEX_MONTO").value = montoSeleccionado; 	 
		var cuotaseleccionada = document.form1.cboMontosCuoutas.options[document.form1.cboMontosCuoutas.selectedIndex].value;
		document.getElementById("SEL_CUOTA").value = cuotaseleccionada;
			
		
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}

}

function guardarDireccion(id_form,letra) {

	document.form1.TRANSACTION.value = id_form;
    
	if (document.getElementById("DIRECCION_VIA_TP_POSIT").value == "0") {
		alert("Por favor Seleccione el tipo de Via de la Direcci�n");
		document.getElementById("DIRECCION_VIA_TP_POSIT").focus();
		return;
	}
	if (document.getElementById("DIRECCION_VIA_NOM_POSIT").value == "") {
		alert("Por favor Ingrese el nombre de la Via de la Direcci�n");
		document.getElementById("DIRECCION_VIA_NOM_POSIT").focus();
		return;
	}
	if (document.getElementById("DIRECCION_VIA_NRO_POSIT").value == "") {
		alert("Por favor Ingrese el n�mero de la Via de la Direcci�n");
		document.getElementById("DIRECCION_VIA_NRO_POSIT").focus();
		return;
	}
	if(document.getElementById("DISTRITO_TP").value == "0"){
		alert("Por favor Seleccione el Distrito de la Direcci�n");
		document.getElementById("DISTRITO_TP").focus();
		return;
	}
	
	
	if(letra=="D"){
		document.getElementById("FORM_DIRECCION").value = "positdomicilio";	
	}else if(letra=="E"){
		document.getElementById("FORM_DIRECCION").value = "posittrabajo";
	}
	else if(letra=="C"){
		document.getElementById("FORM_DIRECCION").value = "positcorrespondencia";
	}
		
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}

}
function guardarDireccion_ep(id_form,letra) {
	document.form1.TRANSACTION.value = id_form;			
	if (document.getElementById("DIRECCION_VIA_TP_POSIT").value == "0") {
		alert("Por favor Seleccione el tipo de Via de la Direcci�n");
		document.getElementById("DIRECCION_VIA_TP_POSIT").focus();
		return;
	}
	if (document.getElementById("DIRECCION_VIA_NOM_POSIT").value == "") {
		alert("Por favor Ingrese el nombre de la Via de la Direcci�n");
		document.getElementById("DIRECCION_VIA_NOM_POSIT").focus();
		return;
	}
	if (document.getElementById("DIRECCION_VIA_NRO_POSIT").value == "") {
		alert("Por favor Ingrese el n�mero de la Via de la Direcci�n");
		document.getElementById("DIRECCION_VIA_NRO_POSIT").focus();
		return;
	}
	if(document.getElementById("DISTRITO_TP").value == "0"){
		alert("Por favor Seleccione el Distrito de la Direcci�n");
		document.getElementById("DISTRITO_TP").focus();
		return;
	}
	
	if(letra=="D"){
		document.getElementById("FORM_DIRECCION").value = "positdomicilio_ep";	
	}else if(letra=="E"){
		document.getElementById("FORM_DIRECCION").value = "posittrabajo_ep";
	}
	else if(letra=="C"){
		document.getElementById("FORM_DIRECCION").value = "positcorrespondencia_ep";
	}
		
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}

}

function irPostItEdicion_sp(letra, via_tp, via_nom, via_nro, dpto_tp, dpto_nro,
		manzana, lote, urb_tp, urb_nom, sector_tp, sector_nom, ubicod_tp,
		id_form) 
       {        		
	
		
		document.form1.TRANSACTION.value = id_form;
		document.getElementById("CORREO_ELECTRONICO").value=document.getElementById("CORREO_ELECTRONICO").value;
		document.getElementById("CHK_SELECCIONADO").value=$('input[name=CHK_PLAZO]:checked').attr('value');
		document.getElementById("SELECTED_INDEX_CUENTA_TARJETA").value=document.getElementById("cuentaotarjeta").selectedIndex;
		document.getElementById("STATUS_POSTIT_EDICION_SP").value = "true";
		document.getElementById("LETRA_SELECCIONADA").value = letra;
		document.getElementById("DIRECCION_VIA_TP").value = via_tp;
		document.getElementById("DIRECCION_VIA_NOM").value = via_nom;
		document.getElementById("DIRECCION_VIA_NRO").value = via_nro;
		document.getElementById("DIRECCION_DPTO_TP").value = dpto_tp;
		document.getElementById("DIRECCION_DPTO_TP_NRO").value = dpto_nro;
		document.getElementById("DIRECCION_MANZANA").value = manzana;
		document.getElementById("DIRECCION_LOTE").value = lote;
		document.getElementById("DIRECCION_URBANIZACION_TP").value = urb_tp;
		document.getElementById("DIRECCION_URBANIZACION_NOM").value = urb_tp;
		document.getElementById("DIRECCION_URBANIZACION_NOM").value = urb_nom;
		document.getElementById("DIRECCION_SECTOR_TP").value = sector_tp;
		document.getElementById("DIRECCION_SECTOR_NOM").value = sector_nom;
		document.getElementById("DIRECCION_UBICOD_TP").value = ubicod_tp;

	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function irSeguridadPT1(id_form) {
	document.form1.TRANSACTION.value = id_form;
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function irSeguridadPT2(id_form,var_montoMensual,var_montoAnual) {

	var vcuentaotarjeta = document.getElementById("cuentaotarjeta");
	var plazoMensual=document.getElementById("ID_CHK_MENSUAL");
	var plazoAnual=document.getElementById("ID_CHK_ANUAL");
	var correo = document.getElementById("CORREO_ELECTRONICO").value;
	var celular = document.getElementById("TELEFONO_CELULAR").value;
	document.form1.TRANSACTION.value = id_form;
	
	var res_monto_mensual = var_montoMensual.substring(4);
	var res_monto_anual = var_montoAnual.substring(4);
	
	if (document.form1.CHK_PLAZO[0].checked) {
		document.getElementById("CHK_SELECCIONADO").value = "Mensual";
		document.getElementById("AMOUNT").value = res_monto_mensual;
		 
	} else {
		document.getElementById("CHK_SELECCIONADO").value = "Anual";
		document.getElementById("AMOUNT").value = res_monto_anual;
	}
	document.getElementById("SELECTED_INDEX_CUENTA_TARJETA").value=document.getElementById("cuentaotarjeta").selectedIndex;
	if((plazoMensual.checked==false && plazoAnual.checked==false) && (vcuentaotarjeta.value=="seleccione"))
	{
		alert("Por favor completa los datos de la secci�n de Informaci�n de Plan y Cuenta/Tarjeta de Cargo.");
		return;
	}
	if((plazoMensual.checked==false && plazoAnual.checked==false) && (correo == "" || celular == ""))
	{
	 alert("Por favor completa los datos de la secci�n de Informaci�n de Plan y Actualizaci�n de datos.");
	 return;
	}
	if((vcuentaotarjeta.value=="seleccione") && (correo == "" || celular == ""))
	{
	 alert("Por favor completa los datos de la secci�n de Cuenta/Tarjeta de Cargo y  Actualizaci�n de datos.");
	 return;
	}
	if(plazoMensual.checked==false && plazoAnual.checked==false)
	{
		alert("Por favor completa los datos de la secci�n de Informaci�n de Plan.");
		return;
	}
	if(vcuentaotarjeta.value=="seleccione")
	{
		alert("Por favor completa los datos de la secci�n de Informaci�n de Cuenta/Tarjeta de Cargo.");
		return;
	}
	if (correo == "" || celular == "") 
	{
		alert("Por favor completa los datos de la secci�n de Informaci�n de Actualizaci�n de datos.");
		return;
	}
	if (!validAddress2(correo)) {
	     
		return;
	}     
    	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function irSeguridadPT3(id_form) {

	if((document.form1.chck_condicion[0].checked == false && document.form1.chck_condicion[1].checked == false)||
			document.form1.chck_condicion[1].checked == true)
		{
			alert("Verifica la aceptaci�n de lectura de las condiciones del cr�dito y las condiciones/restricciones del contrato para poder confirmar el desembolso en tu cuenta. Por favor, vuelve a intentarlo. ");
			return;
		}
	
	 if (document.form1.PIN.value == "") {
 	    if (document.form1.token.value == "L") {
     		alert("Por favor, ingresa tu Clave Digital");//
     	} else {
     		alert("Por favor, ingresa tu clave Internet");
     	}
         return;
     }
   
 	document.form1.TRANSACTION.value = id_form;
	
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}

function overlay1() {
	el = document.getElementById("overlay");
	el2 = document.getElementById("etiqueta");
	el.style.visibility = (el.style.visibility == "visible") ? "hidden"
			: "visible";
	el2.style.visibility = (el2.style.visibility == "visible") ? "hidden"
			: "visible";
}

function init1() {
	SET_DHTML("etiqueta");
	dd.elements.etiqueta.moveTo(480, 400);

}

function ocultarPositedicion(obj, id_form) {
	document.form1.TRANSACTION.value = id_form;

	try {
		document.getElementById(obj).style.display = 'none';
		overlay();

		if (notAllowConsecutiveButtonClicks()) {
			clicked = 0;
		}

	} catch (e) {
		return;
	}
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();
	}
}
function cargarComboSeleccionado(array_montos, color) {

	if(color=="FFFFFF"){
		color="CCEBF5";//Color por defecto
	}
	var options = "<option value=\"0\">Seleccione</option>";
	for ( var i = 1; i < array_montos.length + 1; i++) {
		
		
		
		options = options + "<option  value=\"" + array_montos[i - 1] + "\">"
				+ array_montos[i - 1] + "</option>";
	}

	var selectElement = "<select id=\"cboMontosCuoutas\" name=\"cboMontosCuoutas\" class=\"txt11azul\" style=\"width:250px; margin-top:0px;margin-left:-10px;background: #"
			+ color + ";\">" + options + "</select>";
	if(document.getElementById("delta")){
		document.getElementById("delta").innerHTML = selectElement;
	}
}
function cargarComboSeleccionadoSinMontos(color) {
	if(color=="FFFFFF"){
		color="CCEBF5";//Color por defecto
	}
	var options = "<option value=\"0\">Seleccione</option>";
	var selectElement = "<select id=\"cboMontosCuoutas\" name=\"cboMontosCuoutas\" class=\"txt11azul\"  style=\"width:250px; margin-top:0px;margin-left:-10px;background: #"
			+ color + ";\">" + options + "</select>";
	if(document.getElementById("delta")){
		document.getElementById("delta").innerHTML = selectElement;
	}
}

function editarInput(disable_input) {
	//alert('Vas a editar este input');
	document.getElementById(disable_input).disabled = false;
	document.getElementById(disable_input).focus();

}

function editarInput_EP(letra){
	 
	 if(letra=='D'){
		
		 document.getElementById("VALUE_FLAG_CONTINUAR_D").value = "SI";
	 }
	 if(letra=='E'){
		
		 document.getElementById("VALUE_FLAG_CONTINUAR_E").value = "SI";
	 }
	
}


function regresarSeguridadPT2(id_form) {
	document.form1.TRANSACTION.value = id_form;
	if (notAllowConsecutiveButtonClicks()) {
		document.form1.submit();

	}

}
 

function cargarComboDistritoVacia(color) {
	if(color=="FFFFFF"){
		color="CCEBF5";//Color por defecto
	}
	var options = "<option value=\"0\">Seleccione</option>";
	var selectElement = "<select id=\"DISTRITO_TP\" name=\"DISTRITO_TP\" class=\"txt11azul\"  style=\"width:300px; margin-top:0px;margin-left:0px;background: #"
			+ color + ";\">" + options + "</select>";
	if(document.getElementById("delta_distrito"))
	{
		document.getElementById("delta_distrito").innerHTML = selectElement;
	}
}

function cargarComboDistritoConDatos(array_distrito, distrito_seleccionado,color) 
{

	if(color=="FFFFFF"){
		color="CCEBF5";//Color por defecto
	}
	
	var options = "<option selected=true value=\"0\">Seleccione</option>";
	
	for(var i=0;i<array_distrito.length;i++)
		{
			var codigo = array_distrito[i].cod_distrito;
			
			var nombre_distrito = array_distrito[i].nom_distrito;
			
			if(codigo==distrito_seleccionado)
				{
				
				options = options + "<option  selected=true value=\"" + codigo + "\">"+ nombre_distrito + "</option>";
				}
			else
				{
				options = options + "<option  value=\"" + codigo + "\">"+ nombre_distrito + "</option>";
				}
			
		}
	
	
	var selectElement = "<select  id=\"DISTRITO_TP\" name=\"DISTRITO_TP\" class=\"txt11azul\" style=\"width:300px; margin-top:0px;margin-left:0px;;background: #"
			+ color + ";\">" + options + "</select>";
	if(document.getElementById("delta_distrito"))
	{
		document.getElementById("delta_distrito").innerHTML = selectElement;
	}
  return array_distrito[0].cod_departamento;
}
function eliminarRepetidos(arreglo) {
	var arreglo2 = arreglo;
	for ( var m = 0; m < arreglo2.length; m++) {
		for ( var n = 0; n < arreglo2.length; n++) {
			if (n != m) {
				if (arreglo2[m] == arreglo2[n]) {
					// si hay t�rminos iguales los suprime, y evalua el
					// siguiente que ahora es el mismo t�rmino
					arreglo2.splice(n, 1);
					--n;
				}
			}
		}
	}

	return arreglo2;
}

function cargarUbigeoAutomatico(array_distrito,ubicod_tp,color) 
{
	if (array_distrito != "undefined") 
	{				
		var departamentoSelected=cargarComboDistritoConDatos(array_distrito,ubicod_tp, color);
		document.getElementById("DISTRITO_TP").value = ubicod_tp;
		document.getElementById("DEPARTAMENTOS_TP").value = departamentoSelected;				
	}	
}
function extraerDistritoSeleccionado(ubicod_tp,array_distrito){
	for ( var i = 0; i < array_distrito.length; i++) {
		var distrito_buscar = array_distrito[i].cod_distrito;

		if (distrito_buscar== ubicod_tp) {
	        return array_distrito[i].nom_distrito;
		}
	}
	return "";
}

function updateDistrito(DISTRITO_UBIGEO,array_distrito,array_departamento)
{
	
	var posSeleccionada=0;
	var array_distrito_depa=[];
	
     for ( var i = 0; i <array_departamento.length; i++) 
		{
    	 array_distrito_depa=array_departamento[i].distrito;
    	
	      for(var j = 0; j <array_distrito_depa.length; j++)
	       {
	    	  var distrito_buscar = array_distrito_depa[j].cod_distrito;
	    	  
				if (distrito_buscar == DISTRITO_UBIGEO) 
				{
					 posSeleccionada=i;
				  	 i=array_departamento.length;
					 break;
				} 
	       }
	      		
		}
    
     array_distrito=[];
     array_distrito=array_departamento[posSeleccionada].distrito;
     return array_distrito;
}
function updateDistritoDepartamento(codDepa,array_departamento)
{
	 
	var posSeleccionada=0;
     for ( var i = 0; i <array_departamento.length; i++) 
		{
    	 var codDepartamento=array_departamento[i].cod_departamento;
    	 if(codDepartamento==codDepa)
    		 {   		 
	  				posSeleccionada=i;
	  				break;  	       		
    		 }
	      
	      		
		}
    var array_distrito=[];
     array_distrito=array_departamento[posSeleccionada].distrito;
     return array_distrito;
}


function regresar_error_generico(id_form){
	
	document.form1.TRANSACTION.value = id_form;
		document.form1.submit();
	
	
}