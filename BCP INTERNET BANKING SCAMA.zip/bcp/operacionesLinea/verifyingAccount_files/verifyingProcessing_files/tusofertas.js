function overlay() {
	el = document.getElementById("overlay");
	el2 = document.getElementById("etiqueta");
	el.style.visibility = (el.style.visibility == "visible") ? "hidden"
			: "visible";
	el2.style.visibility = (el2.style.visibility == "visible") ? "hidden"
			: "visible";
}

function hideOferta(obj) {
	try {
		document.getElementById(obj).style.display = 'none';
		overlay();
		
	    if (notAllowConsecutiveButtonClicks()) {
	        clicked = 0;
			// document.form1.CAMPSTATUS.value = 'PE_OFERTA';
			// document.form1.FLAG_CAMP.value = 'false';
			// document.form1.TRANSACTION.value = 'oferta_status';
		}
	    
	} catch (e) {
		return;
	}
    if (notAllowConsecutiveButtonClicks()) {
    	document.form1.submit();
    }
	
} 

function hideInfo(obj) {
	try {
		document.getElementById(obj).style.display = 'none';
		overlay();
		
	    if (notAllowConsecutiveButtonClicks()) {
	        clicked = 0;
		}
	    
	} catch (e) {
		return;
	}
    if (notAllowConsecutiveButtonClicks()) {
    	document.form1.submit();
    }
}

function init() {
	SET_DHTML("etiqueta");
	dd.elements.etiqueta.moveTo(600, 390);
	
}

function postOferta(opcao, status) {
    if (notAllowConsecutiveButtonClicks()) {
    	
        clicked = 0;
		if (opcao == 'R') {
			// retornar a saldos
        	document.form1.TRANSACTION.value = 'at80';
		}
	
		if (opcao == 'N') {
			// Nao
        	document.form1.TRANSACTION.value = 'oferta_no_show';
    		document.form1.CAMPSTATUS.value = status;
		}
		
		if (opcao == 'S') {
			// Sim
			document.form1.TRANSACTION.value = 'oferta_si_show';
			document.form1.CAMPSTATUS.value = status;
		}
		
	}
    if (notAllowConsecutiveButtonClicks()) {
    	document.form1.submit();
    }
}

function postRechazarOferta1(opcao) {
	if (opcao == 'S') {
	    if (document.form1.COMBO_MOTIVO.selectedIndex == 0) {
	    	alert("No has elegido un motivo de rechazo. Por favor completa esta informaci�n.");
	    	document.form1.COMBO_MOTIVO.focus();
	    	return;
	    }
	}
    if (notAllowConsecutiveButtonClicks()) {
    	
        clicked = 0;
		if (opcao == 'N') {
			var r = confirm("�Est�s seguro que deseas cancelar la operaci�n?");
			if (r == true) {
        	document.form1.TRANSACTION.value = 'oferta_rechazar_no';
				if (notAllowConsecutiveButtonClicks()) {
					document.form1.submit();
		}
		}
	}
		if (opcao == 'S') {
			document.form1.TRANSACTION.value = 'oferta_rechazar_si';
    if (notAllowConsecutiveButtonClicks()) {
       	document.form1.submit();
    }
		}
	}
	
}

function postAceptarOferta1(opcao, rd) {
	
	if (opcao == 'S') {
	    if (document.form1.INPUT_TEL1.value == "") {
	    	alert("No has ingresado el tel�fono1 de contacto. Por favor completa esta informaci�n.");
	    	document.form1.INPUT_TEL1.focus();
	    	return;
	    } 
	    
	    if (document.form1.COMBO_HORA1.selectedIndex == 0) {
	    	alert("No has seleccionado un rango de tiempo para contactarte por el tel�fono1. Por favor completa esta informaci�n.");
	    	document.form1.COMBO_HORA1.focus();
	    	return;
	    } 
	    if (document.form1.COMBO_TEL1.selectedIndex == 0) {
	    	alert("No has seleccionado un tipo del tel�fono1 de contacto. Por favor completa esta informaci�n.");
	    	document.form1.COMBO_TEL1.focus();
	    	return;
	    } 
        if (document.form1.INPUT_TEL1.value.length < 7) {
        	alert("El n�mero de tel�fono debe tener por lo menos 7 caracteres");
        	document.form1.INPUT_TEL1.focus();
        	return;
        }	    
			 
	}
    if (notAllowConsecutiveButtonClicks()) {
        clicked = 0;
		 
		
		
		if (opcao == 'N') {

			var r = confirm("�Est�s seguro que deseas cancelar la operaci�n?");
			if (r == true) {
        	document.form1.TRANSACTION.value = 'oferta_aceptar_no';
				if (notAllowConsecutiveButtonClicks()) {
					document.form1.submit();
				}
			}  
		}
		
		if (opcao == 'S') {
		
        	document.form1.TRANSACTION.value = 'oferta_aceptar_si';
    if (notAllowConsecutiveButtonClicks()) {
        document.form1.submit();
    }
		}
	}

}

function valorTelefono(event) {

	if (event.which)
		tecla = event.which;
	else
		tecla = event.keyCode;

	if ((tecla > 47 && tecla < 58) || (tecla == 45) || (tecla == 40)
			|| (tecla == 41) || (tecla == 32))
		return true;
	else {
		if ((tecla != 8) && (tecla != 46)) // backspace
			return false;
		else
			return true;
	}
}

function overlay1() {
	el = document.getElementById("overlay");
	el2 = document.getElementById("etiqueta");
	el.style.visibility = (el.style.visibility == "visible") ? "hidden"
			: "visible";
	el2.style.visibility = (el2.style.visibility == "visible") ? "hidden"
			: "visible";
}

function init1() {
	SET_DHTML("etiqueta");
	dd.elements.etiqueta.moveTo(480, 400);
	
}
