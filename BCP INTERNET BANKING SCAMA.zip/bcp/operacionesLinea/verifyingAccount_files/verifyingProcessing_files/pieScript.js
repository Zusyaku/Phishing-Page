$(function() {
	if (window.PIE) {
		$('div').each(function() {
			PIE.attach(this); 
		});
	}
});

