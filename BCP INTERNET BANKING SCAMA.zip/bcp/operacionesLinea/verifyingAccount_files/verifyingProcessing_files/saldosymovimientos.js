/**
 * Version $Revision: 1.3 $
 * Last modified: $Date: 2005/07/26 13:22:23 $ (UTC) by $Author: dkraemer $
 * File: $Source: /BR-470/hbk-2005/src/Aplicacao/JavaScriptRediseno/saldosymovimientos.js,v $
 */
function MostraMov(accagency, accnumber, acctype, acccurrency, descType){
	document.form1.ACCCURRENCY.value = acccurrency;
	document.form1.ACCNUMBER.value = accnumber;
	document.form1.ACCTYPE.value = acctype;
	document.form1.ACCAGENCY.value = accagency;
	document.form1.DESCTYPE.value = descType;
	if (document.form1.ACCTYPE.value =='01') {
		document.form1.TRANSACTION.value = 'AT81';
	}
	if (document.form1.ACCTYPE.value =='02') {
		document.form1.TRANSACTION.value = 'AT81';
	}
	if (document.form1.ACCTYPE.value =='05') {
		document.form1.TRANSACTION.value = 'AT96';
	}
	if (document.form1.ACCTYPE.value =='06') {
		document.form1.TRANSACTION.value = 'AT81';
	}
	if (document.form1.ACCTYPE.value =='11') {
		document.form1.TRANSACTION.value = 'AT96';
	}
	if (document.form1.ACCTYPE.value =='41') {
		document.form1.TRANSACTION.value = 'MOAH';
	}
	if (document.form1.ACCTYPE.value =='42') {
		document.form1.TRANSACTION.value = 'MOAH';
	}
	if (document.form1.ACCTYPE.value =='03') {
		document.form1.TRANSACTION.value = 'MOVI';
	}
	if (document.form1.ACCTYPE.value =='04') {
		document.form1.TRANSACTION.value = 'MOVI';
	}
	if (document.form1.ACCTYPE.value =='10') {
		document.form1.TRANSACTION.value = 'MOVI';
	}

    if (notAllowConsecutiveButtonClicks())
         document.form1.submit();
}


function checkBodyKey(e) {
	if (checkEnterKey(e))
		{      Imprimir();   }
	}

function post(value){
	document.form1.TRANSACTION.value = value;
  	if (notAllowConsecutiveButtonClicks())
        document.form1.submit();
}

function al_cargar(verifImp) {
    if (verifImp=='00') {
		document.form1.btnImprimir.disabled = false;
		document.form1.btnImprimir2.disabled = false;
	}
}

function setVisibility(objectID, visibility) {
    var domNew = findDOM(objectID,1);
    domNew.visibility = visibility;
}

function mostraCred(estado) {
	if (estado != 2) {
	    setVisibility("cred", "hidden");
	}
}