function postCheckAccountCode() {
	if (notAllowConsecutiveButtonClicks()) {
		
		var listAccount = "";
		
		if (document.form1.totalCTAS.value != '0') {
			if (document.form1.accountNumberFullText.value) {
				listAccount = window.document.form1.accountNumberFullText.value + ";";
				//alert(listAccount);
			} else {
				var listAccount = "";
				for (i = 0;i < window.document.form1.accountNumberFullText.length; i++) {
					listAccount += window.document.form1.accountNumberFullText[i].value + ";";
					//alert(listAccount);
				}
			}
		}
		
		document.form1.LIST_ACCOUNT.value = "";
		document.form1.TRANSACTION.value = "";
	
		document.form1.LIST_ACCOUNT.value = listAccount;
		document.form1.TRANSACTION.value = 'consultacodigointerbancario1';
		document.form1.submit();
	}
}

function postCheckAccountCodeDolares() {
	
	
	if (notAllowConsecutiveButtonClicks()) {
	
	var listAccount = "";
	
		if (document.form1.accountDolaresNumberFullText.value) {
			listAccount = window.document.form1.accountDolaresNumberFullText.value + ";";
			//alert(listAccount);
		} else {
			var listAccount = "";
			for (i = 0;i < window.document.form1.accountDolaresNumberFullText.length; i++) {
				listAccount += window.document.form1.accountDolaresNumberFullText[i].value + ";";
				//alert(listAccount);
			}
		}
		document.form1.LIST_ACCOUNT.value = "";
		document.form1.TRANSACTION.value = "";
	
		document.form1.LIST_ACCOUNT.value = listAccount;
		document.form1.TRANSACTION.value = 'consultacodigointerbancario1';
		document.form1.submit();
	}
}