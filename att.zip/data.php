<?php

$data = "gbluck@yandex.com"; // Your Email Here :)

?>

