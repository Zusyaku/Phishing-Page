<footer style="display: block;">
<div id="gn-zone5">
<div id="z5-footer-content" class="container" data-link-position="Footer" data-event-action="linkClick" data-event-code="Link_Click">
<div class="row">
<div id="z5-footer-links" class="span12">
<div id="z5-ftr-col1" class="span12-sm span3 span4-md">
<div><div class="parbase linkContainer section">
<ul class="no-bullet ">
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<li class="hide-sm hide-xsm">
<a href="#">
<i class="icon-location-pinpoint" aria-hidden="true"></i>
Find a store
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i class="icon-location-pinpoint" aria-hidden="true"></i>
Find a store
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
<i class="icon-misc-datetime" aria-hidden="true"></i>
Make a store appointment
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i class="icon-misc-datetime" aria-hidden="true"></i>
Make a store appointment
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
<i class="icon-location-unitedstates" aria-hidden="true"></i>
Coverage maps
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i class="icon-location-unitedstates" aria-hidden="true"></i>
Coverage maps
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
<i class="icon-location-unitedstates" aria-hidden="true"></i>
Learn about 5G
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i class="icon-location-unitedstates" aria-hidden="true"></i>
Learn about 5G
</a>
</li>
<!-- Language link Motion Point Integration -->
</ul>
</div>
</div>
</div>
<div id="z5-ftr-col2" class="span12-sm span6 span4-md">
<div><div class="parbase linkContainer section">
<ul class="no-bullet ">
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
About AT&amp;T
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i aria-hidden="true"></i>
About AT&amp;T
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
Contact us
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i aria-hidden="true"></i>
Contact us
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
Feedback
<i class="icon-datanetwork-link" aria-hidden="true" aria-label="External Link"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Cpath d='M20.5 17c-.5.6-1.4.7-2 .2-1.1-.9-2.6-.8-3.6.2l-5.8 5.8c-.5.5-.8 1.2-.8 1.9s.3 1.4.8 1.9c1.1 1.1 2.8 1.1 3.8 0l3.2-3.2c.5-.5 1.5-.5 2.1 0s.5 1.5 0 2.1L15 29c-1.1 1.1-2.6 1.7-4 1.7s-2.8-.5-4-1.7c-1.1-1.1-1.7-2.5-1.7-4S6 22.1 7 21l5.6-5.7c2-2 5.3-2.2 7.6-.4.7.6.8 1.5.3 2.1zM29 7c-2.2-2.2-5.8-2.2-8 0l-3.1 3.1c-.5.6-.5 1.5 0 2 .4.4 1 .5 1.4.4.1 0 .1 0 .2-.1 0 0 .1 0 .1-.1 0 0 .1 0 .1-.1.1-.1.2-.1.2-.2l3.3-2.9C24.3 8 26 8 26.9 9.1c1.1 1.1 1.1 2.8 0 3.8l-5.7 5.7c-1 1-2.6 1.1-3.6.2-.6-.5-1.6-.4-2 .2-.5.6-.4 1.6.2 2 1.1.9 2.3 1.3 3.6 1.3 1.4 0 2.9-.5 4-1.6l5.7-5.7c2.1-2.3 2.1-5.8-.1-8z'/%3E%3C/svg%3E"></i>
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i aria-hidden="true"></i>
Feedback
<i class="icon-datanetwork-link" aria-hidden="true" aria-label="External Link"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Cpath d='M20.5 17c-.5.6-1.4.7-2 .2-1.1-.9-2.6-.8-3.6.2l-5.8 5.8c-.5.5-.8 1.2-.8 1.9s.3 1.4.8 1.9c1.1 1.1 2.8 1.1 3.8 0l3.2-3.2c.5-.5 1.5-.5 2.1 0s.5 1.5 0 2.1L15 29c-1.1 1.1-2.6 1.7-4 1.7s-2.8-.5-4-1.7c-1.1-1.1-1.7-2.5-1.7-4S6 22.1 7 21l5.6-5.7c2-2 5.3-2.2 7.6-.4.7.6.8 1.5.3 2.1zM29 7c-2.2-2.2-5.8-2.2-8 0l-3.1 3.1c-.5.6-.5 1.5 0 2 .4.4 1 .5 1.4.4.1 0 .1 0 .2-.1 0 0 .1 0 .1-.1 0 0 .1 0 .1-.1.1-.1.2-.1.2-.2l3.3-2.9C24.3 8 26 8 26.9 9.1c1.1 1.1 1.1 2.8 0 3.8l-5.7 5.7c-1 1-2.6 1.1-3.6.2-.6-.5-1.6-.4-2 .2-.5.6-.4 1.6.2 2 1.1.9 2.3 1.3 3.6 1.3 1.4 0 2.9-.5 4-1.6l5.7-5.7c2.1-2.3 2.1-5.8-.1-8z'/%3E%3C/svg%3E"></i>
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<!-- Mobile - No language link -->
<!-- Language link Motion Point Integration -->
<li>
<a class="langLink" id="ge5p_z1-change-language" href="javascript:void(0)" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="{'events.linkName':'Ver en español','events.linkPosition':'Footer', 'events.linkDestinationUrl':'javascript:void(0)'}" mporgnav="" data-lang="es" data-href="javascript:void(0)">Ver en español</a> 
</li>
</ul>
</div>
<div class="parbase linkContainer section">
</div>
</div>
</div><div id="z5-ftr-col3" class="span12-sm span3 span4-md">
<div><div class="parbase linkContainer section">
<ul class="ftr-social-links ">
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
<i class="icon-social-twitterL" aria-hidden="true">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" style="width: 30px;height: 30px;"><style>.st0{fill:#1d2329}</style><g><path class="st0" d="M15 0C6.7 0 0 6.7 0 15s6.7 15 15 15 15-6.7 15-15c-.1-8.3-6.8-15-15-15zm0 29C7.3 29 1 22.7 1 15S7.3 1 15 1s14 6.3 14 14-6.3 14-14 14z"></path><path class="st0" d="M22.3 9.8c-.6.4-1.2.6-1.9.7-1.1-1.1-2.7-1.2-4.1-.3-.7.5-1.2 1.4-1.2 2.3 0 .2 0 .4.1.6-2.3-.1-4.6-1.3-6.1-3.1-.3.5-.4 1-.4 1.6 0 1 .5 1.9 1.3 2.4-.5 0-.9-.2-1.3-.4 0 1.4 1 2.6 2.3 2.9-.3 0-.5.1-.8.1-.2 0-.4 0-.5-.1.4 1.2 1.5 2 2.8 2-1 .8-2.3 1.3-3.8 1.3h-.4c1.3.8 2.9 1.3 4.6 1.3 4.7 0 8.4-3.8 8.4-8.3v-.5c.6-.4 1.1-.9 1.4-1.5-.5.2-1.1.4-1.7.4.7-.1 1.1-.7 1.3-1.4z"></path></g></svg>
</i>
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i class="icon-social-twitterL" aria-hidden="true">
<svg height="30" width="30"><path fill="#1d2329" d="M15 0C6.7 0 0 6.7 0 15s6.7 15 15 15 15-6.7 15-15c-.1-8.3-6.8-15-15-15zm0 29C7.3 29 1 22.7 1 15S7.3 1 15 1s14 6.3 14 14-6.3 14-14 14z M22.3 9.8c-.6.4-1.2.6-1.9.7-1.1-1.1-2.7-1.2-4.1-.3-.7.5-1.2 1.4-1.2 2.3 0 .2 0 .4.1.6-2.3-.1-4.6-1.3-6.1-3.1-.3.5-.4 1-.4 1.6 0 1 .5 1.9 1.3 2.4-.5 0-.9-.2-1.3-.4 0 1.4 1 2.6 2.3 2.9-.3 0-.5.1-.8.1-.2 0-.4 0-.5-.1.4 1.2 1.5 2 2.8 2-1 .8-2.3 1.3-3.8 1.3h-.4c1.3.8 2.9 1.3 4.6 1.3 4.7 0 8.4-3.8 8.4-8.3v-.5c.6-.4 1.1-.9 1.4-1.5-.5.2-1.1.4-1.7.4.7-.1 1.1-.7 1.3-1.4z"></path></svg>
</i>
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
<i class="icon-social-facebookL" aria-hidden="true">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" style="width: 30px;height: 30px;"><path d="M15 0C6.7 0 0 6.7 0 15s6.7 15 15 15 15-6.7 15-15c-.1-8.3-6.8-15-15-15zm0 29C7.3 29 1 22.7 1 15S7.2.9 15 .9s14 6.3 14 14C29 22.7 22.7 29 15 29z"></path><path d="M15.9 10.9c0-.6.3-.7.6-.7h1.6V7.8h-2.2c-1.6-.1-2.9 1.1-3 2.7v2h-1.5V15h1.5v7.2h3V15h2l.2-2.5h-2.2v-1.6z"></path></svg>
</i>
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i class="icon-social-facebookL" aria-hidden="true">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" style="width: 30px;height: 30px;"><path d="M15 0C6.7 0 0 6.7 0 15s6.7 15 15 15 15-6.7 15-15c-.1-8.3-6.8-15-15-15zm0 29C7.3 29 1 22.7 1 15S7.2.9 15 .9s14 6.3 14 14C29 22.7 22.7 29 15 29z"></path><path d="M15.9 10.9c0-.6.3-.7.6-.7h1.6V7.8h-2.2c-1.6-.1-2.9 1.1-3 2.7v2h-1.5V15h1.5v7.2h3V15h2l.2-2.5h-2.2v-1.6z"></path></svg>
</i>
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
<i class="icon-social-instagramL" aria-hidden="true">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" style="width: 30px;height: 30px;"><path d="M15 0C6.7 0 0 6.7 0 15s6.7 15 15 15 15-6.7 15-15c-.1-8.3-6.8-15-15-15zm0 29C7.3 29 1 22.7 1 15S7.2.9 15 .9s14 6.3 14 14C29 22.7 22.7 29 15 29zm0-19.8h2.8c.4 0 .9.1 1.3.2.6.2 1.1.7 1.3 1.3.2.4.2.9.2 1.3v5.6c0 .4-.1.9-.2 1.3-.2.6-.7 1.1-1.3 1.3-.4.2-.9.2-1.3.2h-5.6c-.4 0-.9-.1-1.3-.2-.6-.2-1.1-.7-1.3-1.3-.2-.4-.2-.9-.2-1.3v-2.8V12c0-.4.1-.9.2-1.3.2-.6.7-1.1 1.3-1.3.4-.2.9-.2 1.3-.2H15m0-1.3h-2.9c-.6 0-1.2.1-1.7.3-.9.4-1.7 1.1-2.1 2.1-.1.6-.3 1.2-.3 1.8v5.8c0 .6.1 1.2.3 1.7.4.9 1.1 1.7 2.1 2.1.5.2 1.1.3 1.7.3h5.8c.6 0 1.2-.1 1.7-.3.9-.4 1.7-1.1 2.1-2.1.2-.5.3-1.1.3-1.7V15v-2.9c0-.6-.1-1.2-.3-1.7-.4-.9-1.1-1.7-2.1-2.1-.4-.2-1.1-.3-1.7-.3-.7-.1-1-.1-2.9-.1zm0 3.5c-2 0-3.6 1.6-3.6 3.6s1.6 3.6 3.6 3.6 3.6-1.6 3.6-3.6c0-1.9-1.6-3.6-3.6-3.6zm0 6c-1.3 0-2.3-1-2.3-2.3s1-2.3 2.3-2.3 2.3 1 2.3 2.3c.1 1.2-1 2.3-2.3 2.3zm4.7-6.2c0 .5-.4.8-.8.8-.5 0-.8-.4-.8-.8 0-.5.4-.8.8-.8s.8.3.8.8z"></path></svg>
</i>
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i class="icon-social-instagramL" aria-hidden="true">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" style="width: 30px;height: 30px;"><path d="M15 0C6.7 0 0 6.7 0 15s6.7 15 15 15 15-6.7 15-15c-.1-8.3-6.8-15-15-15zm0 29C7.3 29 1 22.7 1 15S7.2.9 15 .9s14 6.3 14 14C29 22.7 22.7 29 15 29zm0-19.8h2.8c.4 0 .9.1 1.3.2.6.2 1.1.7 1.3 1.3.2.4.2.9.2 1.3v5.6c0 .4-.1.9-.2 1.3-.2.6-.7 1.1-1.3 1.3-.4.2-.9.2-1.3.2h-5.6c-.4 0-.9-.1-1.3-.2-.6-.2-1.1-.7-1.3-1.3-.2-.4-.2-.9-.2-1.3v-2.8V12c0-.4.1-.9.2-1.3.2-.6.7-1.1 1.3-1.3.4-.2.9-.2 1.3-.2H15m0-1.3h-2.9c-.6 0-1.2.1-1.7.3-.9.4-1.7 1.1-2.1 2.1-.1.6-.3 1.2-.3 1.8v5.8c0 .6.1 1.2.3 1.7.4.9 1.1 1.7 2.1 2.1.5.2 1.1.3 1.7.3h5.8c.6 0 1.2-.1 1.7-.3.9-.4 1.7-1.1 2.1-2.1.2-.5.3-1.1.3-1.7V15v-2.9c0-.6-.1-1.2-.3-1.7-.4-.9-1.1-1.7-2.1-2.1-.4-.2-1.1-.3-1.7-.3-.7-.1-1-.1-2.9-.1zm0 3.5c-2 0-3.6 1.6-3.6 3.6s1.6 3.6 3.6 3.6 3.6-1.6 3.6-3.6c0-1.9-1.6-3.6-3.6-3.6zm0 6c-1.3 0-2.3-1-2.3-2.3s1-2.3 2.3-2.3 2.3 1 2.3 2.3c.1 1.2-1 2.3-2.3 2.3zm4.7-6.2c0 .5-.4.8-.8.8-.5 0-.8-.4-.8-.8 0-.5.4-.8.8-.8s.8.3.8.8z"></path></svg>
</i>
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
<i class="icon-social-linkedinL" aria-hidden="true">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" style="width: 30px;height: 30px;"><path d="M15 0C6.7 0 0 6.7 0 15s6.7 15 15 15 15-6.7 15-15c-.1-8.3-6.8-15-15-15zm0 29C7.3 29 1 22.7 1 15S7.2.9 15 .9s14 6.3 14 14C29 22.7 22.7 29 15 29z"></path><path d="M9 11.8h3v8.8H9v-8.8zm1.4-4.3c-.8-.1-1.5.5-1.5 1.3V9c-.1.8.6 1.5 1.4 1.6h.2c.8.1 1.5-.6 1.6-1.4V9c.1-.8-.5-1.5-1.3-1.6-.2.1-.3.1-.4.1zm8.6 4.1c-1.1 0-2.1.5-2.6 1.4v-1.2h-2.9v8.8h2.9v-4.9c0-.2 0-.4.1-.7.2-.7.9-1.1 1.6-1.1 1 0 1.4.7 1.4 2v4.8h2.8v-5.1c.1-2.8-1.3-4-3.3-4z"></path></svg>
</i>
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i class="icon-social-linkedinL" aria-hidden="true">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" style="width: 30px;height: 30px;"><path d="M15 0C6.7 0 0 6.7 0 15s6.7 15 15 15 15-6.7 15-15c-.1-8.3-6.8-15-15-15zm0 29C7.3 29 1 22.7 1 15S7.2.9 15 .9s14 6.3 14 14C29 22.7 22.7 29 15 29z"></path><path d="M9 11.8h3v8.8H9v-8.8zm1.4-4.3c-.8-.1-1.5.5-1.5 1.3V9c-.1.8.6 1.5 1.4 1.6h.2c.8.1 1.5-.6 1.6-1.4V9c.1-.8-.5-1.5-1.3-1.6-.2.1-.3.1-.4.1zm8.6 4.1c-1.1 0-2.1.5-2.6 1.4v-1.2h-2.9v8.8h2.9v-4.9c0-.2 0-.4.1-.7.2-.7.9-1.1 1.6-1.1 1 0 1.4.7 1.4 2v4.8h2.8v-5.1c.1-2.8-1.3-4-3.3-4z"></path></svg>
</i>
</a>
</li>
<!-- Language link Motion Point Integration -->
</ul>
</div>
<div class="parbase linkContainer section">
<ul class="no-bullet ">
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
<i class="icon-bubble-speech" aria-hidden="true"></i>
TechBuzz blog
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i class="icon-bubble-speech" aria-hidden="true"></i>
TechBuzz blog
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
<i class="icon-bubble-forums" aria-hidden="true"></i>
Community forums
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i class="icon-bubble-forums" aria-hidden="true"></i>
Community forums
</a>
</li>
<!-- Language link Motion Point Integration -->
</ul>
</div>
<div class="parbase linkContainer section">
</div>
</div>           
</div>

<div class="clearfix"></div>
</div>
</div>
<div id="z5-footer-legal" class="row">
<div class="span12">
<div><div class="parbase linkContainer section">
<ul class="ftr-legal-links clear-fix">
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
Legal policy center
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i aria-hidden="true"></i>
Legal policy center
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
Your privacy center
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i aria-hidden="true"></i>
Your privacy center
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
Terms of use
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i aria-hidden="true"></i>
Terms of use
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
Broadband details
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i aria-hidden="true"></i>
Broadband details
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
Advertising choices
<i class="icon-datanetwork-link" aria-hidden="true" aria-label="External Link"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Cpath d='M20.5 17c-.5.6-1.4.7-2 .2-1.1-.9-2.6-.8-3.6.2l-5.8 5.8c-.5.5-.8 1.2-.8 1.9s.3 1.4.8 1.9c1.1 1.1 2.8 1.1 3.8 0l3.2-3.2c.5-.5 1.5-.5 2.1 0s.5 1.5 0 2.1L15 29c-1.1 1.1-2.6 1.7-4 1.7s-2.8-.5-4-1.7c-1.1-1.1-1.7-2.5-1.7-4S6 22.1 7 21l5.6-5.7c2-2 5.3-2.2 7.6-.4.7.6.8 1.5.3 2.1zM29 7c-2.2-2.2-5.8-2.2-8 0l-3.1 3.1c-.5.6-.5 1.5 0 2 .4.4 1 .5 1.4.4.1 0 .1 0 .2-.1 0 0 .1 0 .1-.1 0 0 .1 0 .1-.1.1-.1.2-.1.2-.2l3.3-2.9C24.3 8 26 8 26.9 9.1c1.1 1.1 1.1 2.8 0 3.8l-5.7 5.7c-1 1-2.6 1.1-3.6.2-.6-.5-1.6-.4-2 .2-.5.6-.4 1.6.2 2 1.1.9 2.3 1.3 3.6 1.3 1.4 0 2.9-.5 4-1.6l5.7-5.7c2.1-2.3 2.1-5.8-.1-8z'/%3E%3C/svg%3E"></i>
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i aria-hidden="true"></i>
Advertising choices
<i class="icon-datanetwork-link" aria-hidden="true" aria-label="External Link"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Cpath d='M20.5 17c-.5.6-1.4.7-2 .2-1.1-.9-2.6-.8-3.6.2l-5.8 5.8c-.5.5-.8 1.2-.8 1.9s.3 1.4.8 1.9c1.1 1.1 2.8 1.1 3.8 0l3.2-3.2c.5-.5 1.5-.5 2.1 0s.5 1.5 0 2.1L15 29c-1.1 1.1-2.6 1.7-4 1.7s-2.8-.5-4-1.7c-1.1-1.1-1.7-2.5-1.7-4S6 22.1 7 21l5.6-5.7c2-2 5.3-2.2 7.6-.4.7.6.8 1.5.3 2.1zM29 7c-2.2-2.2-5.8-2.2-8 0l-3.1 3.1c-.5.6-.5 1.5 0 2 .4.4 1 .5 1.4.4.1 0 .1 0 .2-.1 0 0 .1 0 .1-.1 0 0 .1 0 .1-.1.1-.1.2-.1.2-.2l3.3-2.9C24.3 8 26 8 26.9 9.1c1.1 1.1 1.1 2.8 0 3.8l-5.7 5.7c-1 1-2.6 1.1-3.6.2-.6-.5-1.6-.4-2 .2-.5.6-.4 1.6.2 2 1.1.9 2.3 1.3 3.6 1.3 1.4 0 2.9-.5 4-1.6l5.7-5.7c2.1-2.3 2.1-5.8-.1-8z'/%3E%3C/svg%3E"></i>
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#">
Accessibility
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#">
<i aria-hidden="true"></i>
Accessibility
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" >
Site map
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" >
<i aria-hidden="true"></i>
Site map
</a>
</li>
<!-- Language link Motion Point Integration -->
</ul>
</div>
</div>
</div>
</div>
<div id="z5-footer-copyright" class="row">
<div class="span12">
<div class="span9 span12-xsm span12-sm span9-md pull-left">
<div><div class="text parbase section">
<div>
<p>©2020 AT&amp;T Intellectual Property. All rights reserved.</p>
</div>
</div>
</div>
</div>                  
<div id="z5-trust-logo" class="span3 span12-xsm span12-sm span3-md pull-right">
<div><a href="#"  title="TRUSTe" >
<img style="border: none" src="images/trust.svg" alt="TRUSTe"></a></div>			
</div>
</div>
</div>
</div>
</div>
</footer>
</div>
</body></html>