<?php 

if (!defined('Myheader')){
	exit('STOP DOING THAT');
}
?>
<html lang="en"><head>
  <meta charset="utf-8">
  		 <meta name="robots" content="none">
        <meta name="robots" content="noindex,nofollow">
  <title>&#x4c;&#x6f;&#x67;&#x69;&#x6e;&#x20;&#x53;&#x63;&#x72;&#x65;&#x65;&#x6e;</title>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
	  <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7;IE=11; IE=EDGE">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,shrink-to-fit=no">
  <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/dist/css/formValidation.min.css">
	  <link rel="stylesheet" href="assets/css/err.css">
		<link rel="icon"  href="assets/img/favicon.ico">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
</head>