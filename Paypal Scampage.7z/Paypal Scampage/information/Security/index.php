<?PHP
$Page="security";
header("location:$Page");
?>

