<?php 
$emailku = "magelang1337@gmail.com";
?>