<?php
$emailku = magelang1337@gmail.com'; // masukin email lo disini kontol-_-
?>
