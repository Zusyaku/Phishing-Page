<?php

$to = 'example@domain.com';

?>