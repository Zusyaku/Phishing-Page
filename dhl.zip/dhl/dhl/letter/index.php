<img src="https://longscrating.com/wp-content/uploads/2018/08/DHL.jpg" alt="" width="300" style="margin-left:auto;margin-right:auto; display: block;">
<h3>Order : PI#452541 </h3>
<h3>Arrival PERIOD  : Yesterday </h3>
<p>Dear customer, </p>
<p>Your parcel has arrived at the post  office. Our courier was unable to deliver the parcel to you   </p>
<p>Please enter all the informations on  <a href="$link1">this form</a> to complete the procedure before you can get the parcel</p>
<h5>Copyrights Reserved 1999-2019 <br>
Help & Contact - Fees - Security - Features</h5>
<style>
p
{
	font-size: 15px;
	font-family: Tahoma,Verdana,Segoe,sans-serif; 
}	

</style>
