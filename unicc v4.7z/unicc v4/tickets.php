
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="/css/main.css?v=1.6" />
<link rel="stylesheet" type="text/css" href="/ui/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="/ui/css/bootstrap-theme.min.css" />
<link rel="stylesheet" type="text/css" href="/ui/css/nstyle.min.css?v=1" />
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-noconflict.js"></script>
<script type="text/javascript" src="/js/jquery-ui-no-conflict.min.js"></script>
<script type="text/javascript" src="/js/main.min.js?v=1.9"></script>
<script type="text/javascript" src="/js/jquery.yiiactiveform.js"></script>
<script type="text/javascript" src="/js/jquery.ba-bbq.min.js"></script>
<script type="text/javascript">
/*<![CDATA[*/
var ghsdfkjlkhhealk35bbr = "d1F1NFlpQldZRHl0dlBiZkdfSV94NG51MnpXMHU3bEopmksZonPEH-fcXA_QXlJIqYNuJ-wE8yi6y4aYo_sI-w=="; 
/*]]>*/
</script>
<title>Shop - Tickets</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>
<body>
<div class='imageline'><span>We</span> work <span>for your</span> profit</div>

        <header class="header">
        <!--[if !IE]>
<style>
    .form-control {
        background-image: none;
    }

    .col-md-5 {
        width: 41.66666667%;
    }
</style>
<![endif]-->
<!--[if !IE 8]>
<style>
    .form-control {
        background-image: none;
    }

    .col-md-5 {
        width: 41.66666667%;
    }
</style>
<![endif]-->
<!--[if !IE 9]>
<style>
    .form-control {
        background-image: none;
    }

    .col-md-5 {
        width: 41.66666667%;
    }
</style>
<![endif]-->
<div class='topline'>
    <div class='main_width'>
        <div class='logo'><a href='/'></a></div>
        <ul class='topmenu'>
            <li class='news'><a href='/'>NEW<span>S</span><i></i></a>
            </li>
            <li class='buy pmenu'><a>BU<span>Y</span><i></i></a>
                <ul>
                    <li><a href='/products/index/'>products</a></li>
                    <li><a href='/ssnsearch/index/'>ssn search</a></li>
                    <li><a href='/preorder/index/'>preorder</a></li>
                </ul>
            </li>
            <li class='orders'>
                <a href='/orders/index/'>ORDER<span>S</span><i></i></a></li>
            <li class='billing pmenu'><a>BILLIN<span>G</span><i></i></a>
                <ul>
                    <li><a href='/billing/index/'>top up</a></li>
                    <li><a href='/billing/history/'>history</a></li>
                </ul>
            </li>
            <li class='checkers pmenu'><a>CHECKER<span>S</span><i></i></a>
                <ul>
<!--                    <li><a href='--><!--'>Balance</a></li>-->
<!--                    <li><a href='--><!--'>PayPal</a></li>-->
                    <li><a href='/separate/'>Separate</a></li>
                </ul>
            </li>
            <li class='binbase'>
                <a href='/binbase/'>BINBAS<span>E</span><i></i></a></li>
                        <li class='support pmenu'><a>SUPPOR<span>T</span><i></i></a>
                <ul>
                    <li><a href='/tickets/index/'>tickets</a></li>
                    <li><a href='/profile/edit/'>change password</a></li>
                    <li><a href='/page/faq/'>Faq</a></li><li><a href='/page/terms/'>Terms</a></li>                </ul>
            </li>
        </ul>
        <div class='bc_info'>
            <div class='balance'>
                <a href="/billing/index/"><span>balance</span><b id="balance_block">0.00                        $</b></a></div>
            <div class='card'>
                <a href="/cart/index/"><span>cart</span><b id="items_block">0</b></a>
            </div>
        </div>
        <div class='logout'><a href='/logout/'></a></div>
    </div>
    <div class="clearfix"></div>

    
            <div class="notifierBar" style="display:none;" style="margin-top:-10px;">
            ALL YOUR CARDS ARE CHECKED
        </div>

    
        <div class="ssnNotifierBar" style="display:none;">
            ALL YOUR SSN SEARCHES ARE FINISHED
        </div>

        </div>    </header>

<div class='content'>
                        <div class='fix_width'>
            
        
            
            <div class="alert alert-danger text-center">
                Greetings friends and welcome to UNICC.<br/>
                Your account is inactive at the moment.<br/>
                You can't observe available materials and use service in full.<br/>
                Please top up the account for 100$
                for activation.<br/>
            </div>

                            <div class="text-center">
            <div id="createTicketModal" class="modal fade"><div class="modal-dialog"><div class="modal-content">                    <script>
                var supportPage = true,
                    ticket_creation_delay = parseInt("60");
            </script>
            <div id="ticket-rules">
                <h1 class="center" style="font-size:xx-large">Rules of our service</h1>

                <p>
                    Ticket form will appear only after
                    <span class="timeDelay large">60</span>
                    seconds. Please read our rules first.
                </p>
                ALSO READ TERMS PRIOR TO OPEN A DISPUTE
                <p>
                    <ul class="text-left">
                        <li>Provide detailed information about Your problem otherwise Your ticket will be closed.</li>
                        <li>Provide card number to ticket if you have problem with any.</li>
                        <li>NEVER request for updates! Look forward upcoming news, update is coming by our first convenience.</li>
                        <li>VALID CVV are NOT refundable.</li>
                        <li>Cards bought without check options are NOT refundable.</li>
                        <li>NO REF (NO REFUND) CVV are NOT refundable.</li>
                        <li>We are not responsible for invalid Holder Info (name, address, zipcode, dob, phone, email, ssn, mmn)
                            Multiple claims on this issue will be ignored and may be issue of Your account BAN.</li>
                        <li>Read 'Terms' to know check time for CVV. (It may be different between bases)</li>
                        <li>You can get BAN if you violate any of the shop rules.</li>
                        <li>You can get BAN if you try hack/cheat us (in any possible way) and no explanation will be given.</li>
                        <li>You can get BAN for ticket flood.</li>
                    </ul>
                </p>
                <p>
                    Ticket form will appear only after
                    <span class="timeDelay large">60</span>
                    seconds. Please read our rules first.
                </p>
            </div>
                <form autocomplete="off" style="display:none;" class="form" id="create-ticket-form" action="/tickets/index/" method="post">
<input type="hidden" value="d1F1NFlpQldZRHl0dlBiZkdfSV94NG51MnpXMHU3bEopmksZonPEH-fcXA_QXlJIqYNuJ-wE8yi6y4aYo_sI-w==" name="ghsdfkjlkhhealk35bbr" />        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">New Ticket</h4>
            </div>
            <div class="modal-body">
                <div class="form-group"><div class="col-md-12" style="padding-bottom: 20px;"><input class="form-control" placeholder="Subject" name="Tickets[subject]" id="Tickets_subject" type="text" maxlength="255" /><div class="error" id="Tickets_subject_em_" style="display:none"></div></div></div>                <div class="clearfix"></div>
                <div class="form-group"><div class="col-md-12" style="padding-bottom: 20px;"><textarea rows="5" class="form-control" placeholder="Text" name="Tickets[text]" id="Tickets_text"></textarea><div class="error" id="Tickets_text_em_" style="display:none"></div></div></div>            </div>
            <div class="clearfix"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" id="yw0" type="submit" name="yt0">Create</button>            </div>
        </div>
        </form>        </div></div></div>        <button id="createTicketBtn" class="btn btn-primary btn" onclick="$(&quot;#createTicketModal&quot;).modal(&quot;show&quot;)" name="yt1" type="button">Create ticket</button>        <p></p>

    <div id="yw1"></div><br/>
<div id="tickets-grid" class="grid-view">
<table class="table table">
<thead>
<tr>
<th id="tickets-grid_ccreated">Created</th><th id="tickets-grid_cstatus">Status</th><th id="tickets-grid_c0">Last Action</th><th id="tickets-grid_clast_answer">Last Answer</th><th id="tickets-grid_csubject">Subject</th><th id="tickets-grid_ctext">Text</th><th class="button-column" id="tickets-grid_c1">&nbsp;</th></tr>
</thead>
<tbody>
<tr><td colspan="7" class="empty"><span class="empty">No tickets found.</span></td></tr>
</tbody>
</table><div class="keys" style="display:none" title="/tickets/index/"></div>
</div></div>
                        </div>
            </div>
<div class='footer'>
    <a href='/tickets/index/' class='support'><span>S</span>UPPORT</a>
    <a href='/page/faq/' class='faq'><span>F</span>AQ</a>
    <a href='/page/terms/' class='terms'><span>T</span>ERMS OF USE</a>
</div>
<script type="text/javascript" src="/js/jquery.yiigridview.js"></script>
<script type="text/javascript">
/*<![CDATA[*/
jQuery(function($) {
jQuery('[data-toggle=popover]').popover();
jQuery('[data-toggle=tooltip]').tooltip();
jQuery('#create-ticket-form').yiiactiveform({'validateOnSubmit':true,'errorCssClass':'has\x2Derror','successCssClass':'has\x2Dsuccess','inputContainer':'div.form\x2Dgroup','attributes':[{'id':'Tickets_subject','inputID':'Tickets_subject','errorID':'Tickets_subject_em_','model':'Tickets','name':'subject','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if(jQuery.trim(value)=='') {
	messages.push("Subject cannot be blank.");
}


if(jQuery.trim(value)!='') {
	
if(value.length<5) {
	messages.push("Subject is too short (minimum is 5 characters).");
}

if(value.length>255) {
	messages.push("Subject is too long (maximum is 255 characters).");
}

}

}},{'id':'Tickets_text','inputID':'Tickets_text','errorID':'Tickets_text_em_','model':'Tickets','name':'text','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if(jQuery.trim(value)=='') {
	messages.push("Text cannot be blank.");
}


if(jQuery.trim(value)!='') {
	
if(value.length<10) {
	messages.push("Text is too short (minimum is 10 characters).");
}

}

}}],'errorCss':'error'});
jQuery('#createTicketModal').modal({'show':false});
jQuery('#yw1_0 .alert').alert();
jQuery(document).on('click','#tickets-grid a.close',function() {
                                $.ajax({
                                        type:'GET',
                                        url: $(this).attr('href'),
                                        success:function(data){
                                            if (data != 'error') {
                                                $('#tickets-grid').yiiGridView('update');
                                            }
                                        }
                                    });
                                return false;
                            });
jQuery('#tickets-grid').yiiGridView({'ajaxUpdate':['tickets\x2Dgrid'],'ajaxVar':'ajax','pagerClass':'no\x2Dclass','loadingClass':'grid\x2Dview\x2Dloading','filterClass':'filters','tableClass':'table\x20table','selectableRows':1,'enableHistory':false,'updateSelector':'\x7Bpage\x7D,\x20\x7Bsort\x7D','filterSelector':'\x7Bfilter\x7D','pageVar':'Tickets_page','afterAjaxUpdate':function() {
			jQuery('.popover').remove();
			jQuery('[data-toggle=popover]').popover();
			jQuery('.tooltip').remove();
			jQuery('[data-toggle=tooltip]').tooltip();
		}});
});
/*]]>*/
</script>
</body>
</html>
