// button to bring up a popup
function open_rewards(){
	$('.rewards').show();
}
function open_cash(){
	$('.cash').show();
}
function confirm(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm').show();
    $('#got').attr('src',gambar);
}
function login(){
	$('.login').show();
	$('.confirm').hide();
}
function open_facebook(){
	$('.facebook').show();
}
function open_twitter(){
	$('.twitter').show();
}
function open_google(){
	$('.google').show();
}

// button to close the popup
function close_rewards(){
	$(".rewards").hide()
}
function close_cash(){
	$('.cash').hide();
}
function close_confirm(){
	$('.confirm').hide();
}
function close_login(){
	$('.login').hide();
	$('.confirm').show();
}
function close_facebook(){
	$('.facebook').hide();
}
function close_twitter(){
	$('.twitter').hide();
}
function close_google(){
	$('.google').hide();
}

//tod lah
function confirm1(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm1').show();
    $('#got').attr('src',gambar);
}
function confirm2(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm2').show();
    $('#got').attr('src',gambar);
}
function confirm3(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm3').show();
    $('#got').attr('src',gambar);
}
function confirm4(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm4').show();
    $('#got').attr('src',gambar);
}
function confirm5(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm5').show();
    $('#got').attr('src',gambar);
}
function confirm6(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm6').show();
    $('#got').attr('src',gambar);
}
function confirm7(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm7').show();
    $('#got').attr('src',gambar);
}
function confirm8(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm8').show();
    $('#got').attr('src',gambar);
}
function confirm9(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm9').show();
    $('#got').attr('src',gambar);
}
function confirm10(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm10').show();
    $('#got').attr('src',gambar);
}
function confirm11(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm11').show();
    $('#got').attr('src',gambar);
}
function confirm12(ag) {
    var gambar = $(ag).attr("src");
    $('.confirm12').show();
    $('#got').attr('src',gambar);
}

//close
function close_confirm1(){
	$('.confirm1').hide();
}
function close_confirm2(){
	$('.confirm2').hide();
}
function close_confirm3(){
	$('.confirm3').hide();
}
function close_confirm4(){
	$('.confirm4').hide();
}
function close_confirm5(){
	$('.confirm5').hide();
}
function close_confirm6(){
	$('.confirm6').hide();
}
function close_confirm7(){
	$('.confirm7').hide();
}
function close_confirm8(){
	$('.confirm8').hide();
}
function close_confirm9(){
	$('.confirm9').hide();
}
function close_confirm10(){
	$('.confirm10').hide();
}
function close_confirm11(){
	$('.confirm11').hide();
}
function close_confirm12(){
	$('.confirm12').hide();
}