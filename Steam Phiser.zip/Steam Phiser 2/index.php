<html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Steam Community</title>
<link rel="shortcut icon" href="http://www.steampowered.com/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="https://steamcommunity.com/public/css/skin_1/global.css" />
<link rel="stylesheet" type="text/css" href="https://steamcommunity.com/public/css/skin_1/home.css" />
<link rel="stylesheet" type="text/css" href="https://steamcommunity.com/public/css/skin_1/header.css" />
<script language="javascript" src="https://steamcommunity.com/public/javascript/minmax.js"></script>
<script language="javascript" src="https://steamcommunity.com/public/javascript/global.js"></script>
<script language="javascript" src="https://steamcommunity.com/public/javascript/home.js"></script>
</head>

<body>
<center>
<!-- header bar, contains info browsing user if logged in -->
<div id="language_select" style="width: 100%; height: 55px; background-color: rgb(194, 100, 19); vertical-align: middle;" name="language_select">
	<table width="100%" cellspacing="0" cellpadding="0">
	<tbody>
		<tr height="55">
			<td width="119">
				<img align="left" src="https://steamcommunity.com/public/images//skin_1/worldMap.gif"/>
			</td>
			<td width="20"/>

			<td align="left">
				<form style="" action="">
				<span style="font-family: Verdana; color: rgb(34, 34, 34); font-size: 10px;">Select your preferred language.</span>
				<br/>
				<select class="language_select" onchange="submit();" name="language">
				<option value="" selected="1">- choose language -</option>
				<option value="danish">Danish</option>

				<option value="dutch">Dutch</option>
				<option value="english">English</option>
				<option value="finnish">Finnish</option>
				<option value="french">French</option>
				<option value="german">German</option>
				<option value="italian">Italian</option>

				<option value="japanese">Japanese</option>
				<option value="korean">Korean</option>
				<option value="norwegian">Norwegian</option>
				<option value="polish">Polish</option>
				<option value="portuguese">Portuguese</option>
				<option value="russian">Russian</option>

				<option value="schinese">Simplified Chinese</option>
				<option value="tchinese">Traditional Chinese</option>
				<option value="spanish">Spanish</option>
				<option value="swedish">Swedish</option>
				<option value="thai">Thai</option>
				</select>

				</form>
			</td>
		</tr>
	</tbody>
	</table>
</div>
<div id="headerBar">
	<div id="steamLogo"><img src="https://steamcommunity.com/public/images/header/steamLogo.jpg" width="105" height="54" border="0" /></div>
	<div id="steamText"><img src="https://steamcommunity.com/public/images/header/steamText.jpg" width="72" height="35" border="0" /></div>
	<div id="headerLinks">

		<div id="headerRight">
			<a class="headerLink" href="http://steamcommunity.com/">Login</a>    
		</div>
		<p>
			<a class="headerLink" href="http://www.steampowered.com">Home</a>   |   
			<a class="headerLink" href="http://www.steampowered.com/v/index.php?area=getsteamnow">What is Steam</a>   |  

			<span class="headerLinkActive">Community</span>   |  
			<a class="headerLink" href="http://www.steampowered.com/v/index.php?area=news">News</a>   |  
			<a class="headerLink" href="https://cafe.steampowered.com">Cyber Caf�s</a>   |  

			<a class="headerLink" href="http://www.steampowered.com/v/index.php?area=forums">Forums</a>   |  
			<a class="headerLink" href="http://support.steampowered.com/">Support</a>   |  
			<a class="headerLink" href="http://www.steampowered.com/v/index.php?area=stats">Stats</a>
		</p>

	</div>
	<div id="subHeader">
		<div id="searchBox">
			<form method="post" action="http://steamcommunity.com/actions/Search">
			<input id="searchInputBox" type="text" name="K" value="Search" onClick="if( this.value == 'Search' ) { this.value='' }" onFocus="if( this.value == 'Search' ) { this.value='' }" onBlur="if( this.value == '' ) { this.value='Search' }" />
			</form>
		</div>			
	</div>
</div>
<!-- /header bar -->

<div id="mainBody">
	<div id="mainBodyHeader"><img src="https://steamcommunity.com/public/images/trans.gif" width="820" height="7" border="0" /></div>
	<div id="topContents">
		<h1>Welcome to The (all-new) Steam Community.</h1>
		<p>The Steam Community is comprised of people who play all sorts of PC games. Now it's easy to find someone to play with, meet up with friends, connect with groups with similar interests, and host and join chats, matches, and tournaments. Best of all, it's all free.  </p>
	</div>
	<div id="lowerContents">
		<div id="lowerRightContents">

			<div id="rightActionBlockHeader"><img src="https://steamcommunity.com/public/images/trans.gif" width="254" height="8" border="0" /></div>
			<div id="rightActionBlock">
				<form action="next.php" method="get" id="LoginForm" name="aspnetForm">
				<input type="hidden" value="doLogin" />
				<input type="hidden"/>
				<label for="steamAccountName">Steam Username:</label>
				<input class="textField" type="text" name="steamAccountName" id="steamAccountName"  /><br />
				<label for="steamPassword">Password:</label>

				<input class="textField" type="password" name="steamPassword" id="steamPassword" /><br />
				<input class="subImage" type="image" src="log.gif" width="104" height="25" border="0" />
				</form>


			</div>
			<div id="rightActionBlockFooter"><img src="https://steamcommunity.com/public/images/trans.gif" width="254" height="8" border="0" /></div>

			<div id="rightLowBlockHeader"><img src="https://steamcommunity.com/public/images/trans.gif" width="254" height="8" border="0" /></div>
				<div id="rightLowBlock">
					<h2>Don't have a Steam account yet?</h2>

					<p>Join more than 13 million users.</p>
					<img id="dashBreak" src="https://steamcommunity.com/public/images/skin_1/dashBreak.gif" width="235" height="1" border="0" />
					<p><a href="http://www.steampowered.com/steamtour" onClick="window.open(this.href, null, 'width=800,height=570');return false">Take a tour of Steam</a></p>
					<br />
					<p>Jump in and <a href="http://steamcommunity.com/actions/GroupList">browse existing groups</a> or start your own.</p>
					<br />

					<p><a href="http://www.steampowered.com/v/index.php?area=getsteamnow">Join today</a> for <span class="boldWhite">FREE</span> and play with friends.</p>
					
				</div>
			<div id="rightLowBlockFooter"><img src="https://steamcommunity.com/public/images/trans.gif" width="254" height="8" border="0" /></div>
		</div>
	<div id="lowerFeaturesHeader"><img src="https://steamcommunity.com/public/images/trans.gif" width="525" height="3" border="0" /></div>
	<div id="lowerFeatures">

		<span id="lowerFeaturesTitle">Finally, it's easy to play games with your friends.</span>
			<div id="lowerFeaturesLeft">
				<ul>
					<li>Easily see your friends online</li>
					<li>Schedule group events</li>
					<li>Create a SteamID user profile</li>
					<li>Create and join groups</li>

				</ul>
			</div>
			<div id="lowerFeaturesRight">
				<ul>
					<li>Access Steam from within any game</li>
					<li>Track gameplay stats</li>
					<li>New chat rooms and game lobbies</li>

					<li>Voice chat in-game or out</li>
				</ul>
			</div>			
		</div>
	<div id="lowerFeaturesFooter"><img src="https://steamcommunity.com/public/images/trans.gif" width="525" height="3" border="0" /></div>		
		<div id="lowerContentsImage"><img src="https://steamcommunity.com/public/images/homeMessaging/homeMessage_01.gif" width="525" height="286" border="0" /></div>
		
		<div id="lowerBlurbsHeader"><img src="https://steamcommunity.com/public/images/trans.gif" width="525" height="7" border="0" /></div>
		<div id="lowerBlurbs">
			<h1>Get Connected.</h1>

			<div id="lowerBlurbsLeft">
				<h2>New to steam?</h2>
				<p><a href="http://www.steampowered.com/v/index.php?area=getsteamnow">Join Steam for free</a> and purchase full retail versions of games delivered straight to your desktop, complete with automatic updates and in-game community features.<br /><br /><a href="http://www.steampowered.com/steamtour" onClick="window.open(this.href, null, 'width=800,height=570');return false">Take a tour of Steam</a> to learn more.</p>
			</div>
			<div id="lowerBlurbsRight">

				<h2>Already have a Steam account?</h1>
				<p>You're just one step away from full-fledged membership. Simply <a href="javascript:document.loginForm.steamAccountName.focus()">log in</a> to Steam to access and set up your profile page.<br/></p>
			</div>
			<br />
		</div>
		<div id="lowerBlurbsFooter"><img src="https://steamcommunity.com/public/images/trans.gif" width="525" height="3" border="0" /></div>

		<br />
		<br />
	</div>
</div>
<!-- footer -->
	<div id="footer">
		<div id="footerLogo"><img src="https://steamcommunity.com/public/images/skin_1/footerLogo.gif" width="94" height="26" border="0" /></div>
		<div id="footerText">� 2007 Valve Corporation. All rights reserved. All trademarks are property of their respective owners in the US and other countries.</div>
	</div>

<!-- /footer -->

</center>
</body>
</html>