<?php
ini_set( "display_errors", 0); 
$datei = fopen("admin/vendor/visit/visitor.txt","r");
$count = fgets($datei,1000);
fclose($datei);
$count=$count + 1 ;

$datei = fopen("admin/vendor/visit/visitor.txt","w");
fwrite($datei, $count);
fclose($datei);

?>
