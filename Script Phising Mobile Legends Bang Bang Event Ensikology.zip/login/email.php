<?php
$emailku = 'ensikology@gmail.com';
?>